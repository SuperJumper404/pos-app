# Delivery V1 Local Acceptance

DRAFT pending controller frontend freeze, final frontend validation/evidence and independent reviews. This records software preparation on disposable fixtures. It is not authorization or proof of live activation, supplier receipt, deployment or production data readiness.

## Tested Sources

Initial paired bases: frontend 9d8efd9b5662ff8eb6f60035bf20df14f4fe83d5; backend b63e38ea385ede2f85be2dd6774c552abe36b732. Final tested paired commits and exact command status must replace this pending paragraph after validation. Backend owned working-content hashes and actual native logs are in task-17-report.md; frontend remains controller-owned until freeze.

## Actual HTTP And SQL Journeys

The new registered backend journey test executes actual Express routing declarations, authentication/current-account middleware, controllers, business services, transactions and disposable MySQL8.0.33. Installed provider SDKs/production transports execute against HTTP boundary doubles. No business/payment/authorization service is replaced with a success stub.

1. Guest website checkout accepts the authoritative 2600-cent products plus400-cent fee. A locally signed webhook reconciles the actual Stripe payment/stock producer. Payment leaves kitchen preparation unfinished. Actual preparation transitions and archive precede courier pickup/delivery. The durable dossier and anonymous tracking remain usable after archive; the public projection omits private instructions.
2. A fictional WhatsApp login is verified through actual challenge/session SQL and the production transport HTTP double. A saved address is renewed through the customer API and attached to a POS delivery. The original courier collects3000 cents cash. A later2800-cent physical remittance leaves200 cents due. A forbidden origin is refused; staff/client sessions retain their separate authority. An email challenge/verification also exercises its production adapter through the local HTTP double.
3. One courier picks up two ready orders before either concludes. One is manually paid on an independent TPE; the other is cash-paid, reports an issue and is physically returned by restaurant decision. A deactivated courier's attempted collection is refused without a collection row. Issue/return creates zero refunds. The restaurant explicitly confirms full original-courier and independent-card refunds; courier self-refund is refused. The original-source cash return reduces only the still-held source; external-card refund remains a restaurant declaration, providerVerified=false, with no cash movement.

R5 crosses the repeated Europe/Paris02:30 hour using distinct UTC00:30/01:30 instants. The first actual Z contains four sales/120 euros. A later register refund returns the full3000 cents after that closure and leaves the original courier's200-cent debt intact. The later period contains zero orders/revenue/VAT,2800-cent physical receipt and3000-cent register outflow. Prior persisted Z and original sale/VAT/detail/stock rows remain byte-for-byte unchanged. Same-key business and checkout replays add no sales, dossier, stock, remittance or refund. The original courier's replay after unassignment is correctly404 because current authority precedes replay. A replayed archived Stripe checkout returns409 without another provider intent.

The Task2 deferred signer issue is addressed by a lazy operation-boundary preflight: missing/short signer configuration now refuses before any geocoder call. RED observed one supplier call; GREEN observed zero. Loading legacy/disabled routers without the secret remains valid.

## Commands And Limits

Set ENV_FILE=NUL and the explicit local disposable DELIVERY_TEST_DATABASE_URL independently before every SQL command. The harness creates/drops only random smarteat_delivery_test_<nonce> schemas, never the supplied catalog or application database. Full final native exits are propagated and embedded in retained logs. Do not substitute historical prefix/suffix evidence for a successful complete command.

Actual backend PowerShell setup, repeated independently before each command in the backend worktree (the password below is solely the authorized disposable fixture):

```powershell
$env:ENV_FILE = 'NUL'
$env:DELIVERY_TEST_DATABASE_URL = 'mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:JWTKEY = 'delivery-task17-disposable-jwt'
$env:PUBLICIMAGEPATH = "$env:TEMP/task17-disposable-images"
Remove-Item Env:TASK4_TEST_FILTER,Env:TASK5_REVIEW_FILTER,Env:TASK7_FILTER,Env:TASK7_REFUND_FILTER -ErrorAction SilentlyContinue
```

Commands actually invoked after that setup: `npm.cmd test`, `npm.cmd run test:delivery:db`, `node test/delivery-journey.integration.test.js`, `node test/delivery-runtime.integration.test.js`; the narrowed signer/legacy assertion files also ran directly. Every logged command captures `$nativeExit=$LASTEXITCODE`, appends its value and exits with that value. Focused convenience scripts are `test:delivery:journey` and `test:delivery:runtime`; do not interpret their existence as an additional invocation.

| Gate | Current Result |
| --- | --- |
| Backend npm.cmd test | Corrected final whole command native0, ALL66 files in ONE invocation; initial native1 retained |
| Backend unexecuted suffix continuation | Native0, remaining30/30 files pass separately; not whole npm green |
| Backend npm.cmd run test:delivery:db | Pending running17 registered files including final journey revision |
| node test/delivery-journey.integration.test.js | Native0 before final checkout-replay strengthening; final revision covered by registered SQL command |
| node test/delivery-runtime.integration.test.js | Native0: actual node:20-alpine whole application/listener/API, Node20.20.2/MySQL8.0.33, no Nano ID bridge |
| Frontend npm.cmd test / npm.cmd run lint / npm.cmd run build-local | Pending controller freeze and safe build coordination |

The runtime copies only positive-allowlisted tracked JS/SQL/package/index files into an ephemeral container, with no mounts, env files, uploads, .git or host node_modules. Linux npm ci uses the existing lockfile. Actual index.js waits for its disposable database, listens and serves authenticated disabled-delivery availability and absent-channel booleans without provider/delivery secrets. It uses the already-migrated disposable helper schema, not a production compose/empty-database rollout. Its temporary container, context and schema are removed. Existing local servers/MySQL fixture/Docker context remain intact.

Raw failures remain evidence: fixture preparation transition/COUNT type/current-owner replay corrections, the HTTP double's missing secureConnect lifecycle and explicitly stopped hung child native-1, and an initial runtime-port race native1. The corrected double now supports fresh/kept-alive sockets and bounded requests. These are harness limitations/corrections, not production payment fixes or real TLS verification. Runtime npm audit reported47 inherited dependency findings; dependencies were not upgraded.

Earlier tasks retain their original exact test revisions, composite prefix/suffix results, missing embedded-native-marker qualifications and Node18 actual-dependency import-cache bridge limits. Those bridge runs do not prove unbridged production Node18 boot. Current configured Node20 whole-app evidence is separate. Preserve ALL ledger Rulings, reasons/costs and final deferred dispositions in delivery-v1-decisions.md before scratch cleanup.

## Browser And Documents

Controller supplies actual screenshot paths, viewport/state outcomes, the single detector output, UI fix commit and retained PDF/raster paths/hashes. Its first fixture JWT2036 overflowed the browser timer and was replaced with a one-hour fixture; intercepted Vuetify selection clicks were corrected in the harness. These are not product fixes. Initial detector:29 changed Vue files, native0, primary0, advisory79 (35font/41color/3radius), no rerun. Final contextual triage and browser state outcomes remain pending. Route-double browser fixtures and emulated viewports are distinct from actual-router SQL journeys and physical-device acceptance. No phone/maps/OS clipboard, real payment, cloud/physical print or provider-send action is performed.

Task15 produced actual fictional paid/refunded PDFs with the existing receipt generator; both final raster PNGs were visually inspected and independently bound to hashes. Retain these accepted artifacts and the controller's final paths; do not describe a renderer/version/text-only check as PDF visual QA.

## Commissioning Prerequisites

Both real email receipt/verification and real WhatsApp receipt/verification are NOT EXECUTED by the user's explicit instruction to prepare without sends. Configured channel booleans, provider HTTP acknowledgements/doubles and public documentation do not prove end-user receipt. No recipients, credentials or real sends are requested during preparation. No SMS or delivery-progress notifications are added. Any real financial-provider transaction/refund, physical/cloud printing, remote migration, staging/production deployment, push or merge is NOT EXECUTED and requires its own authorization.

Before enabling a restaurant, operations must:

1. Review/apply additive migrations through an approved rollout, retain compatible fee-aware frontend/backend versions, and back up/validate the actual environment separately. No remote migration is run by this acceptance.
2. Prove same-connection UTC SQL readiness for new delivery activation/financial periods. Audit and reconcile the historical basis of naive financial DATETIME cutoffs/archive timestamps through an approved procedure. Current UTC does not prove old records were UTC. Never automatically SET time_zone, convert history or rewrite stored snapshots. Missing/disabled delivery with no persisted financial history retains ordinary session-time Z behavior; any accepted cash/external-card/remittance/correction/refund history retains the UTC requirement even after suspension/settlement.
3. Configure server-only independent CUSTOMER_AUTH_SECRET and DELIVERY_TOKEN_SECRET plus explicit allowed origins/trusted proxies; keep provider secrets/identifiers out of Nuxt, browser state, logs and commits. Multiple OTP instances require the same SQL quota store AND auth secret. Actual TLS/proxy/origin/cookie Secure/SameSite behavior must be verified in the deployment topology; arbitrary third-party storefront domains are not assumed compatible.
4. Validate central Mailjet sender and Meta business permissions/phone/template/language and a configured supported Graph version. In later authorized commissioning, receive and verify codes on BOTH channels using consented test destinations. An approved authentication template uses the same OTP in body and copy-code button. Do not treat supplier acceptance as receipt.
5. Validate aggregate IGN egress quota: the40-per-second conservative shared budget coordinates one SQL store, not independent staging/production databases sharing an IP. Coordinate the aggregate budget before activation. Private entry instructions must never leave for geocoding. Earlier live IGN evidence covers only the documented public-address cases, not customer destinations or full coverage.
6. Configure/verify an upstream shared tracking limiter. The local30/IP/60s limiter has10000 live buckets and fail-closed saturation, but is process-local and reset/multi-worker budgets are not guaranteed. Tokens expire at the earliest stored/created+30d/current or immutable correction closure+7d ceiling. Rotation replay returns no raw URL; lost-response recovery requires a separate explicit renewal.
7. Audit/handle any outstanding historically issued legacy role-changing activation links under current active-admin authority. Current registration/first-admin bootstrap is direct/active and the in-repo legacy token creator/mailer is commented; this does not prove compatibility for old issued links. No production tokens/data were inspected here.
8. Configure each restaurant's verified origin, radius, complete fee bands, minimum/free threshold and explicit fiscal rate/policy before activation. Delivery is disabled by default. No discussed/example price or fiscal rate becomes production configuration automatically.

## Suspension And Recovery

An authorized restaurant administrator suspends new deliveries through the existing settings update with the current revision and enabled=false. Reload the authoritative settings after conflict. Suspension blocks new acceptance without erasing dossiers, accepted fee/address snapshots, engaged payment reconciliation, pickup/delivery, explicit incident/refund resolution, remittances or remaining debt. Keep a compatible fee-aware application running to complete those operations.

For an unavailable/deactivated courier, the restaurant retains missions/debt and explicitly resolves/reassigns physical custody through the existing issue workflow; no account deletion, debt transfer, automatic refund/restock or silent offline success is introduced. Count actual cash and record the actual handover; shortages remain due until an authorized source-linked, reasoned correction. Full manual refunds remain explicit restaurant confirmations with physical return source; independent TPE declarations are not Stripe confirmation.

A rollback begins by suspending new deliveries. Preserve new tables/journals and old immutable closures. Never roll back to code that charges or refunds an engaged order while ignoring its accepted delivery fee. Restore/roll forward only through an approved operations procedure after reconciling in-flight missions/payments/custody. This document does not execute deployment, destructive migration or data restoration.
