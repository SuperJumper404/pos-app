const { createRequire } = require('module');
const { pathToFileURL } = require('url');
(async () => {
  const testPath = process.argv[2];
  const fromTest = createRequire(testPath);
  const nanoidPath = fromTest.resolve('nanoid');
  require.cache[nanoidPath] = { exports: await import(pathToFileURL(nanoidPath).href) };
  fromTest(testPath);
})().catch(error => { console.error(error); process.exitCode = 1; });
