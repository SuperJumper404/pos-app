# Task 1 independent spec and quality review

Reviewed range: `9bd0a1e..1058086`, using the supplied review package.
Backend: `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos`.

Spec Compliance: **issues**.
Task quality: **Needs fixes**.

## Findings

Critical: none identified.

### Important: remove the second mutable payment state

- Location: `db/migrations/20261016120000_delivery_foundation.sql:74`.
- Evidence: `deliveries.payment_status` is an ordinary writable `varchar(32) NOT NULL DEFAULT 'unpaid'`. It is neither a generated projection nor an immutable, dated payment snapshot. The migration contains no restriction freezing this field or tying it to the authoritative payment state. The append-only charge and journal tables demonstrate a different, explicit snapshot design.
- Requirement: backend plan Task 4 Interfaces, line 93, states: "Le paiement demeure dans la commande active/archivee et les paiements existants ; aucun second etat paye mutable dans `deliveries`." Specification section 7, line 224, also makes dossier financial state a projection of the active/archived order and corresponding payments. Section 9, line 284, explicitly includes retained preparation information in `deliveries`, but does not prescribe a payment snapshot there.
- Effect: the persistence contract permits a dossier to say `unpaid` independently of an already paid order, or retain `paid` independently of a later refund. No live service divergence is asserted in this Task 1 review; the schema itself introduces the expressly prohibited second mutable state. Nothing in this implementation establishes a legitimate immutable snapshot interpretation.
- Fix: remove this column from the foundation schema. Produce the API `paymentStatus` from the authoritative active/archive and payment records in its planned integration task. Retain the preparation snapshot, which has a distinct approved purpose. Validate the corrected schema with the focused SQL gate; this finding does not request implementation of later-task services.

Minor: none identified requiring a separate fix.

## Strengths

- Tenant ownership is encoded in composite foreign keys; historical signed INT identifiers remain unchanged, while new SQL identities and references use BIGINT UNSIGNED. The helper enables BIGINT string handling and the test round-trips `9007199254740993` exactly. No new identifier is cast to Number; the helper's Number conversion is for the connection port.
- Money columns constrain cents to the safe integer range, preserve signed adjustment/discrepancy semantics, and check charge and remittance arithmetic.
- Existing shops receive disabled settings; the default also remains disabled. No example delivery fee or implicit VAT rate is activated.
- Legacy rows are inserted before the new migration. Their delivery/customer links remain empty and their dine-in/takeaway meaning and amounts survive migration and rollback/reapply.
- The order/archive foreign keys point toward the durable dossier, with separate unique representation links and no cascade deleting the dossier. Tests cover archive transfer under a dossier lock and survival after deleting both commercial representations.
- Financial records and accepted charge revisions have explicit UPDATE/DELETE rejection triggers. Remittances represent physical money movements in separate tables and do not introduce a second sale or payment insertion path in this scope.
- The helper requires explicit local DELIVERY_TEST_DATABASE_URL, ignores its supplied database pathname, uses a random generated database, tracks successful creation, and drops only its generated owned name in cleanup. It does not load application environment files.

## Independent evaluation of implementation decisions

### Technical allocation counters: justified

`courier_cash_allocation_totals` is a small implementation addition, not an extra commercial ledger. Its source foreign keys, one-source constraint, unique source keys and bounded integer cents support the stated purpose. The BEFORE INSERT trigger takes current locking reads of the collection and remittance, validates cash/courier ownership, and locks both derived totals before checking both caps. This serializes inserts sharing either source even with an older REPEATABLE READ snapshot. The AFTER INSERT trigger updates totals only for rows actually inserted, so ignored duplicates do not inflate counters. Allocation UPDATE/DELETE is prohibited and failed statements roll back transactional counter work.

The supplied SQL tests cover competing collection allocations with an old snapshot, both cap boundaries, duplicate rollback and INSERT IGNORE stability. The design avoids reading a trigger's own target table with a locking aggregate and preserves immutable journal entries. Ordinary transaction deadlock retries remain a caller responsibility. No defect was identified in this allocation insertion path; direct arbitrary writes to the technical totals are outside its intended maintenance contract.

### Historical bootstrap exceptions: justified for the current files

- The initial schema already defines `shop.kitchen_closed` (line 137), and `20260518120000_add_kitchen_closed_to_shop.sql:3` only adds that same column in its up section. Skipping that known duplicate when present preserves the expected baseline.
- `20260724120000_customization_steps_v2.sql:22` already defines `default_extra_price`; `20260729161000_customization_choice_default_price.sql:3` adds it again, then performs the historical data backfill at line 7. The helper omits only the first ALTER and still runs that backfill. Its first-semicolon slicing matches this specific migration's actual statements.
- These exceptions are narrowly named, run only in the disposable bootstrap, and do not alter production migration history. They do not establish that unmodified historical migrations replay cleanly on an empty database; that pre-existing limitation is accurately scoped separately from this foundation migration.

## File-by-file brief coverage

| File | Coverage and assessment |
| --- | --- |
| `db/migrations/20261016120000_delivery_foundation.sql` | Settings, ordered unique band boundaries, durable dossiers, nullable order/archive/customer links, courier availability, charge revisions, idempotent events/collections/remittances/adjustments, shared rate limits, tenant/type constraints, capped allocations and inverse migration are present. Customer tables/FKs are correctly deferred to Task 8. Important payment-state finding prevents approval. |
| `test/helpers/deliveryDatabase.js` | Explicit isolated connection, random owned schema, real historical bootstrap, pre-delivery seeding hook, literal legacy/new fixtures, BIGINT strings, up/down support and nested-finally cleanup meet the helper contract. Both historical accommodations are supported by the focused checks above. |
| `test/delivery-schema.integration.test.js` | Covers pre-migration legacy data, disabled backfill, uniqueness and tenant FKs, archive/deletion durability, up/down/up, exact large ID, UTF8MB4, optimistic version predicate, money bounds, activation guard, idempotency, immutable journals, allocation concurrency/duplicates, adjustment sources and shared counters. It does not catch the prohibited mutable payment column. |
| `package.json:8` | Adds explicit `test:delivery:db` pointing to this SQL test. Supplied diff preserves the existing test command and adds no dependency. |

## Evidence and bounded review log

- Read `task-1-brief.md`, `task-1-report.md` and the supplied 49 KB `task-1-review.diff` once. No git command was run. Tool output cut off the middle of the diff: recovered only the necessary migration tail (315-392), test opening (1-52), and package script line, without rereading whole changed files.
- Concrete risk: competing payment authority versus legitimate snapshot. Consulted relevant specification passages, including sections 7 and 9, and exact Task 4 Interfaces; made one focused schema lookup to anchor `payment_status` at line 74. Section 9 was recovered as a small excerpt after tool output truncation. Finding recorded above.
- Concrete risk: historical FK type/signedness mismatch. One focused search of the initial schema and original payments migration confirms signed INT shop/user/order/payment identities and tenant columns, consistent with this migration.
- Concrete risk: bootstrap exceptions silently skipping necessary historical work. Inspected the two named duplicate migrations and focused predecessor declarations; confirmed the kitchen ALTER is the only skipped up operation and the default-price UPDATE remains executed. Migration filenames were listed to locate predecessor files; no unrelated source exploration followed.
- Consulted only the main plan's relevant identifier/money and disposable helper contracts to resolve their precise boundaries. No later-task application service was inspected.
- `workspace_fs` was unavailable; shell reads were used. No subagent, suite rerun, focused reproducer, provider access, application environment/secret access, application database mutation, code edit, index operation or branch operation occurred. The only write is this requested review file through apply_patch.
- Implementation report evidence, reviewed but not rerun: genuine missing-schema RED, final SQL suite GREEN on MySQL 8.0.33, existing backend suite GREEN, syntax checks, actual dbmate up/down/up, refusal/cleanup checks and zero leftover generated schemas. These are supplied execution evidence, not independent executions by this reviewer.
- Additional controller evidence received during review: `npm exec --offline --yes --package=node@18.20.8 -- node test/delivery-schema.integration.test.js` against dedicated MySQL 8.0.33 passed both named SQL scenarios, including up/down/up, exit 0; information_schema then contained zero `smarteat_delivery_test_*` schemas. This resolves the report's actual Node 18 SQL runtime concern. No code changed for that validation.

Final gate: **Spec Compliance: issues; Task quality: Needs fixes**, solely for the mutable payment state identified above. No additional Critical or Minor findings were identified within Task 1.
