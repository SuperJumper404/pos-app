# Task 13 Author Implementation Report

Status: COMPLETE for the authorized implementation and author self-review. Ready for the controller's independent intermediate code gate. This is not controller approval or visual acceptance. Task17 desktop/mobile four-view/conflict acceptance remains explicitly PENDING, in the controller's single visual-qa-matrix batch. No Task14+ implementation, browser inspection, detector, reviewer or subagent was run.

## Compatible Pair And Scope

| Repository | Exact BASE | Task13 Commit |
| --- | --- | --- |
| F | `3dad991babd4cd966089aecaeead67bdb580040e` | `5bae7b2b0a24d677449fea9ef4129536ed1f3a04` |
| B | `6dfdc2cdc48ea47fd50940887f8d2580dddad5c8` | `b16d97cae4cb2eabb27512ac4c9c543b57c1570d` |

F = `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app`; B = its sibling `express-pos`. Scratch is F `.superpowers/sdd/2026-10-16-delivery-management`. The existing amended task-13-brief.md was read FIRST and was neither regenerated nor modified. Worker context, common contracts, applicable operations/cash/settings/roles spec sections, Task2 actual settings, final Task5/6/7 interface amendments and Task12 store/transport/recovery consumers were read. No wholesale prior-task log/history reread. `workspace_fs` denied this external worktree; shell reads used the worker-context fallback. No extra production/test ownership was needed or taken.

F commit: `feat: add delivery operations workspace`, exactly 13 files, 1184 insertions/25 deletions:

- `pages/livraison/index.vue`
- `components/delivery/DeliveryDispatch.vue`
- `components/delivery/DeliveryCouriers.vue`
- `components/delivery/DeliveryCashRemittances.vue`
- `components/delivery/DeliverySettings.vue`
- `middleware/delivery.js`
- `test/delivery-operator.test.js`
- `helpers/staffRoles.js`
- `layouts/default.vue`
- `pages/staff/index.vue`
- `store/staff.js`
- `store/delivery.js`
- `package.json`

B commit: `feat: correct delivery terminal mistakes`, exactly 5 files, 349 insertions/13 deletions:

- `src/modules/m_deliveryDispatch.js`
- `src/controllers/c_delivery.js`
- `src/routers/r_delivery.js`
- `test/delivery-terminal-corrections.integration.test.js`
- `package.json`

Both commits used explicit file staging after asserting empty preexisting indexes, staged whitespace checks, then invocation-only `git -c core.hooksPath=NUL commit`. Raw outputs: `task-13-commit-f.txt`, `task-13-commit-b.txt`. No persistent hook setting was changed (B still `.githooks`, F has no explicit value). Post-commit `git status --short` was empty in both repositories. Exact BASE-to-HEAD file lists match the lists above. Structured package comparison against both BASEs verified unchanged dependencies/devDependencies and every other script: F prepends only `node test/delivery-operator.test.js && ` to `test`, preserving image-library `pretest`; B appends only ` && node test/delivery-terminal-corrections.integration.test.js` to `test:delivery:db`.

## Operator Behavior

The page has exactly Commandes / Livreurs / Remises d'especes / Reglages. There is one primary Livraison navigation entry, restricted to actual restaurant role0 or delivery-enabled role1. Role6 is denied operator, settings and staff accounts even with forged module arrays or primary-admin flags. Cashier settings tab is disabled; account/PIN and administrative adjustment controls require admin. Categories, product steps and Stock remain filtered out of main navigation/home by the shared helper. Existing internal catalog/stock routes were not changed.

`PERSONAL_ROLE_OPTIONS` extends the existing role-form options with Livreur=6; the older `ROLE_OPTIONS` export remains compatible with existing consumers/tests. Staff account creation/edit/PIN/disable uses existing staff actions and endpoints. Courier permissions are forced empty and service-point assignment null in staff payloads, and its general permission checkboxes are hidden. Staff action entry points also reject current cashier/courier context. Availability uses only the operational PATCH and a separate switch; it never edits account status. Existing staff page can open the selected courier or a new role6 account from the Livreurs links.

Commandes keeps the full server mission list, filters without a local cap, and labels completed history as recent, up to100 dossiers ordered by creation. Preparation/payment/logistics appear independently. Assignment, issue report/resolution and admin terminal correction send the current server version and an idempotency key. Transfer/return uses explicit physical confirmation. Details consume the existing protected address/contact/items projection. Unresolved attempts remain accessible in Commandes after component remount even if authoritative state has already moved to refunded/issue/closed.

The delivery store adds an `operator` subtree with identity/sequence isolation, missions, ordinary couriers, financial holders, settings, authoritative balances/eligibility, pending requests and errors. New actions are `operatorInitialize`, `operatorLoad`, `operatorCommand`, `operatorAvailability`, `operatorSaveSettings`. Resource values are missions/couriers/holders/settings/detail/balance/eligibility; command operations are assign/reportIssue/resolveIssue/correctTerminal/remit/refund/adjust. No new global module or persistence path. The installed delivery/customer/courier root filter remains unchanged.

On network/503/unknown outcome, the exact submitted body/key/version is retained in memory; only explicit Retry sends it again. There is no money retry timer, offline queue or optimistic financial result. A definitive client/conflict response triggers authority reads and records a conflict; a new payload/key requires explicit reconfirmation after successful reads. If reads fail, reconfirmation stays blocked. Successful money UI uses only confirmed server output and refreshes delivery/payment, refund eligibility and the original holder's balance. Changing actor/shop resets the operator scope, ignores late reads, and does not overwrite personal account/checkout state. Checkout RESET preserves this independently managed operator subtree so entering checkout cannot discard an unresolved remittance. Pending state is intentionally memory-only and is not a durable browser journal across a full reload.

The new layout guard restores an existing session through the existing auth middleware before deciding protected deep links. Public/client routes are left to existing authentication flows. No Task12 checkout/resolver/quote/credential/Fetch adapter, personal login/book/session, raw storage sanitizer or transport was replaced. The new calls use the already separate delivery transport, with staff bearer and credentials omitted.

Reglages uses actual Task2 camelCase fields/revision, a signed resolved origin, integer radius/bands, zero-allowed minimum, optional free threshold, configured_rate and explicit 5.5/10/20 fee VAT selection with no implicit rate. Invalid coverage/bands/origin or missing activation VAT blocks submission. Save uses full settings plus expectedRevision and optional originResolutionToken. Suspension is one settings PUT and performs no mission mutation. Task7 `DELIVERY_UTC_SESSION_REQUIRED`503 is shown with the historical-basis audit prerequisite; no SET time_zone or history rewrite was added. Existing origin coordinates can be reused unchanged; new origin comes from the existing postal resolver and server proof.

## New Protected API Contracts

All paths are relative to the existing API prefix. Existing dispatch/cash/refund routes retain their contracts and current-account/tenant checks.

### Former Financial Holders

`buildDeliveryDispatch().couriers({actor, financialHolders:false})` retains the existing assignment list behavior: current role6 only, including inactive6, with availability and mission count. GET `/delivery/couriers` remains unchanged by default.

GET `/delivery/couriers?financialHolders=true` calls `couriers({actor,financialHolders:true})`. Current active same-shop admin or delivery-enabled cashier only. Returns only `{id,username,status,currentCourier}` for same-shop current role6 users OR users referenced by that shop's immutable `delivery_payment_collections`. SQL `currentCourier` is0/1. No email, permissions, credential, other staff list, balance inference or debt transfer. A former courier promoted/reclassified or deactivated remains selectable in Remises; the balance/remittance engine remains Task7's original-custody engine. The projection also retains holders of manual external-card declarations, with cash totals still determined solely by the cash API.

### Manual Refund Eligibility And Consumer

GET `/deliveries/:id/refund-eligibility` -> `dispatch.refundEligibility({actor,deliveryId})`, same current restaurant operator protection and no-store response. Shop barrier -> current commercial/dossier/charge -> current actor -> immutable collection/payment read. It verifies unique manual source, full fee-inclusive amount, paid current order, succeeded matching manual payment, EUR, and absence of Stripe/Terminal/refund incompatibility, using the Task7 producer's eligibility conditions.

Response is `{eligible:false,reasonCode:'DELIVERY_REFUND_NOT_ALLOWED'}` or `{eligible:true,collectionId,method,amountCents,originalCourierId,returnSources}`. New collection ID is an exact decimal string; originalCourierId is a legacy integer. Cash sources are register/courier, excluding self-authorized original-courier return; external_card permits only external_card. This projection is a current compatibility read, not a reservation or custody-capacity guarantee. Task7's actual refund transaction remains authoritative and atomically refuses insufficient original-source capacity.

UI submits ONLY the existing Task7 POST `/deliveries/:id/refund` body `{returnSource,reason,idempotencyKey}`. No amount, mission assignee, holder, next state or client payment authority is posted. Full fee-inclusive amount comes from eligibility. Cash confirmation distinguishes physical register return (original courier debt remains) from physical return by the immutable original holder (only that source debt reduces). Source-insufficiency refusal is visible inside the refund dialog, with no success result. External card explicitly declares the full independent-TPE refund already performed, with no Stripe verification. No provider call, partial refund, courier self-refund, automatic refund on logistics/courier actions, hidden stock return or new financial engine.

### Administrative Terminal Correction

`buildDeliveryDispatch().correctTerminal({actor,deliveryId,reason,expectedVersion,idempotencyKey})` and POST `/deliveries/:id/correct-terminal` with EXACT body `{reason,expectedVersion,idempotencyKey}`. New deliveryId must be a decimal string. Blank/overlong reason, invalid mutation values and extra client fields are refused. Current active same-shop role0 is reloaded under lock; cashier/courier/customer/foreign/inactive/null-role/stale-admin claims are denied. Replay checks current authorization first. Same key/payload replays current authorized delivery with original exact eventId; different payload conflicts. Stale version conflicts with current projection. Different-key races produce one correction and one version conflict; same-key races produce one event and a replay.

Lock order is shop FIRST -> existing resolver's commercial active/archive -> dossier/current charge -> current actor -> event/history. The actual SQL wait test proves waiting on the shop barrier before dossier mutation. Existing non-correction dispatch lock/retry behavior is retained; no financial retry was introduced.

The only fresh correction is terminal delivered/failed/canceled -> issue, with closed_at cleared and courier preserved. The service requires a matching terminal event at the exact current dossier version with matching next status, courier and closed time. Delivered derives prior in_transit from immutable deliver; failed/canceled/unpaid-delivered resolution derives assigned/in_transit from the immutable reportIssue/correctTerminal origin. Invalid/missing history returns409 `DELIVERY_TERMINAL_HISTORY_REQUIRED`; no invented origin or arbitrary client next-state. Existing restaurant issue resolution then decides resume/retry/return/fail/cancel/unpaid confirmation; post-pickup physical-transfer checks still apply. The issue-origin adapter is restricted to the existing owned dispatch service.

Correction increments logistical version and appends only a `delivery_events` row. `previous_state` records actual old terminal snapshot (status/courier/closedAt), `next_state` is issue/courier/closedAt:null, and `reason` plus actor_subject/actor_id identify the author. `result` contains the existing next/version/action/physicalTransferConfirmed fields plus `{sourceEventId,formerTerminalState,issueOrigin,privacyClosedAt}`. No new table or financial journal. Commercial payment/preparation/totals, active/archive/details, charge snapshots, collection/remittance/allocation/adjustment/refund tables, product stock, confirmation hash and tracking hash/expiry remain unchanged. Actual late INSERT failure rolls back the dossier version/state as well.

## Task16 Privacy Anchor Handoff

`result.sourceEventId` is the exact decimal string of the immutable terminal source event. `result.issueOrigin` is the journal-proven physical snapshot, never the client's next state. `result.privacyClosedAt` is a canonical UTC ISO timestamp: the earliest terminal closedAt/prior correction privacyClosedAt in this dossier's immutable operational history. It survives clearing mutable deliveries.closed_at and is carried forward through repeated reclose/correct cycles. Journal SQL naive UTC strings are parsed explicitly as UTC, not worker local time.

Task16 MUST consume the earliest immutable correction privacyClosedAt in addition to any current closed_at when applying the closed+7d ceiling, and take the minimum with unchanged tracking_expires_at / created_at+30d. Query only the authorized dossier's journal internally; do not expose events/reasons publicly. This task does not implement tracking/token endpoints or claim Task16 acceptance. Tracking token hash, stored expiry, created_at and confirmation hash are not rotated or extended. The actual archived repeated-correction SQL test closes a second time a day later and proves the original privacyClosedAt remains unchanged.

## RED / GREEN Evidence

All names below are raw files in this scratch directory. Native Node22 is22.13.1. Node18 is18.20.8 at `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`. Only new SQL tests on Node18 use the real installed Nano ID import-cache bridge, because the unchanged legacy m_orders import needs it; the new test's bridge condition is exactly Node18. No production shim, dependency modernization or unbridged production Node18/Node20 boot claim.

Frontend command is `node test/delivery-operator.test.js` (or the explicit Node18 executable). Tests use real Vue2/Vuex, compile the actual SFC templates, mount controls with the existing-style memory DOM/Vuetify primitive boundary, and cross the actual isolated Axios JSON/HTTP adapter. Monetary/conflict/version expectations are literals; no source-regex assertions stand in for these behaviors.

| Witness | RED | GREEN / Result |
| --- | --- | --- |
| Missing roles/page/components/store operations | `task-13-operator-red.txt`, exit1,0/12 | Initial implementation11/12; remaining failure was reactive-array prototype comparison in fixture, corrected with serialized observable value. Retained `task-13-operator-green-attempt.txt`, `task-13-operator-green.txt`, `task-13-operator-expanded.txt`. |
| Cashier stale-primary navigation/staff-action denial | `task-13-operator-authority-red.txt`, exit1,15/17 | `task-13-operator-authority-green.txt`, exit0,17/17 |
| Existing-session settings deep link | `task-13-deeplink-red.txt`, exit1,17/18 | First corrected guard hit intentionally invalid fixture bearer/QR placeholder (`task-13-deeplink-green.txt`); fixture now supplies an unexpired local parsing token only under token key. `task-13-deeplink-green-final.txt`, exit0,18/18 |
| Checkout availability discarding pending remittance | `task-13-checkout-reset-red.txt` initial assertion-helper failure on missing value, corrected explicit witness `task-13-checkout-reset-red-corrected.txt`, exit1,18/19 | `task-13-operator-node22-final.txt` / `task-13-operator-node18-final.txt`, exit0,19/19 |
| Remounted refunded dossier loses recovery action | `task-13-remount-red.txt`, exit1,19/20 | `task-13-remount-green.txt`, exit0,20/20 |
| Actual dialog omits source-insufficient reason | `task-13-dialog-red.txt`, exit1,20/21 | FINAL `task-13-operator-final-node22.txt` and `task-13-operator-final-node18.txt`, each exit0,21/21 |
| Missing correction service, actual SQL | `task-13-terminal-red.txt`, exit1, expected missing correctTerminal assertion | `task-13-terminal-green-attempt3.txt`, exit0, initial6 SQL groups |
| Numeric new delivery ID accepted | `task-13-terminal-id-red.txt`, exit1, missing expected400 rejection | Final SQL files below each exit0,9 groups |

SQL setup for EVERY SQL invocation, from B (no application database fallback):

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task13-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task13-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-terminal-corrections.integration.test.js
# Alternate runtime, same setup:
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-terminal-corrections.integration.test.js
```

The password above is only the explicitly authorized disposable fixture password. Controller started local Docker Desktop. This worker inspected only named `smarteat-delivery-v1-tests`: mysql:8.0.33,127.0.0.1:33319, anonymous /var/lib/mysql volume, stopped; then started ONLY that container. No context change, Desktop duplicate launch, remote DB, project data mount or other container action. Existing `withDeliveryDatabase` creates/drops only random `smarteat_delivery_test_*` schemas.

Final SQL logs: `task-13-terminal-node22-final.txt`, `task-13-terminal-node18-final-expanded.txt`, each exit0, ALL9 groups in one file invocation. Earlier Node18 `task-13-terminal-node18-final.txt` also passed9 before expanding unchanged-snapshot assertions to details/allocations. Final groups cover original/archived/repeated closure privacy, reason/source proof, exact BIGINT event9007199254740993 through mysql2 production numeric defaults, financial/stock/token snapshots, current-account/tenant denials, strict input, same/different-key SQL races/replay, missing history, late-trigger rollback, real shop-lock wait, full fee-inclusive external-card source1650 cents, promoted inactive original cash holder, new assignee independence, actual Task7 partial remittance500/remaining750, refused insufficient full courier return, register refund preserving750 due, and actual Express/JWT HTTP routes/no-store.

Intermediate SQL failures retained honestly: `task-13-terminal-green-attempt.txt` denied role-changed courier with404 instead of expected403 (admin-only check moved before owner projection); `task-13-terminal-green-attempt2.txt` had fixture router import typo (fixed to src/routers) after5 passing groups; `task-13-terminal-expanded.txt` tried archive with fixture missing product details and correctly hit total mismatch (fixture now inserts actual orderdetail); `task-13-terminal-expanded2.txt` passed8 groups before later strict-ID coverage. No production financial/archive guard was weakened.

Each captured command used `*> <raw-log>`, saved `$LASTEXITCODE`, read the log and exited with that native code. Existing Browserslist stderr appears as PowerShell NativeCommandError decoration in some logs even when native exit is0; final test counts and returned native exits above are the result, not that decoration.

## Focused Regression And Build Evidence

- Final F batch ran `node test/<name>.test.js` once each after the checkout-reset fix, with independent logs `task-13-final-<name>.txt`: delivery-operator (then19, superseded by final21 above), delivery-checkout29/29, customer-account27/27, persisted-state, staff-roles, admin-navigation, staff-page, staff-credentials-page, auth-middleware, session-auth, kiosk-staff-roles, kiosk-staff-service-point, checkout-access, counter-checkout-store. All14 commands exit0. Subsequent frontend changes only add the covered Dispatch recovery strip/dialog refusal and tests; no checkout/account/store change after this batch.
- Earlier `task-13-regression-kiosk-staff-service-point.txt` failed a legacy source contract expecting the general `service_point_id: params.service_point_id` mapping. The owned staff payload now keeps that mapping then explicitly overrides only role6 to null/empty permissions. `task-13-regression-kiosk-staff-service-point-final.txt` and final batch pass. No unowned legacy test was edited.
- B unit commands `node test/delivery-authorization.test.js`, delivery-quotes, staff-credentials, staff-module-permissions, cash-closure all exit0, logs `task-13-backend-<name>.txt`; ENV_FILE=NUL and fixture JWT/public image values set. No provider requests.
- Entire existing `node test/delivery-dispatch.integration.test.js` with explicit SQL environment and TASK5_REVIEW_FILTER removed exits0: `task-13-dispatch-regression-node22.txt`. Includes all existing authorization/issue/archive/payment locks, ready/paid/refunded behavior, old operational missions beyond100 recent closed, concurrent/missing-key deadlocks and prior C1/I1/I2/M1 regressions. This is a whole affected dispatch file, not a new filtered substitute.
- Final focused lint: `node node_modules/eslint/bin/eslint.js helpers/staffRoles.js store/staff.js store/delivery.js middleware/delivery.js pages/livraison/index.vue pages/staff/index.vue layouts/default.vue components/delivery/DeliveryDispatch.vue components/delivery/DeliveryCouriers.vue components/delivery/DeliveryCashRemittances.vue components/delivery/DeliverySettings.vue test/delivery-operator.test.js`, exit0,0 errors/0 lint warnings; `task-13-lint-complete.txt`. Existing stale Browserslist notice only. Earlier lint import ordering and fixture require-await errors were corrected; their intermediate logs remain.
- `node --check` on all4 B JS files and `git diff --check` in both repositories exit0. Staged checks also exit0. LF/CRLF notices only. A post-commit optional `node -e` package-comparison probe failed shell quoting before executing; the same read-only check was completed using tool-returned JSON parsing and verified exact script/dependency preservation against both BASEs. No file was written by that failed probe.
- Existing controller Nuxt wrapper1992/listener6024 on127.0.0.1:8097 was preserved. No server was started/stopped/duplicated. The latest `dev-nuxt-resume-a9598177.stdout.log` records successful recompilation after final Dispatch changes (1.79s); listener was independently verified. Preview is `http://127.0.0.1:8097/livraison`. This is compile evidence only, NOT browser/device acceptance. No fresh build/generate, whole npm baseline or whole registered SQL chain was run, per scoped validation instruction; no such PASS is claimed.

## Author Review And Remaining Limits

Reviewed exact staged/committed scope, package preservation, current-role versus stale-primary behavior, direct-route restoration order, cashier/no-admin paths, separate availability/status, full operational list/recent label, original immutable holder versus assignee, Task7 full-return/source/reason semantics, source capacity rollback, unknown request/key retention and remount recovery, authoritative conflict rereads, independent checkout/customer/raw persistence, settings readiness/shape and the terminal journal/lock/privacy protocol. All required work stayed in owned files; no original checkout, shared ledger, Task14+ source or unrelated refactor was edited.

Controller still owns independent code review/gate and the single Task17 desktop/mobile visual batch of all four views and conflicts. Actual browser layout/contrast/mobile overflow and live commissioning remain unclaimed. The operational UI uses established Vue2/Vuetify/MDI/Poppins, unframed sections/dense tables/tabs and44px important controls; the craft floor was read without rerunning Impeccable context/detector. A UTC readiness result cannot establish historical DATETIME provenance: activation commissioning must audit/reconcile that basis. Independent-terminal refunds are restaurant declarations only. Tracking consumption of the preserved immutable privacy anchor is explicitly Task16 work. Memory-only unresolved operator requests do not survive a full browser reload, consistent with the installed persistence exclusion; the UI never turns an unknown result into financial success.

No real environment read/decryption, Mailjet/Meta/IGN/Stripe/Terminal/payment-provider request, real mail/phone/print/push, remote migration, deployment, push or merge occurred. No pending executable/test session remains; the controller's existing Nuxt server and authorized fixture container remain running.

## Fix Round 1: I1, I2, I3 Only

Progress: all three Important findings are addressed in the authorized frontend scope, with author self-review complete and no remaining implementation blocker. Ready for the controller's SCOPED re-review of `5bae7b2b0a24d677449fea9ef4129536ed1f3a04..a04f9da3b6cb444b7be4317922ba6acdce27252c`. This is not independent approval. M1 browser-data maintenance remains deferred; Task17 visual acceptance remains pending as scheduled. Task14 was not started or changed.

The FULL `task-13-review.md` was read first, before other round1 source/skill reads or edits. Controller's I1-I3 confirmation was consistent with the actual retained page, Dispatch and operator-store behavior; no plan conflict or backend necessity was identified. Applied receiving-code-review, TDD and verification skills; no nested implementer/reviewer. Craft floor read before the bounded UI changes, without a new context/detector/browser loop.

### Exact Commit And Files

- F round1 commit: `a04f9da3b6cb444b7be4317922ba6acdce27252c`, `fix: isolate delivery operator refund confirmations`.
- F parent: `5bae7b2b0a24d677449fea9ef4129536ed1f3a04`.
- B compatible HEAD remains exactly `b16d97cae4cb2eabb27512ac4c9c543b57c1570d`; no B source, test, package, index or commit change in this round.
- Exactly five F files: `pages/livraison/index.vue`, `components/delivery/DeliveryDispatch.vue`, `middleware/delivery.js`, `store/delivery.js`, `test/delivery-operator.test.js`. Commit has393 insertions/46 deletions.
- Explicit five-path staging followed an empty-index check. `git diff --check` and `git diff --cached --check` each exit0 (LF/CRLF notices only). Invocation-only `git -c core.hooksPath=NUL commit -m 'fix: isolate delivery operator refund confirmations'` exits0; retained `task-13-fix1-commit.txt` includes nativeExit0. No persistent hook configuration change.
- Post-commit `git status --short` in F and B is empty. `git show --format= --name-only HEAD` confirms only the five paths above. This scratch report is an ignored append, not an extra production edit.

### I1: Operator Identity And Retained Children

The shared frontend `operatorIdentity(rootState)` includes authenticated/logout state and the existing shop/account/current-role/status/subject/module-permission identity. Page child keys use that identity, and the operator views render only when the authorized identity matches the initialized operator scope. This replaces retained private Dispatch, cash-receipt, reason and settings drafts on a different identity; a same-identity refresh retains its children and pending exact-key attempts.

`operatorInitialize` synchronizes/clears the scope before access assertions, rather than asserting first. Forbidden or logged-out contexts get a null identity and empty operator subtree. The page initializes before redirecting, and the layout middleware clears forbidden/logout scope even on `/login`, before its protected-route classification returns. It does not authenticate or redirect public pages merely for this cleanup. Existing auth restoration remains the existing protected-route flow.

Store entry points synchronize before refusing access. If an actor changes during the initialization await, the old call clears/synchronizes the new scope and returns null, avoiding a late access exception into the retained page. Page refresh loops and store mutation follow-up reads stop on identity changes. Dispatch also resets its local private data on identity change/destruction and checks identity/liveness before accepting late resume/refund results. Its dossier fallback is unavailable to a mismatched scope.

Actual compiled page/child tests retain one mounted Vue page across shop7 -> shop8 -> forbidden courier and back through logout, with private details open, reason/receipt drafts and current-scope checks at redirect. Other tests hold real adapter responses for eligibility/remittance across transitions and prove they cannot repopulate state/dialogs. Same-identity page refresh keeps the same cash child and retransmits the original unresolved body/key only on explicit retry. Direct forbidden action and layout middleware tests verify cleanup before throw/redirect; logout navigation clears scope after leaving the protected page.

### I2: Fresh Eligibility Versus Exact-Key Replay

Each refund opening creates a unique in-memory dialog read ID. The store marks the eligibility read loading, clears its old cache entry, and records ready/failed metadata tied to that ID and current operator scope. Only the latest read can publish data or failure; overlapping/late reads cannot restore an older eligible source. Dispatch blocks new physical-return confirmation while reading, on failure, on an unready/mismatched dialog read, or when current eligibility is false. It displays a specific unavailable message on failure, rather than presenting cached eligibility as current.

The store's NEW-command boundary independently requires the matching successful dialog read ID, eligible current source and ready status, then consumes the read before sending. Internal `confirmationId`/`eligibilityReadId` metadata never enters the API body or persistence. The HTTP refund body remains EXACTLY `{returnSource,reason,idempotencyKey}`. A generic cached read, a different dialog's ID, or the correct dialog ID during/after a failed read cannot authorize a new request.

Existing unresolved replay is a separate branch: its saved path/body/key and original holder remain unchanged, regardless of changed form input or failed/ineligible current reads. Tests explicitly exercise both current eligible=false and HTTP503 while resending the original payload. No automatic retry, replacement key, new physical-return declaration or financial success is generated by a failed eligibility read. Existing definitive-conflict reread/new-confirmation behavior remains covered by the original tests.

### I3: Resulting Original-Holder Custody

The post-refund refresh now returns the actual successful original-holder balance read alongside the confirmed refund result as frontend-only `originalCourierId` and `originalHolderBalance`. The holder ID is the immutable source already saved in the pending request, not the mission assignee or the register authorizer. A failed balance read yields null for this receipt even if an older balance is still cached elsewhere.

For cash refunds, the success dialog displays the original holder and authoritative `remainingDueCents`. Register-return copy states that custody is unchanged, without asserting positive debt; courier-return copy records that source's return and shows the actual resulting balance. If refresh fails, a visible `Solde du detenteur initial indisponible` state replaces the amount. The confirmed financial result remains distinct from the unavailable custody read. Tests cover750 and0 server balances for both register/courier sources, plus refresh failure with a cached balance for both. Mission assignee15 is deliberately different from original holder11, and no assignee balance request is made. No local mission sum, inferred debt or B financial change was added.

### RED / GREEN And Intermediate Evidence

All raw files below are in this scratch directory. Each PowerShell capture saves `$LASTEXITCODE` immediately after the native command, reads its log, and exits with that code. The existing Browserslist message remains visible as stderr/PowerShell NativeCommandError decoration, per deferred M1; it is not substituted for the native exit code.

| Command / Witness | Native Exit / Result | Raw Log |
| --- | --- | --- |
| `node --test-name-pattern='round1' test/delivery-operator.test.js` before fixes | 1; all11 initial new tests fail on I1-I3 assertions, no harness-setup error | `task-13-fix1-red.txt` |
| Same file, pattern `round1 I1` after initial isolation fix | 0;3/3 | `task-13-fix1-I1-green-attempt.txt` |
| Same file, pattern `round1 I2` | 0;2/2, cached failure/in-flight and exact replay cases | `task-13-fix1-I2-green-attempt.txt` |
| Same file, pattern `round1 I3` | 0;6/6, both sources,750/0/unavailable | `task-13-fix1-I3-green-attempt.txt` |
| `node test/delivery-operator.test.js` intermediate | 0;32/32, original21 retained | `task-13-fix1-green-attempt.txt` |
| Pattern `round1 I1 an actor transition` before race fix | 1; expected old call incorrectly throws Access denied during initialization await | `task-13-fix1-I1-init-race-red.txt` |
| Pattern `round1` after race fix and expanded cases | 0;15/15 | `task-13-fix1-expanded-green.txt` |
| Pattern `round1 I1 logout navigation` before middleware cleanup placement fix | 1; old identity remains instead of null on /login | `task-13-fix1-I1-logout-red.txt` |
| Final full operator file, native Node22 and Node18 | 0 each;37/37 each, including logout fix | `task-13-fix1-final-node22-delivery-operator.txt`, `task-13-fix1-final-node18-delivery-operator.txt` |

Initial targeted lint returned1 for the new deferred-test helper's Promise parameter name and reported four new attribute-order warnings: `task-13-fix1-lint-initial.txt`. Helper naming and page attribute order were corrected. `task-13-fix1-lint-final.txt` then returned0 before the final added logout test; final complete lint below also returns0. No dependency/lockfile/browser-data update was made.

### Final Affected Verification On Both Runtimes

Native Node22 executable is the existing `node` (22.13.1). Node18 executable is `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe` (18.20.8). No Nano ID bridge, SQL or backend runtime was needed in this frontend-only round.

From F, one final bounded batch per runtime ran all seven files, retaining independent logs and printing `nativeExit=0` after each. For Node22:

```powershell
$task13Files=@('delivery-operator','delivery-checkout','customer-account','persisted-state','auth-middleware','staff-roles','admin-navigation')
foreach ($task13File in $task13Files) {
  node "test/$task13File.test.js" *> ".superpowers/sdd/2026-10-16-delivery-management/task-13-fix1-final-node22-$task13File.txt"
  $task13Code=$LASTEXITCODE
  Write-Output "Node22 $task13File nativeExit=$task13Code"
  if ($task13Code -ne 0) { Get-Content ".superpowers/sdd/2026-10-16-delivery-management/task-13-fix1-final-node22-$task13File.txt" -Tail 70; exit $task13Code }
}
```

The Node18 batch uses the identical seven-name array and capture, replacing `node` with `& $task13Node18` set to the exact executable above, `node22` in raw names with `node18`, and the printed runtime label. ALL14 commands returned native0; both enclosing tool sessions completed with0. No source edits after these final batches started.

| File | Node22 | Node18 | Log Name Suffix (after `task-13-fix1-final-nodeXX-`) |
| --- | --- | --- | --- |
| delivery-operator |37/37 |37/37 | `delivery-operator.txt` |
| delivery-checkout |29/29 |29/29 | `delivery-checkout.txt` |
| customer-account |27/27 |27/27 | `customer-account.txt` |
| persisted-state | exit0 | exit0 | `persisted-state.txt` |
| auth-middleware | exit0 | exit0 | `auth-middleware.txt` |
| staff-roles | exit0 | exit0 | `staff-roles.txt` |
| admin-navigation | exit0 | exit0 | `admin-navigation.txt` |

That is93 TAP tests per runtime, plus the four legacy assertion files per runtime. The original checkout and account files were run intact, without importing their suites into the new harness or weakening their tests. The operator additions use actual Vue2/Vuex, compiled page/children and the existing isolated Axios JSON/HTTP boundary with local adapter fixtures; there was no browser/real-refund request.

Final lint command, native0 with no lint violations: `node node_modules/eslint/bin/eslint.js store/delivery.js middleware/delivery.js pages/livraison/index.vue components/delivery/DeliveryDispatch.vue test/delivery-operator.test.js`. Raw `task-13-fix1-lint-complete.txt` retains the old Browserslist notice and explicit `lint nativeExit=0`. No whole npm, pretest baseline, SQL chain, production build, detector or broad UI run was performed. No claim of such verification is made.

### Limits And Final State

Author self-review checked the entire five-file fix diff for scope, clear-before-refuse/redirect ordering, retained versus changed identity, mounted child replacement, late-response guards, eligibility ticket/cache invalidation, stale/in-flight/overlapping read refusal, unchanged exact-key replay, actual original-holder result selection and explicit missing balance. Original staff/customer/checkout transports, raw persistence and server authority remain unchanged; the new metadata stays in the already-excluded delivery operator subtree. No endpoint, HTTP refund shape, B producer, terminal correction/privacy anchor, financial journal or dependency changed.

Both worktrees are clean after the F commit; B remains the exact original b16d97c pair. No implementation blocker remains. Controller owns scoped re-review and the pending Task17 desktop/mobile visual batch. Deferred M1 warning noise remains, with native exit codes preserved. No Task14+ source, nested agent, provider, real payment/refund, environment read, original checkout edit, server/container action, push, deploy or merge occurred. The original Nuxt and fixture were left alone. All round1 test/lint execution sessions have completed.
