**I1. Locking the first attempt destroys the address input and clears the accepted display proofs: ADDRESSED.**

- Evidence: F `components/delivery/DeliveryCheckout.vue:145` ignores resolved events while locked, including the unchanged shared input's teardown `resolved(null)`. `refreshQuote` checks the lock before invalidation at `:147`; `invalidate` at `:95` and the session watcher at `:88` also preserve the frozen proofs. Conditional child destruction can no longer clear the parent resolution/quote through these callbacks.
- Covering regression: `I1 mounted confirmed delivery keeps proofs/signature through pending child teardown and Stripe response without cancel` compiles and mounts the actual cart, checkout and shared input with Vue's real patcher. It asserts the real input was destroyed, both proofs and the current signature survived pending, the returned signature matches, Stripe UI is ready, one payment element mounted, and no cancel request occurred. Stripe UI and HTTP are local doubles.
- Check: this case is `ok 1` in both recovered raw runtime logs.

**I2. A persisted pending attempt cannot be recovered after a reload or interrupted tab: ADDRESSED.**

- Evidence: F `store/cart.js:37` introduces a module-local WeakSet keyed by the Vuex cart state. The action guard at `:232` blocks live delivery requests and ordinary fresh submissions against pending state; explicit original retries can proceed when no live request survives. The guard is acquired at `:280`, released in `finally` at `:344`, and checked by `retryCheckout` at `:350`. It is not persisted.
- Check: the necessary unchanged cutoff F `store/cart.js:239-269` retains the existing token and selects `publicAttemptPayload(originalPayload)` for original replay. Together with the diff's `retryCheckout` dispatch, this preserves the stored Stripe choice, endpoint, body, quote/address proof strings and private confirmation secret rather than constructing a fresh order.
- Covering regressions: `I2 reload with persisted pending exactly replays original Stripe endpoint/key/body/proofs/secret and blocks live remount clicks` distinguishes an ordinary mounted page sharing the live Vuex state from a serialized/reloaded state. It checks no extra live request, exactly one restored replay, concurrent retry rejection, exact original body/key, and successful payment preparation. `I2 restored pending counter-paid delivery keeps its original endpoint and payment choice` separately checks the orders endpoint and original counter-paid mode.
- Check: these cases are `ok 2` and `ok 5` in both recovered raw runtime logs.

**I3. A coexisting personal session blocks recovery of a POS guest attempt: ADDRESSED.**

- Evidence: F `store/cart.js:353` starts retry identity with no customer session and only selects a personal session when the original payload has `customerContextId`. An original guest therefore stays guest despite unrelated personal state. For personal attempts, `:355-358` requires the original owner, original/current shop, customer subject and current CSRF. Private original shop metadata is captured at `:120` and stripped from the wire at `:125`; the patch does not persist CSRF.
- Evidence: F `pages/cart.vue:594` keeps a locked original guest's computed delivery session null. A later personal login therefore cannot change that guest attempt's page-bound Stripe signature. The locked consumer's session guard also preserves its accepted proofs.
- Covering regressions: the mounted POS profile/address plus personal-session lost-reply case checks the chosen restaurant contact, guest original metadata, identical replay body, actual Fetch `credentials: 'omit'`, no CSRF, successful completion and unchanged staff/shop/storage state. The personal retry case rejects missing/wrong owner, shop, subject or CSRF, then replays the same body with refreshed current CSRF. The later-login site guest case checks stable signature and guest Fetch credentials on replay.
- Check: these cases are `ok 3`, `ok 4` and `ok 6` in both recovered raw runtime logs.

### New Breakage in the Fix Diff

None identified. New issue counts: Critical 0; Important 0; Minor 0.

### Out-of-Scope Observations

None identified during this bounded review. Task17's single batched desktop/mobile visual QA remains pending; this verdict does not satisfy that acceptance step.

### Checks and Evidence Bounds

- Read the task brief, full I1/I2/I3 findings and final recovered Fix Round 1 report section. Applied `superpowers/subagent-driven-development/re-review-prompt.md`; no subagents or implementation restart.
- Read the supplied `task-12-fix-round1-review.diff` once, including commit/stat context and all four file patches: F `13e2a2ca5759c0a41b3909bca74bd797ecae7479..3dad991babd4cd966089aecaeead67bdb580040e`, one commit, 330 insertions/14 deletions. No regenerated diff or git commands. The only additional source read was the necessary unchanged payload-selection cutoff `store/cart.js:239-269`.
- Read the complete fresh `task-12-fix1-recovered-node22.txt`: TAP tests 29, pass 29, fail/cancelled/skipped/todo 0, duration 6886.7853 ms. All six new cases and the retained 23 cases are present and successful.
- Read the complete fresh `task-12-fix1-recovered-node18.txt`: TAP tests 29, pass 29, fail/cancelled/skipped/todo 0, duration 6503.8774 ms. All six new cases and the retained 23 cases are present and successful.
- Read `task-12-fix1-recovered-lint.txt`: all four changed files checked, 0 errors and 3 existing store/cart.js no-console warnings at lines 431, 441 and 461.
- Check: the raw logs still contain the existing Browserslist stderr notice formatted by Windows PowerShell as NativeCommandError. This is not a failing TAP assertion. The recovered report records explicit LASTEXITCODE propagation and native/tool exit 0 for both runtime runs and affected lint. Native exit values are reported by that controller execution record, not embedded in the redirected TAP files. The earlier shell-exit-1 artifact is not treated as a product failure or as a successful shell command.
- No tests were rerun: the supplied diff and complete recovered logs answer the scoped findings without an unresolved narrow doubt. No whole npm, SQL, CORS or reader suite, browser/visual check, launcher/detector, environment/secret/provider/payment action, push or deploy was performed.
- Source, index, HEAD and branch state were not modified. Only this requested scratch report was written. Backend `6dfdc2cdc48ea47fd50940887f8d2580dddad5c8` is unchanged in the supplied scope and was not re-audited. Any further implementation loop belongs to the controller.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** I1 ADDRESSED; I2 ADDRESSED; I3 ADDRESSED. Open scoped findings: 0.
