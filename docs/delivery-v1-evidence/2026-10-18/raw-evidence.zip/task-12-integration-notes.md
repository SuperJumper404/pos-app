# Task12 personal identity versus existing public-principal seam

Controller source check via workspace_fs original frontend and focused current-worktree rg.
No frontend source was changed; Task9 worker owns backend OTP only.

- pages/click-and-collect/_shopId/_shopName.vue:339 dispatches shared shop/getShopInfoClickAndCollect on mount.
- store/shop.js:160 action loads the safe public endpoint, but writes shared shop_name/address/fiscal/payment/theme/etc. It is not a personal-account state loader.
- Storefront goToClickAndCollect at line387 calls users/postClickAndCollectAccess then navigates /menus.
- store/users.js:267 calls the existing public-session bootstrap, then persistAuthenticatedUser at line92. That helper resets Terminal, writes common localStorage auth and shared users state. This is an existing explicit public-principal switch.
- R4 new personal account page must use the safe public ENDPOINT through its isolated customerApi, keep branding in customer-owned state, and never bootstrap/switch staff/public identity just to login/read/edit a personal addressbook.
- New personal cookie identity attaches optionally to an existing POS/site checkout authorization; it is not a replacement for that bearer and is not permission to switch the staff shop/cart.
- Preserve legacy non-delivery workflows; do not infer that current app already supports parallel isolated staff/public ordering modes on one origin. If required by an actual new delivery flow, return a small explicit ownership/interface proposal; no broad implicit transport/persistence refactor or temporary token swap.
- New tests should snapshot staff auth/storage/shop/cart around customer login/logout/401 and personal shop changes. Old explicit storefront switching is not a new customer-auth side effect; acceptance must distinguish the two contexts rather than claim a wider migration was delivered.

## Current producer adapters (after Task10)

- Task10 placed optional customer attachment and CSRF on the ACTUAL r_orders POST checkout handler after existing bearer authentication. Preserve that route-local order, not a second app-level full-path guard; the latter missed Express prefix-boundary variants. See final Task10 report/routing regressions.
- Current B c_delivery.resolveAddress uses bearer-derived req.shopid and body {address,candidate_id}; personal Task10 resolver instead uses {address,candidateId}. The Task11 shared component speaks a resolver callback interface, so adapt the relevant field name at that boundary rather than copy the UI or change the existing public wire contract accidentally.
- Current quote adapter takes {items:[{product_id,quantity,selected_product_step_choice_ids}],address_resolution_token,discount?} or legacy discount_type/discount_value, never a posted price/shop override. Existing service-point quote requests cannot declare a nonzero/non-none discount. Reuse authoritative server quote DTOs.
- Current requireQuoteActor allows a service-point subject with its actual servicePointId, or existing order-taker staff; it is not a personal-cookie-only quote route. Personal addressbook login needs neither this bearer nor a quote. Safe availability projection is still Task12-owned and must use appropriate existing POS/site context.
- Task11 actual shared-input contract is in its report; its fix for selected ambiguity candidate persistence is pending Task11 gate. Read final reviewed interface, do not resurrect the pre-fix choose-candidate/save bug in the checkout consumer.

This is a disjoint controller characterization, not production edits, new ownership, or completed Task12 work.
