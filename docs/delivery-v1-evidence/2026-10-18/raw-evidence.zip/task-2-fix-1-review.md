# Independent Task 2 Fix Round 1 Review

Scope: supplied `88c33b1..f673929` fixdiff only, against the Task 2 brief/controller postal policy and original Important findings I1/I2/I3. Paths and line numbers below are relative to B at frozen `f673929`, not the later checkout. Read the appended fix report as evidence, not approval.

## I1. Floating discount calculation can change free-delivery eligibility

**ADDRESSED.** `src/helpers/deliveryMoney.js:18` validates the discount intent; line 26 enforces a decimal percentage scale and line 28 calculates half-up cents with BigInt. Amount discounts cross the existing decimal-to-cents boundary once and are capped in cents. `src/modules/m_deliveryQuotes.js:51` uses this helper, with net cents reaching pricing at line 53. The fix removes the legacy discount import without modifying legacy discount behavior.

Coverage: `test/delivery-pricing.test.js:59` covers explicit rounding/scale/maximum-safe cases and invalid intents. `test/delivery-quotes.test.js:35` asserts discount/net/fee/total `[11,94,200,294]` for the exact 105c/10%/95c threshold reproducer; line 40 checks the corresponding minimum rejection. These expected values are literal, independently meaningful assertions.

## I2. Loaded monetary configuration is neither safe nor validated

**ADDRESSED.** `src/modules/m_deliverySettings.js:5` rejects malformed/nonstring/negative/unsafe SQL CHAR amounts, comparing BigInt before Number conversion. Lines 31, 33 and 35 apply this to minimum, nullable free threshold and band fees. The repository validates the assembled settings at line 28; service GET/current-update reads validate at lines 68/71, and quote reads at `src/modules/m_deliveryQuotes.js:45`. Missing settings retain the disabled default at `src/modules/m_deliverySettings.js:26`; validation remains operation-time, with no new boot-time work.

Coverage: `test/delivery-quotes.test.js:43` checks all three SQL money fields with `9007199254740993` and malformed alternatives, rejects unsafe injected service/quote settings, and accepts missing disabled defaults. Lines 304 and 310 add actual SQL MAX_SAFE_INTEGER round-trips and unsafe CHAR SELECT substitution for each field. Nullable thresholds remain permitted when free delivery is disabled. The complete disabled mock at line 289 matches the validated settings contract; the lazy-router regression remains at line 294.

## I3. Mandatory house number and score 0.7 impose an unsupported coverage policy

**ADDRESSED under the binding controller policy.** `src/services/deliveryGeocoding.js:14` limits candidates to provider postal address types with ID/label and matching postcode/commune. Lines 20/26/28 reject wrong requested numbers, numbered-input downgrade and unrelated postal places. Line 31 retains provider identity, label, precision and postal snapshot, with the original provider point at line 34. Lines 153/155 permit automatic resolution only for a unique matching numbered address; an unnumbered street/locality always needs explicit provider selection. The unsupported score gate is removed. The existing search-boundary Point/coordinate checks still precede candidate mapping; no coordinate/centroid/zero-distance fallback is added.

Coverage: `test/delivery-quotes.test.js:64` includes selected street/locality fixtures at score 0.65, retained provider coordinates/label/precision, proof-to-quote preservation and signed-quote precision verification. Lines 89/90 reject omitted selection and numbered downgrade; line 92 begins municipality/nonpostal/unrelated postcode/commune/place/missing-label rejection cases. Line 105 accepts a matching low-score numbered result, followed by wrong-number rejection.

## Report Evidence And Review Method

Confirmed appended `task-2-report.md:200` identifies the covering test files, exact RED/GREEN commands and outputs, including initial independent I1/I2/I3 failures. Its recorded verification is:

- `node test/delivery-pricing.test.js`: exit 0, `delivery pricing tests passed (distance, bands, money, fiscal snapshot, signed address expiry/scope)`.
- `node test/delivery-quotes.test.js`: exit 0, `PASS I1 integer discount thresholds`, `PASS I2 loaded settings safety`, `PASS I3 selected postal precision`, then the quotes pass message.
- The same two files using the explicit cached Node 18.20.8 executable: recorded exit 0 and the same pass outputs; native runtime is recorded as Node 22.13.1.
- `node test/delivery-quotes.test.js --database`, with the explicit disposable local database environment, and its explicit Node18 equivalent: recorded exit 0, `delivery quotes SQL tests passed (atomic settings/revision, shared two-shop quota, narrow identifier projection)`.
- `node test/discount.test.js`: recorded exit 0, `discount tests passed`.

Independently inspected the changed implementation and literal regression assertions. Reconstructed the six frozen final files only in memory from the prior review package plus fixdiff: all 11 fix hunks matched baseline context. Prior package content was used only for the changed files' required context, line references, and the existing validator/coordinate guards on which the fixes rely. No later checkout integration was inspected. Recorded test outcomes above are author-run evidence, not claimed reviewer reruns. No unanswered specific doubt required an additional focused test. No suite/SQL/provider execution, Git, subagents, checkout/index/branch writes or application edits were performed. `workspace_fs` was unavailable; read-only PowerShell and in-memory Node inspection were used. This review file is the only write, via apply_patch.

## New Breakage

None identified in the supplied fixdiff. No open Critical or Important finding remains in this scoped round.

## Out Of Scope, Nonblocking

M1 signing-before-geocode remains the known deferred Minor item, not an open Important finding. Live provider precision/coverage and deployment topology acceptance remain outside this fix-round approval; synthetic fixtures do not establish live acceptance.

**Fix-round verdict: APPROVED.** Independent approval of I1/I2/I3 and this fixdiff only; no later checkout, integration or release approval is implied.
