**C1. Encoded slash bypasses the admin account-write guard.** - **ADDRESSED**.

`B/src/controllers/c_users.js:50` requires trusted staff subject, current active role 0, and matching authenticated account/shop identity. Both registration exports (`:163`, `:333`), credential reset (`:232`), activation (`:386`), update (`:533`) and deletion (`:592`) apply that predicate independently of the URL. Posted authority cannot satisfy it. `B/src/helpers/middleware/auth.js:74` supplies the reloaded account; `:55` splits raw path segments before decoding, preserving namespace boundaries for the central write guard.

`B/src/controllers/c_users.js:49` accepts only canonical positive decimal legacy IDs through 2147483647; target checks precede SQL in reset, detail, update and delete, with numeric conversion after validation. Logout (`:468`) preserves the service-point no-update branch and otherwise targets validated authenticated `req.id`, ignoring the posted target. Regression evidence: `B/test/delivery-authorization.test.js:96` directly exercises the five mutation controllers against seven invalid authority contexts; `:73` checks posted logout-target isolation. `B/test/delivery-dispatch.integration.test.js:506` covers encoded nonadmin writes and unchanged SQL roles; `:515` covers invalid admin targets and successful legitimate update/reset/delete. The original escalation path is closed.

**I1. Independent courier mutations deadlock on missing journal keys.** - **ADDRESSED**.

`B/src/modules/m_deliveryDispatch.js:66` adds a mutation-local wrapper: initial attempt plus at most two retries (`:82`). Only an ER_LOCK_DEADLOCK thrown inside the work callback followed by an explicitly successful rollback marks a candidate (`:71`); the runner must return the identical error. Begin/runner errors, commit-boundary failures, network failures, failed rollback and replaced errors cannot satisfy that condition. Every retry executes the whole mutation (`:121`), reloading commercial/account/ownership/version/journal state. Reads and availability retain their original runner. The shared `B/src/helpers/withTransaction.js:3` is unchanged; its cleanup preserves the retry error only when cleanup succeeds. No provider retry was introduced.

`B/test/delivery-dispatch.integration.test.js:528` uses two independent dossiers and couriers 11/13, pausing after both actual missing-key journal reads with a one-shot barrier. It requires a real SQL deadlock and successful rollback, both successful pickups, version 3, one pickup event each, unchanged stock, replay success and payload conflict. The bounded/exclusion fixture (`:577`) requires three attempts only for the confirmed in-work deadlock and one for each excluded boundary. These assertions and the reported focused RED/GREEN address the original race without changing lock ordering or idempotence.

**I2. The newest-100 query can hide unfinished missions permanently.** - **ADDRESSED**.

`B/src/modules/m_deliveryDispatch.js:32` unions all unassigned/assigned/in_transit/issue rows with a separately limited newest-100 delivered/failed/canceled history. Both branches apply shop scope and, for couriers, owner scope. Ordering uses the derived table's numeric ID and creation time; only the output ID is cast to CHAR (`:35`). The existing list method (`:195`) still returns an array through current authorization and the shared privacy projection.

`B/test/delivery-dispatch.integration.test.js:610` inserts 103 newer terminal dossiers and checks older assigned/in-transit/issue courier work, restaurant unassigned work, courier/shop isolation, 100 closed courier summaries and their address/contact/item redaction. The query no longer silently caps operational work.

**M1. The new SQL registration scenario produces unrelated debug output.** - **ADDRESSED**.

`B/test/delivery-dispatch.integration.test.js:7` captures only a single-argument exact GOOD diagnostic, asserts the captured sequence equals ['GOOD'], forwards unexpected logging and restores console.log in finally. Both actual registration callsites use it (`:304`, `:639`). The regression at `:634` observes stdout and restores its observer in a separate finally. No production m_users cleanup is present. Both final SQL logs contain zero standalone GOOD lines.

## New Breakage in the Fix Diff

None found. New Critical: 0; Important: 0; Minor: 0.

## Out-of-Scope Observations

None newly discovered. Existing controller rulings remain non-blocking: historical activation links require a pre-release compatibility audit; current admin-only role-changing activation remains intentional. Spec section 5 terminal mistake correction belongs to the explicitly assigned future Task13 adapter/UI work. Financial Tasks6/7 and the pre-existing unbridged Node18 Nano ID limitation are outside this fix gate. These items do not reopen the review loop.

## Checks and Evidence

- Reviewed the brief first, original findings and appended Fix Round 1/5 report, then the supplied five-file diff for c4264b5356cdf556877973c7a292485a28c98528..799b555b98c7fa82b6cead67ab66da275e4491b4. The diff was read in one pass; only a tool-truncated test section was recovered separately.
- Source completion reads were limited to the cut-off auth callback, credential-reset/update/delete bodies and dispatch mutation/list continuation. Outside-diff integration reads were limited to r_users route wiring and the shared transaction runner, to verify controller coverage and rollback/error propagation. No project crawl or fresh full review occurred.
- The appended report names focused C1/I1/I2/M1 RED/GREEN runs, final HTTP exit0 on Node22/18, final SQL exit0 on both, and relevant unchanged legacy regressions. Directly reading task-5-round1-full-green-node22.txt and task-5-round1-full-green-node18.txt confirmed 27 PASS SQL groups, 0 FAIL lines and 0 standalone GOOD lines in each, including all six added groups. This checks recorded evidence; it is not a fresh suite execution or independent reproduction of every reported exit code.
- One new read-only focused check extracted the exact production validUserId declaration and evaluated it with Node, without loading controllers or accessing SQL: 900 and 2147483647 accepted; LF/CR/CRLF/U+2028 suffixes, slash suffix, leading zero and 2147483648 rejected. This resolved the only additional validator doubt not covered by the listed invalid-target cases.
- No suites, git commands, subagents, provider calls, environment/remote access or production/index/HEAD mutations. Only this requested scratch report was written. workspace_fs denied the authorized worktree paths because its configured roots exclude .worktrees; targeted read-only PowerShell reads supplied the review evidence.

## Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** C1 ADDRESSED; I1 ADDRESSED; I2 ADDRESSED; M1 ADDRESSED. Addressed: 4/4 (1 Critical, 2 Important, 1 Minor). Open: 0. New breakage: 0. Scoped fix verdict: **PASS**.
