# Task11 existing navigation seams

Controller disjoint source characterization during Task10 review; not a feature change or approval gate.

- Original files read through workspace_fs, then focused worktree rg. middleware/auth.js is opt-in, not registered as a global router middleware by nuxt.config.js. It restores staff/QR auth and redirects unauthenticated callers to /login; do not attach it to the new personal account page or customer layout. Existing public storefront uses layout empty; new owned customer layout can similarly stay independent without broad auth middleware edits.
- plugins/session.client.js is global and watches the legacy staff token. It can clear an actually expired staff session and redirect to /login. This is existing staff expiry behavior, not permission for new customer 401/login/link/logout to invoke it. Preserve active staff state; do not call legacy auth/bootstrap actions in personal workflows. If a concrete new account workflow requires an outside-owned plugin change, return the exact bounded proposal before editing.
- nuxt.config.js exposes process.env.privateURL and existing brand assets; no customer secret belongs in Nuxt configuration. Existing global Axios/session/shopTheme plugins remain present, so prove the independent customer transport does not inherit staff bearer or global logout interceptors.
- Task10 final report is the actual HTTP consumer contract: tenant assertion ?shopId on authenticated personal routes, returned JSON csrfToken, explicit browserBinding on verify/link, stored {addressId} renewal and new {address,candidateId} variant. Read the finalized report after its review/fixes rather than reconstructing routes from old task text.

No frontend production file edited, browser run, screenshot, detector pass or dev server was performed during this preparation.
