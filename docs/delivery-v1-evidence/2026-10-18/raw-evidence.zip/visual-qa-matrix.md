# Delivery V1 batched visual verification

Executed locally on 2026-10-18. See docs/delivery-v1-evidence/2026-10-18/README.md
for actual outcomes, harness corrections, source fixes and coverage limits.
Use fictional disposable shop/customer/order data, not a real environment.

## Run Once After UI Integration

- Existing Impeccable context was already launched once; do not launch it again.
- Read craft-floor before UI edits. Run the final mechanical detector once.
- Run the browser's documented local-web-development/viewport APIs only.
- Capture a desktop/mobile batch, make one bounded visual fix batch, then inspect affected views again.
- Keep real OTP, provider payment/refund, physical printing, phone calls and external-navigation execution out of this batch.
- Unit/HTTP boundary tests cover clipboard copying; do not overwrite or read the user's OS clipboard for QA.
- Distinguish emulated mobile from an actual physical handset in acceptance.

## Viewports

| Name | CSS viewport | Purpose |
| --- | --- | --- |
| Desktop | 1440 x 1000 | Dense operational scan, four operator views, dialogs |
| Mobile | 390 x 844 | Primary portrait account, checkout, courier and tracking |
| Landscape | 844 x 390 | Courier actions/dialogs, usable scrolling, no fixed-footer overlap |
| Narrow | 320 x 640 | Long labels/address wrapping and minimum-width checks |

## Screen Matrix

| View | Fixture/state | Check | Evidence prefix |
| --- | --- | --- | --- |
| Customer account (/compte, resolve shop parameter from Task11) | Public shop branding; configured/unconfigured channels; login/link | No staff shell; correct restaurant; channel availability, input focus, six-digit code, countdown, busy/error/unknown-send states; guest exit | account-* |
| Address book | Three long accented addresses, long private instructions; default change/delete | Labels stable after deletion; one default; no overflow; new postal candidate selection; stored proof renewal/outage; stale shop response ignored | addresses-* |
| POS checkout (existing route from Task12) | One-off and saved destination; accepted quote and changed quote | Mode separate from order source; contact/address fit; exact fee/discount/total; explicit reconfirmation; no cashier exception to radius/minimum/suspension | pos-checkout-* |
| Public site checkout (existing route from Task12) | Guest and verified customer; independent staff session also present | No staff logout; valid private confirmation; preserved basket/errors; lost-response exact intent recovery; no fake paid browser return | site-checkout-* |
| /livraison: Commandes | All operational statuses; old issue beyond recent closed history; long references | Preparation/payment/logistics visible separately; assignment/conflict/reload; only authorized actions; recent history label | dispatch-* |
| /livraison: Livreurs | Active/inactive/unavailable; several missions; role-restricted cashier | Availability distinct from activation; admin account controls only; no courier privilege expansion | couriers-* |
| /livraison: Remises | Partial, surplus, stale version, former-role holder | Expected/received/discrepancy/current debt from server; no self-remittance; correct refresh; no local partial-list money computation | remittances-* |
| /livraison: Reglages | Disabled, incomplete fiscal setup, invalid bands, valid explicit setup, UTC refusal | Correct controls; validation/error fit; admin only; suspension does not cancel existing missions; no invented default price/tax | settings-* |
| Operator financial/terminal correction dialogs | Cash register versus original-courier return, external-card declaration; terminal mistake | Reason/physical source/manual confirmation explicit; no automatic refund/restock; unsupported source refusal; admin terminal action only | resolution-* |
| /livreur | Two missions, one prepaid and one unpaid; long names/address; closed mission | Portrait/landscape, large touch actions, safe tel/map hrefs inspected only; pickup eligibility; manual-card wording; no offline payment success | courier-mobile-* |
| Courier network/replay states | Uncertain collect result; reassigned/closed/current account changed | Same-key recovery, double-tap blocked, current server state replaces local data; no closed private address/instructions | courier-recovery-* |
| /livraison/suivi#<fixture token> | Anonymous browser; active/archived/issue/closed/expired | No staff gate; limited DTO; no internal notes/other missions; no token in URL requests/logs; no-store/referrer policy; visible-only polling/backoff | tracking-* |
| Existing order/history/receipt views | Fee zero/nonzero, accepted fiscal snapshot, refund status | Delivery versus channel; original totals/VAT on reprint; no fake fee product; correct grouped rendering and payout-discount restriction | documents-* |
| Existing reports/Z | Sale period versus later receipt/refund-only period; old snapshot | Drawer inflow/outflow distinct from sales and courier custody; no second revenue/VAT; unchanged historical snapshot | reports-* |

## Mechanical Checks

- No incoherent text/control overlap at each viewport; longest words fit their parent.
- No horizontal page overflow, offscreen dialogs, resizing icon buttons or shifting controls.
- Existing Vuetify/MDI/Poppins design; dense unframed page sections, not marketing/card nesting.
- Existing navigation still excludes Categories, Product Steps and Stock; courier stays in its own shell.
- DOM/network checks verify actual rendered logo/assets, API target, states and permissions; screenshots alone are not functional evidence.
- Inspect private responses/logs with fictional sentinels; do not log raw OTP, tracking tokens or entry instructions.
- PDF verification belongs to Task15: render the actual generated fictional PDF to bitmap, inspect totals/wrapping/fee/VAT. Do not send a physical print.

## Results

Initial batch and one bounded UI wave completed; source F98bfb39. Actual local
screenshots/reports and PDF/PNG evidence retained under the stable docs evidence
directory before cleanup. Browser API doubles are not SQL/provider acceptance;
unexecuted complex states remain explicitly covered by automated boundaries,
not falsely counted as clicked browser states. Native embedded PDF preview is
not visually validated in headless Chrome. Final full branch review remains.
