### Task 3: Creer une livraison dans le checkout existant

**Controller ownership amendment:** Also modify only the `addOrder` and `addDetailOrder` handlers in `B/src/controllers/c_orders.js` to enforce Step3's mandatory legacy split-write prohibition. Reject explicit delivery intent/proof fields on legacy header creation and reject details targeting an accepted same-shop delivery; retain historical non-delivery behavior and existing error conventions. Add focused real-handler regressions to the owned integration test. No router/archive/payment refactor authorized. This resolves an omission in the original file list, not a new feature.

**Files:** Create `B/src/modules/m_deliveryOrders.js`, `B/src/helpers/deliveryTrackingToken.js`, `B/test/delivery-checkout.integration.test.js`; modify `B/src/modules/m_checkout.js`, `B/src/modules/m_orderQuote.js`, `B/src/modules/m_orderEditing.js`, `B/src/controllers/c_orderEditing.js`, `B/package.json`.

**Interfaces:** Consomme devis tache 2 et produit `createDeliveryForOrder`, `resolveDeliveryOrder`, `toDeliveryView` definis dans le plan principal. Etend l'entree checkout avec `fulfillment_type`, `delivery_quote_token`, `address_resolution_token`, `delivery_confirmation_secret`; le lien client reste derive exclusivement d'un contexte verifie et vaut null pour l'invite. `deliveryTrackingToken.js` exporte `createTrackingToken()` et `hashTrackingToken(raw)` ; 32 octets aleatoires, SHA-256, pas de jeton en clair en base. Le checkout renvoie le lien initial une fois et conserve l'empreinte du contexte prive du contrat commun pour la rotation autorisee ulterieure.

- [ ] **Step 1: Ajouter les scenarios SQL** : commande produits 2000 + frais 400 => `subtotal = 24.00`, 1 dossier et 1 mouvement de stock ; rejouer `client_order_token = 'delivery-attempt-1'` => memes identifiants, aucun nouvel evenement et lien precedent toujours valide. Changer l'adresse sous cette cle => conflit. Injecter une erreur apres insertion dossier => rollback commande/dossier/stock. Le test lit les vrais tables/compteurs, pas le nombre d'appels d'une fausse transaction.
  ```js
  assert.equal(Number(order.subtotal), 24)
  assert.equal(deliveryCountAfterReplay, 1)
  assert.equal(stockAfterReplay, stockAfterFirstCheckout)
  assert.equal(previousTrackingTokenStillValid, true)
  ```
- [ ] **Step 2: Executer** `node test/delivery-checkout.integration.test.js` ; attendu rouge sur dossier/frais absents, apres schema et devis verts.
- [ ] **Step 3: Brancher les services sur la connexion transactionnelle existante**, etendre l'empreinte canonique aux donnees livraison, conserver `order_source` et `customerID`. Stocker la revision effective, autoriser une revision explicite avant paiement/recuperation seulement, conserver l'ancienne dans les evenements et bloquer les changements payes par `DELIVERY_EDIT_NOT_ALLOWED`. Bloquer un checkout legacy split-write en livraison pour ne pas contourner le devis. Distinguer dossier provisoire non attribuable et commande acceptee lors d'un paiement en attente.
- [ ] **Step 4: Executer test vert**, `node test/checkout-contract.test.js` et `node test/order-editing.test.js` ; verifier que les valeurs sur place/emporter n'ont pas change. Ajouter le test a `test:delivery:db`.
- [ ] **Step 5: Commit `feat: attach durable delivery to checkout`** dans `B`.

