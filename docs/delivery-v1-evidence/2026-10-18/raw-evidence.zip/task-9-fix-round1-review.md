**I1 - Link reservation reverses the existing Shop/customer FK lock order: ADDRESSED.** `src/modules/m_customerAuth.js:60` now executes `SELECT id FROM shop WHERE id=? FOR SHARE` before the existing customer's `FOR UPDATE` at line 63. The current locking read acquires Shop S in the reservation transaction before customer X. An archive already holding Shop X therefore blocks reservation before it can acquire customer X; conversely, an archive cannot acquire Shop X while that reservation retains Shop S. This removes the specific incompatible ordering identified in I1.

### Finding Verdicts

- **I1: ADDRESSED, 1/1.** The sole production change is the initial Shop locking read and its explanatory comment (`src/modules/m_customerAuth.js:59`). The supplied diff retains the surrounding transaction cleanup and introduces no retry or provider call into reservation. The lock is held until the existing transaction commits or rolls back.
- **Named regression coverage: adequate for the required order.** `test/customer-auth.integration.test.js:161` adds "Shop-first archive and customer link reservation serialize without an FK lock cycle". It invokes the production archive module and customer-auth service against actual SQL, forwarding queries and their actual results through timing gates. The archive is paused after its real Shop `FOR UPDATE` succeeds (line 187); the link is gated after its customer `FOR UPDATE` if it reaches that query (line 197).
- **Actual archive Shop X cannot coexist with link customer X in this reservation path: checked.** Lock metadata from the link connection is observed at `test/customer-auth.integration.test.js:218`; the test requires a Shop wait at line 229. With Shop X held by the paused archive, the new initial Shop S request cannot complete, so the subsequent customer X query cannot execute. The customer-X observation branch makes the pre-fix order fail directly. This argument concerns the actual reservation sequence, rather than relying on the archive FK selecting a particular customer index record.
- **Producer completion and HTTP boundary: checked.** After releasing the gates, the test requires no SQL failures, both operations to succeed, exactly one provider-boundary request, the archive's customer owner to remain "51", removal of the active order, and successful link verification (`test/customer-auth.integration.test.js:230`, line 233, line 234, line 236). Line 224 checks no HTTP request while reservation is blocked. The existing named "HTTP begins after commit and advisory release; late failure cannot downgrade verified challenge" test passes in both final logs; the fix contains no lifecycle/send-path changes. Together these support retention of commit/release-before-HTTP behavior. The new blocked-reservation assertion alone does not establish the precise commit boundary.

### New Breakage in the Fix Diff

- **None found.** New issue counts: Critical 0, Important 0, Minor 0. Reviewed only the production lock change and added regression in the supplied two-file fix diff.

### Out-of-Scope Observations

- **No new observations.** Previously reported Minor M1 remains deferred and is outside this fix-round verdict.

### Evidence Checks

- **Review inputs checked:** `task-9-brief.md`, Important I1 in `task-9-review.md`, and the final "Fix Round 1: I1" section of `task-9-report.md`; applied `superpowers/subagent-driven-development/re-review-prompt.md` directly. Fix base: `42f929258e505811a39368d3cbda892fa2efeda9`; supplied head: `d2f4d623b2f777dc57ce32aab579b96217ccefe0`.
- **Diff checked once:** `task-9-fix-round1-review.diff`, fully returned without cutoff; two files, 87 insertions / 1 deletion. No git diff, source reread, or fresh task review was performed.
- **RED output checked:** `task-9-fix-round1-red-node22.txt:50` fails the new named regression; line 56 identifies the required Shop-before-customer assertion; line 156 reports "link held customer first; SQL failures: none". Totals at lines 158/160/161 are 23 tests, 21 pass, 2 fail (subtest and parent), with zero skips at line 163.
- **Final Node22 output checked:** `task-9-fix-round1-final-green-node22.txt:50` passes the new regression; line 88 passes the existing commit/advisory-release-before-HTTP test; line 127 reports "link waited for Shop; SQL failures: none". Lines 129/131/132/134 report 23 tests, 23 pass, 0 fail, 0 skipped.
- **Final Node18 output checked:** `task-9-fix-round1-final-green-node18.txt:50`, line 88 and line 127 show the same named successes and Shop-wait diagnostic; lines 129/131/132/134 report 23 tests, 23 pass, 0 fail, 0 skipped.
- **Narrow archive output checked:** `task-9-fix-round1-archive-node22.txt:2` reports "PASS SQL actual amendment and archive serialize with standalone dossier resolution"; line 3 reports the selected archive/payment SQL tests passed.
- **Evidence limit checked:** the implementer's report explicitly disclaims a pre-fix deadlock result. The RED log establishes customer-first ordering, with no SQL failure. It does not establish an actual pre-fix FK wait cycle or deadlock. The final regression verifies the required ordering and successful actual-producer completion; no stronger reproduction claim is used for this verdict.
- **Review execution checked:** no suites or focused tests rerun; no unanswered narrow doubt required one. `workspace_fs` denied the explicitly requested worktree paths, so local shell reads were used. Sources, index, HEAD and branch state were left untouched; only this requested scratch verdict was written. No agents, secret-file reads, provider operations or worker lifecycle operations were used.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** I1 addressed; open in-scope findings: 0. New findings: 0 Critical / 0 Important / 0 Minor. M1 remains deferred. Worker retained.
