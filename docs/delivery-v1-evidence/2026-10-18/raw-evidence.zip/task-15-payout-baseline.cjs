const path = require('path')
const fs = require('fs')
const { execFileSync } = require('child_process')
const root = process.cwd()
const target = path.join(root, 'pages/cashregister/payout/_id.vue')
const original = fs.readFileSync
fs.readFileSync = (filename, ...args) => path.resolve(String(filename)) === target
  ? execFileSync('git', ['-C', root, 'show', '7ee09d3407760b3fc488e4eb051bea82b99e437c:pages/cashregister/payout/_id.vue'], { encoding: 'utf8' })
  : original(filename, ...args)
require(path.join(root, 'test/stripe-terminal-payout.test.js'))
