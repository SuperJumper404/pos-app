// Review the proposed SQL against the real fixture without changing the unowned module.
const fs = require('fs')
const path = require('path')
const root = process.cwd()
const target = path.join(root, 'src/modules/m_cashClosures.js')
const original = require.extensions['.js']
const before = '`SELECT archivesdetail.*\n     FROM archivesdetail\n     WHERE archivesdetail.orderId IN (?)`,\n    [orderIds],'
const after = '`SELECT vat_rate, total_ht, total_vat, total\n     FROM archivesdetail\n     WHERE archivesdetail.orderId IN (?)\n     UNION ALL\n     SELECT charge.vat_rate, charge.total_excl_tax_cents / 100,\n            charge.tax_cents / 100, charge.fee_cents / 100\n     FROM archives\n     JOIN deliveries ON deliveries.id = archives.delivery_id AND deliveries.shopid = archives.shopid\n     JOIN delivery_charge_snapshots charge\n       ON charge.delivery_id = deliveries.id AND charge.shopid = deliveries.shopid\n       AND charge.revision = deliveries.charge_revision\n     WHERE archives.id IN (?) AND charge.fee_cents > 0`,\n    [orderIds, orderIds],'
require.extensions['.js'] = (module, filename) => {
  if (filename !== target) return original(module, filename)
  const source = fs.readFileSync(filename, 'utf8').replace(/\r\n/g, '\n')
  if (!source.includes(before)) throw Error('Proposal context changed')
  module._compile(source.replace(before, after), filename)
}
require(path.join(root, 'test/delivery-reports.integration.test.js'))
