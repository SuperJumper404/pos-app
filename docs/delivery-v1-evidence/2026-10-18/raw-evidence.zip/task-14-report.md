# Task14 Courier Mobile Workflow

Status: implementation, focused TDD, affected regressions, targeted lint and author self-review finished. Controller independent review is pending. Actual phone portrait/landscape, long-address, network-error and mixed-payment visual acceptance, screenshots/detector, full npm suites and configured Node20 acceptance remain Task17 work. No visual PASS or whole-V1 acceptance is claimed.

## Paired Identity And Commits

- F: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
- B: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
- F BASE: a04f9da3b6cb444b7be4317922ba6acdce27252c
- B BASE: b16d97cae4cb2eabb27512ac4c9c543b57c1570d
- Final F: **7c4e12efc12865e283a15fd142b058a329133d07**, `feat: add courier mobile delivery workflow`
- Final B: **0150e247fd3ff874eabeb85857aaa7482d2b430e**, `feat: expose current courier availability`
- Both commits are on the existing feat/delivery-v1 worktrees. No new branch, nested agent, reviewer, merge, push or deploy.
- Both source trees and indexes were empty under `git status --porcelain` and `git diff --cached --name-only` after the paired commits. This report and raw evidence are ignored scratch artifacts, outside source commits.

Read task-14-brief.md FIRST without regeneration, then worker-context.md, task-14-integration-notes.md, common contracts, applicable mobile/state/payment/privacy/authority specification sections and Task7 financial producer/report. Only runtime-path evidence was searched in existing Task12/13 reports. No prior task plan was reloaded wholesale or prior source gate redone.

workspace_fs was initially unavailable, then its read_text_file explicitly denied the external worktree as outside its allowed original checkout roots. PowerShell reads in the named paired worktrees followed the worker-context fallback. No original checkout or real .env file was read or decrypted. Config/config.json, nuxt.config.js and plugins/axios.js were inspected in F; the user's prohibition on .env reads takes precedence over the general environment checklist. SQL uses ENV_FILE=NUL explicitly.

Skills applied: executing-plans, test-driven-development with writing-good-tests, verification-before-completion, systematic-debugging, and Impeccable new-work/Operate/craft-floor as an extension of the established Poppins/MDI/Vuetify world. Existing controller context was reused; no design reset, context repair, nested review or detector/browser loop.

## Changed Paths

Exactly eleven F source paths:

1. pages/livreur/index.vue: mission list, local passage arrows, own availability, explicit recovery, own server balance/remittances and closed recap; keyed actor/mission children, scope clearing and visible read failure.
2. layouts/courier.vue: limited mobile shell and existing staff logout, without operator navigation.
3. components/delivery/CourierMission.vue: items/customizations, contact/address/access details only while open, fixed tel/maps links, ready pickup, delivered and issue commands.
4. components/delivery/CourierPayment.vue: server remaining cents, no amount input, paid/refunded states, cash or explicitly manual independent external card, blocked mutation controls.
5. store/courier.js: isolated courier state/actions, identity and response epochs, current authority reads, exact-key recovery and bounded minimal collection metadata.
6. middleware/courier.js: role6 namespace restriction, clear-before-refuse and future public tracking exception.
7. test/courier-mobile.test.js: 27 behavioral cases using real Vue2/Vuex, compiled actual SFCs and real loopback HTTP through the existing isolated Axios/fetch transport.
8. middleware/auth.js: courier redirect before kiosk/client rules and public /livraison/suivi path boundary exception before staff restoration.
9. helpers/staffRoles.js: courier identity/route/public-tracking predicates. Existing operator module denials remain.
10. layouts/default.vue: courier guard runs before the existing delivery guard.
11. package.json: prepend courier-mobile test to the existing test script; pretest image-library, all existing tests and dependencies remain.

Exactly six B source paths:

1. src/modules/m_deliveryDispatch.js: readAvailability uses the existing transaction and current account reload, requires current active role6 and same shop, returns only courierId/available. Existing PATCH block is unchanged.
2. src/controllers/c_courier.js: no-store own availability GET adapter; actor from authenticated request.
3. src/routers/r_courier.js: GET /courier/availability only.
4. test/courier-availability.integration.test.js: disposable SQL and actual Express/JWT/HTTP; current false/true values, caller IDs ignored, strict DTO, no-store, trigger-proven no writes, role/status/tenant/subject changes, existing PATCH behavior.
5. package.json: register new SQL test in test:delivery:db; all previous script entries/dependencies retained.
6. src/helpers/deliveryAuthorization.js: one-line GET allowlist addition for /courier/availability.

Bounded scope finding: path 6 was absent from the brief's B list, but the central guard rejected the explicitly authorized new GET before its router, demonstrated by the SQL/HTTP RED 403-versus-200. A concrete one-line proposal was reported before editing that unowned path. It was treated as necessary to complete the authorized GET, with no alternative bypass or wider staff surface. This narrow scope interpretation is explicitly surfaced for controller review; it is not described as a separate explicit user approval. Only this extra path was added beyond the brief's enumerated B paths.

F Task13 store/delivery.js and its same-identity pending operator subtree, keyed/clear-before-refuse guards, and Task12/customer transport, checkout and persistence implementation paths were not edited. No dependency, lockfile, migration, general staff projection, financial mutation API or availability PATCH implementation changed.

## Behavior And Recovery Contract

- Every courier HTTP path is under /courier. No operator endpoint, caller courierId, caller monetary amount, self-remittance, refund or adjustment action is used.
- The reused buildDeliveryApi reads the staff bearer lazily, omits cookies and avoids the global staff logout interceptor/customer transport. Node tests cross actual loopback HTTP rather than only an Axios adapter double.
- Pickup requires current allowed action, assigned status and preparation 3. Normal completion requires in_transit and zero server due. Issue/payment-pending/terminal states block normal commands. Each mission has an independent in-flight lock; no optimistic payment or delivery transition.
- Collection always rereads own detail before a new collection or explicit recovery. Body is EXACTLY method/expectedVersion/idempotencyKey. Unknown outcomes preserve identical body/key, including changed UI method attempts. No automatic POST, queue or payment retry occurs on mount/refresh/reconnect.
- Dedicated localStorage key smarteat.courier.collections.v1 holds at most 32 entries and at most 16000 input characters. Each entry is EXACTLY shopId/courierId/deliveryId/idempotencyKey/method/expectedVersion. It stores no mission object, address, contact, instructions, reason, token, amounts, balance or financial recap. Full/malformed/unwritable storage blocks new collection without evicting unknown records.
- Unknown prior collection metadata survives authority loss; its prior result is not assumed absent because replay is now refused. Reassignment/404 preflight prevents POST and removes local private details while retaining the unresolved metadata. Definitive financial conflict requires a current reread and another explicit confirmation.
- Other mutation recovery is memory-only, preserving the original body/reason/key during the current identity. This is not a persisted issue-reason queue.
- Every accepted mission response replaces the old row. Terminal responses additionally strip addressSnapshot/contactSnapshot/items, even if a malformed terminal response includes them. Mutation invalidates older list/detail reads; old actor/epoch replies cannot restore private data or balance. New identity/logout clears prior courier memory before refusal. General persistence excludes the module unchanged.
- Manual passage order stays in memory and skips completed rows. It has no transaction or route-optimization API.
- Availability starts unknown and is read through the new GET, never invented from auth or written on mount. PATCH is explicit, not optimistic; an uncertain result returns to unknown and needs a read. Delayed reads cannot overwrite the confirmed toggle or leave a loading flag stuck.
- Own balance is exclusively the Task7 server cents DTO. External-card collection does not derive a local cash debt. Remittance information is read-only.
- tel uses a validated normalized phone and fixed tel: scheme with encoding. Maps uses fixed https://www.google.com/maps/dir/?api=1&destination= plus an encoded postal address only, excluding access instructions. Tests inspect URLs; no real calls or map navigation occurred.
- The future public /livraison/suivi and /livraison/suivi/... exception is path-boundary limited. /livraison, /livraison/suivi-private, staff/settings/orders/checkout operator pages do not gain courier privileges. Existing QR/kiosk/customer regressions passed.

## RED And GREEN Evidence

All raw logs below are under this scratch directory. Native runtime: node v22.13.1. Cached runtime: C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe v18.20.8.

| Witness | Native Result | Raw Log |
| --- | --- | --- |
| Initial frontend absent store/surfaces | exit1; 0/14, first explicit assertion store/courier.js missing, subsequent absent-file failures | task-14-frontend-red.txt |
| Initial GET behind central staff guard | exit1; HTTP403 versus expected200 | task-14-availability-red.txt |
| Initial implementation harness load | exit1; 1/14, test loader delegated ESM relative delivery import to native CJS | task-14-frontend-green-attempt1.txt |
| Corrected loader; observable-array assertions, selector stub and mount timing exposed | exit1; 7/14 | task-14-frontend-green-attempt2.txt |
| Stable replacement order and corrected observable/compiled-boundary assertions | exit0; 14/14 | task-14-frontend-green-attempt3.txt |
| Expanded unknown financial denial witness | exit1; 20/21, recovery metadata erased after403 | task-14-expanded-red.txt |
| Public unauthenticated tracking and delayed availability loading witnesses | exit1; 0/2 | task-14-auth-availability-red.txt |
| Expanded green before final self-review cases | exit0; 25/25 each | task-14-frontend-green-node22.txt, task-14-frontend-green-node18.txt |
| Denied page hid recovery error; completed row consumed visible-order arrow | exit1; 0/2 | task-14-error-order-red.txt |
| Final focused file, all cases, no filtered/skipped tests | exit0; 27/27 each, 0 fail/cancel/skip/todo | task-14-final-frontend-node22.txt, task-14-final-frontend-node18.txt |
| New actual SQL/HTTP file | exit0; 3/3 assertion groups each | task-14-availability-green-node22.txt, task-14-availability-green-node18.txt |
| Existing Task5 full SQL/HTTP file, including current role6 and privacy | exit0; 27 PASS groups each | task-14-task5-http-node22.txt, task-14-task5-http-node18.txt |
| Initial targeted lint | exit1; 3 harness lint errors | task-14-lint-attempt.txt |
| Corrected/final targeted lint | exit0; 0 errors, 0 code warnings | task-14-lint-green.txt, task-14-final-lint.txt |

Harness corrections were not disguised as product defects: the test module loader now compiles relative project imports, Vue observed arrays are compared via plain snapshots, the Vuetify selection primitive exposes its item labels, and mounted HTTP refresh is awaited. The product replacement preserves mission positions instead of appending each mutation result. No expectation, source permission guard or HTTP error was weakened to obtain green.

Initial/final frontend commands were `node test/courier-mobile.test.js`, or the exact cached Node18 executable with the same file. Two narrow RED commands used `node --test-name-pattern='public tracking exception|availability PATCH invalidates' test/courier-mobile.test.js` and `node --test-name-pattern='keeps authority failure|manual order skips' test/courier-mobile.test.js` respectively. Final 27-case commands ran the entire file without a filter.

Every SQL invocation explicitly set these process-local values before running the named test:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:ENV_FILE='NUL'
$env:JWTKEY='task14_disposable_fixture_only'
node test/courier-availability.integration.test.js
node test/delivery-dispatch.integration.test.js
# Each file also executed once on the exact cached Node18 binary above.
```

Each line here represents its recorded individual invocation, not one unguarded multi-command success assumption. The helper creates/drops only random smarteat_delivery_test_* catalogs on the explicit existing loopback fixture. No remote/app catalog, Docker command/context, container creation or other container was used. The new SQL test has the existing test-only real nanoid import-cache bridge conditional on Node18; no production shim or production Node18/20 boot claim.

Log capture used `command 2>&1 | Tee-Object -FilePath <raw-log>; $task14Exit=$LASTEXITCODE; Write-Output "nativeExit=$task14Exit"; exit $task14Exit`. The final logs and later batch logs append that nativeExit line with Tee-Object -Append. Earlier native exit status is in the tool result and the table above, not necessarily inside that earlier raw file. PowerShell presents native Browserslist stderr as NativeCommandError text even for native exit0; statuses above use LASTEXITCODE, never that formatting label. The unchanged stale Browserslist notice remains; its suggested network update was not run.

## Affected Regression Commands

The following seventeen F files each ran once on Node22 and once on Node18, all native exit0. Raw naming is task-14-regression-node22-NAME.txt and task-14-regression-node18-NAME.txt:

```text
auth-middleware
session-auth
auth-storage-repair
qr-session-bootstrap
table-access-auth
kiosk-auth-middleware
kiosk-staff-roles
kiosk-staff-service-point
staff-roles
staff-module-navigation
staff-module-permissions-page
persisted-state
checkout-access
counter-checkout-store
delivery-checkout
customer-account
delivery-operator
```

Command per entry: `node test/NAME.test.js` or `& <cachedNode18> test/NAME.test.js`. The batch captured and checked LASTEXITCODE for each file and stopped on any failure. Both enclosing batch sessions completed0. Counted TAP cases: delivery-checkout29/29, customer-account27/27, delivery-operator37/37 on EACH runtime; the other fourteen files are legacy assertion scripts reporting passed without TAP counts. Thus 34 successful frontend regression file invocations, with93 counted TAP cases per runtime plus legacy assertions. Task14 adds27 counted cases per runtime separately; no invented assertion grand total.

B regression commands `node test/NAME.test.js`, then cached Node18 with the same names: delivery-authorization, service-point-session-auth, staff-module-permissions, staff-login-contract. All eight invocations exit0, logs task-14-backend-node22-NAME.txt and task-14-backend-node18-NAME.txt. ENV_FILE=NUL and the fixture JWT key were explicit. Existing authorization test retains its existing test-only Node18 nanoid bridge. No new bridge was needed for the other three scripts.

Final lint command from F:

```text
node node_modules/eslint/bin/eslint.js store/courier.js middleware/auth.js middleware/courier.js helpers/staffRoles.js layouts/default.vue layouts/courier.vue pages/livreur/index.vue components/delivery/CourierMission.vue components/delivery/CourierPayment.vue test/courier-mobile.test.js
```

Both Node22 and Node18 `--check` passed for the four changed B source JS files and new SQL test (five files each). `git diff --check` and `git diff --cached --check` passed in both repositories, native0. LF/CRLF informational notices only. Full npm test/build and full repository lint were deliberately not repeated: user assigned broad final validation to Task17.

## Self-Review And Limits

Reviewed the actual staged source diffs and test boundary/behavior assertions. Programmatically compared staged names to the exact11 F and6 B path lists before commits. Source totals: F1098 insertions/2 deletions, B84 insertions/2 deletions. No unrelated staged or working files appeared. Existing Task12 source paths/customer/persistence and Task13 operator subtree were not modified; their affected regression evidence is retained rather than redoing prior tasks.

Author review found and fixed, through recorded RED/GREEN: stable mutation replacement position, preservation of unknown collection metadata across a later denial, public unauthenticated tracking boundary, delayed availability loading/response handling, error visibility outside a cleared private scope, and manual order filtering of completed missions. No remaining known functional failure in the executed gates. Controller review still owns independent assessment, including the explicit one-line backend scope interpretation above.

The SFC tests use actual Vue render functions and events with a minimal in-memory DOM and Vuetify primitive boundary. They prove compiled control behavior and real HTTP serialization/recovery; they do not prove real Vuetify layout, touch ergonomics, browser pixel visibility, portrait/landscape overflow, MDI rendering or visual acceptance. These remain explicitly pending for the one Task17 visual-qa-matrix batch. The existing controller-owned Nuxt process/listener at127.0.0.1:8097 was neither started, stopped nor replaced. Only ephemeral loopback HTTP test fixtures were opened and closed.

No provider/real email, WhatsApp, SMS, IGN, payment, refund, print, map navigation or phone call occurred. No secrets were decrypted or printed. All test actors/contacts/credentials are disposable fixtures. No mutation recovery metadata includes private delivery content, and no automatic recovery POST happens on mount.

Commit commands were exactly invocation-local hook overrides:

```text
git -c core.hooksPath=NUL commit -m "feat: expose current courier availability"
git -c core.hooksPath=NUL commit -m "feat: add courier mobile delivery workflow"
```

Raw commit logs: task-14-backend-commit.txt and task-14-frontend-commit.txt, each nativeExit0. No persistent hooks configuration was changed. Explicit path staging preceded both commits; no git add-all, reset, checkout, force or amend.

Final paired readbacks: B0150e247fd3ff874eabeb85857aaa7482d2b430e and F7c4e12efc12865e283a15fd142b058a329133d07, with empty source statuses and empty indexes. Scratch evidence/report is intentionally uncommitted. Independent review and Task17 validation remain pending.

## Round1 I1 Privacy Freshness Fix

Status: I1 implemented, RED/GREEN verified, targeted affected regressions and modified-file lint passed. Ready for controller scoped rereview; no independent reviewer or task-gate PASS is claimed here. This section supersedes the original author self-review's assertion that no functional failure was known: the subsequent controller review demonstrated I1, which the earlier27-case gate did not cover. M1 lingering read-failure feedback and M2 inherited validation noise remain deferred to final triage as explicitly requested.

### Scope And Identity

- Read task-14-review.md in FULL before any other round1 file. Applied receiving-code-review, TDD/writing-good-tests and verification-before-completion guidance. Continued with the established external-worktree PowerShell fallback after the already recorded workspace_fs denial; no original checkout reads.
- F round1 BASE: 7c4e12efc12865e283a15fd142b058a329133d07.
- F round1 commit: **6cd46a4163aa04ba7ce875b19501e51c9203bde9**, `fix: coordinate courier mission privacy freshness`.
- B remains **0150e247fd3ff874eabeb85857aaa7482d2b430e** with no change or new commit.
- Exactly two source paths changed and committed: F/store/courier.js and F/test/courier-mobile.test.js. No other owned file was necessary. Source delta225 insertions/13 deletions: store46 additions/13 deletions; tests179 additions.
- No Task15 work, backend changes, SQL, broad suites/build, browser/detector loop, server start/stop, provider, real environment read/decryption, original checkout, push, deployment or merge. Only temporary loopback HTTP fixtures required by the existing behavioral tests were opened and closed.

The controller ruling in the review confirms that the original one-line backend GET authorization amendment is authorized scope, rather than an extra-scope finding. The earlier report's cautious scope interpretation is superseded by that ruling; round1 does not touch the backend.

### Implementation

Per-resource read tokens alone could not protect a mission across list/detail/command response boundaries. The store now additionally keeps an identity-local publication sequence and an ID-to-freshness map in memory. A read captures the sequence at initiation. A detail publication/removal, a command boundary/result, and a list closure/omission protect the affected mission IDs against older in-flight work.

A list reconciles each row against the mission's publication sequence. It retains newer authoritative current rows, omits protected tombstones, and can still update independent missions from the same response. Protected rows absent from an older list retain their stable positions; the existing local order remains respected. List closure/omission protects against older details as well. Pending detail IDs are tracked even before their first mission publication, so an authoritative empty list can protect their absence. The list action returns the reconciled current missions, not the unfiltered stale DTO.

Ordinary active list rows do not establish a privacy barrier against an already-running detail authority check. A detail404 still clears the mission when the overlapping active list happened to finish first. Detail publications establish the cross-resource barrier; newer list terminal/removal publications do likewise. A later new server read captures the new sequence and may authoritatively reintroduce/reopen the mission. There is no permanent client prohibition, fabricated terminal state or server-version replacement.

Commands protect only their own mission, replacing the previous blanket read-token invalidation. Their result publication checks the same mission freshness as reads. An older nonterminal command reply cannot overwrite a newer terminal detail or revive a removed mission; confirmed request bookkeeping still settles without publishing the stale private DTO. A confirmed terminal reply with a newer SERVER version can supersede an intervening pre-commit active detail, but cannot revive a removed mission or supersede a newer terminal mission. A command404 clears immediately and protects removal before its follow-up own-detail request completes. Per-resource loading-token cleanup remains intact; the controlled interleavings assert all busy flags are released.

Identity epochs, current actor checks, per-mission command locks and current-server collection preflight remain. No collection amount, courier identity, availability or balance authority was added on the client. The six persisted recovery fields, validation/bounds, exact unresolved body/key, write-before-POST and explicit replay requirements are unchanged. M1 error clearing and M2 dependency/logger cleanup were not implemented as side effects.

### Behavioral Witnesses

Nine new `round1 I1` cases use the actual exported store, real Vue2/Vuex and the existing Axios/fetch adapter through actual loopback HTTP. No source assertion stands in for their behavior. Controlled promises wait for the request to reach the HTTP server before releasing the next response.

1. New collection: preload an in-transit mission; hold its collection-detail read; start/hold a list with the old private snapshot; release detail404; assert mission absent and no POST; release list; assert mission remains absent. The unrelated mission updates to literal version8, local order survives and loading clears. A new authoritative list can subsequently publish literal version9.
2. The same exact interleaving with an existing unresolved cash collection: the changed UI external-card choice cannot replace the original cash body/key; the persisted six-field entry remains byte-for-byte unchanged; no new POST is sent.
3. A newer terminal detail defeats both an older held list and an older held detail; address/contact/items remain absent and the server version7 remains. A later new authoritative version8 read remains possible.
4. A newer list terminal projection defeats an older active detail.
5. A newer list omission defeats an older active detail.
6. An older successful pickup response cannot overwrite a newer terminal detail or reintroduce private fields; confirmed pending bookkeeping and loading clear.
7. A successful delivery's server version3 closure supersedes a concurrent pre-commit active version2 detail; a held old list cannot reopen it.
8. A command404 removes the mission BEFORE its follow-up detail read finishes, and a held old list cannot resurrect it during that follow-up.
9. An authoritative empty list protects an in-flight detail ID not previously present in the mission array.

Existing27 cases remain, including compiled SFC events, two independent missions, no optimistic payment, exact-key loss/reload/replay, private terminal redaction, identity changes, availability/balance, manual order, bounded/unwritable storage, general persistence exclusion and unchanged Task13 pending state.

### RED/GREEN And Native Exits

All raw names below are in this scratch directory. Native Node22 is22.13.1; cached Node18 is18.20.8 at `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`. Every round1 captured command appends its actual LASTEXITCODE as `nativeExit=...` to its raw log and exits that native value.

| Command / Scenario | Native Result | Raw Log |
| --- | --- | --- |
| `node --test-name-pattern='round1 I1' test/courier-mobile.test.js`, original first six witnesses | exit1;0/6, expected privacy assertions fail: reassigned mission resurrected twice, terminal state overwritten three times, omitted mission restored | task-14-fix1-red-node22.txt |
| Same focused command after initial per-mission coordination | exit0;6/6 | task-14-fix1-green-focused-node22.txt |
| `node --test-name-pattern='round1 I1 command \|round1 I1 empty' test/courier-mobile.test.js` | exit1;2/3, confirmed closure lost to intervening active detail; initial after-completion404 witness and empty-list witness passed | task-14-fix1-command-red-node22.txt |
| `node --test-name-pattern='round1 I1 command ' test/courier-mobile.test.js`, strengthened404 witness held follow-up read | exit1;0/2, closure still active and command404 failed to clear before reread | task-14-fix1-command-denial-red-node22.txt |
| `node test/courier-mobile.test.js`, full file after both command corrections | exit0;36/36 | task-14-fix1-full-green-attempt-node22.txt |
| Final full file on Node22 after equivalent map lookup simplification | exit0;36/36,0 fail/cancel/skip/todo | task-14-fix1-final-node22.txt |
| Final full file on exact cached Node18 binary | exit0;36/36,0 fail/cancel/skip/todo | task-14-fix1-final-node18.txt |
| `node node_modules/eslint/bin/eslint.js store/courier.js test/courier-mobile.test.js` | exit0; no ESLint code diagnostics, inherited Browserslist stderr | task-14-fix1-lint.txt |

The two command counterexamples were discovered during I1 self-review, before final validation. They were added as executable witnesses and observed RED before correcting command publication. No expectations were weakened, production bridge introduced, provider invoked, or test marked skipped to make GREEN. The closure correction uses only confirmed server status/version, and the404 correction concerns immediate private removal.

Exact final focused commands:

```powershell
node --test-name-pattern='round1 I1' test/courier-mobile.test.js
node --test-name-pattern='round1 I1 command |round1 I1 empty' test/courier-mobile.test.js
node --test-name-pattern='round1 I1 command ' test/courier-mobile.test.js
node test/courier-mobile.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/courier-mobile.test.js
node node_modules/eslint/bin/eslint.js store/courier.js test/courier-mobile.test.js
```

Exact capture pattern for each command:

```powershell
<command> 2>&1 | Tee-Object -FilePath <raw-log>
$task14Exit=$LASTEXITCODE
"nativeExit=$task14Exit" | Tee-Object -FilePath <raw-log> -Append
exit $task14Exit
```

For the affected regression batches the same per-file capture/exit check runs inside a foreach; any nonzero native exit stops the batch. Both final batches completed with exit0.

### Affected Regressions

Seven focused F files were run once per runtime in round1, fourteen successful file invocations total. Command per entry is `node test/NAME.test.js` or `& <exact cachedNode18> test/NAME.test.js`. Raw log names are `task-14-fix1-regression-node22-NAME.txt` and `task-14-fix1-regression-node18-NAME.txt`; each contains nativeExit0.

| NAME | Node22 | Node18 |
| --- | --- | --- |
| auth-middleware | legacy assertions pass | legacy assertions pass |
| session-auth | legacy assertions pass | legacy assertions pass |
| counter-checkout-store | legacy assertions pass | legacy assertions pass |
| delivery-checkout |29/29|29/29|
| customer-account |27/27|27/27|
| delivery-operator |37/37|37/37|
| persisted-state | legacy assertions pass | legacy assertions pass |

This is93 counted TAP regression cases plus four legacy assertion files per runtime, separate from the36 courier cases per runtime. No whole npm suite, SQL or backend regression was repeated. The raw session-auth logs still contain inherited fixture `REspondse DAta` output; frontend compiler/lint logs still contain stale Browserslist stderr. These are M2, not pristine output, new secret exposure or a failed native command. No network dependency update or logger cleanup was attempted.

### Self-Review, Commit And Limits

Inspected both complete source diffs after implementation. Checked per-mission protection rather than resource-only invalidation, removed and unseen IDs, stable merge/order, independent-row updates, command response priority, explicit future refresh, busy cleanup and unchanged persisted body shape. New freshness metadata contains only IDs/sequences in memory and remains excluded with the whole courier module from general persistence. Existing identity/epoch guards still run before publication and refusal.

`git diff --check` and `git diff --cached --check` each completed0. The staged filename list was compared programmatically to EXACTLY `store/courier.js` and `test/courier-mobile.test.js` before commit. Empty index was confirmed before staging. The commit was created with:

```text
git add -- store/courier.js test/courier-mobile.test.js
git -c core.hooksPath=NUL commit -m "fix: coordinate courier mission privacy freshness"
```

Raw commit log `task-14-fix1-commit.txt` contains nativeExit0. No persistent hook configuration was changed. Post-commit readback F6cd46a4163aa04ba7ce875b19501e51c9203bde9 has empty `git status --porcelain` and empty `git diff --cached --name-only`. B remained0150e247fd3ff874eabeb85857aaa7482d2b430e with empty status; no B source or index mutation occurred. The appended report and raw logs remain intentionally ignored scratch artifacts.

Limits: this is the I1 fix and author verification, pending controller scoped rereview. M1/M2 remain deferred. Actual phone portrait/landscape/screenshots/detector, visual acceptance, full application suites/build and configured Node20 commissioning remain Task17's single planned batch. No visual PASS, full-V1 PASS or Task15 progress is claimed. No nested agents/reviewers, actual recipients/provider/payment/refund/print/call, environment/decryption, original checkout, server management, remote database, push/deploy or merge occurred.

## Round2 N-I1 Confirmed Nonterminal Results

Status: N-I1 implementation and author verification complete, ready for controller scoped rereview of this new fix only. Original I1's nine round1 cases remain green. No controller acceptance, full task gate or visual PASS is inferred. M1/M2 remain deferred and untouched. No Task15 work.

### Scope And Paired Commit

- Read task-14-fix-round1-review.md in FULL first, before other round2 inspection.
- F BASE: 6cd46a4163aa04ba7ce875b19501e51c9203bde9.
- F new commit: **7ee09d3407760b3fc488e4eb051bea82b99e437c**, `fix: reconcile confirmed courier command results`.
- B remains **0150e247fd3ff874eabeb85857aaa7482d2b430e**; no B edits, SQL, migrations or B tests.
- Exactly F/store/courier.js and F/test/courier-mobile.test.js changed. Store13 additions/5 deletions, test109 additions, total122 additions/5 deletions.
- Reused receiving-code-review, TDD/writing-good-tests and verification-before-completion guidance already read in this conversation. Established worktree shell fallback remains applicable after the recorded workspace_fs denial. No original checkout or real environment file was accessed.
- A narrow read of the current B/src/modules/m_deliveryCollections.js producer confirmed that a NEW collection increments delivery.version, whereas an idempotent replay returns toDeliveryView of the CURRENT locked dossier/order without incrementing version again. No backend module was executed for that producer check.

### Targeted Correction

The version exception no longer depends on closed(row). A confirmed server version strictly greater than the currently displayed version can supersede an intervening ACTIVE detail, including assigned/version2 -> in_transit/version3 pickup and unpaid/version2 -> paid/version3 collection. It still requires an existing nonterminal current mission to bypass the cross-resource freshness boundary. It cannot bypass that boundary for a removed or terminal mission.

The command result is never directly published over an equal or higher currently displayed server version, including an intervening active LIST that does not advance the privacy sequence. If that conflict concerns a still-active mission, the already-confirmed operation is reconciled by ONE GET /courier/deliveries/:id using the existing guarded own-detail read. It does not send another mutation, invent a version, merge a paid flag locally, change a monetary amount or select a caller courier identity. The returned confirmed outcome uses the accepted current state projection after this read, preserving financial response metadata such as collectionId/idempotentReplay. If the mission was removed/terminal, the stale response remains suppressed and no reconciliation is used to reopen it.

Confirmed pending/recovery bookkeeping is still settled once the POST is confirmed; ambiguous PROJECTION ordering does not turn a confirmed payment into a new attempt. Unknown outcomes still retain their original body/key. Busy remains held while reconciliation runs and releases normally. The existing six-field persisted collection metadata, actor/epoch guards, read/list privacy sequences, stable order, other missions, availability and own balance authority are unchanged. No other state architecture or UI file was changed.

### Eight New Controlled Cases

All use actual Vue2/Vuex and the existing real loopback HTTP/Axios/fetch boundary, with promises released only after the corresponding request reaches the HTTP fixture. These are behavior assertions, not source-text checks.

1. New pickup: hold confirmed pickup POST; publish pre-commit assigned/version2 detail; release in_transit/version3 confirmation; require current status/version/actions and a non-null confirmed outcome.
2. Explicit pickup recovery: same ordering after an uncertain first reply; the two explicit POSTs retain the identical original key/body.
3. New collection: pre-commit unpaid/version2 detail followed by confirmed paid/version3 projection; require zero server due and deliver action, without losing the nonterminal result.
4. Collection replay with UNCHANGED logistical version: first payment is applied as paid/version3 but reply is lost; reload/current preflight already returns paid/version3; replay retains expectedVersion2 and the original key/body; concurrent paid/version3 detail publishes before replay confirmation. Replay returns current paid/version3/idempotentReplay=true, not an invented version4. The conflict is reconciled by one own GET, with no third POST.
5. Confirmed pickup version3 versus a newer active DETAIL version5: hold reconciliation GET and assert version5/issue is never replaced by the older confirmation; release current server read and retain5.
6. The same lower-version command confirmation versus an active LIST version5. This also guards against a version regression where no detail publication sequence was advanced.
7. A nonterminal version7 reply after authoritative removal cannot restore the mission or initiate a new GET to reopen it.
8. A nonterminal version7 reply after a later terminal detail/version6 cannot replace that terminal authority, despite its numerically higher version. Private address remains absent and no extra GET occurs.

The positive cases also assert stable local order, unchanged other mission, pending cleanup, released loading flags, exact replay bodies and cleared dedicated metadata only after confirmed collection. All prior36 courier cases remain unchanged and pass in the final44-case runs.

### RED/GREEN Evidence

Runtime identities remain native Node22.13.1 and cached Node18.20.8 at `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`. All round2 raw logs are retained in this scratch directory with appended actual `nativeExit` markers.

| Evidence | Native Result | Raw Logs |
| --- | --- | --- |
| Initial focused RED on the live round1 store, eight new cases | exit1 each;2 pass/6 fail. Pickup new/replay remain assigned, new collection remains old, equal financial projection loses outcome, lower-version confirmations omit reconciliation. Two privacy controls pass. | task-14-fix2-red-node22.txt, task-14-fix2-red-node18.txt |
| Initial focused GREEN after narrow publication/reconciliation change | exit0 each;8/8 executed new cases | task-14-fix2-green-focused-node22.txt, task-14-fix2-green-focused-node18.txt |
| Producer-shaped replay refinement on working fix | exit0;8/8 | task-14-fix2-producer-green-node22.txt |
| Initial attempt to run refined witnesses against BASE text using node -e | exit1 each; shell quoting failed BEFORE tests. Not product RED evidence. | task-14-fix2-producer-base-red-node22.txt, task-14-fix2-producer-base-red-node18.txt |
| Corrected BASE characterization through stdin, actual refined replay fixture | exit1 each;2 pass/6 fail; confirmed equal-version replay specifically returns null instead of a confirmed result. | task-14-fix2-producer-base-red-corrected-node22.txt, task-14-fix2-producer-base-red-corrected-node18.txt |
| FINAL full actual working store/SFC/HTTP file | exit0 each;44 tests/44 pass/0 fail/cancel/skip/todo | task-14-fix2-final-node22.txt, task-14-fix2-final-node18.txt |
| Modified-file ESLint | exit0; no ESLint code diagnostics; inherited Browserslist stderr | task-14-fix2-lint.txt |

Node18's filtered runs enumerate the other36 tests as name-filter skips; its filtered logs therefore report44 total,8 executed,36 skipped, rather than Node22's8 selected entries. The FINAL unfiltered runs on BOTH runtimes execute all44 with zero skips. No test is disabled or weakened to make the fix pass.

The initial equal-payment fixture was a defensive same-version/new-response example. It was refined to the actual producer contract: applied-but-lost collection, current paid version3, then same-key replay returning current version3 without another increment. The refined fixture was then checked against the EXACT original BASE store text on both runtimes to retain a true RED witness for its confirmed-outcome assertion. The shell quoting failure was retained separately and corrected; it is not conflated with a product failure.

Exact ordinary focused/final/lint commands, from F:

```powershell
node --test-name-pattern='round2 N-I1' test/courier-mobile.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' --test-name-pattern='round2 N-I1' test/courier-mobile.test.js
node test/courier-mobile.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/courier-mobile.test.js
node node_modules/eslint/bin/eslint.js store/courier.js test/courier-mobile.test.js
```

Exact corrected BASE characterization code and command shape (same code on both runtimes):

```powershell
@'
const fs=require("fs"),path=require("path"),cp=require("child_process");
const target=path.resolve("store/courier.js");
const base=cp.execFileSync("git",["show","6cd46a4163aa04ba7ce875b19501e51c9203bde9:store/courier.js"],{encoding:"utf8"});
const read=fs.readFileSync;
fs.readFileSync=function(file,...args){return typeof file==="string"&&path.resolve(file)===target?base:read.call(this,file,...args)};
require("./test/courier-mobile.test.js");
'@ | node --test-name-pattern='round2 N-I1' -
# Second invocation substitutes the exact cached Node18 executable for node.
```

This comparison only substitutes the exact BASE file text supplied to the existing test module loader. It runs real exported BASE actions/mutations with the CURRENT real Vue/Vuex/HTTP fixture; it does not mock publication decisions, permissions, versions, or HTTP behavior. It reads git object content in F, not an original checkout. No production/test file was reverted, rewritten or shimmed for this comparison. The final44-case runs use the actual working store normally with no read substitution.

Each invocation uses the established raw-capture wrapper:

```powershell
<command> 2>&1 | Tee-Object -FilePath <raw-log>
$task14Exit=$LASTEXITCODE
"nativeExit=$task14Exit" | Tee-Object -FilePath <raw-log> -Append
exit $task14Exit
```

### Affected Regressions

The same bounded seven-file affected batch ran once per runtime after final source edits. Exact per-file command is `node test/NAME.test.js` or `& <cachedNode18> test/NAME.test.js`. Each file's LASTEXITCODE is captured, appended, checked and stops the batch on failure. Both batch sessions finished native0.

| NAME | Node22 | Node18 |
| --- | --- | --- |
| auth-middleware | legacy assertions pass | legacy assertions pass |
| session-auth | legacy assertions pass | legacy assertions pass |
| counter-checkout-store | legacy assertions pass | legacy assertions pass |
| delivery-checkout |29/29|29/29|
| customer-account |27/27|27/27|
| delivery-operator |37/37|37/37|
| persisted-state | legacy assertions pass | legacy assertions pass |

Raw names: `task-14-fix2-regression-node22-NAME.txt` and `task-14-fix2-regression-node18-NAME.txt`. All fourteen contain nativeExit0. This is93 TAP regression cases plus four legacy assertion scripts per runtime, separate from44 courier tests per runtime. Full npm suites, build, SQL, backend validation, browser and screenshots were not repeated. Inherited Browserslist diagnostics and legacy fixture auth logging remain M2, explicitly not pristine output; no dependency/logger cleanup or M1 error-clearing change was made.

### Self-Review And Commit

Read both complete two-file diffs. Verified the changed surface is only confirmed command publication/result reconciliation: no new routes, dependencies, state structures, persistence fields, availability writes, amounts or selected courier identity. The producer-shaped test keeps expectedVersion2 while replay/current projection stays version3. Lower/equal responses do not overwrite the current active DTO before reconciliation; removed/terminal barriers are not relaxed to obtain a newer-looking UI. Independent mission/order and pending/body/loading assertions are retained.

`git diff --check` returned0 explicitly. Confirmed empty index before staging, then staged ONLY the explicit allowed paths and compared the staged name list programmatically against those exact two names. `git diff --cached --check` returned0 explicitly. LF/CRLF informational notices only.

```text
git add -- store/courier.js test/courier-mobile.test.js
git -c core.hooksPath=NUL commit -m "fix: reconcile confirmed courier command results"
```

Commit log: task-14-fix2-commit.txt, nativeExit0. Invocation-local hooks override only; no persistent configuration change. F readback7ee09d3407760b3fc488e4eb051bea82b99e437c has empty source status and empty index. B readback remains0150e247fd3ff874eabeb85857aaa7482d2b430e with empty status. Scratch report/logs remain intentionally uncommitted.

Limits: N-I1 author fix and verification only, pending controller scoped rereview. Original I1 has its existing nine regression cases passing on both runtimes. M1/M2 remain deferred. No Task15, whole application acceptance, real browser/phone portrait/landscape/screenshot/detector or configured Node20 validation was attempted; these remain Task17 work. No agents/reviewers, environment access/decryption, real provider/payment/refund/print/call, original checkout, backend/SQL mutation, server management, remote DB, push/deploy or merge occurred. Temporary loopback listeners are only the existing behavioral HTTP fixtures and were closed.
