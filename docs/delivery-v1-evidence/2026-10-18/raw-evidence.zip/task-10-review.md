# Spec Compliance

**Issues found. Task quality: Needs fixes. Critical: 0; Important: 2; Minor: 0.**

Reviewed BASE `d2f4d623b2f777dc57ce32aab579b96217ccefe0` through HEAD `5d932b0c0afe24b5db9a903059771dc1420eb81f`: two commits, thirteen authorized backend files. The amended brief was read first. The two additional test files are covered by the explicit test-contract reconciliation authorization, and their changes preserve the remaining assertions.

The session, ownership, cookie, proxy, stored-address and independent-auth contracts are implemented, but the exact-origin and cookie-checkout CSRF requirements have two routing gaps below. The existing passing tests do not exercise the accepted double-slash mount boundary.

Cannot verify deployment acceptance from this diff: actual browser cookie storage/SameSite behavior over TLS, live receipt of either OTP channel, and configured whole-application Node20 startup remain commissioning/Task17 work. These are acknowledged limits, not new blocking findings.

## Strengths

- `src/helpers/customerSession.js:38` validates the current SQL shop/customer/login challenge, verification/consumption, expiry and invalidation before insertion. `db/migrations/20261016130000_delivery_customers.sql:100` supplies unique challenge use, and line 104 supplies the composite verified-owner FK. The new consumer correctly accepts verified timeout-origin challenges without requiring `sent_at`; a consumed challenge cannot yield a second session.
- `src/helpers/customerSession.js:85` generates 32 random bytes and persists only a SHA256 digest, with a separate random CSRF hash. Lines 60, 65 and 90 implement tenant-scoped expiry/revocation and a fixed thirty-day lifetime. Lines 81 and 105 bind CSRF to the session and compare valid-length digests with `timingSafeEqual` after exact-origin validation. CAST/DATE_FORMAT and UTC SQL strings avoid numeric-ID rounding and driver timezone dependence.
- `src/helpers/middleware/customerAuth.js:5` distinguishes secure host-only `__Host-smarteat_customer` from local development cookies. Serialization at line 16 sets Path=/, HttpOnly, SameSite=Lax, Secure as applicable, fixed Max-Age and Expires without Domain. Secure requests do not accept the weaker development name.
- `src/helpers/middleware/customerAuth.js:28` attaches only `req.customerSession`, checks the existing authenticated checkout tenant for optional attachment, and leaves staff/service-point identity fields intact. `src/routers/r_customers.js:10` mounts personal endpoints independently, while its staff endpoints retain their own authentication. The clipped controller prologue at `src/controllers/c_customers.js:16` still checks the current staff account, tenant and delivery permission.
- `src/helpers/customerCors.js:20` implements exact-origin credentialed responses, Vary, bounded preflight methods/headers and early OPTIONS termination for recognized paths. Line 48 configures Express trust from literal IP/CIDR entries, defaults to false and rejects an invalid list. `index.js:71` retains the raw Stripe parser before JSON parsing; personal routing precedes stale staff-header authentication.
- The personal address adapter derives ownership from the session, rejects posted owner/coordinate fields, and reuses the existing services. `src/modules/m_customers.js:131` renews an owned stored address with a new fifteen-minute proof without geocoding. `src/services/deliveryGeocoding.js:150` sends only postal fields, and its line 12 candidate projection filters supplier-private data. New DTOs explicitly omit raw session tokens, OTPs and internal hashes; the added production paths do not log them.
- The new tests exercise real SQL, HTTP, crypto, current staff authentication, exact IDs, UTC behavior, challenge/session races, rollback, tenant isolation, link conflicts, zero-call stored renewal and forged-XFF quotas. Their provider doubles stay at HTTP boundaries. Package changes retain existing commands and dependencies and add direct CommonJS `cookie` 0.7.2 with its nested legacy Express version preserved. The report contains pinned official version-specific cookie API notes; no additional SDK lookup was needed.

## Issues

### Critical

None.

### Important

**I1. Accepted mount-boundary paths bypass the exact-origin policy.** `src/helpers/customerCors.js:10` and `src/helpers/customerCors.js:17` classify the raw original URL by removing the prefix once, then requiring a single leading slash before `customer-auth`/`customer`. Express accepts `/baseurl/api/v1//customer-auth/challenges`: mounting the router consumes the extra boundary slash and dispatches `/customer-auth/challenges`, while this classifier sees `//customer-auth/challenges` and returns false. Both the exact-origin middleware and the legacy-wildcard exclusion consequently miss the request. Public challenge and verification handlers have no subsequent CSRF guard, so an explicitly forbidden Origin can reach these mutations, contrary to the brief. Absolute-form request targets produce the same classifier mismatch; the ordinary double-slash path is sufficient to establish the finding.

Focused reproduction with the installed Express and actual `buildCustomerCors`: POST from `https://evil.test` to the canonical challenge path returned 403, but POST to the double-slash variant reached a witness route with 200 and `scoped:false`. The witness replaced only the business handler, so this proves dispatch/policy disagreement without sending an OTP. Uppercase and trailing-slash canonical variants returned 403; encoded static-segment variants did not reach the witness.

Fix by making path scoping agree with Express dispatch, or rejecting noncanonical request targets before every customer router. Cover the accepted extra boundary slash and absolute-form handling in focused tests. Fixing checkout CSRF alone does not fix public challenge/verify origin enforcement.

**I2. Checkout attachment and CSRF are mounted at a different routing boundary from the actual mutation.** `index.js:87` registers them on the full application path `${prefix}/orders/checkout`, whereas the mutation is registered inside the prefix-mounted orders router at `src/routers/r_orders.js:13`. `/baseurl/api/v1//orders/checkout` misses the application-level guard but reaches that router's checkout handler. Thus a valid existing staff/service-point bearer plus customer cookie can reach checkout without the required customer attachment or CSRF check. Existing bearer authentication remains required; this is a bypass of the new customer policy, not anonymous order creation.

Focused reproduction using the exact application-route/prefix-router topology and installed Express: with customer cookie, allowed Origin and no CSRF, the canonical path hit the guard and returned 403; the double-slash path reached the mutation witness with 200, `attachmentRan:false`, and legacy `Access-Control-Allow-Origin: *`. No SQL/payment/provider handler was invoked. Even correcting I1's CORS classifier would still allow this missing-CSRF case from an allowed Origin.

Fix by attaching the customer middleware to the same routed checkout handler after existing authentication, or by enforcing a shared rejection of every noncanonical path before both dispatch layers. Preserve existing guest/staff authorization. Add a regression asserting that every accepted checkout spelling either runs attachment and CSRF or is rejected before mutation.

### Minor

None newly identified. Previously acknowledged TAP environment/fault diagnostics remain deferred and nonblocking as instructed.

## Checks And Scope

- Read the complete supplied `task-10-review.diff` once, sequentially, without regenerating it or running Git commands. Read worker-context, integration notes, common contracts, specification section 8 and HTTP/privacy constraints, Task9 final/fix evidence, and the full Task10 report including final test-contract reconciliation. Used `superpowers/subagent-driven-development/task-reviewer-prompt.md`; no agents were dispatched.
- Changed-source exception: read only `src/controllers/c_customers.js:1` through its prologue because the diff starts mid-controller, to verify staff authorization after moving the router; read only `index.js:66` through the raw-parser boundary because that middleware begins outside the hunk context. No other changed source was reread.
- Named risk, checkout mutation coverage and unchanged authorization: inspected `src/routers/r_orders.js`, the route declarations in `src/routers/r_stripe.js` and `src/routers/r_delivery.js`, `src/helpers/middleware/auth.js`, and the checkout adapter at `src/modules/m_checkout.js:543`. The actual new checkout mutation is `/orders/checkout`; other inspected legacy mutations retain bearer guards and do not derive authority from the customer cookie. No general payment audit was performed. This task provides the optional context; downstream use of that context for order linkage is not claimed here.
- Named risk, stored-address ownership and supplier-private fields: inspected the participating Task8 address service, the Task2 resolution definition and geocoder projection/request construction. Owned customer/address lookups are SQL-scoped; stored renewal contains no supplier call; new postal resolution uses the existing filter and signer.
- Named risk, Shop/customer/challenge FK order: inspected only the participating customer-auth reserve/consume definitions, archive Shop/owner-linked insert definitions, and session FK declarations. Session creation takes Shop SHARE before customer SHARE and challenge UPDATE. The personal adapter takes Shop before Task8's customer UPDATE. Task9 consumed-challenge verification returns before trying another ownership mutation, and late-send persistence only touches open challenges. No additional concrete lifecycle defect was established; no speculative transaction rewrite or race rerun is requested.
- Named risk, actual Express proxy behavior: inspected the allowlist implementation and the diff's real HTTP assertions for both `req.ip` and `req.secure`, default false, invalid entries, trusted/untrusted peers and the rotating-XFF SQL quota. The tests cover actual Express behavior rather than a supplied service IP.
- Named risk, route matcher disagreement: ran only the two narrow in-memory loopback Express probes described under I1/I2. Both exited 0 and closed their servers. These are routing/guard witnesses, not actual OTP, payment, browser or production-boot tests. No suite, heavy race or repeated schedule was run.
- Read existing final log tails: new CORS 3/3 and session SQL/HTTP 16/16 on Node22 and Node18; reconciled existing address SQL 11/11 and auth SQL 23/23 on both runtimes, zero failures/skips. Auth logs retain `link waited for Shop; SQL failures: none`. The single existing npm-test log ends with the legacy staff/admin tests passing; its exit 0 and eleven focused legacy-file results are recorded in the implementer's report. No npm or SQL suite was rerun.
- Missing customer configuration is handled lazily in the new operation paths; the actual-index test constructs the middleware stack with no customer auth secret and returns unavailable channel metadata. It deliberately suspends startup readiness, so it is not evidence of a configured whole Node20 boot. Node18 legacy import bridges remain test-only.
- `workspace_fs` was attempted and denied the external worktree; used the documented shell-read fallback. No environment secret file, remote resource, provider operation, source/index/HEAD mutation, migration or Git-state operation was performed. The sole written artifact is this requested scratch review.

## Assessment

**Spec compliance: Needs fixes. Task quality: Needs fixes. 0 Critical / 2 Important / 0 Minor.**

The core session and ownership implementation is supported by meaningful SQL/HTTP evidence, and the authorized test reconciliation is correct. The two demonstrated dispatch mismatches leave required origin and CSRF protection incomplete; the worker should fix them before approval.
