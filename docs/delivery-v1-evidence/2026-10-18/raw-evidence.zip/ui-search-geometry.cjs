const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const qa = require('./ui-qa.cjs');
async function main() {
  const browser = await qa.chromium.launch({ channel: 'chrome', headless: true });
  const results = [];
  try {
    for (const width of [1440, 390, 320]) {
      const o = await qa.openContext(browser, 'admin', { width, height: 844 });
      await qa.go(o.page, '/livraison');
      await o.page.locator('section[aria-label="Commandes livraison"] .se-search-field').waitFor();
      const actual = await o.page.locator('section[aria-label="Commandes livraison"] .se-search-field').evaluate(el => {
        const r = el.getBoundingClientRect();
        const input = el.querySelector('input');
        const box = input.getBoundingClientRect();
        return { viewport: innerWidth, left: r.left, right: r.right, width: r.width, inputWidth: box.width,
          overflow: document.documentElement.scrollWidth > innerWidth + 1, minWidth: getComputedStyle(el).minWidth };
      });
      assert.ok(actual.left >= 0 && actual.right <= width + 1 && actual.inputWidth > 0 && !actual.overflow, JSON.stringify(actual));
      results.push(actual);
      await o.context.close();
    }
    assert.deepEqual(qa.report.errors, []);
    assert.deepEqual(qa.report.unmatchedApi, []);
  } finally {
    await browser.close();
    fs.writeFileSync(path.join(__dirname, '../ui-search-geometry.json'), JSON.stringify({ results, pageErrors: qa.report.errors, unknownApi: qa.report.unmatchedApi }, null, 2));
  }
  process.stdout.write(JSON.stringify(results) + '\n');
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
