# Task 4 Integration Notes

Disjoint controller inspection of original source; reconcile against Task3 changes before editing.

## Actual archive path

- `src/modules/m_orders.js` has a live transaction builder near the top and legacy/dead definitions later. The final `module.exports.mArchiveOrder = orderArchiveModule.mArchiveOrder` selects the transactional path. Modify that actual export, not only later legacy code.
- Current transaction locks shop, then active order, then details. It copies a literal `ARCHIVE_ORDER_FIELDS` allowlist, inserts archive/details/customization snapshots, deletes active snapshots/customizations/details/order. Include new delivery/customer/fulfillment links and durable preparation snapshot before deletion. Delivery must never FK-cascade with the active representation.
- Avoid introducing order->delivery locks when dispatch/collection resolve delivery->order. Pre-read the link then acquire the consistent delivery/commercial row order, revalidating under locks, while respecting existing shop serialization. Do not fix potential cycles merely by fake lock-count tests.

## Payments and replay

- Existing `m_payments.markPaymentSucceeded` does an initial nonlocking payment lookup, then locks active order before payment row. Active-only lock/find queries fail after archive today. Preserve commercial/payment authority; do not create mutable paid state on deliveries.
- Duplicate successful webhook after archived paid order must return idempotently without another stock settlement/payment. Refund needs the stable original order link and tenant-correct active/archive resolution, not confusing archive PK with original active PK.
- Existing Terminal `lockPaymentSession` deliberately locks allocation order IDs in sorted order BEFORE payment session. This avoids a tested start/finalization cycle. Do not invert it casually or make Terminal wait for a delivery lock while a delivery mutation waits on that order.

## Fee/discount allocation risk

- Actual `src/services/stripeTerminalPayments.js` maps each entire `o.subtotal` into `helpers/stripeTerminal.allocateTerminalOrderAmounts`, then applies payment-time discount to the entire amount. For delivery this would discount the fee and may cross minimum/free thresholds without a new accepted quote.
- Actual archive path derives a Terminal line discount from `sum(orderDetails.total) - terminalAllocation.amount_cents`. With products 20 + fee4 already included in allocation24 this becomes -4, an invalid discount. Delivery must keep accepted product and fee snapshots separate and validate their sum against settled allocation; do not redistribute the fee into product VAT/details.
- Respect the approved explicit unpaid repricing/reconfirmation path. An inline Terminal discount must not silently change a delivery charge or become a charge on an unconfirmed new total. Choose the smallest compatible guarded behavior and report any necessary interface ruling; do not build a second payment engine.
- If the actual allocation helper itself must change, `B/src/helpers/stripeTerminal.js` is the existing owner; the plan's service/module list does not mean duplicating that helper's core algorithm elsewhere. Keep changes narrow and carry new allocations through archive/refund/receipt contracts.

## Manual settlement boundary

- Current `c_orders.collectOrderPayment` performs a nonlocking read then unconditional legacy `mUpdateOrders` to paid. Delivery needs a scoped transactional path that checks current payment/provider state and cannot overwrite a concurrent courier/Stripe settlement.
- Current `buildCashRegisterArchiveFields` can settle an unpaid legacy order from an explicit payment method. Preserve legitimate cashier settlement but do not let a kitchen-only archive falsely collect a delivery, overwrite a pending Stripe intent, change a courier cash liability or rewrite accepted discounts.
- Controller settlement ruling in task4 brief: delivery price changes only through explicit revision/requote, no new inline delivery discount on legacy collect/archive/Terminal. Task15 adapts `F/pages/cashregister/payout/_id.vue` and focused payout tests; non-delivery path unchanged.

Confirmed original `test/order-editing.test.js`, `m_orderEditing.js`, `c_orderEditing.js` exist. No controller edits were made during this inspection.
