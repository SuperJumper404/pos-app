# Task 6: Manual Courier Collections

## Status

Implementation and author self-review complete in the six Task6-owned backend files. Task6 SQL/HTTP tests pass on native Node22.13.1 and Node18 with the fixture-only real Nano ID ESM import bridge. Task3 checkout, Task4 archive/payment and focused legacy regressions pass. Independent review/acceptance belongs to the controller.

Integration is **not fully green**: the unchanged Task5 full dispatch test stops at its obsolete assertion that the reserved collect-payment endpoint returns404. It now correctly returns400 for that test's empty body. This is an ownership boundary, not an unreported passing suite. The package SQL chain will stop there before reaching the appended Task6 command until that assertion is updated.

Exact indispensable extra-owner proposal: permit an edit only to `B/test/delivery-dispatch.integration.test.js:288`, replacing its POST collect-payment empty-body404 assertion with a400 assertion plus `JSON.parse(response.body).error === 'DELIVERY_REQUEST_INVALID'`. Keep the adjacent GET cash-balance404 assertion and every other expectation intact. This file was **not edited**. No production workaround or conditional route was added to preserve the obsolete404 behavior.

- B: `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos`.
- F: `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app`.
- B branch: `feat/delivery-v1`.
- BASE: `799b555b98c7fa82b6cead67ab66da275e4491b4`.
- F compatible HEAD: `6f694519d0db9ee631fe9d85550af71165dac293`, unchanged.
- Task6 commit: `af525158c5fc79f3f1f42d15a5f1ff64378859f3`, `feat: collect delivery cash and external card payments`.

Read task-6-brief first, then worker-context/integration-notes, common contracts, specification7/10/11, Task4 interfaces/lock protocol and Task5 interfaces/current-account/lock protocol/final Fix Round1. Tasks1-5 were not reimplemented. `workspace_fs` denied the paired worktrees, so shell reads were used as worker-context explicitly permits. No ledger or original checkout was changed.

## Files

Exactly the brief's six B files:

1. New `src/modules/m_deliveryCollections.js`: injectable transaction/repository service and connection-only SQL repository.
2. New `test/delivery-collections.integration.test.js`: actual disposable SQL, real HTTP/authentication, concurrency, rollback, precision and privacy coverage.
3. `src/controllers/c_courier.js`: collection adapter using the existing actor/response/error/no-store adapters.
4. `src/routers/r_courier.js`: POST route on the existing authenticated courier namespace.
5. `src/modules/m_deliveryOrders.js`: eligible own in-transit `collectPayment` action hint through the existing projection.
6. `package.json`: append the collection test to `test:delivery:db`; every previous command and the unit-test script remain unchanged.

This report and generated test logs are authorized ignored F scratch artifacts, not frontend source changes. No dependency, migration, shared transaction-helper or m_orders edit.

## API and Authority

`buildDeliveryCollections({repository?, runInTransaction?, clock?}).collect({actor, deliveryId, method, expectedVersion, idempotencyKey}) -> {collectionId, delivery, idempotentReplay}`.

POST `/baseurl/api/v1/courier/deliveries/:id/collect-payment` accepts exactly:

```json
{"method":"cash","expectedVersion":1,"idempotencyKey":"device-request-key"}
```

`method` is exactly `cash|external_card`. The body cannot declare amount, courier or actor. Missing/unknown fields fail400. Actor comes from the existing authenticated staff request, whose role/active state is DB-derived; the service again locks/reloads that account and requires current active role6 and current own same-shop assignment before any replay or private projection. A forged role6 claim for the cashier fails; a stale admin claim for the actual current courier cannot expand authority and can still perform this own courier action. Inactive, wrong-shop, reassigned, service-point and staff-without-own-courier-mission requests fail.

Fresh collection requires expected version, in_transit, no closed_at, preparation3 and eligible unpaid commercial state. Shared `assertDeliveryCollectionAllowed` rejects paid, refunded, pending/unknown/provider/attached Stripe or Terminal state. Persisted creating/processing Terminal allocations also reject even with an unpaid/null-intent header. A current payment-row check rejects non-canceled detached provider/payment records. Issue requires the restaurant's existing reasoned resolution before collection. Amount is always shared `toDeliveryView(...).remainingDueCents`, with existing financial snapshot validation and safe integer cents; zero is refused. The existing signed-INT commercial payment capacity is explicitly checked at2147483647 cents instead of relying on SQL overflow.

## Payment Record Source and Atomicity

Reuse the existing pure `buildCashRegisterCollectionFields` and `assertDeliveryCollectionAllowed`; do not call the staff-only, own-transaction `m_orders.collectDeliveryOrderPayment`. The service updates the actual commercial representation under its supplied connection, inserts one `payments` record, inserts one immutable `delivery_payment_collections` record referencing it, increments the logistical version and appends one `collectPayment` event, all before a single commit.

The legacy `payments.stripe_payment_intent_id` column is NOT NULL/unique even for the new manual record. Its value is explicitly `manual_delivery:<exact delivery ID>:<new logistical version>`, a local identity, never a provider intent. `payment_method` is the existing canonical cash/card label, status is succeeded, fee is0, currency eur, amount is server-derived. Commercial `payment_provider` and `stripe_payment_intent_id` remain null; stripe_charge_id remains null. `external_card` is preserved explicitly in the linked immutable collection and event as a manual independent-TPE declaration, never Stripe verification.

`payments.order_id` always uses `delivery.origin_order_id`, including replay after archive. Updating an archived commercial row uses `resolveDeliveryOrder.order.id`, its actual archive PK; those are different identities. Actual SQL tests archive the paid order and verify replay still references the original payment order ID.

Cash custody/debt derives solely from immutable collections with `method='cash'`; the2400 fixture contributes2400. `external_card` contributes0 cash debt. There is no mutable delivery paid/debt field, drawer entry, second sale, stock settlement, inventory reservation transition or automatic refund. The existing journal immutability triggers refuse UPDATE/DELETE. Task7 will allocate/remit the cash and distinguish it from drawer receipts.

Injected errors at appendCollection (after actual paid update/payment INSERT) and appendEvent (after actual collection INSERT) are observed on the same connection and then thrown. Independent reads after rollback prove the order, payments, collections, version, events, reservations, stock and movements match their exact before rows. A retry using the rolled-back key succeeds once.

## Clock and Locking

Transaction order is **shop closure barrier -> original commercial row or actual archive -> dossier -> effective charge current read -> active actor -> collection replay lookup -> provisional commercial payment -> provider/payment reconciliation -> immutable collection/version/event**. Resolve uses Task4's commercial-first resolver and current charge read. All queries, inserted-ID reads and clock queries use the runner's SAME connection. No nested transaction, default-pool read inside the transaction, late shop/FK parent acquisition, provider call or global retry is introduced.

The shop is selected FOR UPDATE first, before any identity snapshot or commercial/account lock. This serializes same-shop collections with archive, closure and future remittance. Actual performance_schema waits prove two independent couriers wait first on shop while the barrier holder can still lock both orders and accounts; neither collector has called its clock during the wait. After release, both post once with times >= the precise cutoff. Task5's existing local dispatch-only retry remains untouched; its actual I1 deadlock/retry regression passes.

Replay lookup reads the immutable collection without a missing-key FOR UPDATE lock. Its RR snapshot starts after the shop barrier, so a preceding collection is visible; shared event-key uniqueness enforces conflicts without first taking a global missing-journal gap lock. Cross-action key collision is tested to roll back the provisional payment/collection as well.

Self-review added a deterministic two-SHOP race, pausing both after their clocks and before payment INSERTs. The first implementation reproduced a missing-payment-range `ER_LOCK_DEADLOCK`. Moving the current payment reconciliation read after the provisional own INSERT removes the empty-range/opposing-insert-intention cycle. The next run exposed MySQL choosing a PRIMARY full scan on the tiny payments table; InnoDB diagnostics showed each collector held its own payment and waited on the other's. The final query explicitly uses the existing `order_id` index, excludes its own inserted payment ID and performs a current FOR UPDATE read of only the owned order's range. Conflicts roll back the provisional writes. Final same-shop and cross-shop tests pass without any retry.

### Exact interface for Task7

The production default is repository `postingTime({connection})`, executing:

```sql
SELECT DATE_FORMAT(UTC_TIMESTAMP(6),'%Y-%m-%d %H:%i:%s.%f') AS now
```

It runs after acquiring the shop barrier and locked commercial/account eligibility checks. It returns a UTC SQL timestamp string with exactly six fractional digits; no JS Date conversion/rounding is used for the production reference clock. `appendCollection({collection,connection})` receives that string in `collection.created_at`, `appendEvent({event,connection})` receives the identical string in `event.created_at`, and the commercial payment receives it in `payment.created`. SQL parameters preserve the full string. The repository-boundary test asserts all six digits for default and explicit clocks.

Explicit fixture `clock({connection})` may be async and return the exact SQL6 string; Date/ISO-like values are converted with millisecond precision padded to six digits. Only trusted injected tests choose their date, never request bodies. Default period comparisons must keep using the DB UTC microsecond string.

Current foundation columns remain DATETIME(0), and therefore cannot store the fractional part supplied by this interface. **Task7 owns the financial DATETIME(6)/default migration and closure compatibility. No timestamp migration was added here.** Upgrade collection/remittance/adjustment financial storage as planned and retain this exact string interface; do not replace the default with JS milliseconds, seconds slicing or a pre-barrier timestamp. This task does not claim completed cash-period integration before that work.

New delivery/collection/event IDs are exact decimal strings, via SQL CAST and CAST(LAST_INSERT_ID() AS CHAR) on the insertion connection. The tests use production mysql2 BIGINT defaults, not only the harness's string-friendly pool, and prove9007199254740993 remains exact. Numeric new delivery IDs are rejected400 so the service cannot accept an already-rounded caller Number. Legacy order/payment FKs retain their schema types.

## Replay and Privacy

Hash covers operation, server actor/shop, exact delivery ID, method and expectedVersion. Same key/method/payload returns the original collection ID and idempotentReplay true, before optimistic version checks and without writing anything. Different method/version/delivery/actor conflicts409 `DELIVERY_IDEMPOTENCY_CONFLICT`. New key on a paid order fails409. A key already used by dispatch's event journal also conflicts and rolls back every provisional financial write.

Current active account and own assignment are rechecked before lookup/projection. Both fresh and replay results use shared `toDeliveryView` on the current commercial representation. Neither collection nor event stores a frozen private delivery DTO. Closed replay after archive has the current delivered/payment summary and no address/contact/items; reassigned and inactive replay fail. Checkout's accepted replay is never consulted as payment authority. Existing tracking/contact redaction, response envelope and Cache-Control:no-store behavior are reused.

## RED/GREEN Commands and Outputs

All runtime commands ran in B. Every SQL invocation explicitly supplied the authorized disposable URL and ENV_FILE=NUL; no real env or application DB fallback was used:

```powershell
$env:ENV_FILE='NUL'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:JWTKEY='task6-disposable-jwt-key-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task6-fixture/'
```

The password/JWT key above are disposable fixtures only. The running container was `smarteat-delivery-v1-tests`, MySQL8.0.33 on loopback33319. `withDeliveryDatabase` creates/drops only random `smarteat_delivery_test_*` databases. Native Node was `v22.13.1`. No SQL group is skipped when configuration is absent; the helper rejects missing explicit URL.

### Initial RED

```powershell
node test/delivery-collections.integration.test.js
```

Before production code, exit1:

```text
Loaded env file: NUL
FAIL SQL real HTTP concurrent same key collects 2400 once and lost response replays: AssertionError
actual [404, 404], expected [200, 200]
Error: Cannot find module '../src/modules/m_deliveryCollections'
```

The very first fixture attempt tried JSON parsing the HTML404 response; its pool-options spread also emitted mysql2 option warnings. The fixture was corrected to read status/non-JSON responses and use explicit production-style pool options, then the expected404 assertion RED above was observed before implementation.

### Additional RED and investigation

Same command, before cross-shop lock correction, exit1:

```text
FAIL SQL independent shops do not deadlock on missing payment-record gaps: AssertionError
,ER_LOCK_DEADLOCK
```

It repeated after only moving reconciliation after INSERT. Actual SHOW ENGINE INNODB STATUS on the disposable server identified the PRIMARY scan of the two provisional rows, motivating the explicit existing order_id index. The final implementation passes the same deterministic race. A separate test-query typo initially used REQUESTED_ENGINE_LOCK_ID; corrected to MySQL's actual REQUESTING_ENGINE_LOCK_ID. This was a fixture error, not claimed as product RED evidence.

Strict new-ID RED is retained in `task-6-id-red-node22.txt`. Same SQL command before the final type guard, exit1:

```text
FAIL SQL strict body, method, cents, actor and mission guards leave no financial writes:
AssertionError [ERR_ASSERTION]: Missing expected rejection.
```

It attempted a numeric new delivery ID. Final code requires a string and returns400.

### Final GREEN

After the final production edit, both commands below exit0,13 groups each:

```powershell
node test/delivery-collections.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-collections.integration.test.js
```

Final full logs: `task-6-green-node22.txt`, `task-6-green-node18.txt`. Each exact output:

```text
Loaded env file: NUL
PASS SQL real HTTP concurrent same key collects 2400 once and lost response replays
PASS SQL shared projection offers collection only on eligible own in-transit missions
PASS SQL independent shops do not deadlock on missing payment-record gaps
PASS SQL concurrent different keys refuse already paid and external card creates zero cash debt
PASS SQL strict body, method, cents, actor and mission guards leave no financial writes
PASS SQL pending Terminal allocations and detached uncertain provider records block substitution
PASS SQL issue needs restaurant resume and event-key collisions roll back the whole collection
PASS SQL actual concurrent Stripe success stays authoritative without second payment or stock movement
PASS SQL post-payment pre-collection and post-collection pre-event failures roll back actual rows
PASS SQL current replay privacy survives archive closure reassignment suspension and role changes
PASS SQL exact BIGINT identities under production pool defaults and cross-dossier key conflicts
PASS SQL independent couriers serialize at shop before commercial/account locks and clock
PASS SQL posting boundary preserves six digits for DB and explicit clocks
```

These final commands were logged using PowerShell `*> <scratch>/task-6-green-nodeNN.txt`, then `$task6Exit=$LASTEXITCODE`, `Get-Content` of the log, and `exit $task6Exit`. The Node18 log uses the existing cached Node18 executable, with actual Nano ID bridged only inside the fixture. No claim of repaired unbridged production Node18 boot.

The actual webhook race invokes production `buildStripeWebhookEventHandler` with only its external charges.retrieve boundary stubbed. It observes both the webhook and collector blocked on the actual commercial row in performance_schema before releasing a fixture lock; the webhook succeeds, manual collection refuses, one provider payment remains, no manual collection or extra stock movement occurs.

### Affected regressions

With the same explicit environment, all below exit0:

```powershell
node test/delivery-checkout.integration.test.js
node test/delivery-archive-payments.integration.test.js
node test/delivery-authorization.test.js
$env:TASK5_REVIEW_FILTER='I1'
node test/delivery-dispatch.integration.test.js
```

Task3 ends `delivery checkout SQL tests passed`, preserving its existing diagnostic output. Task4 prints13 PASS SQL groups and ends `delivery archive/payment SQL tests passed`. The authorization test prints `PASS HTTP current-role isolation, exact surfaces, customer rejection, own profile/logout and personal PIN login`.

The opt-in I1 Task5 run prints exactly:

```text
Loaded env file: NUL
PASS SQL I1 independent pickups survive a one-shot real missing-journal gap deadlock
PASS SQL I1 retry is bounded and excludes unconfirmed rollback begin commit and network errors
```

Focused legacy batch, exit0 (each node command's exit checked before continuing):

```powershell
$task6Tests=@('cash-register-payment','stripe-payment','stripe-terminal-locking','payment-method-standardization','order-delete-hidden-archive','delivery-authorization')
foreach ($task6Test in $task6Tests) {
  node "test/$task6Test.test.js"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
```

Outputs include `cashRegisterPayment tests passed`, `stripePayment tests passed`,29 Terminal locking PASS cases, `payment method standardization tests passed`, `order delete hidden archive contracts passed`, and the authorization PASS above. Existing fixture-only archive/delete diagnostics were present, not new provider activity.

### Known full dispatch regression

With no TASK5_REVIEW_FILTER:

```powershell
node test/delivery-dispatch.integration.test.js
```

Exit1, six pre-HTTP SQL groups pass, then:

```text
AssertionError [ERR_ASSERTION]: 400 == 404
at test/delivery-dispatch.integration.test.js:288:14
actual: 400
expected: 404
```

The later full Task5 groups did not execute in that invocation. Their green status is not claimed. The scoped I1 run above is separate evidence only. The owned Task6 HTTP test explicitly proves the same empty-body request returns400 and DELIVERY_REQUEST_INVALID. This is why the exact single-file ownership amendment at the start is necessary. Full `npm run test:delivery:db` and whole baseline `npm test` were not redundantly rerun; the SQL chain's known stop is disclosed.

`node --check` passes for all five changed/new JS files. `git diff --check` passes, with only existing LF/CRLF conversion notices for three touched legacy files.

## Self-Review

Performed the review personally, no agents/reviewers: inspected the complete scoped production diff and tests, checked account authority/replay ordering, active/archive identities, exact insert IDs, method/amount validation, immutable linking/results, provider/Terminal checks, rollback boundaries, inventory non-use, scope/privacy, current projection and clock precision. Reproduced and fixed the independent-shop InnoDB cycle through actual SQL, without transaction retries. Confirmed the shared helper and generic cashier/controller behavior were unchanged. Reviewed the package script to retain every existing command.

No unresolved owned production defect identified. Residual integration concerns are the explicitly unowned Task5 assertion and Task7 precision/closure work. This is author verification, not independent task approval or completed delivery V1 commissioning.

## Commit and Limits

Scoped commit command required by the brief:

```powershell
git add -- src/modules/m_deliveryCollections.js test/delivery-collections.integration.test.js src/controllers/c_courier.js src/routers/r_courier.js src/modules/m_deliveryOrders.js package.json
git diff --cached --check
git -c core.hooksPath=.git-hooks-disabled-task6 commit -m "feat: collect delivery cash and external card payments"
```

Commit command exit0:

```text
[feat/delivery-v1 af52515] feat: collect delivery cash and external card payments
6 files changed, 570 insertions(+), 2 deletions(-)
create mode 100644 src/modules/m_deliveryCollections.js
create mode 100644 test/delivery-collections.integration.test.js
```

`git rev-parse HEAD` returned `af525158c5fc79f3f1f42d15a5f1ff64378859f3`. `git status --short` in B and `git -C ../pos-app status --short` both returned empty, exit0. The staged whitespace check exited0. `git config --get core.hooksPath` returned `.githooks` before and after the commit; only the commit invocation used the override. The report/logs remain ignored F scratch artifacts. No frontend commit was made.

No real provider, OTP, email or WhatsApp send, environment decryption, remote/app DB operation, migration outside the random disposable DBs, push, deployment, merge, original-checkout edit, ledger rewrite, unowned production/test edit or subagent/reviewer occurred. No real environment file was opened/staged. Test servers, pools and disposable databases use finally cleanup. Task7 owns financial timestamps/defaults, cash balances/remittances/closure snapshots, and later tasks own UI/provider commissioning.

## Bounded Integration Completion: Final Status

**Task6 domain implementation and bounded integration completion are complete and verified. Controller full-range review is pending.** This section supersedes the earlier integration-pending assessment; all original failure evidence above is retained as history. The extra scope is now explicitly authorized by the updated task-6-brief and the user's resume instruction. The deliberately pending Task7 DATETIME(6)/default upgrade is not a Task6 domain blocker and was not implemented here.

Original implementation commit is preserved: `af525158c5fc79f3f1f42d15a5f1ff64378859f3`. Test-only follow-up: **`39f116934f9873eef70fd56836799493b6100467`**, `test: update courier collection route contract`.

### Exact Amendment and Self-Review

Only `B/test/delivery-dispatch.integration.test.js` changed in the follow-up. Its obsolete POST empty-body404 assertion was replaced with a captured actual HTTP response, a400 status assertion, and exact actual response error-code assertion:

```js
assert.equal((await http("/courier/cash-balance")).status, 404);
const emptyCollection = await http("/courier/deliveries/41/collect-payment", { method: "POST", body: {} });
assert.equal(emptyCollection.status, 400);
assert.equal(JSON.parse(emptyCollection.body).error, "DELIVERY_REQUEST_INVALID");
```

Reviewed the full follow-up diff personally: one file,3 insertions/1 deletion. The adjacent GET cash-balance404 and every other assertion are unchanged. No new production behavior, package-script change, test filter, dependency or scope expansion. The existing RED evidence is the actual `400 == 404` failure above, now resolved by the authorized contract correction rather than a production workaround. `node --check test/delivery-dispatch.integration.test.js`, unstaged and staged whitespace checks all exit0; only the usual LF/CRLF conversion notice appeared before staging.

### Exact Verification Environment

Every one of the three completion runtime commands below was a separate PowerShell invocation in B, prefixed with the following explicit environment and filter clearing:

```powershell
$env:ENV_FILE='NUL'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:JWTKEY='task6-disposable-jwt-key-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task6-fixture/'
Get-ChildItem Env: | Where-Object { $_.Name -match 'FILTER' } | ForEach-Object { Remove-Item -LiteralPath ('Env:' + $_.Name) }
$env:TASK5_REVIEW_FILTER=''
$env:TASK4_TEST_FILTER=''
```

This removes inherited filter variables and explicitly clears both filters used by the registered delivery tests. No real environment file was read or decrypted. The URL/JWT/image values are inert local test fixtures. SQL still uses only the disposable helper's random databases on the authorized loopback MySQL server; no app/remote DB or fallback.

### Complete Task5 SQL on Both Runtimes

Both full test commands exit0,27 PASS SQL groups each, without TASK5_REVIEW_FILTER:

```powershell
node test/delivery-dispatch.integration.test.js *> ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-task5-node22.txt
$task6Exit=$LASTEXITCODE
Get-Content ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-task5-node22.txt
exit $task6Exit
```

```powershell
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-dispatch.integration.test.js *> ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-task5-node18.txt
$task6Exit=$LASTEXITCODE
Get-Content ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-task5-node18.txt
exit $task6Exit
```

Runtime versions checked: Node22.13.1 native and Node18.20.8. Node18 uses the existing fixture-only real Nano ID import bridge; production imports were not changed. Both complete logs are retained beside this report and contain all27 groups, including the formerly unreachable actual HTTP group and final C1/I1/I2/M1 regressions. Both print:

```text
PASS SQL actual HTTP courier/operator routes, stale admin JWT, availability and active-account reload
PASS SQL I1 independent pickups survive a one-shot real missing-journal gap deadlock
PASS SQL I1 retry is bounded and excludes unconfirmed rollback begin commit and network errors
PASS SQL I2 all old operational work remains enumerable beyond 100 newer terminal missions
PASS SQL M1 known registration diagnostic is captured without stdout noise
```

### Registered Node22 SQL Chain: One Run

After both complete Task5 runs passed, the registered SQL chain was run **exactly once** in this completion pass, with the same explicit environment and all filters cleared:

```powershell
npm.cmd run test:delivery:db *> ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-chain-node22.txt
$task6Exit=$LASTEXITCODE
Get-Content ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-6-completion-chain-node22.txt
exit $task6Exit
```

Exit0. Actual npm output confirms the unchanged registered commands were executed in order:

```text
> express-pos@1.0.0 test:delivery:db
> node test/delivery-schema.integration.test.js && node test/delivery-quotes.test.js --database && node test/delivery-checkout.integration.test.js && node test/delivery-archive-payments.integration.test.js && node test/delivery-dispatch.integration.test.js && node test/delivery-collections.integration.test.js
```

The full output was read and is retained in `task-6-completion-chain-node22.txt`. Schema's legacy up/down/up and financial journal tests pass, quote SQL passes, checkout ends `delivery checkout SQL tests passed`, archive/payment ends `delivery archive/payment SQL tests passed`, all27 dispatch groups pass, and all13 Task6 groups run to completion, ending:

```text
PASS SQL independent couriers serialize at shop before commercial/account locks and clock
PASS SQL posting boundary preserves six digits for DB and explicit clocks
```

Final log counts, checked after all commands finished:

```text
task-6-completion-task5-node22.txt PASS SQL=27 FAIL/assertion/GOOD=0
task-6-completion-task5-node18.txt PASS SQL=27 FAIL/assertion/GOOD=0
task-6-completion-chain-node22.txt PASS SQL=76 FAIL/assertion/GOOD=0
```

The chain also contains schema PASS lines, quote/checkpoint summaries and the HTTP checkout PASS line not counted by the anchored PASS SQL count. Existing harmless legacy diagnostics remain in the full output. No unchanged Task6 standalone test or whole unit baseline was rerun during this bounded pass; Task6 ran only as the registered chain's final command.

### Follow-Up Commit and Controller Handoff

After verification and self-review, commands all exit0:

```powershell
git add -- test/delivery-dispatch.integration.test.js
git diff --cached --check
git diff --cached --stat
git -c core.hooksPath=.git-hooks-disabled-task6 commit -m "test: update courier collection route contract"
```

Actual commit output:

```text
[feat/delivery-v1 39f1169] test: update courier collection route contract
1 file changed, 3 insertions(+), 1 deletion(-)
```

Post-commit `git rev-parse HEAD`: `39f116934f9873eef70fd56836799493b6100467`. `git merge-base --is-ancestor af525158c5fc79f3f1f42d15a5f1ff64378859f3 HEAD` exits0. `git diff --stat af525158c5fc79f3f1f42d15a5f1ff64378859f3 HEAD` confirms only the one authorized test file. Both worktrees' short status output is empty; persistent hooksPath remains `.githooks`. No frontend commit, provider send, production change, agent/reviewer, deployment, push or merge.

**Controller full Task6 review range:** `799b555b98c7fa82b6cead67ab66da275e4491b4..39f116934f9873eef70fd56836799493b6100467`. Both Task6 commits are included. No independent approval is claimed here. Task7 financial timestamp/default and period work remains deliberately pending under its existing contract, with the precision-preserving interface documented above.
