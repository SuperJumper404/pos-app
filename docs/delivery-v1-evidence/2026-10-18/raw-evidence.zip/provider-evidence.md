# Provider Evidence

## IGN (checked 2026-10-17)

Primary documentation: https://cartes.gouv.fr/aide/fr/guides-utilisateur/utiliser-les-services-de-la-geoplateforme/geocodage/ (updated 2026-09-14).

- Direct geocoding uses GET https://data.geopf.fr/geocodage/search. The documented provider ceiling is 50 requests/second per IP; approved internal shared ceiling remains 40.
- Search integrates autocomplete. Do not switch to the separate completion API (its quota differs) while assuming the search quota.
- Filter to postal address index, not POI/parcel, and verify exact request/response schema against linked Swagger before coding.
- Only postal query leaves backend; complement/interphone/instructions remain private. Provider errors must not become zero coordinates or an empty-address success.

## Public-address probe (2026-10-17)

One read-only request used only the public town-hall postal address published by the government directory, not client data: https://lannuaire.service-public.gouv.fr/nouvelle-aquitaine/correze/ccfdeaee-6a3d-4dd7-825e-f281ff59f7bb (`Le Bourg 19170 Pradines`).

GET search with this postal input, index=address, autocomplete=0, postcode=19170, limit=3 returned municipality Pradines (score about0.553) and two different street names (Le Mazel/Le Magoutier, scores about0.54/0.53). No exact postal destination was resolved. This illustrates why a municipality coordinate must not silently substitute for an unresolved delivery address; it does NOT prove that every unnumbered address is unresolvable or justify a universal housenumber-only product policy.

No real client data, entry instructions or personal contact was submitted. This single public probe is not full live-provider acceptance testing.

## Production Geocoder Path, Controlled Public Cases

Native Node22 ran the real `buildDeliveryGeocoding` and `buildSqlGeocodingQuota({pool:db.pool})` inside `withDeliveryDatabase`, with explicit disposable test URL. No transport fake or quota bypass; no app database.

- `11 Rue des Menhirs / 19170 / Bonnefond` (public town-hall address from https://lannuaire.service-public.gouv.fr/nouvelle-aquitaine/correze/7c17bb56-73bb-475f-b7c6-7cb9b8c4e328) resolved with provider precision `housenumber`.
- `Le Mazel / 19170 / Pradines` (public named postal place already returned by official IGN search above) first refused automatic resolution with candidates, then resolved via explicit returned providerId with precision `street`.
- Output: `PASS live public numbered address: provider precision housenumber`; `PASS live public named location: explicit choice, provider precision street`; exit0. Test helper cleanup completed. Only normalized public postal input left the machine; no customer data/contact/instructions or credentials sent.

This verifies the real default HTTP transport, API response shape, current selection policy and shared SQL reservation on two controlled public cases. It is not complete delivery-precision/coverage acceptance, and does not validate Mailjet/WhatsApp.
