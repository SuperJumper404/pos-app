# Task 5: current-account courier authorization and transactional dispatch

## Status

**NEEDS_BOUNDED_SCOPE. Not complete and not fully GREEN. Ready for controller review of the scoped implementation and the two precise proposals below.**

- B commit: `a43a1617508c326b11d6a6da121878dd1eb568ca` (`feat: authorize couriers and dispatch deliveries`).
- B BASE: `c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8`; branch `feat/delivery-v1`.
- Compatible unchanged F HEAD: `6f694519d0db9ee631fe9d85550af71165dac293`; branch `feat/delivery-v1`.
- B status after commit: exactly `## feat/delivery-v1`, clean. Persistent `core.hooksPath` remains `.githooks`.
- All 15 amended-brief files are committed, including the shared projection amendment. No unowned production/test file was changed.
- Final HTTP authorization test passes on native Node22 and on Node18 with the test-local real Nano ID dependency bridge. Seven SQL scenario groups passed on both runtimes before adding the final unowned-collector regression. The **final SQL command exits 1**, proving an unresolved issue can still be collected by the existing legacy cashier handler. The existing module-list test also exits 1 because its expected list omits the required `delivery` permission.

This is author self-review only. No subagent/reviewer was spawned. The controller owns independent review and any ownership amendment. Task1-4 were not redone.

## Indispensable Bounded Proposals

### 1. Existing collection transaction: production ownership amendment needed

Allow a narrowly scoped change to **`B/src/modules/m_orders.js`**, specifically its actual exported `collectDeliveryOrderPayment` transaction, immediately after the existing commercial-first locked `resolveDeliveryOrder` call. Reject `context.delivery.delivery_status === 'issue'` with HTTP409 / `DELIVERY_TRANSITION_INVALID` before updating payment. Existing imports and the existing transaction suffice; no ledger, payment state, refund, stock operation, or lock-order change is needed.

The final owned SQL test already reproduces this through **actual HTTP `POST /orders/collect/:id`**, the production router/controller/module and disposable SQL. It assigns an unpaid delivery, reports an issue, and expects HTTP409 with payment still unpaid. Current result is **HTTP200**, which changes the commercial order to paid. A shared-auth pre-check would race and would not enforce this transactionally; making the general DTO reject issue reads would break authorized issue/history access. Neither workaround was used.

Also review the **same file's `buildOrderArchiveModule` unpaid-delivery settlement branch**: code inspection shows explicit cashier archive can collect an unpaid order. The bounded matching guard should refuse that new settlement while the locked dossier is `issue`, but continue allowing already-paid/refunded kitchen archives. This archive variant is a source-review finding, not an executed RED claim in this task. Add its targeted disposable-SQL assertion to the already-owned `delivery-dispatch.integration.test.js` when authorizing the production amendment. Existing in-flight provider reconciliation and Task4 Terminal lock protocol must remain intact.

Task6's new courier collection must likewise reject `issue` until restaurant resolution. No courier collection endpoint or financial placeholder was created here.

### 2. Required module permission: legacy expected-list amendment needed

Allow exactly the expected-list addition **`"delivery"` after `"borne"` in `B/test/staff-module-permissions.test.js`**, whose array equality starts at line32. Production `STAFF_MODULE_KEYS` must include `delivery`; the owned new HTTP test already covers that role6 receives no staff module permissions even with forged/stored arrays. Do not drop or weaken the old test's other assertions.

These are the only requested extra-file changes. They were not silently implemented. The final commit deliberately retains the SQL RED regression for the controller's next bounded fix.

## Files

Created:

- `src/helpers/deliveryAuthorization.js`: role/actor/owner predicates and exact courier method/path surface guard.
- `src/modules/m_deliveryDispatch.js`: injectable transactional dispatch builder, current-account authorization, journal/replay, availability, mission reads/items and courier operational list.
- `src/controllers/c_courier.js`: HTTP adapters, no-store responses, server-derived identity; shared HTTP adapters also used by delivery controller.
- `src/routers/r_courier.js`: role6-only namespace and implemented courier operations.
- `test/delivery-authorization.test.js`: real Express HTTP/JWT authentication and real user/PIN controller with injected persistence boundaries; no SQL requirement.
- `test/delivery-dispatch.integration.test.js`: actual disposable SQL, production modules, handlers and routers, concurrency/privacy/archive/driver checks, plus the final RED legacy-collector regression.

Modified:

- `src/helpers/staffPermissions.js`: `COURIER=6`, module `delivery`, forced empty permissions for role6.
- `src/helpers/staffAccess.js`: role6 is staff for personal credentials; **order takers remain 0/1/4**.
- `src/helpers/middleware/auth.js`: current active account reload, central surface enforcement, current-role account-write restrictions, optional bearer guard before legacy handlers, explicit customer rejection.
- `src/controllers/c_users.js`: courier personal login/PIN registration and minimal session/profile, own logout identity, no courier service-point assignment, shop-scoped updates/deletion, courier deactivation instead of deletion. Legacy role-changing activation requires a current active admin.
- `src/controllers/c_delivery.js`: operator dispatch/read/availability adapters; existing quote/server4/settings flows retained.
- `src/routers/r_delivery.js`: operator routes guarded by current admin or current cashier with `delivery` permission.
- `src/modules/m_deliveryOrders.js`: **only shared `toDeliveryView` authorization/privacy/actions/acceptance projection and its import**; resolver/archive/financial/charge code untouched.
- `index.js`: optional staff-bearer guard before legacy handlers and courier router registration.
- `package.json`: prepends new pure/HTTP test to `test`, appends SQL test to `test:delivery:db`; all previous commands preserved exactly.

## Interfaces and Endpoint Names

`buildDeliveryDispatch({repository, runInTransaction, clock})` exports:

- `assign`, `pickup`, `reportIssue`, `resolveIssue`, `deliver`: `{actor, deliveryId, expectedVersion, idempotencyKey, ...payload}` -> current `DeliveryView` plus string `eventId` and `idempotentReplay`.
- `get({actor, deliveryId})`, `list({actor})` -> shared views. List currently returns the latest 100 scoped dossiers.
- `couriers({actor})` -> same-shop courier ID/name/active/availability/active-mission-count only, including inactive accounts for restaurant operations.
- `availability({actor, courierId?, available:boolean})`: courier identity is server-derived; an operator can target a same-shop active courier.

Mutation payload uses `courierId` (historical integer FK), `reason`, `action`, and `physicalTransferConfirmed:true` as applicable. `resolveIssue.action` is one of `resume|retry|return|fail|cancel|confirm_unpaid_delivery`. Reasons are required for issues/resolutions. `return` records confirmed restaurant return as `unassigned` with no courier; `retry` records an available active assignee and returns to `assigned`; `resume` restores the journaled prior state. Post-pickup physical handover/return requires explicit confirmation. Multiple missions per courier are allowed.

Routes relative to existing `/baseurl/api/v1`:

| Method | Endpoint | Authority |
| --- | --- | --- |
| GET | `/deliveries` | Current admin or cashier with delivery permission |
| GET | `/deliveries/:id` | Same operator scope |
| POST | `/deliveries/:id/assign` | Restaurant only |
| POST | `/deliveries/:id/resolve-issue` | Restaurant only |
| POST | `/deliveries/:id/report-issue` | Restaurant only |
| GET | `/delivery/couriers` | Restaurant operational projection |
| PATCH | `/delivery/couriers/:id/availability` | Restaurant operational availability |
| GET | `/courier/deliveries` | Own current active courier |
| GET | `/courier/deliveries/:id` | Own dossier, including scoped archived/closed summary |
| PATCH | `/courier/availability` | Own server-derived current active courier |
| POST | `/courier/deliveries/:id/pickup` | Own assignment, preparation3 including archive |
| POST | `/courier/deliveries/:id/report-issue` | Own assigned/in-transit mission |
| POST | `/courier/deliveries/:id/deliver` | Own in-transit mission, remaining due0 |
| GET | `/user/me` | Courier minimal current own profile |
| POST | `/logout` | Courier own identity, posted other ID ignored |

Existing address-resolution/quote/settings endpoint names are unchanged. Settings and account/role writes remain admin-only; adding a cashier module permission does not make the cashier an admin. Server4 quote/POS behavior and the service-point JWT subject interpretation are retained.

`assertStaffSurface({access, method, path})` checks exact normalized router-relative namespace/method patterns, not `/courier*` prefix matching. It rejects other users, orders, metrics, legacy order details, products/stock mutations, self-remittance/adjustment and method/path suffix tricks. Full API-prefix case and Express trailing slash/encoded dynamic-ID variants cannot bypass account-write guards. GET/POST/HEAD are not treated as interchangeable.

**Future routing coordination:** the existing controller ledger tail already records the Task7 ruling and cost. The guard admits only **GET `/courier/cash-balance`** for the future own-balance adapter; its route does **not** exist now (actual HTTP404 asserted). The future courier `/collect-payment` method is similarly reserved in the guard but unimplemented (HTTP404 asserted). No self-remit/adjust authority was added. Task7 must derive own identity from the active account. The ledger's stated cost remains adjustment of two small adapters/HTTP checks and Task14 wiring if this choice changes; no new ledger implementation or duplicate ruling was written by this worker.

## Current-Account Authentication and Privacy

JWT proves the session signature; current DB `access` and active `status` determine staff authority. An old admin or cashier JWT for a now-role6 account is constrained as courier **before legacy handlers**. Signed/stored `module_permissions` cannot grant role6 orders/stock/metrics/users access. Unknown explicit subjects and opaque customer bearer values do not become staff. Existing explicit service-point tokens keep their service-point context and no personal identity.

The optional central guard applies to bearer-bearing legacy requests too. Public credential/proof entry points (`POST /login`, `/table-access`, existing click-and-collect session creation) remain independent of an expired staff header, preserving existing staff/service-point login contracts. Their actual proof handlers still validate their own credentials; they do not acquire staff authority from that header.

Every dispatch read/mutation/replay reselects the current active account under a SQL lock. Same-shop current assignment ownership is checked **before replay/version-conflict projection**. Old owners cannot read a reassigned dossier or replay an old mutation to obtain the new owner's data. Inactive courier requests fail, while operator history remains available and no mission/debt/history row is deleted.

The single `toDeliveryView` removes **all address/access/contact fields** (and operational items) from courier closed summaries for delivered/failed/canceled. It retains reference, current payment status and financial summary. Both later reads and old mutation replays use this current shared projection; journal results contain only logistical metadata, not a frozen private DTO. Live own missions include items, preserved customization snapshots and contact through this projection without opening legacy order APIs. HTTP delivery responses are `Cache-Control: no-store`.

The availability flag only governs new assignments; an unavailable courier still picks up/delivers accepted missions. Suspension of new delivery intake does not enter dispatch authorization. Acceptance/assignability derives from current commercial payment state, not frozen checkout event results: pending/unknown/canceled payment and unpaid Stripe uncertainty are not assignable. Financial values reuse safe-integer-cent validation and existing euro projection.

## Lock and Transaction Protocol

All dossier reads/mutations/replays reuse Task4 `resolveDeliveryOrder` with locking: immutable identity pre-read -> **active commercial row or archive -> dossier -> current charge snapshot**. Task5 does not need a shop lock. If a future caller needs one it must precede commercial locking. Archive keeps shop-first order; Terminal's sorted-orders -> payment-session protocol, without a dossier lock, is untouched.

Current actor/target account and journal lookups follow dossier resolution. The commercial/dossier locks serialize assignment, expected-version checking, logistics update and the append-only idempotent event in one transaction. Same key/different payload returns409. Same key/same payload returns the current authorized view without reapplying the action. An injected failure after the mutation/event rolls both back.

Item/customization rows use current locking reads under the resolved commercial representation. This matters when the identity pre-read opened an RR snapshot before archive committed: an initial plain read lost the new archive items. A deterministic actual-archive-commit barrier reproduced RED and the current reads pass GREEN. Product names are read separately so mission reads do not lock product rows unnecessarily.

New dossier/event IDs remain strings through SQL `CAST`; appended event identity is `CAST(LAST_INSERT_ID() AS CHAR)` **on the insertion connection**. The production-style mysql2 pool with `supportBigNumbers:false` proves exact `9007199254740993` delivery/event IDs. Archive item lookup uses `resolveDeliveryOrder.order.id` as the archive PK, not the normalized original-order commercial reference.

## RED/GREEN Commands and Outputs

Commands ran from B, PowerShell with `npm.cmd` conventions. Every SQL invocation explicitly set only the authorized local disposable URL:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-dispatch.integration.test.js
```

The unchanged helper creates/drops only random `smarteat_delivery_test_*` databases. No application DB fallback, silent SQL skip, remote catalog, real env load, foundation-fixture edit or migration/history edit was used. Availability and charge snapshots are supplied by the owned test.

Initial RED, both exit1 before implementation:

```text
node test/delivery-authorization.test.js
MODULE_NOT_FOUND ../src/helpers/deliveryAuthorization
node test/delivery-dispatch.integration.test.js
MODULE_NOT_FOUND ../src/modules/m_deliveryDispatch
```

Further reproduced RED -> GREEN findings:

| Reproduction | RED | Correction / final result |
| --- | --- | --- |
| Actual nested courier router auth |403 instead of200 | Use full original URL plus exact existing prefix for shared surface extraction; HTTP GREEN |
| Canceled commercial payment assignment | Missing expected rejection | Current payment acceptance projection; SQL GREEN |
| Register trailing slash / case / encoded user path |500 reached unauthorized account handler, expected403 | Canonical account-write guard; HTTP GREEN |
| Case variation of the full API prefix |500 instead of403 | Case-correct prefix extraction before account guard; HTTP GREEN |
| Courier bearer at a legacy public handler |200 instead of403 | Central optional bearer gate before handlers; HTTP GREEN |
| Legacy activation by nonadmin/anonymous |500 reached account repository, expected403 | Current-active-admin controller gate; HTTP GREEN |
| Valid personal PIN login with stale bearer |401 instead of200 | Preserve independent credential/proof entry points; HTTP GREEN |
| Actual archive commits while pickup waits |0 archived items instead of1 | Current item/customization reads; SQL GREEN |

Final HTTP command on native Node22, **exit0**:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
node test/delivery-authorization.test.js
```

```text
Loaded env file: NUL
PASS HTTP current-role isolation, exact surfaces, customer rejection, own profile/logout and personal PIN login
```

Node18 executable is `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe` (`v18.20.8`). The first Node18 HTTP run failed with the reported existing `ERR_REQUIRE_ESM` at real `staffCredentials.js -> nanoid`. Only then was the owned HTTP test given the same conditional real `await import('nanoid')`/require-cache bridge as the SQL test. Final Node18 HTTP command with the same fixture env **exits0** and prints the identical PASS. No runtime/dependency production repair is claimed.

Native Node22 SQL before the final legacy-collector regression **exited0**, all seven groups. Node18 then ran that complete version, **exit0**, retained in `task-5-node18-sql.txt`:

```text
PASS SQL assignment race/version/idempotence, own detail, ready pickup, issue resolution, unpaid and closed replay privacy
PASS SQL multiassignment, reassign privacy, physical transfer and current payment acceptance
PASS SQL archived ready pickup, customization and production-driver BIGINT event/delivery projection
PASS SQL pickup waits for actual archive commit and reads current archived items/customizations
PASS SQL observed commercial waits, current locked charge revision and actual dispatch/archive overlap
PASS SQL atomic rollback, return/fail/cancel journal, no automatic financial or stock changes
Loaded env file: NUL
GOOD
PASS SQL actual HTTP courier/operator routes, stale admin JWT, availability and active-account reload
```

SQL concurrency is real: two assignment transactions for delivery41/version1 produce one success and one version conflict; `performance_schema.data_lock_waits` joined to `data_locks` proves commercial waits before releasing the revision and archive barriers. Actual production archive and dispatch overlap without a cycle. Archive/current-charge and RR item-race tests use real SQL/modules, not lock-call count assertions.

The **final native Node22 SQL command exits1**, after those same seven PASS groups, at the new required-rule reproduction:

```text
AssertionError [ERR_ASSERTION]: Unresolved issue must block the existing manual collection transaction (unowned m_orders.js)
actual: 200
expected: 409
```

Full final output: `task-5-final-sql.txt`. This is an unresolved contract failure, not a passing final SQL suite. Do not report the earlier Node18 seven-group GREEN as covering the subsequently added legacy-collector assertion. The final standalone HTTP test was rerun on both runtimes after the last shared-auth/login adjustments and passed; the final SQL legacy-collector failure remains pending the ownership amendment.

### Focused legacy validation

With `ENV_FILE=NUL`, disposable JWT key above, and `PUBLICIMAGEPATH` set to the absent scratch path `.../task-5-absent-image-fixture`, ran each requested/relevant file separately, preserving every exit:

| File | Exit / result |
| --- | --- |
| `delivery-authorization` |0 PASS |
| `staff-credentials` |0 PASS |
| `staff-module-permissions` |**1**, expected-list mismatch: actual adds `delivery` |
| `staff-login-contract` |0 PASS |
| `admin-email-login` |0 PASS |
| `admin-legacy-password-login` |0 PASS |
| `service-point-session-auth` |0 PASS |
| `service-point-access-token` |0 PASS |
| `service-points-controller` |0 PASS |
| `table-access-controller` |0 PASS |
| `stock-authorization` |0 PASS |
| `delivery-quotes` |0 PASS, including server4/pricing/discount/HTTP scope contracts |

Final focused rerun after auth changes: `staff-login-contract`, `service-point-session-auth`, `table-access-controller`, `delivery-quotes`, all exit0. All 14 changed/new JS files passed `node --check`; `git diff --cached --check` exited0. Only Git's existing LF/CRLF notices occurred.

One intermediate PowerShell `node -e` aggregate-runner attempt failed at shell quoting before executing tests. Replaced it with an ordinary PowerShell foreach invoking each real test file; that is the complete 11-pass/1-known-failure evidence above. An initial lock-observer query used a column from `data_locks` on `data_lock_waits`; the fixture query was corrected to the real-table join before passing concurrency evidence. Temporary driver-option warnings were removed by building the production-style pool from explicit authorized fixture connection fields.

Package-script verification parsed BASE and current JSON and asserted exact prefix/suffix preservation, **exit0**:

```text
PASS all pre-existing npm test and SQL script commands preserved
```

No full `npm test` or cross-task `npm.cmd run test:delivery:db` was repeated. Task4's historical full npm invocation remains exit1 with all62 files subsequently passing through follow-ups; that is inherited evidence, not a full exit0 command in this task. In the present final code, the existing strict module-list test and final SQL collection regression prevent a full-green claim.

## Commit and Limits

Scoped commit command, exit0:

```powershell
git add -- <the exact 15 amended-brief files listed above>
git diff --cached --check
git -c core.hooksPath=.git-hooks-disabled-task5 commit -m "feat: authorize couriers and dispatch deliveries"
git rev-parse HEAD
git status --short --branch
git config --get core.hooksPath
```

```text
[feat/delivery-v1 a43a161] feat: authorize couriers and dispatch deliveries
15 files changed, 827 insertions(+), 44 deletions(-)
a43a1617508c326b11d6a6da121878dd1eb568ca
## feat/delivery-v1
.githooks
```

The hook override was invocation-local; no persistent hook change or env staging/encryption occurred. The report and test-output logs are authorized ignored F scratch artifacts, not a frontend-source commit. The existing controller routing decision/cost was read only from the ledger tail and not rewritten.

No cash ledger, collection/remittance endpoint, balance endpoint, self-remit/adjust control, provider/OTP send, mail/WhatsApp contact, real Stripe call, env decryption, remote DB use/migration, push, deployment, merge, original-checkout edit or frontend UI change was performed. No server was left running; HTTP fixtures bind only ephemeral loopback ports and close in finally blocks; disposable DBs/pools close through the existing helper.

This report does not claim Task5 complete. Remaining required work is the bounded existing-collector issue guard (including the unpaid archive variant review), the one-line legacy module expectation update, and their focused GREEN verification after controller authorization. Later financial tasks must use the same current-account, issue, ownership, shared-projection and lock contracts.

## Bounded Completion: Final Current Status (2026-10-17)

**COMPLETE within the amended Task5 scope; ready for the controller's independent full-range review.** This appended status supersedes the historical `NEEDS_BOUNDED_SCOPE` status and outstanding proposals above. Their failure provenance is retained, not rewritten as an earlier success. This was continued Task5 implementation, not a review-fix round.

- Original implementation commit **`a43a1617508c326b11d6a6da121878dd1eb568ca` is preserved**.
- Follow-up B commit: **`c4264b5356cdf556877973c7a292485a28c98528`**, `fix: enforce delivery settlement intervention and staff scope`.
- Controller review range: **`c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8..c4264b5356cdf556877973c7a292485a28c98528`**.
- Both commits are on the paired `feat/delivery-v1` backend worktree. No amendment/squash of the first commit, merge, push or deployment.
- No remaining Task5 implementation or ownership blocker. All required focused final commands below exit0.

### Authorized Changes and Exact Current Interfaces

The controller authorized the bounded production additions and the conditional linked-test fixture enrichment. The follow-up changes exactly five B files:

1. `src/modules/m_orders.js`: six production lines, only inside the actual exported locked delivery manual collector and archive builder. After commercial-first locked resolution, manual collection refuses `delivery_status === 'issue'` with `DomainError(409, 'DELIVERY_TRANSITION_INVALID', ...)`. Archive refuses a **new unpaid settlement** while the locked delivery remains `issue`; already-paid/refunded preparation archives continue through the existing checks. No dossier/version/event auto-clear, refund, stock movement, provider reconciliation change, archive identity change or Terminal lock change.
2. `src/controllers/c_orders.js`: twelve production lines, a small private delivery-only staff predicate and its two call sites. `POST /orders/collect/:id` requires trusted **current active staff0/1** for a delivery. `POST /orders/archive/:id` requires trusted **current active staff0/1** if the delivery is not already paid/refunded; an already-paid/refunded delivery permits existing preparation staff **0/1/4/5**. Service-point/customer/guest cannot archive a delivery, even one already paid. Courier remains centrally denied. The predicate checks the DB-derived `req.currentUser` active status, role, shop and identity against the authenticated request; body `actor`, `access` and `currentUser` fields cannot supply authority. It does not add a new `delivery` module requirement to legacy cashier settlement. Non-delivery branches are unchanged.
3. `test/staff-module-permissions.test.js`: **only** adds `"delivery"` immediately after `"borne"` in the expected list. Every other assertion is retained.
4. `test/delivery-dispatch.integration.test.js`: extends the existing actual HTTP/SQL suite with staff-role fixtures, customer/service-point claims, reasoned resume and manual settlement, unpaid issue archive refusal/recovery, already-paid/refunded kitchen archive, non-delivery preservation, queued issue-versus-settlement races, and engaged provider reconciliation.
5. `test/delivery-archive-payments.integration.test.js`: **only** enriches the direct-controller request fixture inside `manual delivery collection refuses duplicate pending Stripe and inline discounts`. It selects the actual seeded cashier10's `id/shopid/access/status` from the disposable DB and supplies `sessionSubject`, `id`, `access` and `currentUser`. Every expected status, monetary, transaction, preparation, provider and duplicate-collection assertion is unchanged.

The controller's interpretation is implemented explicitly: a generic legacy manual settlement is not a reasoned incident-resolution action. V1 requires **`resolveIssue({action:'resume', reason, ...Mutation})` before manual collection/new unpaid archive settlement**. The test proves the restaurant resolution event records the real actor10 and reason, logistics/version remain unchanged by subsequent legacy payment, and a cashier with no `delivery` module can still perform the existing financial settlement once the incident is resolved. Dispatch permissions are not broadened.

All previously reported courier/dispatch routes, shared DTO, future GET `/courier/cash-balance` allowance, current-account reload, BIGINT/string and cent contracts remain unchanged. No new public endpoint or financial placeholder was added. Task6/7 remain responsible for the courier collection ledger, balance and remittances.

### Completion RED Provenance

First added the bounded actual SQL/HTTP assertions, then ran the unchanged production implementation, **exit1**, saved as `task-5-completion-red.txt`:

```text
FAIL SQL unresolved issue blocks actual manual collection then reasoned resume permits legacy cashier: ERR_ASSERTION actual=200 expected=409
FAIL SQL unpaid issue blocks actual archive settlement without changing active rows: ERR_ASSERTION actual=undefined expected=[object Object]
FAIL SQL server cannot manually settle or archive an unpaid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL kitchen cannot manually settle or archive an unpaid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL legacy customer cannot manually settle or archive an unpaid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL point3 cannot manually settle or archive an unpaid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL point2 cannot manually settle or archive an unpaid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL service_point cannot archive a paid delivery: ERR_ASSERTION actual=200 expected=403
FAIL SQL locked issue wins against queued manual collection and unpaid archive: ERR_ASSERTION actual=fulfilled expected=rejected
```

The unpaid archive RED invokes the **actual production archive module and transaction** with an explicit cash method: it succeeded where `assert.rejects` required409. GREEN additionally verifies actual HTTP archive returns409, no archive row is created, the active order remains unpaid, and only after a reasoned resume can the cashier archive/settle. Paid/refunded issue archives and provider reconciliation already passed before the guards and continue to pass afterward.

After adding the production guards, ran the requested focused Task4 SQL cases before editing its auth fixture, **exit1**, `task-5-task4-auth-fixture-red.txt`:

```text
PASS SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery
PASS SQL kitchen archive cannot collect and cashier preserves accepted discount
FAIL SQL manual delivery collection refuses duplicate pending Stripe and inline discounts: ERR_ASSERTION
PASS SQL Terminal settles full accepted fee and archive preserves product VAT
```

Concrete necessity: that manual test invoked the real controller with only `{params, shopid, body}`, so it no longer represented an authenticated staff request and failed before its financial409/200/409 assertions. The user's conditional authorization permitted only this fixture enrichment. It now uses the seeded real DB cashier account; no production guard or expected behavior was weakened. No other linked-test fixture was changed.

### Final GREEN Commands and Outputs

Every runtime command used `ENV_FILE=NUL`, disposable `JWTKEY='task5-local-signing-fixture-only'`, and the explicit authorized local URL for SQL. No real environment file was read. Node22 is native; Node18 uses only the existing fixture-local **real Nano ID ESM import/cache bridge**, not a stub or production runtime patch.

Task5 final HTTP and module-list tests, **exit0 on both Node22 and Node18**:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
node test/delivery-authorization.test.js
node test/staff-module-permissions.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-authorization.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/staff-module-permissions.test.js
```

Each runtime prints:

```text
PASS HTTP current-role isolation, exact surfaces, customer rejection, own profile/logout and personal PIN login
staff module permission tests passed
```

Task5 final **complete** SQL/HTTP file, **exit0 on both runtimes**, with all **21 scenario groups** passing (including every earlier Task5 race/privacy/archive/BIGINT case):

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-dispatch.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-dispatch.integration.test.js
```

Separate real invocations are retained as `task-5-completion-green-node22.txt` and `task-5-completion-green-node18.txt`; both commands explicitly set the URL and fixtures in their own shell. The new completion groups print:

```text
PASS SQL unresolved issue blocks actual manual collection then reasoned resume permits legacy cashier
PASS SQL unpaid issue blocks actual archive settlement without changing active rows
PASS SQL server cannot manually settle or archive an unpaid delivery
PASS SQL kitchen cannot manually settle or archive an unpaid delivery
PASS SQL legacy customer cannot manually settle or archive an unpaid delivery
PASS SQL customer subject cannot manually settle or archive an unpaid delivery
PASS SQL point3 cannot manually settle or archive an unpaid delivery
PASS SQL point2 cannot manually settle or archive an unpaid delivery
PASS SQL service_point cannot archive a paid delivery
PASS SQL customer cannot archive a paid delivery
PASS SQL active staff preparation roles archive paid or refunded issues without clearing logistics
PASS SQL admin manual settlement and non-delivery legacy permissions remain unchanged
PASS SQL locked issue wins against queued manual collection and unpaid archive
PASS SQL engaged provider reconciliation remains allowed during issue
```

The new race starts an actual `reportIssue` transaction queued on the commercial row, proves its SQL wait, then queues the actual manual collector or unpaid archiver and proves the second wait before releasing the barrier. The issue commits first, and both financial variants re-read the locked current dossier and reject with `DELIVERY_TRANSITION_INVALID`, leaving the order unpaid. This supplements the HTTP boundary guard; a nontransactional issue pre-check was not used.

Task4 focused manual/kitchen/preparation/payment SQL, **exit0 on both runtimes**, after the one authorized auth fixture enrichment:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:TASK4_TEST_FILTER='manual delivery collection|kitchen archive|paidDoes|Terminal settles'
node test/delivery-archive-payments.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-archive-payments.integration.test.js
```

Logs: `task-5-task4-green-node22.txt`, `task-5-task4-green-node18.txt`:

```text
PASS SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery
PASS SQL kitchen archive cannot collect and cashier preserves accepted discount
PASS SQL manual delivery collection refuses duplicate pending Stripe and inline discounts
PASS SQL Terminal settles full accepted fee and archive preserves product VAT
delivery archive/payment SQL tests passed
```

Affected legacy files were executed individually on **both runtimes**, each **exit0**:

| File | Evidence |
| --- | --- |
| `cash-register-payment.test.js` | `cashRegisterPayment tests passed` |
| `stripe-payment.test.js` | `stripePayment tests passed` |
| `stripe-terminal-refunds.test.js` | `stripe terminal refund/archive tests: 33/33 passed` |
| `order-delete-hidden-archive.test.js` | `order delete hidden archive contracts passed` |

Commands used the same NUL env/JWT fixture and the explicit absent `PUBLICIMAGEPATH` scratch path documented above. Node22 invoked each file directly with `node test/<file>.test.js`. Each Node18 process used exactly this real-dependency bridge before requiring the unchanged legacy test:

```js
(async () => {
  require.cache[require.resolve('nanoid')] = { exports: await import('nanoid') };
  require('./test/<file>.test.js');
})().catch(error => { console.error(error); process.exitCode = 1; });
```

No broad `npm test`, cross-task `test:delivery:db`, or unrelated unchanged suite was repeated. Package scripts were not changed by this follow-up; all previously preserved test commands remain registered. All five changed JS files pass `node --check`; staged whitespace check exits0. The earlier Task4 full-npm failure/follow-up provenance remains historical and is not recast as a full-green npm invocation here.

### Final Self-Review, Commit and Remaining Limits

Reviewed all five follow-up diffs, including the actual exported archive builder (not its dead legacy definition), both controller dispatch branches, the precise issue guards after locked resolution, identity/status/shop checks, exact one-line module expectation, and the linked fixture diff with unchanged assertions. Confirmed:

- Current active staff authority comes from Task5 auth's DB account, never posted actor/role/module fields.
- Paid/refunded preparation archives retain payment and issue state; issue is not auto-resolved and archive does not conclude the mission.
- Reasoned restaurant resume is required before generic manual settlement of an unresolved incident; no audit identity/reason is invented by the collector.
- Pending engaged provider success still reconciles during issue, preserving preparation and logistics/version.
- Existing non-delivery settlement/archive permissions remain unchanged.
- Commercial -> dossier -> current-charge and shop-first archive locks remain intact; Terminal still has no new dossier lock.
- No additional file, dependency, migration, env, namespace or financial ledger was introduced.

Follow-up commit command, **exit0**:

```powershell
git add -- src/controllers/c_orders.js src/modules/m_orders.js test/delivery-archive-payments.integration.test.js test/delivery-dispatch.integration.test.js test/staff-module-permissions.test.js
git diff --cached --check
git -c core.hooksPath=.git-hooks-disabled-task5 commit -m "fix: enforce delivery settlement intervention and staff scope"
```

```text
[feat/delivery-v1 c4264b5] fix: enforce delivery settlement intervention and staff scope
5 files changed, 159 insertions(+), 10 deletions(-)
c4264b5356cdf556877973c7a292485a28c98528
```

Persistent `core.hooksPath` remains `.githooks`. The hook bypass was invocation-local, and the first commit was not amended. Report/log updates stay in authorized F scratch. No ledger rewrite, subagent/reviewer, real provider/OTP/mail/WhatsApp send, real env/decryption, remote DB, push, deployment, merge or original-checkout edit occurred. All test servers/connections were closed by their existing finally/helper cleanup.

There are **no remaining Task5 blocking concerns**. The previously reported unbridged Node18 Nano ID production compatibility limitation is unchanged and not claimed fixed; Node18 verification above is explicitly fixture-bridged. Full release/integration commissioning and later financial tasks remain their assigned scope. Independent controller review should now cover the full BASE-to-follow-up range stated at the start of this completion section.

## Fix Round 1/5: C1, I1, I2, M1

**Current status: fixes implemented and verified; independent scoped re-review pending. This is not quality approval.** The review found concrete bugs after the preceding implementation-complete claim; that claim was not independent approval. The historical report and failure provenance above remain intact. This section supersedes the preceding assessment of remaining findings.

- Read the **full** `task-5-review.md` before starting changes. Used its C1/I1/I2/M1 findings and the controller decisions as the scope.
- FIX_BASE: `c4264b5356cdf556877973c7a292485a28c98528`.
- Original BASE remains `c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8`.
- Fix commit: **`799b555b98c7fa82b6cead67ab66da275e4491b4`**, `fix: harden account writes and concurrent courier dispatch`.
- Fresh scoped re-review range: **`c4264b5356cdf556877973c7a292485a28c98528..799b555b98c7fa82b6cead67ab66da275e4491b4`**. Earlier commits are preserved.
- Author disposition: **1 Critical + 2 Important + 1 Minor addressed; 0 deferred**. No subagent/reviewer was used, and the controller still owns the acceptance decision.

### Finding-to-Change Mapping

| Finding | Change | Verification |
| --- | --- | --- |
| **C1 Critical** | Independent trusted-current-active-admin checks in account mutation controllers; strict whole legacy user IDs; boundary-preserving central write classification | Real HTTP/production controllers/disposable SQL encoded-ID denial and legitimate admin writes; direct-controller missing/forged/inactive/wrong-shop/null-role context denial |
| **I1 Important** | At most two local retries of the complete SQL dispatch mutation after an explicit confirmed rollback of an in-work `ER_LOCK_DEADLOCK`; shared transaction helper unchanged | One-shot two-independent-mission/different-courier journal-gap barrier; both pickups succeed, one event each; bounded retry and negative error-boundary cases |
| **I2 Important** | All operational dossiers plus independently bounded latest100 terminal dossiers, preserving the array API | 103 newer terminal fixtures cannot hide older own assigned/in-transit/issue missions or restaurant unassigned work; owner/shop scope and closed redaction asserted |
| **M1 Minor** | Exact known `GOOD` registration diagnostic captured/asserted only in the owned SQL fixture, with finally restoration | RED stdout-noise assertion, GREEN exact diagnostic capture; final full logs have zero standalone `GOOD` lines; unexpected messages are forwarded |

Changed exactly five already-owned B files:

- `src/controllers/c_users.js`.
- `src/helpers/middleware/auth.js`.
- `src/modules/m_deliveryDispatch.js`.
- `test/delivery-authorization.test.js`.
- `test/delivery-dispatch.integration.test.js`.

No new ownership was needed. The conditional authorization for linked staff/admin test-fixture maintenance was **not used**: none of `staff-credentials`, `staff-login-contract`, `staff-module-permissions`, `admin-email-login`, or `admin-legacy-password-login` needed an edit. Their existing assertions remain unchanged. No `m_users` query/log cleanup, transaction-helper change, migration, dependency, package-script change, or frontend change was made.

### C1: Account Mutation Authority and Complete IDs

`registerWithStaffCredentials`, the legacy `register` export, `setStaffCredentials`, `updateUser`, and `deleteUser` now independently require `req.sessionSubject === 'staff'` and an authenticated `req.currentUser` with actual role0, active status, matching request identity and shop. Missing, inactive, wrong-shop and null-role contexts are denied. Posted `access`, actor or `currentUser` data does not supply this context. The existing role-changing activation keeps the same current-active-admin policy, now through the common controller predicate.

The path classifier splits URL segments **before** decoding them, so decoding an encoded separator cannot change the account namespace boundary. Write methods beneath the `user` namespace remain admin-only. This is defense in depth; controllers no longer depend on a URL regex to authorize a mutation.

User targets must be whole canonical positive decimal legacy signed-INT IDs (`1..2147483647`). Slash/backslash suffixes, spaces, decimals, exponent syntax, zero and overflow fail400 before the numerical lookup/update. Conversion to Number occurs only after validation. Credential reset, update, deletion and detail read use this check. New delivery/event BIGINT IDs remain strings and are not subjected to this legacy-user rule. Logout derives the validated authenticated own user ID rather than using a posted numeric-prefix target; the existing service-point logout remains a no-user-update success.

New regression uses real routers, production controllers, actual authentication and disposable SQL. It sends encoded self-promotion targets for cashier10, server15, kitchen16 and a service-point session, asserts403 and unchanged account role, then exercises valid admin numeric update/reset/delete with HTTP200 and actual SQL postconditions. Invalid admin targets are checked on PATCH, credential reset, DELETE and GET. Pure/HTTP test additionally invokes all five mutation controllers with seven invalid authority contexts each, proving the controller guard independently of routing. It verifies posted logout target `14/extra` cannot target another account.

**RED provenance:** the new actual-controller fixture returned **500 instead of403** on encoded nonadmin writes, and **500 instead of400** on invalid admin targets. `task-5-round1-C1-red.txt` records these actual responses. This run is not represented as an actual successful200 promotion; the review's separate sentinel/numeric-prefix evidence remains its own evidence. The regression checks the correct authorization/validation boundary rather than repeating that sentinel. Direct-controller mutation checks also failed500 instead of403 before the guard, including a later self-review RED for null-role/incomplete context. All now pass.

No real account or live token database was accessed. Only helper-created random fixture databases were used. Previously issued legacy activation links, if any, remain a **pre-release compatibility audit**, not a new blocking finding or grounds to restore arbitrary anonymous role changes.

### I1: Local Retry After Confirmed Rollback

Kept commercial-first resolution, current locking reads, owner checks, version checks, current charge/payment authority, journal `FOR UPDATE`, unique keys and append-only event semantics. A plain journal snapshot read could miss a concurrently committed replay under repeatable read; a global runner retry could replay provider-side effects. Neither was introduced.

Only the dispatch **mutation** wrapper retries, with an initial attempt plus at most **two retries**. It records a retry candidate only when:

1. The SQL work callback itself throws exactly `ER_LOCK_DEADLOCK`.
2. `await connection.rollback()` succeeds explicitly.
3. The transaction runner returns that same error after its cleanup.

Every retry re-enters the complete transaction and reloads its commercial representation, current account, owner, version and journal state. Runner/begin errors, post-work/commit-boundary errors, unconfirmed rollback and network errors are not replayed. `withTransaction.js` is unchanged; reads, availability and unrelated/provider flows do not acquire this retry policy.

The real concurrency regression creates two ready paid dossiers assigned to **different** couriers11/13. A connection wrapper pauses only after both **actual missing journal lookups** finish for distinct fresh keys in the same index gap. It releases once; retries do not re-enter the barrier. Both pickups must succeed with version3/in-transit, exactly one pickup event per dossier, unchanged stock, normal replay and same-key/different-payload409. The fixture also counts a real SQL `ER_LOCK_DEADLOCK` and successful rollback, so a synthetic conflict or simple serialized success cannot masquerade as this race.

Fault-boundary fixtures use actual transactions with targeted injected errors to assert exactly three attempts for confirmed in-work deadlock and exactly one for rollback failure, begin error, post-work deadlock/commit-boundary error and network error. Their version and journal changes roll back. This is fault injection, not a claim that a real network/commit acknowledgment was lost during this task.

**RED:** one independent pickup rejected instead of succeeding; the bounded-policy fixture counted1 attempt instead of3. **GREEN:** both independent pickups and all policy exclusions pass on both runtimes, alongside the existing version/idempotence/rollback/archive races.

### I2: Complete Operational Enumeration

`listIds` now unions **all** authorized `unassigned|assigned|in_transit|issue` dossiers with the independently newest100 authorized `delivered|failed|canceled` dossiers. The final sort uses SQL creation time/numeric ID; only the outgoing ID is CAST to CHAR. Shop scope and courier ownership apply independently to both branches. The response remains the existing array, with the existing per-dossier current authorization and shared `toDeliveryView` privacy projection. No frontend pagination or new endpoint was invented.

Regression inserts103 newer terminal missions and older assigned/in-transit/issue missions for the courier, an old unassigned restaurant mission, a foreign owner and a foreign shop. Actual HTTP lists must contain all old operational work, expose no other courier/shop data, retain an independent100-item terminal history, and omit address/contact/items from closed courier summaries.

**RED:** the old query omitted old operational work (`actual=false`, `expected=true`). The first new-query focused run exposed an incomplete foundation fixture: the newly visible seed delivery41 had no charge snapshot and produced409. Only this owned test was enriched with its required zero-fee snapshot and missing header defaults; the foundation helper/history/migrations were not edited. The corrected focused run and both complete runs pass. This intermediate fixture failure is not omitted or reported as a passing run.

### M1: Narrow Diagnostic Capture

The owned test wraps only its actual registration request. It consumes **exactly one argument equal to `GOOD`**, asserts the captured sequence is exactly `['GOOD']`, forwards all unexpected log calls unchanged, and restores `console.log` in `finally`. The regression observes stdout separately and restores that observer in its own `finally`, so it asserts the known diagnostic no longer appears as unrelated test output. The production `m_users` log is untouched.

**RED:** actual `GOOD` appeared and the stdout assertion was `true` instead of `false`. **GREEN:** focused registration and complete SQL runs pass; standalone `GOOD` count is **0** in each final runtime log.

### Commands and Exact Evidence

All commands ran in B with `ENV_FILE=NUL`, disposable JWT signing fixture, and this explicitly authorized local disposable SQL URL when SQL was needed:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task5-local-signing-fixture-only'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
```

Focused RED/GREEN used `TASK5_REVIEW_FILTER='C1'`, `'I1'`, `'I2'` or `'M1'` and `node test/delivery-dispatch.integration.test.js`. The filter is explicit opt-in; the normal registered SQL test runs all old and new scenarios, with no silent skip or application-DB fallback.

| Log | Exit | Result |
| --- | --- | --- |
| `task-5-round1-C1-red.txt` |1 | Real HTTP invalid authority/ID reached500, expected403/400 |
| `task-5-round1-C1-green.txt` |0 | Both real SQL/HTTP C1 groups pass |
| `task-5-round1-I1-red.txt` |1 | Independent pickup rejected |
| `task-5-round1-I1-policy-red.txt` |1 | Race failure and attempts1 vs3 |
| `task-5-round1-I1-green.txt` |0 | Race and bounded/excluded retry cases pass |
| `task-5-round1-I2-red.txt` |1 | Old operational mission omitted |
| `task-5-round1-I2-green.txt` |0 final | Final focused pass; the initial409 fixture failure is documented above and in tool evidence, and its GREEN-attempt file was overwritten by this final run |
| `task-5-round1-M1-red.txt` |1 | Known stdout noise still present |
| `task-5-round1-M1-green.txt` |0 | Exact known diagnostic captured |

Final Task5 HTTP test **exit0 on both runtimes**, after the last controller predicate change:

```powershell
node test/delivery-authorization.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-authorization.test.js
```

Both print:

```text
PASS HTTP current-role isolation, exact surfaces, customer rejection, own profile/logout and personal PIN login
```

Final complete Task5 SQL **exit0 on both runtimes**, **27 groups each**:

```powershell
$env:TASK5_REVIEW_FILTER=''
node test/delivery-dispatch.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-dispatch.integration.test.js
```

The two commands were separate invocations, each explicitly setting NUL/JWT/local URL and clearing the focused filter. Full logs are `task-5-round1-full-green-node22.txt` and `task-5-round1-full-green-node18.txt`. Both retain all21 previous SQL groups and add:

```text
PASS SQL C1 current nonadmins cannot self-promote through encoded user IDs
PASS SQL C1 admin rejects whole invalid IDs before update credential delete and read SQL
PASS SQL I1 independent pickups survive a one-shot real missing-journal gap deadlock
PASS SQL I1 retry is bounded and excludes unconfirmed rollback begin commit and network errors
PASS SQL I2 all old operational work remains enumerable beyond 100 newer terminal missions
PASS SQL M1 known registration diagnostic is captured without stdout noise
```

Node22 is native. Node18's previously documented Nano ID issue is handled only by the owned fixtures' real ESM import/cache bridge, not by a production dependency patch. The final log check reports:

```text
task-5-round1-full-green-node22.txt PASS SQL=27 GOOD=0
task-5-round1-full-green-node18.txt PASS SQL=27 GOOD=0
```

Relevant existing tests executed individually, with the same NUL/JWT fixture and absent scratch `PUBLICIMAGEPATH` when needed:

| Test | Node22 | Node18 |
| --- | --- | --- |
| `staff-credentials` |0 |0 |
| `staff-login-contract` |0 |0 |
| `staff-module-permissions` |0 |0 |
| `admin-email-login` |0 |0 |
| `admin-legacy-password-login` |0 |0 |
| `service-point-session-auth` |0 |0 |
| `service-point-access-token` |0 |0 |
| `service-points-controller` |0 |0 |
| `table-access-controller` |0 |0 |
| `stock-authorization` |0 |0 |
| `cash-register-payment` |0 |Not redundantly rerun this round |
| `stripe-payment` |0 |Not redundantly rerun this round |
| `stripe-terminal-refunds` |0, 33/33 cases |Not redundantly rerun this round |
| `order-delete-hidden-archive` |0 |Not redundantly rerun this round |

Node22 used `node test/<file>.test.js` in a PowerShell foreach that recorded each exit (the same batch also ran the new HTTP test). Node18 used the already documented real Nano ID import/cache bridge per isolated legacy process. No linked test fixtures or expected assertions changed. The extra null-role/incomplete-admin direct-controller RED and final HTTP GREEN are preserved in this turn's exact tool output; those are not described as separate SQL failures.

No whole baseline `npm test` or cross-task SQL suite was rerun. Five changed files pass `node --check`; unstaged/staged whitespace checks exit0 with only the repository's LF/CRLF notices.

### Self-Review, Commit and Limits

Reviewed the complete five-file diff, the controller guard placement before lookups/writes, all numeric target callsites, raw segment classification, retry origin/rollback/error-identity/max-attempt conditions, numeric SQL sort and actor scopes in both list branches, one-shot barrier behavior, synthetic-fault boundaries, and diagnostic restoration. Confirmed current ownership/private projection, commercial-first/current charge locks, stock/event uniqueness, normal replay/payload conflict and existing rollback assertions remain passing in the complete runs. No global transaction retry or provider-flow change exists.

Scoped commit, **exit0**:

```powershell
git add -- src/controllers/c_users.js src/helpers/middleware/auth.js src/modules/m_deliveryDispatch.js test/delivery-authorization.test.js test/delivery-dispatch.integration.test.js
git diff --cached --check
git -c core.hooksPath=.git-hooks-disabled-task5 commit -m "fix: harden account writes and concurrent courier dispatch"
```

```text
[feat/delivery-v1 799b555] fix: harden account writes and concurrent courier dispatch
5 files changed, 288 insertions(+), 17 deletions(-)
799b555b98c7fa82b6cead67ab66da275e4491b4
```

The override is invocation-local; persistent `core.hooksPath` remains `.githooks`. No env staging/decryption, real provider/OTP/mail/WhatsApp send, real or remote account/token DB access, push, deployment, merge, original-checkout edit, ledger rewrite or helper/reviewer agent occurred. Disposable databases, HTTP servers and connections were closed through fixture finally/helper cleanup. Logs/report are authorized F scratch only.

All four requested findings are implemented with RED/GREEN evidence; **fresh independent scoped re-review remains pending**. Existing unbridged Node18 runtime limits, later financial tasks and the pre-release legacy-activation compatibility audit are unchanged and are not new blocking findings in this fix round.
