# Task15 Delivery Receipts, History and Reports

Status: implementation, scoped verification, actual PDF image inspection, author self-review and both commits complete in the authorized paired worktrees. Independent review belongs to the controller. No nested implementer, agent or reviewer was used.

## Identity And Scope

- F = `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app`
- B = `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos`
- Scratch = `F/.superpowers/sdd/2026-10-16-delivery-management`
- F BASE = `7ee09d3407760b3fc488e4eb051bea82b99e437c`
- B BASE = `0150e247fd3ff874eabeb85857aaa7482d2b430e`
- F commit = `7f02d6c9c4ea123d6681cc0bcb116d0ecb3c17e0`
- B commit = `94e0a7785ae8fb4bee2cccde8dd7285a6f0aa9f6`.
- Commit message in both repositories: `feat: include delivery charges in receipts and reports`.

Read existing task-15-brief.md FIRST without regenerating it, followed by worker-context.md, task-15-integration-notes.md, common contracts, applicable specification sections 6/7/10/11, Task7 final completion/refund consumer contract, and relevant actual Task4/12 producer APIs. Re-read the controller-amended brief when closure ownership was granted. No whole prior plan/history was loaded. workspace_fs was tried and denied the external worktree; worker-context's shell fallback was then used. All manual edits used apply_patch.

TDD, verification, PDF and Impeccable skills were applied within the user's workflow. Read `C:/Users/kalag/.codex/skills/pdf/SKILL.md` and Impeccable craft-floor before UI edits; preserved dense Nuxt2/Vue2/Vuetify/Poppins/MDI. No context refresh, detector, new visual identity or whole-UI screenshot batch. Whole npm/build/UI acceptance remains Task17.

F changed files, staged by exact explicit allowlist:

```text
components/orders/TakeawayChip.vue
components/orders/VatBreakdown.vue
helpers/cashierReceipt.js
helpers/orderTicket.js
helpers/vat.js
package.json
pages/cashregister/payout/_id.vue
pages/history/index.vue
pages/history/ticket/_id.vue
pages/orders/detail/_id.vue
pages/orders/index.vue
pages/reports.vue
store/cashClosures.js
test/delivery-receipts.test.js
test/stripe-terminal-payout.test.js
```

B changed files, including the subsequent explicit controller grant:

```text
package.json
src/controllers/c_orders.js
src/helpers/orderMetrics.js
src/modules/m_orders.js
src/modules/m_cashClosures.js
test/delivery-reports.integration.test.js
```

`F/helpers/receiptBundle.js` needed no production edit: the existing passthrough preserves the extended receipt payload. Actual bundle/transport tests verify this. No lockfile, dependency, application metadata, backend financial producer, clock, refund engine, migration or unrelated file was changed.

## Implemented Behavior

- Cashier payload accepts an explicit `deliveryCharge` or reads the accepted `financials.delivery_charge`/`delivery_charge`. Validated explicit server cents/HT/tax/rate are used, without current-settings rate inference. Server grand total remains authoritative. Subtotal before discount includes the fee while the saved discount stays a product discount.
- ESC/POS, cloud XML and SmartPrint structured `ticketData.business`/`render` all include a separate delivery charge and complete VAT. Product lists and itemCount remain products only. Free delivery prints 0.00 with no extra fee VAT row. Mixed grouping preserves each exact-string delivery identity once in the fee/VAT projection, without fake products or stock changes.
- Cashier and kitchen fulfillment detect delivery before web/click_collect or an old explicit channel label. Receipt data excludes top-level tracking/instructions; raw receipt/order/shop/remark logs were removed from the touched printing/history/report surfaces.
- History/detail show delivery fulfillment, fee and complete VAT. The actual existing history jsPDF generator consumes the same payload and preserves the original sale after refund/settings changes. Financial refund status is shown separately, without subtracting the sale/fee/VAT document.
- Active HTTP order list now casts delivery/customer identities to strings and consumes the same existing delivery-financial enrichment as detail/archive reads. SQL/HTTP tests use a delivery ID above 2^53. Existing archive/public receipt paths retain accepted fee snapshots after settings changes and full confirmed manual refund.
- `c_orders.orderByToken` now queries an explicit receipt-public shop business/branding/tax allowlist, rather than returning the admin shop DTO. Actual HTTP sentinel tests exclude admin_password, private printer configuration and a newly added unknown private configuration column from response/logs, while the unchanged admin module still returns its full DTO. Legacy non-delivery token receipts are covered.
- Metrics retain the original gross sale, count one order, expose delivery fees, refunded-sale status and product-plus-fee VAT, and do not count fees in top products. Physical remittance/refund journals never enter product sales metrics.
- Reports display Task7 stored immutable register/courier sales sources and posting-period collection/remittance/refund fields separately. Drawer refunds are labelled outflows; courier custody refunds and external independent-TPE declarations are separate. No subtraction of period collections from period sales. Missing historical JSON fields remain unavailable rather than recomputed. Zero-order remittance/correction/refund periods can close from the server-supplied activity counts; no fake order is created.
- Inline discounts are disabled for any payout selection containing delivery, including mixed selections, and the submit payload omits such discounts. Detail settlement has the same guard. Eligible unpaid/pre-pickup delivery editing uses existing server editable-order/quote/amend APIs with explicit quote confirmation, accepted version and idempotency key. Lost responses retain the exact body/key; route departure is blocked during uncertainty. Settled/non-delivery recovery behavior is retained. Terminal delivery receipts bypass the legacy product-total scaling that would otherwise absorb the fee into products, and retain original discount fields.

The edit path follows the current amendment API. Additional apartment/instruction changes are rejected locally rather than silently posted as unsupported fields; the endpoint does not accept the checkout-only delivery_address_details contract. Broader private-detail editing was not added to Task15.

## Approved Closure Extension

Source inspection and real SQL RED showed `getArchiveDetailsForOrders -> buildCashClosureSnapshot -> buildVatSummary` consumed product tax only. A bounded, unapplied proposal was reported before any unowned edit: `task-15-closure-proposal.patch`. Its apply-check succeeded. A scratch-only module loader first exercised that proposed SQL against the real fixture, without changing the unowned file. These proposal runs are not claimed as integrated production acceptance.

The controller then explicitly approved ONLY `B/src/modules/m_cashClosures.js`'s four-fiscal-column projection, amended the brief and retained ledger ownership. The implementation exactly adds the accepted archived charge via same-shop delivery/current charge-revision joins and UNION ALL. Only fee VAT inputs are added; order count, revenue, payments, custody, posting clocks and old persisted closures are unchanged. The dedicated SQL regression uses two product lines plus two stored charge revisions to catch fee multiplication or missing revision filtering, checks literal VAT, changes restaurant settings, reads the stored JSON directly, then verifies the original stored closure after cross-period refund/remittance.

## Runtime And Commands

Native runtimes: Node22 `v22.13.1`; Node18 `v18.20.8` at `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`.

Every SQL invocation explicitly used this PowerShell setup, with no application DB fallback:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task15-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task15-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
```

The password is the authorized disposable local fixture only. Existing `withDeliveryDatabase` creates/drops only random `smarteat_delivery_test_*` catalogs at loopback33319. Production-style mysql2 projections and actual Express/auth/controller/module calls use fixture pools. Temporary HTTP test listeners bind loopback port0 and close in finally. No existing Nuxt8097/listener6024/SQL service was stopped or reconfigured.

The commands below redirect native stdout/stderr to the named raw logs, save `$task15Exit=$LASTEXITCODE`, print the relevant output and `exit $task15Exit`. No PowerShell success inference replaced a native exit. The affected runner additionally prints `NATIVE_EXIT` for every child and `RESULT` for the batch.

```powershell
# F, focused
node test/delivery-receipts.test.js
# F, affected once per runtime
node .superpowers/sdd/2026-10-16-delivery-management/task-15-affected.cjs frontend
# B, focused actual HTTP/SQL, clear filter for the full four scenarios
Remove-Item Env:TASK15_REPORT_FILTER -ErrorAction SilentlyContinue
node test/delivery-reports.integration.test.js
# B, affected once per runtime
node ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-15-affected.cjs backend
# B, final accepted-revision/immutable-closure focus
$env:TASK15_REPORT_FILTER='SQL closures'
node test/delivery-reports.integration.test.js
# B, existing R5 closure regression after the approved projection change
$env:TASK7_FILTER='R5 sale'
node test/courier-cash.integration.test.js
```

Node18 runs use the exact executable above in place of node. New HTTP/SQL tests use a test-only import-cache bridge to the REAL installed nanoid package on18, following Task3/7. Two unchanged affected tests also needed the scratch `task-15-node18-real-nanoid.cjs` runner. No production shim or claim of unbridged Node18 production boot compatibility.

## RED/GREEN And Raw Logs

All filenames below are relative to Scratch. Intermediate failures remain retained and are not called GREEN.

| Evidence | Native Exit | Raw Log |
| --- | ---: | --- |
| Initial receipt RED: missing fee/VAT, grouped fee, fulfillment, Vue VAT/closure; PDF loader initially needed its browser-only QR boundary corrected | 1 | task-15-f-red.log |
| Actual edit/closure RED after loader corrections | 1 | task-15-edit-red.log |
| Baseline B actual HTTP/SQL RED against exact supplied B BASE modules, after correcting test fixture charge shape/append-only setup | 1 | task-15-b-baseline-red.log |
| Initial B fixture failures, retained separately: attempted snapshot update, missing band/free fields, fee VAT missing | 1 | task-15-b-red.log |
| Payout exact F BASE focused RED: delivery guard missing | 1 | task-15-payout-baseline-red.log |
| Payout product-VAT RED: actual product line scaled20 to24 | 1 | task-15-payout-vat-red.log |
| Payout delivery/mixed guard and Terminal fee/VAT GREEN | 0 | task-15-payout-vat-green.log |
| Edit-link actual loading-state RED then GREEN on22/18 | 1 then0/0 | task-15-edit-link-red.log; task-15-edit-link-green22.log; task-15-edit-link-green18.log |
| Unsupported private edit fields RED then final focused GREEN on22/18, ten scenarios | 1 then0/0 | task-15-edit-details-red.log; task-15-final-focused22.log; task-15-final-focused18.log |
| B HTTP original fee/reprint/public privacy GREEN on22 | 0 | task-15-b-http-green22.log |
| B pre-approval final command on22/18:3 HTTP pass,1 closure fee-VAT failure | 1/1 | task-15-b-final22.log; task-15-b-final18.log |
| Proposal-only real SQL closure test after fixture reread metadata correction | 0/0 | task-15-closure-proposal22-final.log; task-15-closure-proposal18-final.log |
| Actual integrated closure/settings/persisted JSON focus on22 | 0 | task-15-closure-integrated22.log |
| Actual integrated unfiltered four-scenario HTTP/SQL commands on22/18 | 0/0 | task-15-b-green-integrated22.log; task-15-b-green-integrated18.log |
| Final two-line/two-revision closure regression on22/18 | 0/0 | task-15-closure-revision22.log; task-15-closure-revision18.log |
| Existing cash-closure unit regression after approved edit22/18 | 0/0 | task-15-closure-regression22.log; task-15-closure-regression18.log |
| Existing actual SQL R5 closure regression22/18 | 0/0 | task-15-r5-regression22.log; task-15-r5-regression18.log |

Affected frontend files: delivery-receipts, receipt-printing, receipt-bundle, history-ticket, vat-breakdown, cash-closures-store, reports-ticket-z, history-archive-ordering, order-detail-checkout, cash-register, refund-status, printing-fire-and-forget, order-edit, stripe-terminal-payout. `task-15-affected-f22.log` exits1 with13/14 because an empty deliveryCharge metadata key tripped the legacy bundle's broad forbidden-Charge check; omit delivery metadata on legacy structured tickets, then `task-15-bundle-fix22.log` exits0. The passing files were not all repeated on22. Node18 full affected batch `task-15-affected-f18.log` exits0,14/14. Both batches include the complete60/60 Terminal payout cases. Later final focused receipt tests cover the last detail edit-link/private-field guards and PDF wrapping on both runtimes.

Affected backend files: order-metrics-revenue-series, cash-closure, vat, cash-register-payment, service-point-order-display, service-point-cash-register-detail, order-delete-hidden-archive, stripe-terminal-payments, stripe-terminal-refunds. `task-15-affected-b22.log` exits0,9/9. Plain18 batch `task-15-affected-b18.log` exits1,7/9 due to the known pre-existing nanoid ESM boot boundary. ONLY the two failing files were rerun with the real installed dependency bridge: `task-15-hidden-archive18-bridge.log` exit0 and `task-15-terminal-refunds18-bridge.log` exit0,33/33 provider refund/archive assertions. These are separate successful compatibility runs, not a false plain18 batch pass.

Targeted ESLint: `task-15-lint-accepted.log` exits0, zero errors/five pre-existing warnings (one lone-template and four payout test console warnings). Last edited detail/test files are clean in `task-15-lint-last.log`, exit0. Older lint-error/correction evidence remains `task-15-lint-initial.log` and `task-15-lint-final*.log`. Existing stale Browserslist notices were not fixed out of scope. All eight changed Vue templates compiled with the real Vue2 compiler, exit0, `task-15-template-compile.log`. Backend node syntax and both git diff/check/staged-check commands exited0.

No whole npm test/build was run; explicitly reserved for Task17. Frontend pretest image-library behavior is preserved. New frontend unit file is appended to existing npm test; backend SQL file is appended to test:delivery:db without silent skips.

## Actual PDF Artifact QA

The actual `pages/history/ticket/_id.vue` Vue script, its computed payload and its existing jsPDF generator produced the fictional PDFs, not a replacement renderer. `task-15-f-pdf-final22.log` exits0. Browser-only QR import is inert in the test boundary; these fictional receipts have no QR configured. No physical/cloud print submission occurred. SmartPrint/cloud bundle tests use injected fetch/dispatch doubles exclusively.

Renderer used exactly the prepared `smarteat-delivery-pdf-qa:20261018` image by immutable hash `sha256:a8ca570ac2bb8fdd3d6255542a4fdb7e70378f13f3f219b526ce20f88d616590`, with `--rm --network none`. Only the fictional artifact directory was bind-mounted at `/artifacts`; no source/env/real data mounts, Docker context changes, builds, installs or other container actions.

The first raster was actually viewed and found blank: the prepared minimal renderer had no Courier font. Existing local Windows Courier New font files were copied only into the artifact directory, with an artifact-local fonts.conf and `FONTCONFIG_FILE=/artifacts/fonts.conf`. No new renderer or application dependency was installed. A subsequent actual PNG inspection found a clipped refund line; it was split into two short lines and the existing PDF writer now wraps to the58mm page's available width. A follow-up found an isolated currency glyph wrap; the correct53mm printable width keeps the product price/currency together. Final PNGs were rendered again and BOTH were opened and visually inspected using `tools.view_image` in functions.exec. Not a tooling-version or text-only assertion.

Final artifacts, all under `Scratch/qa-runtime/pdf/artifacts/task15/`:

| File | SHA256 |
| --- | --- |
| delivery-paid.pdf | 89125DE8B8854A8B272EC7C6AC755DF72A2D29FC84E087683FF57C3ACE993C04 |
| delivery-refunded.pdf | CA3169BF966BE517B81E02317AEEDB302D4825BBD9E0211ABC0030F3E2AF3870 |
| delivery-paid-1.png | A9F4DCE692EC9A95E8B2DEE7ADA410E342B8223625744AB8CB44DA819B1DE27D |
| delivery-refunded-1.png | FCE44AC9F76DBE8F639AE364727CF6A717EAFB509CCAF7F20D758F87C454E88B |

Actual final visual inspection: restaurant/title/address and order/date are readable; Mode Livraison and Articles1 are distinct; one product20.00 and a separate delivery4.00 line; HT18.18/3.33, VAT1.82/0.67, bold total24.00, payment/footer all visible. Refunded PNG shows both `Remboursement confirme` and `Vente initiale conservee` without clipping. Product euro glyph remains on its price line; no overlap, black boxes, clipped totals or private fields. Both are a single58mm page. Final raster commands exit0 without font warnings: `task-15-pdf-paid-raster-accepted.log`, `task-15-pdf-refunded-raster-accepted.log`.

`python task-15-pdf-literals.py` via the installed pypdf extracts the ACTUAL final PDF text, verifies literal amounts, state, absence of PRIVATE_ sentinel, one page and58mm width: exit0, `task-15-pdf-literals.log`. This supplements the actual image inspection, not substitutes for it. Intermediate raster logs are retained. PDF/artifact scripts/fonts remain local scratch QA, not product artifacts or app metadata.

## Author Self-Review And Limits

Reviewed the complete exact staged scope and both BASE diffs. Checked immutable accepted fee source, explicit server VAT, free fee, mixed grouping, counts/no fake product, separate financial refund display, current-vs-posting source axes, source-linked physical refund fields, old JSON handling and zero-order close guard. Corrected Terminal product scaling, legacy empty delivery metadata, loading-state edit-link opening and PDF clipping/wrapping through focused regression evidence. Public allowlist protects unknown future private fields while leaving admin DTO untouched. New delivery IDs stay strings. No stock/payment/refund producer mutation was added.

Closure amendment review: the fiscal UNION is separate from product rows, constrained to selected archive IDs and matching shop/delivery/accepted charge revision. It cannot multiply by product lines or count a previous charge revision; final regression checks both cases. Stored prior closure JSON is read, not rebuilt after settings/refund/remittance. The four-column consumer was read before the approved edit. No clock/custody/refund engine rewrite.

API environment assumptions were checked in worktree nuxt.config.js, plugins/axios.js and config/config.json. Existing /baseurl/api/v1 requests were preserved. No .env, original checkout, encrypted secrets or real environment was read/decrypted. No provider, IGN, real recipient, Stripe/TPE/refund, print, remote DB, push/deploy/merge or phone action occurred. User's explicit no-env rule takes precedence over the generic environment-read convention.

Residual limits: no real printing, whole UI batch, complete npm/build or production/provider acceptance claim. Those remain Task17/commissioning. Existing unbridged Node18 nanoid boot limitation remains explicit. The price-edit path uses the existing editable-order/quote contract, with unsupported extra private-detail edits refused; no broad editing/financial API redesign. Independent task review remains controller-owned.

## Final Commit And Verification Appendix

Final actual integrated backend commands passed4/4 on BOTH runtimes, native exits0. Those processes loaded the four-scenario test file before its final two-product/two-revision strengthening. The strengthened closure fixture then passed against the actual production module separately on22 and18, native exits0; there were no subsequent production source edits. This records exactly which test revision ran, without repeating the whole batch.

Final frontend focused file passes10/10 on22 and18 (`task-15-final-focused22.log`, `task-15-final-focused18.log`), native exits0. Only Vue option declaration ordering moved afterward for lint; behavior and template stayed unchanged. Final targeted lint on those files exits0 without ESLint warnings/errors (`task-15-lint-last.log`; the retained stale Browserslist notice remains). Affected legacy bundle correction is green; all other requested affected files are covered as described above, including60/60 Terminal payout cases on each runtime.

Both commits used invocation-local hooks suppression, never a persistent git configuration change:

```powershell
# F exact15-file allowlist was explicitly staged and compared with --cached --name-only.
git -c core.hooksPath=NUL commit -m 'feat: include delivery charges in receipts and reports'
# B exact6-file allowlist, including only the approved closure file addition, was checked likewise.
git -c core.hooksPath=NUL commit -m 'feat: include delivery charges in receipts and reports'
```

F commit: `7f02d6c9c4ea123d6681cc0bcb116d0ecb3c17e0` (15 files,641 insertions,50 deletions).
B commit: `94e0a7785ae8fb4bee2cccde8dd7285a6f0aa9f6` (6 files,258 insertions,17 deletions).
Both commit native exits0. Final git status --short returned EMPTY in both repositories; git diff --check exited0. Scratch report/QA artifacts are ignored local evidence and were not staged. No production/session changes overlap the controller. All spawned test processes were awaited and temporary fixture HTTP listeners/pools closed; existing services are preserved.

`task-15-final-native-exits.json` records the final raw-log paths, native exits and tool completion evidence, including the initial affected-batch failures and their narrow corrections rather than hiding them. There is no outstanding ownership/context blocker. The earlier closure proposal is now integrated under the explicit controller grant; it is not a pending NEEDS_CONTEXT request. Remaining limitations are the explicit Task17/commissioning boundaries above.

## Fix Round1: I1 Address Preservation

Read FULL `task-15-review.md` FIRST as requested, then the amended Task15 brief. I1 was confirmed against the actual postal resolution -> quote -> authorized amendment -> locked delivery revision chain. Used receiving-code-review/systematic-debugging with TDD and final verification. M1 inherited warnings remain deferred. No nested agent/reviewer and no Task16 work.

Round1 BASE F `7f02d6c9c4ea123d6681cc0bcb116d0ecb3c17e0`, B `94e0a7785ae8fb4bee2cccde8dd7285a6f0aa9f6`. Authorized Round1 production/test files: F/pages/orders/detail/_id.vue, F/test/delivery-receipts.test.js, B/src/modules/m_deliveryOrders.js narrowly inside reviseDeliveryForOrder, B/test/delivery-reports.integration.test.js. All manual edits use apply_patch. Original checkouts, env files, clocks/locks/financial producers and provider configuration were not changed.

### Contract And Implementation

The revision reads the accepted private fields from `previous.delivery.address_snapshot`, supplied by the existing caller's locked commercial/delivery transaction. Actual fields from normalizeAddress are complement, building, floor, intercom and instructions. It uses existing normalizeAddress and validCoordinates validation with explicit nonempty street/postalCode/city/country fields; it does not allow normalizeAddress's country default to establish equality. Latitude/longitude compare exactly. Existing providerId/cityCode/precision identity, when present in the accepted snapshot, must also match. Provider display label alone may change without identifying another destination.

For the same verified canonical postal/geographic destination, the revision copies ONLY the currently accepted private fields, preserving their exact saved values and presence. New private values in a postal proof are not adopted; no new client private fields, HTTP schema, signed price proof or quote intent was added. A different/insufficiently verified destination carrying existing nonempty access details throws409 `DELIVERY_ADDRESS_CHANGE_NOT_ALLOWED` before the new charge/event insertion. The caller's existing transaction rolls back earlier proposed product/price/reservation/stock writes. Legacy destination changes with no existing private details are not blanket-banned; no new general address editor was built.

No replay/version/auth/payment/pre-pickup/fee/VAT/audit mechanism was rewritten. Existing exact replay happens before revision and still returns the persisted result when current settings are disabled. The original and revised audit views both retain the accepted private fields. The price edit dialog title is explicit, and the409 error tells the operator to retain the validated address. Existing rejection of new client consignes and exact frozen 5xx/network retry body/key remain intact.

### Actual RED/GREEN

All SQL runs used the same explicit disposable fixture URL and ENV_FILE=NUL/JWTKEY/PUBLICIMAGEPATH setup documented above. Round1 tests temporarily set and restore a fixture-only DELIVERY_TOKEN_SECRET for the real HTTP route/default signer; no env file or real signing secret was loaded. They use the existing random-database harness, actual GET editable and PATCH amendment routes, current staff authorization and real SQL repositories. No resolver/provider send occurs: resolution proofs are signed fixture canonical addresses, verified by the actual quote/amend code. On18, only the documented test-only real nanoid import bridge is used.

- `task-15-r1-sql-red.log`: native1, two intended failures before production changes. Same-address price revision cleared old fields/adopted proof instructions; changed-address amendment returned200 rather than409.
- `task-15-r1-vue-red.log`: native1, actual Vue method produced only a generic reprice error rather than the bounded address-retention recovery.
- `task-15-r1-sql-green22.log` / `task-15-r1-sql-green18.log`: native1 intermediate, rollback case passed but the successful revision assertion compared a mysql2 TextRow prototype with a plain literal. Corrected ONLY the fixture object projection to `{...state}`; expected version2/charge_revision2 were unchanged.
- `task-15-r1-canonical-red.log`: native1, additionally exposed an empty country being inferred as FR by existing normalization, allowing an insufficient canonical destination. Explicit nonempty source/quote postal fields now prevent this fallback comparison.
- `task-15-r1-sql-final22.log` / `task-15-r1-sql-final18.log`: native0, both new SQL scenarios passed after the canonical check.
- Final fixture tightening removed all private fields from the positive resolution proof, so it is literally a price-only discount from an accepted nonempty private snapshot. It additionally checks HTTP400 for a newly posted checkout-only delivery_address_details field. Final `task-15-r1-sql-accepted22.log` and `task-15-r1-sql-accepted18.log`: native0,2/2 each. These include original accepted private details -> discount2 -> total22, products VAT1.64 plus unchanged fee4/VAT0.67, version/charge revision2, immutable audit, exact replay after settings suspension, no duplicate charge/event, and original stock. Four rejected destination variants (street, coordinates, provider identity, empty country) preserve complete before/after SQL rows across orders/details/delivery/charges/events/products/reservations/stock movements despite a proposed quantity change.
- `task-15-r1-vue-final22.log` / `task-15-r1-vue-final18.log`: native0, new actual Vue regression checks the precise409 recovery and frozen request object without private-field expansion. Existing uncertain-response retry test remains passing.

Final command forms (SQL setup is mandatory before EACH command):

```powershell
$env:TASK15_REPORT_FILTER='Round1'
node test/delivery-reports.integration.test.js
# Same command on18 with the exact Node18 executable above.
$env:TASK15_RECEIPT_FILTER='Round1'
node test/delivery-receipts.test.js
```

Raw final logs contain `NATIVE_EXIT=0` captured from LASTEXITCODE, not inferred from their printed PASS messages. Earlier initial RED exits were also returned by the native tool and remain described explicitly above.

### Affected Verification

`task-15-r1-affected.cjs frontend` executed exactly8 affected files once per runtime: delivery-receipts (all11 cases), order-edit, order-detail-checkout, receipt-printing, receipt-bundle, history-ticket, vat-breakdown and stripe-terminal-payout. `task-15-r1-affected-f22.log` / `task-15-r1-affected-f18.log`: native0,8/8 each, including60/60 Terminal payout cases. The final focused test reruns cover the subsequent test-only Error-object lint correction and optional selection filter; no production behavior changed after those affected runs.

Backend affected runner executed exactly3 files per runtime: order-editing, stripe-terminal-payments, stripe-terminal-refunds. `task-15-r1-affected-b22.log` / `task-15-r1-affected-b18.log`: native0,3/3 each, including33/33 provider refund/archive assertions.18 uses the real nanoid bridge only for the two legacy files importing the affected CommonJS handler chain; no production boot compatibility claim.

Existing actual SQL Task4 regression selected ONLY `actual amendment and archive|mixed Terminal selection|Terminal settles full` via TASK4_TEST_FILTER. `task-15-r1-terminal-sql22.log` / `task-15-r1-terminal-sql18.log`: native0,3/3 each. This retains commercial/dossier serialization, mixed-selection discount refusal and full accepted fee/product VAT through Terminal settlement/archive without any live provider call.

Targeted modified F lint initially failed the new test's plain-object Promise.reject (`task-15-r1-lint.log`, native1). Fixture now rejects an Error carrying response metadata, matching Axios. `task-15-r1-lint-final.log` and final `task-15-r1-lint-accepted.log`: native0, zero ESLint errors/warnings, stale Browserslist notice retained as deferred M1. Backend node --check and git diff --check pass (only existing LF/CRLF notices). No backend lint script exists; no tooling/dependency was added.

### Remaining Fixture Ownership Request

The legacy actual producer suite `B/test/delivery-checkout.integration.test.js:169` expects its successful price/items revision to change street7 to9 while retaining private instructions; line182 asserts the changed street. That case contradicts the corrected I1 safety contract. Running it against the actual fix produced the expected409 refusal: `task-15-r1-producer22-initial.log`, native1, after preceding checkout cases passed. This failure is NOT hidden or represented as an all-green producer suite.

Concrete NEEDS_CONTEXT proposal, reported before any unowned source edit: approve ONLY those two fixture lines to use the original `address` for its existing quantity2/discount1 revision, then expect street7. Keep every financial, stock, audit, replay/conflict and paid/picked-up assertion. Changed-destination refusal/rollback now has dedicated actual HTTP/SQL coverage in the owned Task15 file. Exact unapplied patch: `task-15-r1-producer-fixture-proposal.patch`; normal `git apply --check` succeeded. This test file is outside the explicitly amended Round1 allowlist and remains untouched pending controller grant. This is an ownership/obsolete fixture blocker, not a request to weaken the production guard.

### Self-Review And Limits

Reviewed the exact Round1 source/test diff. Private data comes from the already locked accepted snapshot, not request/quote details; every field uses the actual address schema. Conservative canonical/coordinate comparison refuses ambiguous reuse and does not transfer instructions to another destination. The local snapshot copy leaves signed quote/fee/financial intent untouched. Late source guard rolls back on the same caller transaction; audit/replay and current paid/pre-pickup guards are unchanged. Test SQL confirms rollback includes prior stock mutations. Sensitive values never enter production logs; test sentinels appear only in retained RED assertion diffs.

No whole npm/build, original/env read, new server, Docker action, provider send, real payment/refund/print, browser loop, push/deploy or Task16 work. PDF source did not change and no PDF artifacts/raster were regenerated; the affected receipt unit file still exercises its existing in-memory jsPDF contract. The previously inspected Task15 PDF artifacts remain the accepted evidence. M1 dependency/old-warning cleanup is deferred as instructed.

Round1 commits (native commit exits0, invocation-local `-c core.hooksPath=NUL`):

- F `9a106e8c0e9b2648a4e9cb95a8e751c910bce575`: ONLY pages/orders/detail/_id.vue and test/delivery-receipts.test.js (21 insertions,3 deletions).
- B `f19cd8233b8ffd0b9254373083d4b9f39c26b363`: ONLY src/modules/m_deliveryOrders.js and test/delivery-reports.integration.test.js (120 insertions,1 deletion).
- Message in both: `fix: preserve delivery access details during repricing`.
- Both staging operations used explicit allowlists, compared against --cached --name-only, followed by staged diff --check. Final status --short EMPTY in both worktrees; final diff --check exits0. No unrelated file/configuration was staged. Scratch report/proposal/log artifacts remain ignored local evidence.

I1 implementation and scoped RED/GREEN/self-review are complete and committed. The exact two-line legacy producer test maintenance above remains NEEDS_CONTEXT because that test is outside the amended Round1 allowlist; no unowned edit was made. Native final exits and SHA bindings are also recorded in `task-15-r1-native-exits.json`. This is not an all-green delivery-checkout producer suite claim, nor a claim that the review has accepted I1. Controller scoped re-review is the next gate.

### Approved Producer Fixture Completion

The controller subsequently approved EXACTLY the two lines in `task-15-r1-producer-fixture-proposal.patch`, with the ruling and brief scope recorded before editing. This resolves and supersedes the historical NEEDS_CONTEXT status above. Applied that exact patch via apply_patch: the positive quantity2/discount1 revision keeps its original `address`, and the street assertion expects `7 rue Test`. Every other assertion is unchanged. The dedicated changed-destination409/full SQL rollback coverage in delivery-reports remains unchanged at the preceding production fix commit. No production source or frontend file changed in this completion.

Ran the WHOLE producer file on both runtimes, with NO selection filter. Before each native command the process received this explicit disposable fixture setup (not an env file):

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task15-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task15-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
Get-ChildItem Env: | Where-Object { $_.Name -match '^TASK.*FILTER$' } | ForEach-Object { Remove-Item -LiteralPath ('Env:' + $_.Name) }
node test/delivery-checkout.integration.test.js
# Second invocation, with the same explicit setup:
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-checkout.integration.test.js
```

The file has no optional environment selection filter; it ran its main checkout/edit assertions and all review cases. Existing Node18 test-only real nanoid import bridge was used unchanged; no production shim/dependency was added. Each command redirected full stdout/stderr to its raw log, captured `$LASTEXITCODE` immediately, appended `NATIVE_EXIT=$task15Exit`, and exited with that same native code. Each completed with 23 `PASS SQL` markers plus `delivery checkout SQL tests passed`:

| Runtime | Whole File Raw Log (relative to this report) | Native Exit | Tool Completion |
| --- | --- | --- | --- |
| Node22 v22.13.1 | task-15-r1-producer22-accepted.log | 0 | bd2261 |
| Node18 v18.20.8 | task-15-r1-producer18-accepted.log | 0 | 4853e4 |

This is the final GREEN for the earlier retained producer RED (`task-15-r1-producer22-initial.log`, native1). All existing financial/replay/conflict/archive/stock/payment/pre-pickup assertions now pass with a valid same-destination positive fixture. No assertions were deleted or relaxed beyond the exact two approved fixture lines.

Self-review confirmed the complete staged diff contains ONLY `B/test/delivery-checkout.integration.test.js`, two inserted/two removed lines matching the approved proposal. `git -c core.hooksPath=NUL add -- test/delivery-checkout.integration.test.js` used an explicit single-file allowlist; a scripted --cached --name-only check rejected any other staged path. Staged diff --check exited0 (tool c785cd; only Git's LF/CRLF notice). Commit command `git -c core.hooksPath=NUL commit -m 'test: align delivery repricing fixture with address preservation'` exited0 (8b4264).

- F remains `9a106e8c0e9b2648a4e9cb95a8e751c910bce575`, unchanged.
- B new HEAD `a22f75a02c5c9e8439b1c33d956a104dc85f364b`, direct parent `f19cd8233b8ffd0b9254373083d4b9f39c26b363`.
- Final status --short EMPTY and diff --check exit0 in BOTH worktrees (014477/1d9b53). Scratch report/log/manifest evidence remains ignored and unstaged. All test processes completed.

Limits unchanged: no repeated whole npm/build or previously passing affected batches, new browser/server/Docker action, PDF regeneration, original checkout/env read, remote database, provider/payment/refund/print submission, nested agent, push/deploy/merge, or Task16. Existing services were preserved. M1 warnings remain deferred. DONE for this bounded implementation; ready for controller coupled scoped review, not a claim of independent review acceptance.
