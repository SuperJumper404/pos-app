const fs = require('fs');
const { chromium, openContext, go, capture, report, reportPath, session } = require('./ui-qa.cjs');
async function main() {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const viewport = { width: 390, height: 844 };
    if (process.argv[2] !== 'remaining') {
    const unavailable = await openContext(browser, 'anonymous', viewport, { channels: { email: false, whatsapp: false } });
    await go(unavailable.page, '/compte?shopId=7');
    await capture(unavailable.page, 'account-unconfigured-mobile', ['indisponible pour le moment', 'Reessayer']);
    await unavailable.context.close();
    const failed = await openContext(browser, 'anonymous', viewport, { challengeStatus: 'failed' });
    await go(failed.page, '/compte?shopId=7');
    await failed.page.getByLabel('Adresse e-mail', { exact: true }).fill('recette@example.invalid');
    await failed.page.getByRole('button', { name: 'Recevoir un code', exact: true }).click();
    await capture(failed.page, 'account-send-failed-mobile', ["Le code n'a pas pu etre envoye"]);
    await failed.context.close();
    }
    const linked = await openContext(browser, 'anonymous', viewport, { personal: true });
    await go(linked.page, '/compte?shopId=7');
    await linked.page.getByRole('button', { name: 'Ajouter un e-mail ou WhatsApp', exact: true }).click();
    await capture(linked.page, 'account-link-mobile', ['Ajouter un contact', 'Mes adresses']);
    await linked.context.close();
    for (const [size, width] of [['desktop', 1440], ['mobile', 390]]) {
      const cashier = await openContext(browser, 'cashier', { width, height: 844 });
      await go(cashier.page, '/livraison');
      const tabs = await cashier.page.getByRole('tab').allTextContents();
      report.interactions.push({ name: `cashier-tabs-${size}`, tabs, settingsDisabled: await cashier.page.getByRole('tab', { name: 'Reglages', exact: true }).getAttribute('aria-disabled') });
      await cashier.page.getByRole('tab', { name: 'Livreurs', exact: true }).click();
      await capture(cashier.page, `couriers-cashier-${size}`, ['Livreur de recette']);
      report.interactions.push({ name: `cashier-account-controls-${size}`, count: await cashier.page.getByRole('button', { name: 'Gerer le compte et le PIN', exact: true }).count() });
      await cashier.context.close();
      const admin = await openContext(browser, 'admin', { width, height: 844 });
      await go(admin.page, '/livraison');
      await admin.page.locator('.v-select .v-input__slot').first().click();
      await admin.page.getByRole('option', { name: 'Terminees recentes', exact: true }).click();
      await admin.page.getByRole('button', { name: 'Actions livraison', exact: true }).first().click();
      await admin.page.getByText('Corriger une erreur terminale', { exact: true }).click();
      await admin.page.getByLabel('Motif', { exact: true }).fill('Erreur de statut fictive pour la recette.');
      await capture(admin.page, `terminal-correction-${size}`, ['Paiement, stock et especes restent a traiter separement']);
      await admin.context.close();
    }
    const narrow = await openContext(browser, 'admin', { width: 320, height: 640 });
    await go(narrow.page, '/livraison');
    await narrow.page.getByRole('tab', { name: 'Reglages', exact: true }).click();
    await narrow.page.waitForTimeout(700);
    await capture(narrow.page, 'settings-narrow-settled', ['Reglages']);
    await narrow.context.close();
  } finally {
    await browser.close();
    report.finishedAt = new Date().toISOString();
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    process.stdout.write(`captures=${report.captures.length}, failures=${report.failures.length}, pageErrors=${report.errors.length}\n`);
  }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
