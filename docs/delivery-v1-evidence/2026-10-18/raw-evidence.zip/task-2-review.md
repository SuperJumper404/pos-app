# Independent Task 2 Review

**Task Quality: Needs Fixes. Spec Compliance: Issues.**

Scope: supplied `d402f52..88c33b1` review package, Task 2 only. B is the delivery-v1 `express-pos` worktree; F is its neighboring `pos-app`. References below are relative to B unless prefixed F. The common contracts in F/docs/superpowers/plans/2026-10-16-delivery-management.md and exact fixtures in task-2-brief.md are binding. The implementation report was evidence to inspect, not an approval.

## Spec Compliance

| Status | Assessment |
| --- | --- |
| Compliant | All 13 named files are supplied. Exact distance/band/minimum/free fixtures, R1 postal-only request/private complement, R3 one-cent discount, configured fee VAT, takeaway product VAT, shop-bound address proof (15 min), quote (5 min), purpose separation, server prices, session-derived shop and guest discount denial are implemented. |
| Compliant | Missing/default settings disable delivery; activation requires origin/radius/full bands/explicit fee VAT. SQL settings updates are atomic and revision-controlled. New SQL identifiers are omitted rather than cast to numbers; historical product/choice IDs retain their existing numeric representation. |
| Compliant | Provider errors/timeouts do not become zero-distance or successful empty results; backend cache and in-flight sharing exist. One SQL named lock and an all-shop aggregate impose a shared maximum of 40 reservations; this is not 40 per shop. Native HTTP transport has an absolute 5-second timer. |
| Compliant | Only backend environment names/default provider URL and explicit dummy signing fixtures are introduced; no provider credential is present in this diff. Router construction does not require the signing secret. Existing API prefix, global JSON error handling, CORS and raw Stripe webhook parsing are preserved. |
| Issues | Delivery discount arithmetic returns to floating euro amounts, violating the new internal cents contract and changing fee decisions (I1). Loaded monetary settings are converted to unsafe numbers without validation (I2). The new mandatory house-number/confidence policy narrows address coverage without a requirement or validated acceptance decision (I3). |
| Cannot Verify | Actual IGN coverage/precision and live supplier acceptance were not established by injected fixtures. Reported Node 18/22, SQL and full-suite passes were not rerun. No independent assertion about checkout/payment integration or complete V1 acceptance is made. |

## Strengths

- Good separation of pure pricing/money/signature logic, supplier transport, SQL repositories and thin HTTP adapters; no dependency additions or checkout imports.
- Unrounded Haversine distance and inclusive bands are used for enforcement; net products drive both minimum and free delivery. Fiscal HT/TVA splitting itself uses integer arithmetic.
- HMAC verification checks signature, purpose, time and shop. Client prices, raw coordinates and body shop/actor flags cannot become quote authority. Service-point tokens cannot grant their own discount or administrator settings access.
- Quota cleanup destroys connections with uncertain lock/rollback state. Cross-shop SQL concurrency and settings rollback/revision behavior have reported test evidence.
- Tests include actual legacy product quotation, injectable supplier calls, local HTTP failure servers, routing and disposable SQL coverage; exact required Task 2 fixtures are present.

## Critical Findings

None identified in this task scope.

## Important Findings

### I1. Floating discount calculation can change free-delivery eligibility

**File:** `src/modules/m_deliveryQuotes.js:52` (and line 53).

After adapting the legacy product total to cents, the new service converts it back to euros and calls `calculateDiscount`, whose percentage calculation rounds floating values with `toFixed(2)`. Converting its result to cents cannot recover the lost cent. The integer requirement applies inside this new service even when a legacy helper is reused.

**Effect/evidence:** An in-memory `createQuote` reproducer with 105 product cents, 10% discount, free threshold 95 and band fee 200 returned discount 10, net 95, fee 0, total 95. Integer half-up rounding, consistent with the new money helper's rounding convention, gives discount 11, net 94, fee 200, total 294. This can also change minimum eligibility. The report's R3 fixed-amount fixture does not cover this case.

**Fix:** Normalize the authorized discount intent at the boundary, then calculate amount/percentage discounts in integer cents using an explicit decimal percentage scale and rounding rule. Keep the legacy product quote adapter at the boundary; do not change historical discount behavior globally. Add a focused percentage/threshold regression.

### I2. Loaded monetary configuration is neither safe nor validated

**File:** `src/modules/m_deliverySettings.js:26` (also lines 28, 30 and the unvalidated service pass-through at line 63).

Selecting BIGINT money as CHAR is good, but immediately converting it with `Number` without a safety check can silently change its value. `getSettings` returns it directly, including through admin GET. Validation on update and later in pricing does not validate this read boundary. The report's statement that selected monetary values are checked as safe cents is not true of this path.

**Effect/evidence:** A focused repository stub returning SQL text `minimum_items_cents = '9007199254740993'` produced `minimumItemsCents = 9007199254740992`, with `Number.isSafeInteger` false and no error. The same conversion pattern affects the free threshold and fees. Such configuration can be exposed rounded and later makes quote pricing unavailable.

**Fix:** Parse/reject unsafe or malformed monetary fields before returning settings, and validate the loaded settings at the concerned service boundary. Preserve valid disabled defaults and lazy legacy boot; do not add a process-start validation failure or change the global pool. Add a read-boundary regression for the SQL string value above.

### I3. Mandatory house number and score 0.7 impose an unsupported coverage policy

**File:** `src/services/deliveryGeocoding.js:128` (through line 130).

Every selection, including an explicit provider ID, is filtered through `type === 'housenumber'`, string housenumber and score >= 0.7. Neither the common contract nor Task 2 specifies those mandatory acceptance criteria. This is a material restriction on resolvable French addresses, including unnumbered premises, rather than merely implementing the required ambiguity rejection. Calling it conservative in the report does not establish that the coverage loss is acceptable.

**Effect/evidence:** An injected unique address feature with valid coordinates, matching postcode, score 0.99 and `type: 'street'` was rejected with an empty candidate list even when its provider ID was explicitly selected. Thus the consumer cannot resolve that class of unnumbered postal result. This fixture demonstrates the imposed restriction, not that every street centroid is accurate enough for delivery.

**Fix:** Establish and document a justified supplier precision/selection policy that covers legitimate unnumbered premises, with representative fixtures, or obtain an explicit product decision accepting that limitation before treating Task 2 as compliant. Do not solve this by accepting arbitrary street centroids, browser coordinates or distance fallbacks. Explicit choice must still refer to an adequately resolved postal location.

## Minor Findings

### M1. Missing signing configuration is discovered after supplier work

**File:** `src/modules/m_deliveryQuotes.js:33` (signing occurs at line 37).

`resolveAddress` geocodes before the default signer checks its secret. A focused injected-geocoder reproducer with no signing secret returned `DELIVERY_UNAVAILABLE` only after one geocoder call. Legacy boot remains correctly lazy, but repeated unusable resolution attempts can consume shared supplier quota and send postal data when a proof cannot be issued.

**Fix:** Preflight signing configuration at entry to an operation requiring a signed proof, before cache misses/quota/provider calls. Keep this validation out of router construction and historical startup. Test that the unavailable operation performs zero supplier calls.

## All 13 File Obligations

| File | Review result |
| --- | --- |
| `index.js` | Router mounted under existing prefix; CORS, global JSON error and raw webhook order preserved. |
| `package.json` | Both new pure tests added; previous test commands retained; SQL quote mode follows Task 1 SQL test. |
| `src/controllers/c_delivery.js` | Authenticated shop authority; body prices/scope ignored; service-point manual discount denied; settings GET/PUT admin-only; sanitized failures. |
| `src/helpers/deliveryAddress.js` | Postal/private fields normalized separately; bounded HMAC tokens; address purpose, shop and 15-minute TTL checked. |
| `src/helpers/deliveryMoney.js` | Safe nonnegative cents/overflow guards and integer fiscal split; does not prevent the separate I1/I2 caller defects. |
| `src/helpers/deliveryPricing.js` | Raw Haversine, inclusive complete bands, net minimum/free rules, explicit activation VAT and invalid inputs handled. |
| `src/helpers/env.js` | Lazy backend-only accessor; no real new credential; M1 concerns when it is validated. |
| `src/modules/m_deliverySettings.js` | Disabled defaults, resolved origin, atomic revisioned updates and narrow ID projections; I2 read validation gap. |
| `src/modules/m_deliveryQuotes.js` | Server product reload/takeaway VAT; scoped signed five-minute quote and canonical intent; I1 and M1. |
| `src/routers/r_delivery.js` | Four authenticated routes, injectable factory and compatible default-router export. |
| `src/services/deliveryGeocoding.js` | Postal-only provider request, cache/deduplication, shared SQL quota and timeout/refusal handling; I3 coverage restriction. |
| `test/delivery-pricing.test.js` | Exact Task 2 numerical fixtures, invalid values/bands/VAT, money/fiscal checks and proof scope/expiry/tampering present. |
| `test/delivery-quotes.test.js` | R1/R3, authoritative prices, guest/admin scope, expiry, provider failure/cache/HTTP deadline, lazy boot and SQL evidence; lacks regressions for findings above. |

## Independent Decisions And Scope

- Two-second bucket accounting is acceptable against a maximum of 40/s, which is a ceiling rather than a promised throughput. It sacrifices sustained capacity (roughly 20/s) but the lock and aggregate are global across shared SQL instances/shops. No per-shop-quota finding.
- Admin-only full settings GET agrees with the explicit settings permissions contract. A future public availability projection is separate work; no GET permission finding.
- Mandatory housenumber/0.7 acceptance is not approved merely because it is conservative: see I3. Live precision suitability remains unverified.
- Quotes do not create an order or grant checkout authority. POS and the existing public site's authenticated service-point context can obtain Task 2 quotes; guest discount denial is enforced here. Restricting actual delivery checkout origins and enforcing checkout/payment recalculation remain Tasks 3/5, not missing Task 2 checkout implementation.
- Deferred: order persistence, final recalculation/confirmation before payment, tracking, dispatch, customer sessions and UI. This is not a final branch or V1 release review.

## Review Evidence And Method

Read the three named inputs and common contracts; read the supplied diff once. Numbered reads of changed files completed inspection where tool output clipped the diff. All 13 obligations above were examined. `workspace_fs` was attempted but unavailable; targeted shell reads were used. No git commands, crawl, suite reruns, subagents, checkout/index/branch mutations, provider requests or application writes were performed.

Unchanged-code risk/check pairs: (1) product/discount authority and rounding -- one focused inspection of `m_orderQuote.js` and `discount.js`; (2) staff/public session scope -- one focused inspection of `middleware/auth.js` and `staffAccess.js`. The changed `index.js` assembly was also checked specifically for JSON errors/CORS/raw Stripe webhook preservation. Focused in-memory reproducers addressed only doubts not answered by the report: rounding/thresholds, unsafe SQL read conversion, missing-secret ordering and the imposed unnumbered-address policy. No database or supplier was contacted by these reproducers.

**Verdict: Needs Fixes.** Correct I1/I2 and resolve I3's acceptance policy before approving Task 2. M1 is an additional bounded improvement. Existing reported suite/SQL passes provide useful regression evidence but do not resolve these uncovered behaviors.
