# Task 10 report

Implementation status: TASK10 implemented and author self-reviewed; controller review remains required. New tests and the single whole npm test pass. Two earlier SQL test assertion sites still assert that the now-required personal routes do not exist; the exact bounded ownership need is recorded below. No claim that the whole registered SQL command is green.

B: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
F: sibling pos-app. Scratch: F/.superpowers/sdd/2026-10-16-delivery-management.
Branch: feat/delivery-v1. Starting clean HEAD / BASE: d2f4d623b2f777dc57ce32aab579b96217ccefe0.
Commit: 23e26673127fab08378851aed36147d0fc23ecec, `feat: isolate customer sessions and address permissions`.
Compatible unchanged frontend HEAD: 6f694519d0db9ee631fe9d85550af71165dac293.

## Scope and authority

Read task-10-brief.md FIRST, then worker-context.md, task-10-integration-notes.md, common contracts, specification section 8 and HTTP/permissions sections, and final Task8/9 reports including their fix rounds. The amended brief was not regenerated. Existing plans, briefs, rulings, progress.md and history remain intact.

Exactly the eleven brief-owned backend files changed: index.js; package.json; package-lock.json; src/helpers/customerSession.js; src/helpers/middleware/customerAuth.js; src/helpers/customerCors.js; src/helpers/env.js; src/controllers/c_customers.js; src/routers/r_customers.js; test/customer-session.integration.test.js; test/customer-cors.test.js. No migrations, shared staff middleware, persistence, legacy auth modules, old tests, frontend source or real environment files changed. This report and raw logs are ignored scratch artifacts in F.

workspace_fs was attempted and refused the paired worktrees (allowed roots are the original checkouts). Shell reads followed the explicit worker-context fallback. Skills used: executing-plans, test-driven-development, systematic-debugging and verification-before-completion. User instructions override skill bookkeeping/agent/cleanup workflows: no ledger regeneration, scratch deletion, subagents or independent reviewers were invoked. The controller owns independent review.

## Produced interfaces

`buildCustomerSession({repository?,clock?,secret?,allowedOrigins?})` exports the common contract unchanged:

- create({shopId,customerId,verifiedChallengeId}) -> {rawToken,session,csrfToken}.
- read({rawToken,shopId}) -> session|null.
- revoke({rawToken,shopId}).
- csrfToken(session) -> hex HMAC string.
- verifyCsrf({session,token,origin}) -> boolean (unavailable configuration can raise a sanitized service error).

Internal session shape: {id,shopId,customerId,tokenHash,csrfSecretHash,expiresAt,subject:'customer'}. New IDs are exact decimal strings; shopId retains the legacy integer type. These hash/internal fields are never in a production HTTP DTO. `buildSqlCustomerSessionRepository({pool?})` exposes create/read/revoke and transactionForShop({shopId},work). The latter begins a transaction, locks Shop FOR SHARE, executes work on that connection, then commits or rolls back; failed rollback destroys the connection. There are no application deadlock retries.

Creation generates 32 cryptographically random bytes, encoded as canonical base64url (43 characters); SQL stores only SHA256(rawToken). A second random 32-byte value is hashed for csrf_secret_hash. CSRF is a server HMAC over a domain separator plus session id, shop, customer, token hash and CSRF hash. Validation requires an exact allowed Origin, a 64-hex token, an unexpired session, and timingSafeEqual. The OTP is never used as CSRF material.

Session creation locks Shop, then the owned customer, then the challenge. It requires the exact shop/customer, login purpose, no link target, verified_at + consumed_at, sent state, non-invalidated and unexpired challenge. UNIQUE verified_challenge_id makes two creates race to one session. It deliberately does NOT require sent_at or provider acknowledgement: a verified timeout-origin challenge with null sent_at is accepted. All dates use whole-second UTC SQL strings/DATE_FORMAT, independent of the mysql2 driver's timezone/numeric defaults. Read checks shop, revocation and expiry; expiry is exactly creation + 30 days, without sliding extension.

`buildCustomerMiddleware({sessions?})` and direct exports provide requireCustomerSession, attachOptionalCustomerSession, requireCustomerCsrf, requireCustomerCsrfIfPresent. Only req.customerSession is attached; req.id/access/shopid/sessionSubject and servicePointId are untouched. Optional attachment verifies against the existing authenticated checkout req.shopid and yields null for another shop. A cookie cannot satisfy any legacy bearer authentication.

Cookie policy: HTTPS uses __Host-smarteat_customer, Path=/, HttpOnly, Secure, SameSite=Lax, Max-Age=2592000 and matching Expires, with no Domain. HTTP development uses smarteat_customer only on localhost/loopback hostnames and outside NODE_ENV=production. Remote insecure HTTP verification fails before consuming the code. A secure request never accepts the weaker local cookie. Logout revokes the exact shop/token and clears only the cookie name appropriate to that transport. Wrong-shop logout does not revoke or clear another session.

`buildCustomerAuthController` now accepts sessions in addition to its Task9 auth/transports dependencies. `buildPersonalCustomersController({customers?,quotes?,sessionRepository?})` adapts the existing Task8 service and Task2 resolver. The default personal service wraps Task8's transactions with transactionForShop so address owner/FK work follows Shop -> customer order; it does not modify the shared staff adapter or m_customers. Injectable test services are actual SQL implementations.

## HTTP contract for Task11

All paths below are relative to the existing API prefix. Responses retain helpers/response.js envelopes and authenticated results are Cache-Control: no-store. The authenticated personal routes require `?shopId=<legacy integer>` as an expected-tenant assertion. This value selects no owner: it must match the cookie's SQL session, and all business shop/customer parameters then come ONLY from req.customerSession. Posted shopId/customerId on these mutations is rejected. Checkout instead uses its existing authenticated req.shopid.

| Method/path | Input | data DTO / guards |
| --- | --- | --- |
| GET /customer-auth/channels | none | {email:boolean,whatsapp:boolean}; existing Task9 configuration readiness only |
| POST /customer-auth/challenges | Task9 shopId/channel/destination/countryCode?/browserBinding/locale? | Existing safe challengeId/expiresAt/resendAfter/status, forced login/null owner |
| POST /customer-auth/verify | {shopId,challengeId,code,browserBinding} | Set-Cookie + {subject:'customer',shopId,customerId,expiresAt,csrfToken}; no raw token in body |
| GET /customer-auth/session | ?shopId | Same safe session DTO, current SQL session required |
| POST /customer-auth/logout | ?shopId; empty body | {loggedOut:true}, session + CSRF required |
| POST /customer-auth/link/challenges | ?shopId; {channel,destination,countryCode?,browserBinding,locale?} | Existing safe challenge DTO; purpose='link' and owner derived from session; session + CSRF |
| POST /customer-auth/link/verify | ?shopId; {challengeId,code,browserBinding} | {linked:true}; explicit browserBinding passed to Task9 linkIdentity; session + CSRF |
| GET /customer/addresses | ?shopId | Existing Task8 owned address DTO array |
| POST /customer/addresses | ?shopId; {addressResolutionToken,complement?,instructions?,makeDefault?} | Existing Task8 address DTO; session + CSRF |
| PATCH /customer/addresses/:addressId | ?shopId; Task8 optional proof/private/default fields | Existing Task8 address DTO; session + CSRF |
| DELETE /customer/addresses/:addressId | ?shopId; empty body | {id}; session + CSRF |
| POST /customer/address-resolutions | ?shopId; exactly {addressId} OR {address,candidateId?} | {addressSnapshot,addressResolutionToken,expiresAt}; session + CSRF |

Postal address fields are street/postalCode/city/country/complement/instructions only. Browser coordinates/provider snapshots are rejected; candidateId is camelCase on this personal route. Stored renewal calls the actual Task8 resolveStoredAddress/existing signAddressResolution, with zero geocoder/supplier calls even during outage. New/changed postal destinations use the actual Task2 geocoder/quota/signer; ambiguous responses expose only its filtered postal candidate DTOs, never supplier-private fields. Private apartment/door instructions are not sent to IGN. Both resolver variants share the same origin/CSRF guards. No pricing, staff token or public contact lookup is involved.

New sanitized errors: CUSTOMER_SESSION_INVALID (401), CUSTOMER_SESSION_UNAVAILABLE (503), CUSTOMER_CSRF_FORBIDDEN and CUSTOMER_ORIGIN_FORBIDDEN (403). Existing Task8/9/Task2 domain errors retain their codes, including CUSTOMER_IDENTITY_CONFLICT (409). No customer failure triggers staff logout or persistence mutation.

## CORS, proxies and dependency

`buildCustomerCors({prefix?,allowedOrigins?})`, `isCustomerCorsRequest(req,prefix?)` and `configureCustomerTrustProxy(app,trustedProxies?)` are exported. index installs exact-origin handling BEFORE the legacy wildcard. Its wildcard middleware skips personal paths and cookie-bearing checkout requests; legacy bearer/public requests retain historical wildcard behavior without credentials. Personal routes are mounted before global authenticationIfPresent, so stale/malformed staff headers cannot block an independent customer request. Staff-only customer routes still run their existing current-account authentication and authorization.

Allowed cross-origin responses use the exact Origin, Access-Control-Allow-Credentials:true, and Vary:Origin. Unknown/null origins are refused without wildcard/credentials. Reads without Origin are permitted; personal mutations and preflights require an allowed Origin. OPTIONS terminates with 204 before auth/mutation, permits GET/HEAD/POST/PATCH/DELETE and Content-Type/X-CSRF-Token/Authorization/Authentication/Accept, and varies on requested method/headers. Cookie checkout preflights are recognized by X-CSRF-Token in Access-Control-Request-Headers, since browser preflights do not carry cookies. The CSRF token is in the safe JSON DTO, so no exposed response header is required.

Stripe's bodyParser.raw stays before JSON parsing and authentication. A test executes actual index.js wiring and checks that the downstream signature boundary receives an unchanged Buffer/hash. Only startup, image mkdir checks and that downstream boundary are controlled in this non-boot test; production middleware ordering is real.

env.js adds lazy getCustomerSessionConfig(): CUSTOMER_ALLOWED_ORIGINS is a comma-separated exact list of HTTPS origins or HTTP localhost/loopback origins (no paths, wildcard or normalization into a different origin). CUSTOMER_TRUSTED_PROXIES is a comma-separated literal IP/CIDR list. Default trust is false; an invalid entry disables trust for the whole list. It uses Express's supported trust-proxy implementation, never raw body IP/XFF. Trust also determines req.secure behind the approved proxy. The existing CUSTOMER_AUTH_SECRET is reused with domain separation and must meet Task9 readiness/separation from JWTKEY. No environment file was read or modified for configuration.

Direct dependency: cookie ^0.7.2, installed 0.7.2. Official version-specific primary documentation was consulted before implementation:

- https://raw.githubusercontent.com/jshttp/cookie/v0.7.2/README.md (require('cookie'), parse, serialize, maxAge in seconds, expires Date, no default Domain, httpOnly/secure/sameSite='lax').
- https://raw.githubusercontent.com/jshttp/cookie/v0.7.2/package.json (CommonJS index.js and Node >=0.6, compatible with 18).

Install command: `npm.cmd install cookie@^0.7.2 --save --registry=https://registry.npmjs.org --ignore-scripts --no-audit --no-fund`, exit 0; task-10-install.txt. Existing Express 0.4.0 cookie dependency remains nested and unchanged. No unrelated dependency/tooling modernization. Structured BASE/package comparisons prove every old test command, other script and dependency is retained; only the two new test prefixes and direct cookie dependency are added.

## Verification and logs

Native Node22: v22.13.1. Cached Node18: v18.20.8, executable C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe. Commands ran from B. Every SQL invocation explicitly set DELIVERY_TEST_DATABASE_URL=mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql, the authorized local disposable MySQL fixture. The existing harness created/dropped random smarteat_delivery_test_* databases only. Unit tests require no SQL/provider configuration. No registered whole SQL suite was repeatedly run.

| Command / phase | Exit / result | Raw log in scratch |
| --- | --- | --- |
| node test/customer-cors.test.js, before helper implementation | 1, two absent-module failures | task-10-cors-red.txt |
| node test/customer-session.integration.test.js, before helper implementation | 1, absent session module | task-10-session-red.txt |
| Initial cors implementation | 0, 2/2 | task-10-cors-green-attempt.txt |
| Initial SQL/HTTP implementation | 1, eight functional groups passed; staff JWT fixture loaded after env module | task-10-session-green-attempt.txt |
| Corrected JWT fixture initialization | 0, 10/10 TAP tests | task-10-session-green.txt |
| Extended provider/quotas/IDs/link coverage | 0, 14/14 | task-10-session-extended.txt |
| Default personal adapter Shop-order regression RED | 1, actual SQL observed customers before Shop | task-10-shop-order-red.txt |
| Default personal adapter Shop-order GREEN | 0, 15/15, Shop then customers | task-10-shop-order-green.txt |
| Actual index HTTP/CORS/raw-Stripe test | 0, 3/3 | task-10-index-http.txt |
| FINAL Node22 node test/customer-cors.test.js | 0, 3/3 | task-10-node22-customer-cors.test.js.txt |
| FINAL Node22 node test/customer-session.integration.test.js | 0, 16/16 | task-10-node22-customer-session.integration.test.js.txt |
| FINAL Node18 executable + the two same test files | 0, 3/3 and 16/16 | task-10-node18-customer-cors.test.js.txt; task-10-node18-customer-session.integration.test.js.txt |
| Both runtimes: node test/customer-code-transports.test.js and node test/customer-identity.test.js | 0, 7/7 and 17/17 per runtime | task-10-node18/22-<filename>.txt |
| Both runtimes: delivery-authorization.test.js | 0, existing actual HTTP/current-role/staff-login/profile/logout contracts | task-10-node18/22-delivery-authorization.test.js.txt |
| Node22: eleven legacy staff/service-point/table QR files below | 0 each | task-10-node22-<filename>.txt |
| Plain Node18 staff-credentials.test.js probe | 1, existing legacy require(nanoid) ESM limitation | task-10-node18-staff-credentials.test.js.txt |
| Node18 with tests-only actual Nano ID cache bridge: eleven files below | 0 each | task-10-node18-bridge-<filename>.txt |
| node test/delivery-schema.integration.test.js | 0, both existing groups, including complete migration chain up/down/up | task-10-schema-regression.txt |
| node test/customer-addresses.integration.test.js | 1; 9 pass, one obsolete route-absence subtest plus parent fail; populated rollback passed | task-10-existing-customer-addresses.integration.test.js.txt |
| node test/customer-auth.integration.test.js | 1; 21 pass, one obsolete route-absence subtest plus parent fail; archive/Shop lock schedule and staff stored JWT passed | task-10-existing-customer-auth.integration.test.js.txt |
| npm.cmd test, ONCE, full environment below | 0, all registered unit/HTTP legacy commands through admin-legacy-password-login completed | task-10-npm-test.txt |
| Structured package/CommonJS dependency checks | 0 | task-10-static.txt |
| node --check on all nine new/changed JS files; git diff --check and staged --check | 0 each | terminal evidence; no syntax/whitespace errors |

The eleven focused legacy files: staff-credentials.test.js, staff-module-permissions.test.js, staff-login-contract.test.js, admin-email-login.test.js, admin-legacy-password-login.test.js, service-point-access-token.test.js, service-point-session-auth.test.js, shop-service-points-init.test.js, service-points-controller.test.js, table-access-token.test.js, table-access-controller.test.js. Each ran separately on Node22. Node18 used the same filenames and, only where needed for legacy imports, this invocation-local test bridge to the REAL installed dependency:

```powershell
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' -e "import('nanoid').then(dependency => { require.cache[require.resolve('nanoid')] = { exports: dependency }; require('./test/' + process.argv[1]); }).catch(error => { console.error(error); process.exitCode = 1; });" <filename>
```

The two new test files contain the same existing bridge only inside their Node18 actual-handler loading paths. No production interop was broadened, and no unbridged Node18 boot is claimed. Configured Node20 whole application boot remains Task17.

New SQL/HTTP coverage includes cookie attributes/transport/name separation, only token hashes in SQL, safe DTOs, exact thirty-day expiry, revocation/wrong-shop rejection, simultaneous bearer+cookie contexts, stale staff headers, optional checkout wrong-shop null context, missing/OTP/cross-session CSRF, forbidden/no Origin mutation and OPTIONS behavior, concurrent HTTP verify/account/session uniqueness, duplicate direct creates, unverified/expired/link/wrong-owner/invalidated proofs, null-sent_at verified timeout, link purpose/owner/browser isolation and conflict, actual IGN HTTP filtering/ambiguity/outage plus zero-call stored renewal, real cross-shop SQL IP ceiling under rotating untrusted XFF, IDs above 2^53 under numeric driver defaults and +02:00 timezone, Shop-first personal transactions, trigger-induced session insert rollback, and preservation of users.token plus staff bearer after personal logout.

## Exact disposable command environment

Focused commands used ENV_FILE=NUL, fixture JWTKEY/PUBLICIMAGEPATH and the explicit SQL URL above; transport/config fixtures are supplied by the existing HTTP-double helper. No real .env or provider account data is loaded. Full test command was invoked exactly once with:

```powershell
$env:NODE_ENV='test'
$env:ENV_FILE='NUL'
$env:PORT='0'
$env:DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/task10_no_app_database'
$env:DBHOST='127.0.0.1'
$env:DBPORT='33319'
$env:DBUSER='root'
$env:DBPASS='local_delivery_test_only'
$env:DBNAME='task10_no_app_database'
$env:JWTKEY='task10-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task10-fixture/'
$env:EMAIL='central@example.test'
$env:MAILAPIKEY='fixture-public-key'
$env:MAILSECRETKEY='fixture-private-key'
$env:STRIPE_SECRET_KEY='sk_test_task10_fixture'
$env:STRIPE_WEBHOOK_SECRET='whsec_task10_fixture'
$env:STRIPE_PUBLISHABLE_KEY='pk_test_task10_fixture'
$env:STRIPE_CONNECT_RETURN_URL='http://localhost:3000/task10-return'
$env:STRIPE_CONNECT_REFRESH_URL='http://localhost:3000/task10-refresh'
$env:CUSTOMER_AUTH_SECRET='task10-customer-auth-secret-disposable-only'
$env:DELIVERY_TOKEN_SECRET='task10-delivery-token-secret-disposable-only'
$env:CUSTOMER_ALLOWED_ORIGINS='https://shop.smarteat.test,http://localhost:3000'
$env:CUSTOMER_TRUSTED_PROXIES=''
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
Remove-Item Env:TASK4_TEST_FILTER,Env:TASK5_REVIEW_FILTER,Env:TASK7_FILTER,Env:TASK7_REFUND_FILTER -ErrorAction SilentlyContinue
npm.cmd test *> '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-10-npm-test.txt'
```

The non-existent task10_no_app_database name is a guard against an unintended app-database fallback, not an application catalog used for SQL tests. SQL tests use only withDeliveryDatabase and the explicit disposable URL. These credentials/keys/domains are local test literals.

## Bounded ownership need and limits

Reported to the controller/user BEFORE any potential outside-file edit; NO outside-file edit was made. Exactly two existing assertion sites need authorization/ownership extension to update their former-stage assumptions:

1. B/test/customer-addresses.integration.test.js:201 loops over /customer/addresses, /customer-auth/session and /customers?phone=... and asserts all are 404. The first two now require 401 without a customer session; the public contact-search path must remain 404. Only split this assertion by the new guarded-vs-absent status, preserving every staff/SQL assertion.
2. B/test/customer-auth.integration.test.js:463 asserts POST /customer-auth/verify is 404. The empty verification request now correctly returns 401 CUSTOMER_CODE_INVALID in this builder-level test. Update that former absence assertion to the guarded verification contract; retain the surrounding secret/input/IP/challenge assertions.

Actual evidence: 401 !== 404 at those exact lines; each suite has only that functional subtest failure (plus its parent). Existing Task9 archive/link schedule still observes link waiting for Shop with no SQL failures. The full registered test:delivery:db command therefore cannot be called green until the controller grants that narrow test ownership and those assertions are reconciled. This is not silently skipped, hidden, or worked around by production feature flags. No assertion in either outside-owned file was changed.

Tests use real loopback HTTP and actual SQL/crypto; provider boundaries alone redirect outbound Mailjet/Meta/IGN requests to loopback fixtures. Cookie/browser-relevant behavior is verified at HTTP/header/Express proxy boundaries. A real TLS browser storage/SameSite end-to-end run was not performed. Host-only/Secure/HttpOnly/SameSite/CSRF/CORS semantics and preflight effects have explicit assertions; deployment cookie/proxy topology still needs Task17 browser acceptance. Both real OTP channel receipt/verification and provider readiness are commissioning prerequisites, not local successes.

No production env read/write, secret decrypt, remote DB, real recipient/account/OTP request, payment, print, push, deploy, merge or persistent Git hook change occurred. No frontend dev server or unrelated process was stopped. Existing env/TAP diagnostics and Task8/9 deferred minor observations were left intact. No unrelated cleanup was made.

## Self-review and completion

Author self-review read the complete production diff/new helpers and test evidence, checking task ownership, one-use challenge/tenant/purpose/expiry checks, null-sent_at acceptance, hash/DTO boundaries, cookie policy, middleware context isolation, independent stale-header path, raw Stripe parser placement, exact CORS/preflight and proxy trust, Shop-first locking, SQL rollback/UTC/string IDs, dependency placement and preservation of all existing scripts. No additional in-scope defect was identified. The two former-stage test assumptions above are explicit controller follow-up; independent review remains controller-owned.

Scoped commit command: `git -c core.hooksPath=NUL commit -m 'feat: isolate customer sessions and address permissions'`, exit 0, raw task-10-commit.txt. The override was invocation-local, with no persistent config write or environment hook execution. Commit 23e26673127fab08378851aed36147d0fc23ecec contains exactly the eleven owned backend files (837 insertions / 11 deletions). Final `git diff d2f4d623b2f777dc57ce32aab579b96217ccefe0 HEAD --check` exited 0. `git status --short --branch` in both B and F showed only `## feat/delivery-v1`, clean. Scratch report/logs remain available and were not deleted. All required command sessions finished; no helper/server remains running from these tests.

## Authorized test contract reconciliation (2026-10-18)

The controller/user explicitly granted the narrow ownership extension BEFORE independent review and confirmed the two exact assertion sites. This append supersedes the earlier unresolved ownership/obsolete-assertion status above; all previous report history and failure logs remain intact. Functional source implementation still awaits controller independent review.

Follow-up BASE: 23e26673127fab08378851aed36147d0fc23ecec. Follow-up commit: 5d932b0c0afe24b5db9a903059771dc1420eb81f, `test: reconcile customer route contracts after session wiring`. Only B/test/customer-addresses.integration.test.js and B/test/customer-auth.integration.test.js changed, exactly two hunks (7 insertions / 3 deletions). No production changes, schema/config/dependency/script changes, other assertion changes, test-title/log cleanup, agents, provider operations or whole npm rerun occurred.

- Address assertions now require 401 for mounted /customer/addresses and /customer-auth/session without a customer session. Public /customers?phone=0612345678 retains its 404 assertion.
- The former verify-absence comment/assertion now verifies that the empty builder-level POST returns 401 CUSTOMER_CODE_INVALID and no Set-Cookie. Every surrounding SQL, public DTO, server-IP and auth assertion is preserved.

RED evidence, reused as explicitly authorized: task-10-existing-customer-addresses.integration.test.js.txt (401 !== 404 at the prior line 201) and task-10-existing-customer-auth.integration.test.js.txt (401 !== 404 at the prior line 463). No redundant RED execution or production rollback was performed.

Both FULL SQL files ran separately under each runtime, without test-name filters or skips. Node22 v22.13.1 was native; Node18 v18.20.8 used the same cached executable as the initial task. Each runtime's PowerShell invocation explicitly set:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task10-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task10-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
```

Exact test commands and final output summaries (full output in the named scratch logs):

| Command | Exit / final TAP output | Raw log |
| --- | --- | --- |
| node test/customer-addresses.integration.test.js | 0; tests 11, pass 11, fail 0, cancelled 0, skipped 0, todo 0; duration_ms 14734.8493 | task-10-followup-node22-customer-addresses.integration.test.js.txt |
| node test/customer-auth.integration.test.js | 0; tests 23, pass 23, fail 0, cancelled 0, skipped 0, todo 0; duration_ms 14983.7687 | task-10-followup-node22-customer-auth.integration.test.js.txt |
| & 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-addresses.integration.test.js | 0; tests 11, pass 11, fail 0, cancelled 0, skipped 0, todo 0; duration_ms 19573.3491 | task-10-followup-node18-customer-addresses.integration.test.js.txt |
| & 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-auth.integration.test.js | 0; tests 23, pass 23, fail 0, cancelled 0, skipped 0, todo 0; duration_ms 15584.9985 | task-10-followup-node18-customer-auth.integration.test.js.txt |

Each file was invoked directly as shown and redirected with `*>` to its own named log; the PowerShell wrapper recorded `$LASTEXITCODE`, read the final 14 log lines, and failed if either file returned nonzero. Both runtime wrappers exited 0. Both auth logs retain the actual SQL schedule diagnostic `archive/link schedule: link waited for Shop; SQL failures: none`. The populated customer migration rollback/up test also passed on both runtimes. All provider requests remained at the existing loopback HTTP doubles; SQL used only the explicit disposable server and random smarteat_delivery_test_* databases. Existing tests-only actual Nano ID bridges and inherited diagnostics were preserved; no production Node18 interoperability or configured Node20 boot claim is added.

Author self-review inspected the entire two-hunk diff against the exact authorization. `node --check` on each changed file, `git diff --check`, `git diff --cached --check`, and `git diff 23e26673127fab08378851aed36147d0fc23ecec HEAD --check` all exited 0. Only normal LF-to-CRLF staging notices appeared.

Scoped follow-up commit invocation: `git -c core.hooksPath=NUL commit -m 'test: reconcile customer route contracts after session wiring'`, exit 0; full output in task-10-followup-commit.txt. Hook override remained invocation-local, with no persistent Git config write or environment hook execution. Final B HEAD is 5d932b0c0afe24b5db9a903059771dc1420eb81f; F remains 6f694519d0db9ee631fe9d85550af71165dac293. Both worktrees are clean on feat/delivery-v1, with report/logs ignored in scratch. Both test command sessions exited; no task-created test jobs, HTTP servers or database pools remain running.

Full controller Task10 review range: d2f4d623b2f777dc57ce32aab579b96217ccefe0..5d932b0c0afe24b5db9a903059771dc1420eb81f, including initial implementation commit 23e26673127fab08378851aed36147d0fc23ecec and this test-only follow-up. The two formerly blocking assertion sites are reconciled and their full files now pass on both runtimes. No second npm.cmd test and no whole test:delivery:db run was performed. The initial successful single npm run remains its recorded evidence; no new whole-SQL-suite, real browser/TLS, live OTP/provider commissioning or independent-review success is claimed.

## Fix Round 1/5: I1 and I2

Read task-10-review.md in full: 0 Critical, 2 Important, 0 new Minor. This round addresses I1 and I2 only. BASE / clean starting HEAD: 5d932b0c0afe24b5db9a903059771dc1420eb81f. Commit: 4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1, `fix: enforce customer policy at Express routing boundaries`. Author verification is complete for the two routing fixes; controller scoped re-review remains pending. A separately owned legacy source-regex assertion needs reconciliation, described below.

### Exact scope and changes

Exactly four backend files changed (205 insertions / 6 deletions):

- src/helpers/customerCors.js: classifier now uses the supported Express req.path pathname instead of splitting the raw original request target. It accounts for the one optional boundary slash consumed by the prefix mount when computing its classification-only relative path. It does NOT change req.url/originalUrl, globally normalize paths, introduce a custom URL parser/dependency, or refactor staff authentication. The exact-origin handler and wildcard exclusion continue to use the SAME classifier.
- src/routers/r_orders.js: only the newly authorized customer-middleware import and actual POST /orders/checkout chain changed. The chain is now authentication -> attachOptionalCustomerSession -> requireCustomerCsrfIfPresent -> orders.checkout, at the same route boundary as the mutation. All other route declarations and existing authentication remain untouched.
- index.js: removed the now-unnecessary full-application-path checkout guard and its customer-middleware import. CORS remains before the legacy wildcard; Stripe raw parsing, personal-router independence and all other mounts remain intact.
- test/customer-cors.test.js: added routing witnesses executing the actual index.js and r_orders.js routing declarations against installed Express. Customer/order business handlers are inert witnesses. JWT authentication, cookie parsing, session HMAC/CSRF middleware and route matching execute for real; current-user lookup/session read use in-memory fixtures. No OTP, SQL checkout/payment or provider handler is invoked by these witnesses. HTTP response collection now handles a non-JSON 404 body so unaccepted spellings can be asserted as pre-mutation rejections. No existing test log or unrelated minor cleanup occurred.

No changes to customerSession, customerAuth middleware, controllers, migrations, environment/configuration, dependencies/scripts, shared staff auth, earlier test-contract reconciliation, frontend source, briefs, original reports/review or ledger. The r_orders.js extension stays exactly within its granted import/checkout-chain boundary.

Primary API checked: [Express 4 req.path](https://expressjs.com/en/4x/api/request/#req.path), which exposes the request pathname and excludes the mount point inside mounted middleware. The installed Express request getter and router prefix-trimming implementation were also inspected. Both CORS checks run before the prefix routers at the application root, then classify the same parsed path Express uses. Tests assert that accepted requests retain their original raw request targets, including absolute-form targets.

### RED/GREEN and coverage

Initial RED was reproduced on BOTH runtimes against unchanged production code. New actual-index witnesses reached public challenge/verify handlers from forbidden origins on double-slash/absolute-form targets; the actual checkout router without the index guard reached the mutation witness without customer CSRF. Both RED runs had 66 TAP tests, 15 pass / 51 fail (including failing parent tests). This is actual dispatch/guard behavior, not an assertion on source text.

After I1 alone, all public challenge/verify origin witnesses passed, but independent checkout and combined index witnesses remained RED: 66 tests, 41 pass / 25 fail. This explicitly proves that correcting the classifier alone is insufficient for I2. After moving the middleware to the actual routed checkout chain, the same 66-test file passed. Coverage was then expanded to check both existing staff and service-point bearers and preserve bearer-only/guest-customer checkout behavior.

Final full CORS file: 76/76 on Node22 and Node18. It covers canonical targets, an extra prefix-boundary slash, absolute-form canonical targets, absolute-form double-boundary targets, and case-insensitive double-boundary targets with trailing slash/query. For challenge AND verify, it checks forbidden-origin POST refusal before a witness, allowed-origin dispatch with exact credentialed CORS, and allowed/forbidden preflights with no mutation. For every accepted checkout spelling it checks:

- Real route authentication precedes customer attachment and CSRF, independently of index/CORS.
- Valid staff or service-point bearer + customer cookie + missing CSRF returns 403 before the mutation witness.
- Correct CSRF permits the owned customer context and preserves staff/service-point subject.
- Existing bearer checkout without a customer cookie remains accepted; cookie without an existing bearer remains 401.
- Actual index rejects forbidden Origin, returns exact allowed-origin CORS, terminates cookie preflights without auth/attachment/mutation, and refuses missing CSRF from an allowed Origin.
- Legacy bearer-only checkout from its prior Origin retains noncredentialed wildcard behavior, and another staff orders read runs only its existing authentication.
- Triple boundary slash, doubled internal orders separator, doubled trailing separator and encoded static-segment targets are 404 before any mutation witness. No broad URL rewrite is used to make them route.

The routing fixture has explicit throwing SQL-boundary stubs and the existing tests-only real Nano ID import bridge for Node18. A selected run with the three old tests excluded verified that the new witnesses are independently runnable; the full file then ran again solely after that test-fixture isolation change. The SQL runs were NOT repeated due to the host pause.

### Exact commands and raw evidence

All commands ran from B. Native Node22 v22.13.1 and cached Node18 v18.20.8 were unchanged. Main affected-file commands:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task10-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task10-fixture/'
$env:EMAIL='central@example.test'
$env:MAILAPIKEY='fixture-public-key'
$env:MAILSECRETKEY='fixture-private-key'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/customer-cors.test.js
node test/customer-session.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-cors.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-session.integration.test.js
```

Each file's output was redirected to its named log with `*>`, `$LASTEXITCODE` was captured, and the last TAP lines were read. Each runtime wrapper completed with exit 0. SQL used only the explicit disposable server and existing random-database harness, never application data.

| Stage / exact test command | Exit / final output | Scratch log |
| --- | --- | --- |
| node test/customer-cors.test.js, RED | 1; 66 tests, 15 pass, 51 fail | task-10-fix-round1-red-node22.txt |
| Node18 executable + test/customer-cors.test.js, RED | 1; same 66/15/51 | task-10-fix-round1-red-node18.txt |
| node test/customer-cors.test.js, I1 fix only | 1; public I1 group GREEN, I2 groups RED; 66 tests, 41 pass, 25 fail | task-10-fix-round1-I1-green-I2-red.txt |
| node test/customer-cors.test.js, both fixes | 0; initial 66/66 before coverage expansion | task-10-fix-round1-green-attempt.txt |
| node test/customer-cors.test.js, expanded coverage | 0; 76/76 | task-10-fix-round1-final-node22-customer-cors.test.js.txt |
| Node18 executable + test/customer-cors.test.js, expanded coverage | 0; 76/76 | task-10-fix-round1-final-node18-customer-cors.test.js.txt |
| node test/customer-session.integration.test.js | 0; tests 16, pass 16, fail/cancelled/skipped/todo 0; duration_ms 3507099.8337 | task-10-fix-round1-final-node22-customer-session.integration.test.js.txt |
| Node18 executable + test/customer-session.integration.test.js | 0; tests 16, pass 16, fail/cancelled/skipped/todo 0; duration_ms 3508331.7576 | task-10-fix-round1-final-node18-customer-session.integration.test.js.txt |
| node --test --test-name-pattern='I1\|I2' test/customer-cors.test.js, fixture independence | 0; 73/73 selected tests | task-10-fix-round1-isolated-witnesses-node22.txt |
| Node18 executable + --test --test-name-pattern='I1\|I2' test/customer-cors.test.js, fixture independence | 0; 73 pass, 3 old top-level tests skipped by selection | task-10-fix-round1-isolated-witnesses-node18.txt |
| FINAL node test/customer-cors.test.js, after fixture isolation | 0; tests 76, pass 76, fail/cancelled/skipped/todo 0; duration_ms 1839.3185 | task-10-fix-round1-cors-final-node22.txt |
| FINAL Node18 executable + test/customer-cors.test.js | 0; tests 76, pass 76, fail/cancelled/skipped/todo 0; duration_ms 1959.239 | task-10-fix-round1-cors-final-node18.txt |

The literal selected pattern in PowerShell was `--test-name-pattern='I1|I2'`; the table escapes its pipe only for Markdown rendering. The three skipped tests in the Node18 selected run all pass in the final unfiltered file. No SQL skips occurred.

Host pause: the controller reported clock.sleep(120s) returning after roughly 3529s and explicitly requested continuation without redispatch/repeating completed work. Both already-started SQL sessions eventually returned exit 0, 16/16. Their large elapsed durations above reflect that pause, not a test failure or a claimed throughput result. These sessions were resumed/read to completion once, not rerun. The working HEAD stayed at BASE through verification until the scoped commit.

Narrow existing legacy commands used the same disposable ENV_FILE/JWTKEY/PUBLICIMAGEPATH/EMAIL/Mailjet literals above, plus STRIPE_SECRET_KEY=sk_test_task10_fixture and STRIPE_WEBHOOK_SECRET=whsec_task10_fixture. No live account/provider calls occurred:

```powershell
node test/counter-checkout-payment-mode.test.js
node test/checkout-contract.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' -e "import('nanoid').then(dependency => { require.cache[require.resolve('nanoid')] = { exports: dependency }; require('./test/' + process.argv[1]); }).catch(error => { console.error(error); process.exitCode = 1; });" counter-checkout-payment-mode.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' -e "import('nanoid').then(dependency => { require.cache[require.resolve('nanoid')] = { exports: dependency }; require('./test/' + process.argv[1]); }).catch(error => { console.error(error); process.exitCode = 1; });" checkout-contract.test.js
```

- Counter checkout payment mode: exit 0 on both runtimes; `counter checkout payment mode tests passed`. Logs: task-10-fix-round1-legacy-node22-counter-checkout-payment-mode.test.js.txt and task-10-fix-round1-legacy-node18-counter-checkout-payment-mode.test.js.txt.
- Checkout contract: exit 1 on both runtimes, at the exact old source regex described below. Logs: task-10-fix-round1-legacy-node22-checkout-contract.test.js.txt and task-10-fix-round1-legacy-node18-checkout-contract.test.js.txt. Execution stops there; later assertions in that file are not claimed as run/passing. Node18 uses only the already-approved tests-only actual dependency bridge, not a production interop change.

### Bounded extra ownership need

Reported in commentary BEFORE any possible outside-file edit; no outside-owned edit was made. B/test/checkout-contract.test.js:2671 asserts the exact old source pattern `.post("/orders/checkout", authentication, orders.checkout)`. I2 necessarily adds the two customer guards after authentication, so that former pattern fails even though the actual Express witnesses prove the required guarded behavior. Both runtime logs confirm this same regex mismatch.

Need: authorization for ONLY that existing regex assertion to expect `.post("/orders/checkout", authentication, attachOptionalCustomerSession, requireCustomerCsrfIfPresent, orders.checkout)`, preserving every other assertion and all production files. The current authorization covers r_orders.js import/chain, not this legacy test file, so it was left unchanged. Do not weaken/rearrange production guards to satisfy the obsolete pattern. The legacy checkout-contract gate remains red pending that narrow test ownership; no wholly green legacy/full-npm claim is made for this round.

### Self-review, commit and limits

Author self-review read all four changed-file diffs and checked both findings independently: parsed-path scoping and unchanged raw targets; shared exact-origin/wildcard predicate; public challenge/verify forbidden-origin coverage; guard placement at the actual prefix-mounted POST route after bearer auth; same-shop attachment and CSRF before the inert witness; guest-customer/service-point and staff bearer-only behavior; preflights without cookies/side effects; rejected spellings; no other route changes; no business/provider/payment handler in routing witnesses. No additional in-scope functional issue was identified. Independent scoped re-review remains controller-owned.

`node --check` on index.js, customerCors.js, r_orders.js and customer-cors.test.js, `git diff --check` and `git diff --cached --check` exited 0. Commit command: `git -c core.hooksPath=NUL commit -m 'fix: enforce customer policy at Express routing boundaries'`, exit 0; task-10-fix-round1-commit.txt. The hook override is invocation-local; no persistent configuration or environment hook executed. Final commit 4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1 contains exactly the four files above. B and F are clean; unchanged F HEAD is 6f694519d0db9ee631fe9d85550af71165dac293. All test command sessions finished; no task-created job/server/pool remains running.

Round review range: 5d932b0c0afe24b5db9a903059771dc1420eb81f..4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1. Full Task10 history remains d2f4d623b2f777dc57ce32aab579b96217ccefe0..4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1, retaining both initial and reconciliation commits. No full npm or whole SQL rerun, other task, secret/env file read/write/decrypt, live provider/recipient/account operation, SQL/payment routing mutation, print/push/merge/deploy or agent/reviewer invocation occurred. TLS browser/SameSite commissioning, live OTP receipt and configured Node20 boot remain the previously documented acceptance limits.

## Round 1 authorized checkout-contract follow-up

The controller/user verified line 2671 and explicitly granted ownership of ONLY its existing route-chain regex. Follow-up BASE / clean starting HEAD: 4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1. Commit: 1a0d7c32a26d20bac0a1da3b707b13364611eee7, `test: assert guarded customer checkout route chain`.

Exactly one assertion in B/test/checkout-contract.test.js changed (one insertion / one deletion). It now requires authentication THEN attachOptionalCustomerSession THEN requireCustomerCsrfIfPresent THEN orders.checkout in the POST checkout declaration. Every other assertion and all production files are unchanged. The earlier actual Express behavior coverage remains the recorded 76 tests; no new feature or source behavior was introduced. This append supersedes the unresolved regex-ownership/legacy-gate status in the preceding round report, preserving that history and all original logs.

RED was reused as explicitly authorized: task-10-fix-round1-legacy-node22-checkout-contract.test.js.txt and task-10-fix-round1-legacy-node18-checkout-contract.test.js.txt, both failing the prior exact route-chain regex at line 2671. No redundant old-pattern run was performed.

Both WHOLE affected legacy-file commands were run with the same disposable environment:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task10-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task10-fixture/'
$env:EMAIL='central@example.test'
$env:MAILAPIKEY='fixture-public-key'
$env:MAILSECRETKEY='fixture-private-key'
$env:STRIPE_SECRET_KEY='sk_test_task10_fixture'
$env:STRIPE_WEBHOOK_SECRET='whsec_task10_fixture'
node test/checkout-contract.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' -e "import('nanoid').then(dependency => { require.cache[require.resolve('nanoid')] = { exports: dependency }; require('./test/' + process.argv[1]); }).catch(error => { console.error(error); process.exitCode = 1; });" checkout-contract.test.js
```

Each command's complete output was redirected with `*>` to its own log, `$LASTEXITCODE` was captured, and the final output was read. Node22 was v22.13.1; Node18 was v18.20.8. Node18 used only the already approved invocation-local test cache bridge to the REAL installed Nano ID dependency; no production interop change.

| Attempt | Exit / observed output | Scratch log |
| --- | --- | --- |
| Initial Node22 full-file invocation, run alongside Node18 | 1; TypeError: fetch failed, cause read ECONNRESET, runUploadMiddlewareContracts line 1270 | task-10-fix-round1-followup-node22-checkout-contract.txt |
| Initial Node18 full-file invocation, run alongside Node22 | 1; ENOTEMPTY during fs.rmSync cleanup at runUploadMiddlewareContracts line 1312, temporary customization-upload-e7WYeI/customization-choices directory | task-10-fix-round1-followup-node18-checkout-contract.txt |
| FINAL Node22 full file, sequential | 0; Loaded env file: NUL; customization and checkout contracts passed | task-10-fix-round1-followup-sequential-node22-checkout-contract.txt |
| FINAL Node18 full file, sequential | 0; Loaded env file: NUL; customization and checkout contracts passed; existing buffer.File experimental warning retained | task-10-fix-round1-followup-sequential-node18-checkout-contract.txt |

The different upload failures were reported with exact lines BEFORE any possible unowned change. No upload/harness/network/cleanup code was changed. Both initial processes exited 1 and finished; no process termination was needed. One sequential pass of both identical full-file commands/configuration then exited 0 on each runtime, including the formerly failing route assertion and all later archive/snapshot assertions. No test filter, skipped phase or shortened suffix was used. The cause of the initial transient failures was not established; a successful sequential run is not claimed as a harness repair. The logs remain visible as a test-stability limit, with no unauthorized minor cleanup.

Self-review inspected the entire one-line diff against the granted order and confirmed no other staged file. `node --check test/checkout-contract.test.js`, `git diff --check` and `git diff --cached --check` exited 0. Scoped commit command: `git -c core.hooksPath=NUL commit -m 'test: assert guarded customer checkout route chain'`, exit 0; raw task-10-fix-round1-followup-commit.txt. The hook override remained invocation-local; no persistent Git config change or environment hook executed.

Final B HEAD: 1a0d7c32a26d20bac0a1da3b707b13364611eee7. Unchanged F HEAD: 6f694519d0db9ee631fe9d85550af71165dac293. B/F are clean on feat/delivery-v1; scratch report/logs remain ignored and available. All test sessions completed, with no task-created job/server/pool left running. No SQL or npm suite, new feature, agent/reviewer, production/environment change or live-provider/deployment operation occurred in this follow-up.

Full Round 1 scoped review range: 5d932b0c0afe24b5db9a903059771dc1420eb81f..1a0d7c32a26d20bac0a1da3b707b13364611eee7, including routing fix 4b2fe12c6fea9f6e8d57fec8d1bac912acc6f4c1 and this test-only follow-up. Full Task10 range remains d2f4d623b2f777dc57ce32aab579b96217ccefe0..1a0d7c32a26d20bac0a1da3b707b13364611eee7. The authorized legacy regex gate now passes on both runtimes; source functional implementation and scoped re-review are still pending controller approval. Prior TLS/browser, live OTP/provider commissioning and configured Node20 boot limits remain unchanged.
