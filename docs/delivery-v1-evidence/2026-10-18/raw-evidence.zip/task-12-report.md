# Task 12 report

Status: Task12 owned implementation and author self-review finished; final focused frontend23/23, SQL13/13 and existing CORS76/76 pass on Node22 AND Node18. CORS ownership was explicitly granted and applied. The legacy reader-route assertion ownership request below is still pending; no overall Task12 completion or commits claimed yet. Controller owns independent review, Nuxt runtime and the single Task17 visual acceptance batch.

## Scope and bases

F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
B = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
Scratch = F/.superpowers/sdd/2026-10-16-delivery-management

Original paired BASE and current pre-commit HEADs:
- F 955f3981b0e0339c388aa87e6dbb18ce0720f74e
- B 1a0d7c32a26d20bac0a1da3b707b13364611eee7

Read task-12-brief.md FIRST and in full, followed by worker-context, task-12-integration-notes including CURRENT PRODUCER ADAPTERS, common contracts, relevant checkout/pricing/identity specification and final Task3/4/10/11 consumer interfaces. Re-read the amended brief when CORS ownership was granted. Did not regenerate the brief, alter the controller ledger, spawn helpers/reviewers or begin another task. workspace_fs was unavailable; used the paired-worktree shell fallback explicitly provided in worker-context. Original checkouts were not edited. TDD/execution/debugging/verification skills were applied within the user scope. Craft-floor read before UI work; established Nuxt2/Vue2/Vuetify, Poppins, MDI and 44px controls retained. No context launcher/detector/browser loops.

### Frontend files (10)

| File | Change |
| --- | --- |
| components/delivery/DeliveryCheckout.vue | Mode selector, reused address input, account login/book selection, bounded staff profile search/create, server quote and explicit confirmation. |
| store/delivery.js | Safe availability, resolver adapters, quote sequencing, same-principal bearer transport, optional customer credentials, transient profile/book/discount state. |
| test/delivery-checkout.test.js | Real Vue/Vuex/Axios consumer tests, compiled SFC templates, narrow HTTP/timer/provider boundaries. |
| pages/cart.vue | Delivery section and authoritative totals, payment choice, tracking confirmation, guarded exact recovery and current-state resolution. |
| pages/caisse/menu.vue | Existing service choice routes existing cart/customer/discount into common checkout; 44px wrapping service label. |
| pages/click-and-collect/_shopId/_shopName.vue | Personal account link, separate from existing explicit legacy storefront switch. |
| store/cart.js | Delivery wire payload/attempt identity, 32-byte confirmation secret, exact original retry and safe resolved-payment handling. |
| helpers/counterCheckout.js | Extended delivery attempt signature, private-detail allowlist and browser secret generation; original counter-paid helper reused. |
| helpers/stripeCheckout.js | Delivery-aware signature/readiness extension without changing historical defaults. |
| package.json | Prefix new focused test to npm test; exact original pretest, 83 old commands, dependencies and every other field preserved. |

DeliveryAddressInput.vue was REUSED UNCHANGED, including Task11's selected candidate retention, 300ms debounce, stale/context/destroy guards and fresh stored-ID resolution. No duplicate geocoding form. r_orders.js was READ and left unchanged: its actual authentication -> attachOptionalCustomerSession -> requireCustomerCsrfIfPresent -> checkout chain remains at the same route boundary and order.

### Backend files (8 before pending test grant)

| File | Change |
| --- | --- |
| src/controllers/c_delivery.js | Minimal authenticated availability projection using actual caller shop/quote actor. |
| src/routers/r_delivery.js | GET /delivery/availability, authentication required. Full settings remains admin-only. |
| src/modules/m_checkout.js | Same-shop verified server customer context and SQL owner verification, transactional order/dossier attachment, fingerprinted private delivery details. |
| src/controllers/c_stripe.js | Same verified customer mapping, tracking result forwarding, explicit current paid/refunded resolution; frozen replay remains non-authoritative. |
| src/routers/r_stripe.js | Actual payment-intent start route: bearer -> optional customer -> CSRF -> existing handler. |
| src/helpers/customerCors.js | Explicit controller-granted one-path classifier extension, described below. |
| test/delivery-customer-checkout.integration.test.js | Actual Express routing, actual SQL repositories, genuine simultaneous HTTP checkout, local provider HTTP boundaries. |
| package.json | Prefix new SQL test only to test:delivery:db; exact other scripts/dependencies/fields preserved. |

No package-lock, migration, production environment, dependency, shared staff auth, persistence, Task3/4 producer, order-edit module or index.js edits. No other production ownership needed.

## Interfaces and pricing

DeliveryCheckout props include {shopId,cart,discount,value}; input emits the chosen fulfillment string and quote emits the authoritative DeliveryQuote or null on invalidation. Additional ready/address/customer events connect the bounded parent section; never emits paid. Site excludes dine_in. Disabled availability does not force a delivery cart to takeaway. Every new quote invalidates prior confirmation; expiration also blocks a new checkout. The cashier can explicitly choose reception payment or the existing counter_pay_before:<method> path. Site uses existing Stripe or payment at delivery.

Delivery store actions: loadSettings, resolveAddress, quote, resetForShop; additional bounded staff search/create/address and checkoutRequest adapters. Availability returns only {enabled}, ignores posted/query shop overrides, denies courier/unauthenticated actors and does not grant cashier full settings. Quotations post only product IDs/quantities/choice IDs, signed address proof and discount intent. No posted prices, coordinates or fee calculation. Discount precision is forwarded to the server rather than prematurely rounded.

Wire delivery additions to existing checkout:

```text
fulfillment_type: delivery
delivery_quote_token: exact signed quote
address_resolution_token: exact signed postal proof
delivery_confirmation_secret: 64 hex characters / 32 cryptographic bytes, generated before send
delivery_address_details: {complement?,instructions?}
```

The extra private-detail object is allowlisted, length/control-character checked, included in the canonical server fingerprint and copied into the accepted address snapshot only inside checkout transaction. It cannot replace postal fields, coordinates, financials, account owner or quote. Personal instructions are not sent to the geocoder. This supplies order-specific private edits without overwriting the Task11 shared form or changing the existing resolution wire contracts.

Shared input callback adaptation: public/POS new text becomes {address:{street,postalCode,city,country},candidate_id?} on /delivery/address-resolutions. Personal callback remains {address,candidateId?} on /customer/address-resolutions. Unchanged selected personal addresses send EXACTLY {addressId}; staff sends {} to /delivery/customers/:customerId/addresses/:addressId/resolve. These existing server-owned adapters issue fresh proofs from stored snapshots without IGN. A personal session in memory does not divert the staff owned-address path into the personal book.

R3 actual SQL: 2500-cent products initially free; one-cent product discount produces 2499 net +400 delivery =2899. Old Pay is blocked before provider start and before quote confirmation. Confirmed current quote sends expected_total 28.99 and local Stripe boundary receives 2899 cents. Fee is not a product and is not re-added to cart merchandise total. Existing Task3/4 VAT/stock/paid immutability producers remain authoritative.

## Current customer credential handshake

Task11 customerApi remains responsible for code login, link, logout, safe branding, session and personal book. Its verified session contains shopId/customerId/expiry/csrfToken in memory, separate from staff/public bearer. Personal activities never invoke users/postClickAndCollectAccess, shop/getShopInfoClickAndCollect, Terminal reset, staff logout or token/storage restoration tricks. The old explicit storefront bootstrap remains its existing separate workflow; this implementation does not claim simultaneous isolated staff/public principals on one origin.

The delivery transport reads the already established bearer principal. It uses an independent Axios instance so a personal HTTP failure does not enter the global staff logout interceptor. Its browser Fetch adapter explicitly sets credentials=omit for guest/availability/quote/staff-address requests, including same-origin requests (XHR withCredentials=false alone would still send same-origin cookies). Only identity-bearing checkout uses credentials=include / withCredentials=true and X-CSRF-Token from the same-shop current personal session. No full session or CSRF credential is saved in pending recovery. Customer401 isolation is tested at actual Axios JSON/error boundaries; Task11 login/link/logout/401/persistence invariants also remain covered by its real 27-test regression file.

The actual orders checkout boundary is unchanged. The actual Stripe start boundary now applies the same optional session and CSRF after bearer authentication. Only req.customerSession, verified by the server middleware, becomes internal verifiedCustomer. Normalization ignores forged customer_account_id and verified-owner inputs. SQL verifies the account in caller shop; Shop -> customer locks precede inserting/attaching owner FKs. Orders and durable deliveries attach atomically. BIGINT account IDs remain strings; tests create 9007199254740993. Guest/no-email and foreign-shop cookie requests attach no account.

### Granted CORS extension

Only the shared checkout classifier expression changed from orders/checkout to the explicit alternatives orders/checkout OR stripe/payment-intents/qr-table. The existing optional trailing slash, case-insensitivity, req.path parsed pathname, prefix boundary double slash and absolute-form handling remain. Cookie or Access-Control-Request-Headers X-CSRF-Token activates the SAME exact-origin/credentials/preflight policy. No /stripe/* wildcard; webhook, Terminal, cancel/refund and bearer-only legacy classification remain unchanged. Actual start-route order remains bearer -> optional customer -> CSRF -> controller. RED OPTIONS200 rather than204 was preserved before the explicit ownership grant.

## Recovery

Only the existing single cart.clientOrderPayload recovery is extended: public checkout body/proofs/private secret, cart clone, stripe flag, optional original customerContextId and minimal postal display fields. Delivery/customer/courier roots remain excluded by unchanged Task11 sanitizer/subscriber. No complete address books, missions, payment queues, tracking-token persistence or offline payments are added.

Unresolved states freeze mode, address, products and payload. retryCheckout transmits the exact original public body with the same client_order_token, proof strings, private instructions and confirmation secret. It does not resolve/geocode/requote under that key. Matching original personal identity is required before retry; staff principal stays unchanged. Refreshed address/quote under an unresolved key returns CHECKOUT_ATTEMPT_UNRESOLVED. Prewrite requote stays reprice_required until explicit confirmation of the new server total. Original discount/address display are restored without mutating the pending payload.

Legacy already-processed handling is narrowed for delivery: a generic 409 cannot clear recovery and enable a new order. Current Task4 commercial state, not frozen accepted replay, may return checkout_resolved:true with paid/refunded after resolving the matching original dossier. Only that explicit current response closes the attempt/cart; no second payment preparation is entered. Unknown/pending state remains unresolved. Frozen durable replay still returns its originally accepted payment state unchanged. Exact replay after suspension/expired proof does not create a second order/dossier/stock movement or rotate tracking.

## RED/GREEN evidence

All logs below are retained in scratch. Native Node22 v22.13.1 and Node18 v18.20.8; Node18 binary is C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe. SQL commands explicitly set DELIVERY_TEST_DATABASE_URL=mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql and ENV_FILE=NUL. Only random smarteat_delivery_test_* catalogs are created/dropped by the existing helper. No supplied application catalog fallback. Legacy CommonJS handler tests on Node18 use only the tests-only bridge to the REAL installed Nano ID module; production Node18 boot is not claimed fixed.

| Phase/log | Actual result |
| --- | --- |
| task-12-red-frontend.txt | exit1; 1/9 passes (existing stale-input behavior); 8 missing Task12 modules/consumer failures. |
| task-12-red-backend.txt | exit1; initial SQL plus missing web source fixture, documented correction below. |
| task-12-red-backend-corrected-fixture.txt | exit1; 5 pass/5 fail including parent; genuine missing availability/customer attachment/Stripe CSRF/private details. |
| task-12-green-frontend-attempt1.txt / task-12-green-backend-attempt1.txt | exit0; initial frontend9/9 and actual HTTP/SQL10/10. |
| task-12-page-red-corrected-harness.txt -> task-12-page-green-attempt1.txt | page old-Pay guard/payload RED -> GREEN10/10. |
| task-12-recovery-transport-red.txt -> task-12-recovery-transport-green.txt | reprice unlock, restored discount and same-origin cookie omission RED -> GREEN14/14. |
| task-12-frozen-mount-red-expanded.txt -> task-12-frozen-mount-green.txt | precision and frozen-mount proof clearing RED -> GREEN17/17. |
| task-12-pos-payment-red.txt -> task-12-pos-payment-green.txt | explicit cashier paid mode RED -> GREEN18/18. |
| task-12-processed-recovery-red.txt -> task-12-processed-recovery-green.txt | unsafe generic replay release/current resolution RED -> GREEN20/20. |
| task-12-current-commercial-red.txt | actual SQL missing explicit current settled descriptor RED, plus still-ungranted CORS failure. |
| task-12-staff-address-red.txt -> task-12-staff-address-green-node22.txt / task-12-staff-address-green-node18.txt | coexisting personal account must not divert staff resolver: real RED then final21/21 on both runtimes. |
| task-12-cors-red-only-sql.txt / task-12-final-backend-node18-cors-blocked.txt | only CORS subtest red; all11 other actual SQL/HTTP scenarios pass. |
| task-12-cors-final-node22.txt / task-12-cors-final-node18.txt | existing full customer-cors file76/76 on both runtimes after granted one-line extension. |
| task-12-sql-final-node22.txt | final focused actual SQL13/13 (12 scenarios plus parent), no skipped/cancelled/todo. |
| task-12-sql-final-node18.txt | identical final focused actual SQL13/13, no skipped/cancelled/todo. |
| task-12-mode-identity-red.txt -> task-12-final-frontend-node22.txt / task-12-final-frontend-node18.txt | explicit delivery-to-takeaway switch must retain same-shop customer CSRF, without bootstrap; RED -> GREEN22/22 on both runtimes. |
| task-12-draft-red.txt -> task-12-final-focused-node22.txt / task-12-final-focused-node18.txt | cashier draft must be consumed once rather than populate another order; RED -> final GREEN23/23 on both runtimes. |
| task-12-producers-node22.txt / task-12-producers-node18.txt | existing full delivery-checkout.integration.test.js THEN delivery-archive-payments.integration.test.js both exit0, on both runtimes. Actual Task3/4 replay, fee/VAT, paid immutability, archive, stock and SQL-lock/race regressions retained. |

Harness mistakes were not presented as product RED: first web JWT fixture omitted its required source='web' and was corrected before backend production work; first page loader needed to support real template-only SFCs before producing the genuine page guard RED. One expanded radius fixture changed max distance without changing its fee-band boundary, correctly triggering invalid settings; replaced it with a valid signed distant-address fixture and reran. Initial Node18 regression shell quoting failed before executing any test; corrected to retained scratch task-12-node18-bridge.cjs, then all seven required legacy files ran and passed. First design-system attempt detected generic search words using its existing whole-SFC regex; adjusted only owned copy, retained the unchanged assertion, and final design-system file passes. No asserted behavior was weakened.

## Regression and validation bounds

- F focused required files: counter-checkout, counter-checkout-store, stripe-checkout, order-edit, table-access-auth, auth-middleware, admin-menu-express-checkout, persisted-state, customer-account. Initial order-edit failure from its legacy import-stripping loader was fixed using real ES import/lazy SFC registration in owned cart code; required-frontend-continuation passes, including actual Task11 27/27. Logs task-12-required-frontend-initial.txt and task-12-required-frontend-continuation.txt.
- B required legacy files: counter-checkout-payment-mode, stripe-payment, order-editing, table-access-token, table-access-controller, service-point-session-auth, checkout-contract. All pass on22 and18. Initial optional undefined verifiedCustomer key broke an exact legacy DTO assertion; changed owned controllers to omit absent field. Logs task-12-required-backend-node22*.txt and task-12-required-backend-node18-corrected.txt. Node18 retains its existing buffer.File experimental warning.
- F npm.cmd test ran ONCE, including unchanged image-library pretest, then-current Task12 tests and all83 original commands; exit0, task-12-npm-frontend.txt. Later staff-resolver/mode-identity/draft regressions and their bounded source fixes are covered by the final23/23 focused files, not a second npm invocation or a claim that the whole npm invocation ran on the final23-case revision.
- B npm.cmd test ran ONCE; exit1 at stripe-terminal-readers.test.js:610 old web-route array, after12 complete original files and preceding reader cases. Continued only the unrun53-command suffix from stripe-terminal-kiosk-assignment; exit0, task-12-npm-backend-continuation.txt. Do not describe the original invocation as green. Pending assertion grant is below.
- Affected frontend lint: task-12-lint-current.txt exit0, zero errors/three EXISTING store/cart.js no-console warnings and stale Browserslist notice. Earlier lint failed one test-only require-await and new test component-count warnings; corrected the test fixture and documented test harness multi-component rule. No production baseline warning/dependency refresh.
- Structured comparison against both exact BASE package.json files passes: only new frontend test prefix/backend SQL prefix differ; dependencies, pretest and every other script/field unchanged.
- git diff --check passes both worktrees, with existing LF->CRLF notices only. No full registered cross-task SQL suite was repeated. No Nuxt build/dev/server/browser claim.

Host pauses inflated elapsed timestamps, including final frontend durations2230098.5913ms/2233295.1116ms. Resumed the ORIGINAL running sessions and collected their exit0; did not restart these tests because of a pause. Duration is not represented as active execution time or a performance result.

## Author self-review

Reviewed the complete tracked source diff and new components/store/tests against the amended ownership/brief, current producer contracts and security boundaries. Fixed owned findings with witnessed RED/GREEN: reprice Pay gate; exact proof/secret recovery and discount restoration; premature discount rounding; frozen component mounting clearing proof display; generic already-processed response clearing unresolved delivery; staff stored-address routing being diverted by a coexisting personal session; customer CSRF loss on explicit mode switch; cashier draft surviving consumption. Retained server commercial authority and unchanged Task11 candidate/private-field/persistence protections. The CORS finding was reproduced at actual HTTP before the explicit ownership grant. The sole unresolved source-test finding is the unowned obsolete reader-route expectation below; no unowned source/test edit was made to hide it.

No independent review or visual acceptance is claimed. No workflow helper/reviewer, runtime process, database race loop, production auth replacement, token-save/restore mechanism, local fee calculation or duplicate checkout implementation was introduced.

## Pending bounded ownership and completion

B/test/stripe-terminal-readers.test.js:610 still expects [authentication,handler] for the now-required cookie-aware Stripe start route. Proposed ONLY add the customer-middleware import inside that route test and expect [authentication,attachOptionalCustomerSession,requireCustomerCsrfIfPresent,handler]. Preserve the other reader/connect/webhook cases. This request was reported before editing; file remains intact pending explicit grant. CORS production ownership was separately granted and is already implemented/verified.

Scoped commits await the remaining test gate. Final compatible paired commit hashes will replace the pre-commit heads above after the task gate closes. Required commit subject: feat: support delivery checkout on POS and storefront; invocation-local core.hooksPath=NUL only. No push/merge/deploy or persistent Git configuration changes.

Manual mobile guest/connected outside-radius/minimum acceptance, real rendering/overflow/assets, Nuxt compilation and independent source acceptance remain controller-owned Task17 checks. No screenshot/detector/browser loop or actual supplier commissioning acceptance is claimed. The controller hidden Nuxt server127.0.0.1:8097 (wrapper40396/listener37940) was never started/stopped/duplicated/accessed by this worker. No real Mailjet/Meta/IGN/Stripe/terminal/printing/phone call, remote DB, real environment read/decryption, secret discovery or production operation occurred. All provider doubles were in-process boundaries or loopback HTTP.

## Final authorized reader fix and paired commits

FINAL STATUS: Task12 implementation, author self-review, requested verification and both scoped commits are complete. This final section SUPERSEDES the earlier pre-commit/pending-ownership status statements; their original RED evidence remains intact. No owned implementation or ownership request remains outstanding. Independent source review and controller-owned Task17 compilation/visual/commissioning acceptance are not claimed complete.

The user read the pre-commit report in full, verified the exact reader-route assertion and expressly granted ONLY B/test/stripe-terminal-readers.test.js: the customer-middleware import inside its existing route test and the web-start assertion. Applied exactly these two hunks, with no production change:

```js
const customerMiddleware = require("../src/helpers/middleware/customerAuth");
assert.deepStrictEqual(web.stack.map((layer) => layer.handle), [authentication, customerMiddleware.attachOptionalCustomerSession, customerMiddleware.requireCustomerCsrfIfPresent, legacy.createQrTablePaymentIntent]);
```

All other reader/connect/webhook assertions, fixtures and harness code are unchanged. The pre-existing task-12-npm-backend.txt failure at the old array is the authorized RED witness; it was not redundantly reproduced. The entire corrected file was executed, unfiltered, on both runtimes:

| Final command (B, ENV_FILE=NUL and disposable JWTKEY fixture) | Actual result | Log |
| --- | --- | --- |
| node test/stripe-terminal-readers.test.js | exit0; all77 tests pass, including route bindings and all reader/provider-boundary cases | task-12-reader-final-node22.txt |
| C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe test/stripe-terminal-readers.test.js | exit0; identical77/77 | task-12-reader-final-node18.txt |

Neither invocation needed the Nano ID bridge for this affected file. No second whole npm invocation, focused frontend/SQL/CORS replay, producer rerun or provider call was performed after this permission or because the host generation changed.

### Exact final compatible pair

- F **13e2a2ca5759c0a41b3909bca74bd797ecae7479**, parent **955f3981b0e0339c388aa87e6dbb18ce0720f74e**.
- B **6dfdc2cdc48ea47fd50940887f8d2580dddad5c8**, parent **1a0d7c32a26d20bac0a1da3b707b13364611eee7**.
- Both commit subjects: `feat: support delivery checkout on POS and storefront`.

Exact F commit files (10;1074 insertions,21 deletions):

```text
components/delivery/DeliveryCheckout.vue
helpers/counterCheckout.js
helpers/stripeCheckout.js
package.json
pages/caisse/menu.vue
pages/cart.vue
pages/click-and-collect/_shopId/_shopName.vue
store/cart.js
store/delivery.js
test/delivery-checkout.test.js
```

Exact B commit files (9;335 insertions,6 deletions):

```text
package.json
src/controllers/c_delivery.js
src/controllers/c_stripe.js
src/helpers/customerCors.js
src/modules/m_checkout.js
src/routers/r_delivery.js
src/routers/r_stripe.js
test/delivery-customer-checkout.integration.test.js
test/stripe-terminal-readers.test.js
```

No other file is in either commit. In particular, reused DeliveryAddressInput.vue, the actual r_orders.js checkout boundary, package-lock files, staff/public auth and persistence files remain unchanged. Additional ownership comprised exactly the safe availability pair from the amended brief, the separately granted exact-path CORS classifier and this narrowly granted reader assertion.

### Final command and status evidence

After the corrected reader runs, inspected its entire diff and mechanically re-compared both package.json objects against the exact original BASEs. F differs ONLY by the new test prefix: original pretest and all83 existing test commands/dependencies/other fields retained. B differs ONLY by the new SQL prefix: all66 unit commands/dependencies/other fields retained. Both checks exit0.

Staged explicit paths only with `git add -- <the file lists above>`. `git diff --cached --check` passed in each repo. Compared `git diff --cached --name-only` programmatically against each exact allowlist, then inspected each staged stat. Scope checks passed with10 F/9 B files.

The exact scoped commit invocation in EACH worktree was:

```powershell
git -c core.hooksPath=NUL commit -m 'feat: support delivery checkout on POS and storefront'
```

Outputs retained in task-12-commit-f.txt and task-12-commit-b.txt identify the exact successful commits and file counts above. Hook override was invocation-local; no persistent hook configuration write or environment hook execution. F has no configured core.hooksPath (`git config --get` returns1 for unset, not a code-validation failure); B retains `.githooks`.

The orchestration host timed out/changed generation while waiting on the paired commit call, after the commits actually completed. Did NOT retry either commit. Function-store path bindings were lost in that generation; an initial read-only check therefore showed the default workspace's unrelated planning HEAD. Rebound both explicit worktree paths, then read their actual successful commit logs and HEADs above. No mutation was issued at that default workspace and no completed test was restarted.

Final explicit-worktree Node/git verification asserted, separately for F and B:

- exact HEAD and exact parent BASE;
- empty `git status --porcelain` (clean worktree/index, no other pending tracked or untracked changes);
- empty `git diff --cached --name-only`;
- `git diff <BASE> HEAD --check` success;
- exact committed path allowlist10/9.

Both verification commands exit0. Scratch report/logs remain ignored and available for controller review. The combined earlier metadata command's frontend exit1 came only from querying its unset hook option; the independent final assertions explicitly verified every code/scope/cleanliness check successfully.

### Retained final verification bounds

Final focused frontend23/23, actual Task12 SQL13/13 (12 scenarios plus parent), existing CORS76/76, and corrected reader77/77 all pass on Node22 AND Node18. Existing full Task3 delivery-checkout SQL and Task4 delivery-archive/payments SQL files also pass on both runtimes. Required counter/Stripe/order-edit/QR regression commands and affected lint results above are retained without rerun. Final draft/page/test lint task-12-final-draft-lint.txt exits0 with only the existing Browserslist notice; the broader affected lint records zero errors/three old cart-store no-console warnings.

F's SINGLE whole npm invocation exited0 with unchanged pretest and the source/test revision at that time. Later bounded staff-adapter, mode-CSRF and consumed-draft fixes were verified by the final23-case focused files and affected lint; do not represent the earlier whole invocation as running on that later revision.

B's SINGLE whole npm invocation exited1 on the obsolete reader chain assertion. The unrun53-command suffix subsequently exited0; the corrected WHOLE reader file now passes77/77 on both runtimes. Together with the original12-file passing prefix, every one of the66 registered unit commands has a successful run across that bounded sequence. This is composite verification, NOT a claim of a whole npm exit0 or a second npm invocation. No full registered cross-task SQL suite was rerun.

No task-created runtime/server remains to manage; all started test/lint/commit sessions have completed. No real provider, recipient, payment, terminal, printer, phone, secret/environment decryption, production/remote DB, push, merge or deploy operation occurred. Controller owns independent source review and the later single Task17 desktop/mobile visual/runtime batch. No next-task work was started.

## Fix Round 1: I1, I2, I3 (Recovered After Interruption)

Status: fix implemented by the original worker before interruption, recovered and committed by the controller after the user requested continuation. Independent scoped review is PENDING. This section supersedes the initial source-review-pending state without changing its original verification history.

Fix BASE F: 13e2a2ca5759c0a41b3909bca74bd797ecae7479. Fix HEAD F: 3dad991babd4cd966089aecaeead67bdb580040e, `fix: preserve delivery checkout and recover pending attempts`. Compatible B remains 6dfdc2cdc48ea47fd50940887f8d2580dddad5c8, unchanged. Exactly four frontend files, 330 insertions / 14 deletions: components/delivery/DeliveryCheckout.vue, pages/cart.vue, store/cart.js and test/delivery-checkout.test.js.

Recovery: the previous controller wait cell belonged to a stale host generation. A fresh agent lookup explicitly returned not_found for original worker Boyle. No Node process matching the Task12 test/fix was running. The four uncommitted fix files and original RED/GREEN/lint/regression artifacts were preserved. The controller read the entire existing diff; no implementation was restarted, no pending edit reverted, no second implementation worker spawned and no backend code changed. Fresh focused verification was performed before staging/committing the recovered patch.

### Changes

- I1: the owned checkout consumer ignores resolution, quote invalidation and session-clear callbacks while locked. Its refresh path checks the lock before invalidation. The unchanged shared Task11 input can still emit resolved(null) on destruction, but cannot erase frozen parent proofs or change the active Stripe signature.
- I2: a module-local WeakSet keyed by the actual Vuex cart state distinguishes a surviving live delivery request from a reloaded persisted pending attempt. A live request, including ordinary remount/concurrent clicks, remains blocked; a restored pending delivery can explicitly replay the original body, endpoint, payment choice, proof strings, key and private confirmation secret. The live guard is removed in finally and is not serialized.
- I3: retry credentials derive from the original attempt. Guest/POS attempts pass no customer session even if personal state appears later. Personal attempts require the original customer and shop, a verified customer subject and current CSRF. A minimal original customerContextShopId joins the existing private recovery metadata and is stripped from the public body; no CSRF token is persisted. The page keeps a locked original guest signature independent of an unrelated personal login.

### Covering Tests

Six new cases use the actual compiled cart and checkout templates, Vue's real patcher/lifecycle, the unchanged shared address input, real Vuex and actual Axios/Fetch transforms with only leaf rendering, Stripe UI and HTTP boundaries doubled. They cover confirmed quote -> pending child destruction -> Stripe response with stable tokens/signatures and no cancellation; persisted pending reload versus live remount; POS selected restaurant profile/address plus unrelated personal state and lost reply; exact personal identity/shop/current-CSRF matching; counter-paid pending replay; and a personal login appearing after a site guest attempt. No live browser, Stripe, provider, payment or SQL action is part of these frontend tests.

The retained original-author expanded RED artifact task-12-fix1-expanded-red-node22.txt reports 29 tests, 23 pass and 6 fail, naming the six new cases. Original final logs task-12-fix1-final-node22.txt and task-12-fix1-final-node18.txt each report 29/29. Original bounded regression evidence task-12-fix1-regressions-node22.txt is retained, including the account27/27 and table-auth success. These are retained author artifacts, not newly repeated whole suites.

Fresh controller commands from F:

```powershell
node test/delivery-checkout.test.js *> .superpowers/sdd/2026-10-16-delivery-management/task-12-fix1-recovered-node22.txt
$nativeExit = $LASTEXITCODE
Write-Output "NativeNodeExit=$nativeExit"
exit $nativeExit
```

The Node18 invocation used the same test and exit-code handling with executable C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe and log task-12-fix1-recovered-node18.txt. Affected lint used `node node_modules/eslint/bin/eslint.js components/delivery/DeliveryCheckout.vue pages/cart.vue store/cart.js test/delivery-checkout.test.js`, the same native-exit handling and log task-12-fix1-recovered-lint.txt.

| Fresh verification | Observed result |
| --- | --- |
| Node22 focused file, complete | NativeNodeExit=0, tool exit0; tests29/pass29/fail0/cancelled0/skipped0/todo0, duration6886.7853ms |
| Node18 focused file, complete | NativeNodeExit=0, tool exit0; tests29/pass29/fail0/cancelled0/skipped0/todo0, duration6503.8774ms |
| Lint of all four changed files | NativeLintExit=0, tool exit0; zero errors/three existing cart no-console warnings and old Browserslist notice |
| Unstaged/staged diff --check | Both exit0; normal existing LF/CRLF notices only |

The first controller attempt redirected native stderr without explicitly propagating LASTEXITCODE. Its shell result was1 despite TAP29/29, because Windows PowerShell wrapped the old Browserslist stderr notice as NativeCommandError. That artifact remains task-12-fix1-controller-node22.txt and is not presented as a product assertion failure or successful command. The unchanged test was rerun with explicit native exit propagation as shown above; both fresh runtime runs exit0. No warning was suppressed, source changed or assertion weakened to obtain these results.

### Commit And Limits

The index was empty before staging. Only the four listed paths were added; the complete staged path list was read and staged diff --check passed. `git -c core.hooksPath=NUL commit -m 'fix: preserve delivery checkout and recover pending attempts'` exited0. Hook override was invocation-local, with no environment hook or persistent Git configuration change. Both worktrees are clean on feat/delivery-v1 after the commit.

No whole npm/registered SQL/CORS/reader suite was repeated for this frontend-only fix. The original Task12 npm composite bounds remain unchanged. No real environment read/write/decryption, provider, recipient, payment, printer, phone, push, merge or deploy operation occurred. The existing controller Nuxt server was not restarted or stopped. Browser visual acceptance remains the single Task17 batch. Scoped review range is F 13e2a2ca5759c0a41b3909bca74bd797ecae7479..3dad991babd4cd966089aecaeead67bdb580040e; backend changes are outside this fix diff and already covered by the full Task12 review.
