# Customer provider preflight (controller, 2026-10-17)

No real Mailjet/WhatsApp send is authorized: user explicitly chose preparation without actual sending. Use injected HTTP transports and fictional recipients, never local/production provider credentials. Actual reception/verification remains commissioning acceptance, not a claimed success.

## Task8 phone parser

Original backend dependencies contain no reliable international phone parser; lockfiles checked. Task8 already authorizes backend-only libphonenumber-js if needed. Official README consulted: https://github.com/catamphetamine/libphonenumber-js

- Strict whole-input parsing uses extract:false; default extraction otherwise accepts prose containing a number.
- max metadata provides stricter digit validation; isValid plus canonical .number provides E164. Do not accept extensions as silently identical login destinations.
- Existing npm registry produced an HTTP warning during earlier runtime acquisition. Do not change global npm config; any new dependency install must explicitly use https://registry.npmjs.org per command. Keep Node18 compatibility and lockfile scoped.
- Email SQL identity semantics must match preserved local-part distinctions; default unicode_ci does not. Controller requires actual SQL collision coverage, not only pure normalization tests. IDs exact strings even with production mysql2 defaults.

## Task9 email

Official current basic Send API documentation: https://dev.mailjet.com/docs/email-api/send-api-v31/send-basic-email (old /email/guides/send-api-v31 redirects there).

Send v3.1 payload uses Messages array, one OTP recipient per message; inspect each result status instead of assuming any HTTP200 means successful send. Reuse installed node-mailjet transport shape/version after checking its local API. Sanitized transport errors must never surface/log secret, destination, code or provider request body.

## Task9 WhatsApp

Official Meta-owned Postman request for authentication template provisioning: https://www.postman.com/meta/whatsapp-business-platform/request/6vkv46u/create-authentication-template-w-otp-copy-code-button

Meta developer URLs for send templates and copy-code authentication returned internal errors through current web access. This is a documentation access limitation, not proof that the APIs are unavailable. Verify the actual send payload from a primary Meta source before implementation, including code body/button components required for authentication template. Do not guess a Graph version: configured supported version and approved authentication template are deployment prerequisites. Browser sends no arbitrary provider URLs. No SMS/progress notifications introduced.

Additional reachable primary reference: https://whatsapp.github.io/WhatsApp-Nodejs-SDK/api-reference/messages/template/ documents generic approved-template sends with name/language/components/body/text parameters. Page explicitly says SDK is ARCHIVED, so it is not current authentication-specific proof and NOT a dependency recommendation. It links Template_Object types. Newer /documentation/business-messaging/whatsapp/templates/authentication-templates/ URL also inaccessible through current web tool. Do not treat these access failures or generic example as a live OTP acceptance result.

## Superseding primary send-contract evidence (browser)

Chrome browser read succeeded after web-tool errors. Canonical redirected page, displayed updated 2026-10-06:
https://developers.facebook.com/documentation/business-messaging/whatsapp/templates/authentication-templates/copy-code-button-authentication-templates

Sending section confirms POST graph.facebook.com/<configured API version>/<configured business phone number ID>/messages, bearer access token. Payload messaging_product=whatsapp, recipient_type=individual, to=normalized recipient, type=template; template has configured name, language.code, components. The SAME code is supplied twice:

- body, parameters [{type:text,text:code}]
- button, sub_type:url, index:"0", parameters [{type:text,text:code}]

Creation uses OTP/copy_code; rendered button becomes URL. Successful response has messages[].id (not proof of end-user receipt). Use the approved authentication template. Keep graph version configurable and recipe-tested, do not copy a version/example ID from documentation into defaults. No creation/send request, login, clipboard access or account operation occurred; public docs only. Owned research tab closed. This resolves send-payload documentation access, NOT real supplier acceptance.
