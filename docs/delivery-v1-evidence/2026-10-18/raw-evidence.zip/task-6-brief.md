### Task 6: Enregistrer le paiement manuel du livreur une seule fois

**Linked contract-test amendment:** Also update ONLY the obsolete reserved-route assertion in B/test/delivery-dispatch.integration.test.js for POST /courier/deliveries/:id/collect-payment with empty body: route now exists, so expect400 and exact DELIVERY_REQUEST_INVALID, not404. Keep adjacent unimplemented GET cash-balance404 and every other assertion unchanged. Run complete Task5 SQL22/18 and once registered Node22 SQLchain after this test-only correction. No production conditional/workaround to preserve obsolete404.

**Files:** Create `B/src/modules/m_deliveryCollections.js`, `B/test/delivery-collections.integration.test.js`; modify `B/src/controllers/c_courier.js`, `B/src/routers/r_courier.js`, `B/src/modules/m_deliveryOrders.js`, `B/package.json`.

**Interfaces:** Produit `buildDeliveryCollections().collect` du plan principal. `/courier/deliveries/:id/collect-payment` accepte uniquement methode, version et cle, jamais un montant autoritatif. `cash` alimente la dette ; `external_card` est une declaration manuelle distincte de Stripe. Les deux utilisent le reglement commercial existant et un evenement lie.

- [ ] **Step 1: Test SQL concurrent** pour commande due 2400 : deux requetes meme cle => un paiement et une collection de 2400 ; nouvelle cle sur commande deja payee => refus. Carte externe => dette especes 0. Stripe en cours => refus/reconciliation ; un webhook reussi concurrent ne peut permettre deux paiements. Reponse perdue puis replay => meme collection.
  ```js
  assert.equal(collectionCount, 1)
  assert.equal(cashDebtCents, 2400)
  assert.equal(externalCardCashDebtCents, 0)
  ```
- [ ] **Step 2: Executer** `node test/delivery-collections.integration.test.js` ; attendu rouge sur endpoint/collection manquants.
- [ ] **Step 3: Implementer `collect`** dans une transaction verrouillant dossier et representation commerciale ; exiger affectation courante, etat `in_transit`, preparation finie et paiement eligible. Conserver la cle et son hash/resultat ; une cle reusee pour une autre methode renvoie `DELIVERY_IDEMPOTENCY_CONFLICT`. Un rollback ne laisse ni dette ni commande payee partielle. Les corrections et restitutions physiques sont des evenements autorises distincts, pas une modification d'une collection existante.
- [ ] **Step 4: Test vert**, regression paiement/archive taches 3-4 et test de refus d'une collection role staff sans mission. Ajouter le test au script SQL.
- [ ] **Step 5: Commit `feat: collect delivery cash and external card payments`** dans `B`.

