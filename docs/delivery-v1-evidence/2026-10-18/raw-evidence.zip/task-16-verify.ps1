param([ValidateSet('frontend','backend-unit','backend-sql')][string]$Side)
$ErrorActionPreference='Continue'
$task16Scratch='C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app/.superpowers/sdd/2026-10-16-delivery-management'
$task16Front=Split-Path (Split-Path (Split-Path $task16Scratch))
$task16Back=Join-Path (Split-Path $task16Front) 'express-pos'
$task16Node18='C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe'
$task16Runtimes=@(@{Name='22';Path=(Get-Command node).Source},@{Name='18';Path=$task16Node18})
if ($Side -eq 'frontend') {
  Set-Location -LiteralPath $task16Front
  $task16Files=@('delivery-tracking.test.js','delivery-checkout.test.js','delivery-operator.test.js','courier-mobile.test.js','customer-account.test.js',
    'auth-middleware.test.js','session-auth.test.js','table-access-auth.test.js','kiosk-auth-middleware.test.js','qr-handshake.test.js','qr-session-bootstrap.test.js',
    'checkout-access.test.js','counter-checkout.test.js','counter-checkout-store.test.js','order-detail-checkout.test.js','order-edit.test.js','persisted-state.test.js',
    'cash-register.test.js','refund-status.test.js','delivery-receipts.test.js','receipt-bundle.test.js','receipt-printing.test.js','receipt-settings.test.js',
    'click-and-collect-page.test.js','client-navigation-overdrive.test.js','staff-roles.test.js','kiosk-checkout.test.js','orders-statuses-timeline.test.js','admin-navigation.test.js')
} elseif ($Side -eq 'backend-unit') {
  Set-Location -LiteralPath $task16Back
  $task16Files=@('customer-cors.test.js','customer-identity.test.js','delivery-authorization.test.js','table-access-token.test.js','table-access-controller.test.js',
    'service-point-access-token.test.js','service-point-session-auth.test.js','service-point-order-display.test.js','checkout-contract.test.js','counter-checkout-payment-mode.test.js',
    'order-editing.test.js','order-detail-stock.test.js','order-delete-hidden-archive.test.js','order-attribution.test.js','order-attribution-transition.test.js',
    'cash-register-payment.test.js','receipt-shop-settings.test.js','payment-method-standardization.test.js','staff-module-permissions.test.js','staff-login-contract.test.js')
} else {
  Set-Location -LiteralPath $task16Back
  $task16Files=@('delivery-tracking.integration.test.js','delivery-checkout.integration.test.js','delivery-archive-payments.integration.test.js',
    'delivery-terminal-corrections.integration.test.js','delivery-dispatch.integration.test.js','delivery-customer-checkout.integration.test.js','customer-session.integration.test.js','delivery-reports.integration.test.js')
}
$task16Results=@()
foreach ($task16Runtime in $task16Runtimes) {
  foreach ($task16File in $task16Files) {
    $env:ENV_FILE='NUL'
    $env:JWTKEY='task16-disposable-signing-fixture-only'
    $env:PUBLICIMAGEPATH='http://127.0.0.1/task16-fixture/'
    # Explicit on EVERY SQL invocation; never inherit an application database URL.
    $env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
    Get-ChildItem Env: | Where-Object { $_.Name -match '^TASK.*FILTER$' } | ForEach-Object { Remove-Item -LiteralPath ('Env:'+$_.Name) }
    $task16Log=Join-Path $task16Scratch ('task-16-'+$Side+'-'+$task16Runtime.Name+'-'+$task16File+'.log')
    & $task16Runtime.Path ('test/'+$task16File) *> $task16Log
    $task16Exit=$LASTEXITCODE
    Add-Content -LiteralPath $task16Log -Value "NATIVE_EXIT=$task16Exit"
    $task16Results+=@{Runtime=$task16Runtime.Name;File=$task16File;Log=$task16Log;Exit=$task16Exit;Bridge=$false}
    if ($task16Runtime.Name -eq '18' -and $task16Exit -ne 0 -and (Select-String -LiteralPath $task16Log -Pattern 'ERR_REQUIRE_ESM' -Quiet)) {
      $task16Bridge="import('nanoid').then(dependency => { require.cache[require.resolve('nanoid')] = { exports: dependency }; require('./test/' + process.argv[1]); }).catch(error => { console.error(error); process.exitCode = 1; });"
      $task16Log=$task16Log.Replace('.log','-bridge.log')
      & $task16Runtime.Path -e $task16Bridge $task16File *> $task16Log
      $task16Exit=$LASTEXITCODE
      Add-Content -LiteralPath $task16Log -Value "NATIVE_EXIT=$task16Exit"
      $task16Results+=@{Runtime=$task16Runtime.Name;File=$task16File;Log=$task16Log;Exit=$task16Exit;Bridge=$true}
    }
    Write-Output ($Side+' Node'+$task16Runtime.Name+' '+$task16File+' exit='+$task16Exit)
  }
}
$task16Results | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $task16Scratch ('task-16-'+$Side+'-native-exits.json'))
$task16Final=@($task16Results | Where-Object { $_.Exit -ne 0 -and -not (($_.Runtime -eq '18') -and (Select-String -LiteralPath $_.Log -Pattern 'ERR_REQUIRE_ESM' -Quiet)) })
if ($task16Final.Count) { exit 1 }
exit 0
