**I1 - An authoritative detail denial does not invalidate an older concurrent list, allowing private data to return: ADDRESSED.** F/store/courier.js:18, :86, :100, :136, :147 and :164 coordinate publication across overlapping reads for each mission. Detail404 removes the mission and advances its freshness; an already-running list cannot republish its private snapshot. The same protection covers newer terminal detail versus an older list; the existing per-resource token also rejects an older detail. F/test/courier-mobile.test.js:519 adds the exact collection-preflight/list/detail404 ordering for both new collection and unresolved replay.

## Finding Verdicts

- **I1: ADDRESSED.** Identity remains unchanged in the regression. The list starts while collection preflight is pending; detail404 completes first; no collection POST occurs; the old list completes without restoring the denied mission. The unrelated row still updates. The unresolved case retains its original cash method/key and byte-for-byte recovery storage despite an external-card UI choice. This is the original defect, not just the previously covered successful-mutation ordering.
- **Equivalent closure/removal cases: ADDRESSED.** F/store/courier.js:95 protects terminal and omitted IDs against older details; :83 tracks detail IDs before first publication, so an empty authoritative list also protects unseen IDs. Terminal projections still use safeMission at :24 and strip address/contact/items. New detail publications advance only the affected mission's freshness at :104.
- **Command privacy interactions within I1: ADDRESSED.** F/store/courier.js:232 protects the commanded mission at entry; :253 captures freshness before POST; :260-266 suppress stale command publication/return while settling confirmed bookkeeping. A confirmed higher-server-version closure may supersede an intervening active detail, but that exception requires an existing active row and cannot restore a removed mission or supersede a newer terminal row. Command404 protects immediate removal at :278 before the follow-up authority read at :280. Nonterminal command confirmation has separate new breakage below.

## New Breakage In The Fix Diff

**New Critical: 0; Important: 1; Minor: 0.**

**N-I1 (Important) - A confirmed nonterminal command is discarded after a concurrent pre-commit active detail.** F/store/courier.js:253, :260, :262 and :264-266.

Check: command POST captures sequence S; while it is pending, an own-detail read publishes the still-active server version2 and advances this mission's freshness. The POST then confirms pickup as in_transit/version3. Only closed(row) qualifies for the version-based publication exception at :260, so this valid nonterminal result retains sequence S and is rejected by MISSION at :101. Nevertheless :264 clears pending and :266 returns null. The visible mission remains assigned/version2, with its old allowed actions, and there is no success-path mission reread to reconcile it. Before this fix, the command-success hunk published the confirmed result unconditionally.

Check: a single focused in-memory scenario using the actual exported store, real Vue2/Vuex, controlled promises and an injected transport reproduced this ordering for explicit pickup recovery. Output: "REPRODUCED: confirmed pickup replay version3/in_transit discarded after concurrent pre-commit detail version2/assigned; UI remains assigned, pending cleared, return=null, loading released." The diagnostic exited0 because it asserted the faulty behavior. No HTTP listener, real network, server or DB was used.

Check: the retained tests do not answer this case. Test33 covers an older active command versus a newer terminal detail; test34 covers a terminal command versus a pre-commit active detail. Neither checks a confirmed higher-version nonterminal command versus a lower-version active detail. Fix publication/reconciliation for that ordering while preserving I1's removed/terminal privacy barriers, and add the corresponding regression.

Check: inspected the entire supplied fix package once, including the change from blanket read invalidation to per-mission protection, list reconciliation, command publication and all nine added behavioral cases. No source hunk was cut off; no changed implementation/test file was separately reread.

Check: F/store/courier.js:89-98 keeps protected current rows or tombstones while accepting independent incoming rows. Protected rows omitted by an older list are reinserted at their prior positions; the explicit local order is filtered against the reconciled rows. The list action returns reconciled state at :145, not rejected stale DTOs.

Check: F/store/courier.js:137 permits reads begun after the protection boundary to publish new server authority. This is a freshness barrier for older work, not a permanent tombstone or a client-generated delivery version. F/store/courier.js:72 resets the new in-memory metadata with the existing identity epoch.

Check: F/store/courier.js:172 retains per-resource loading-token cleanup; :284 releases the mission command lock. The new code does not erase other resources' tokens. Held list/detail/command regressions assert that all loading flags are released.

Check: F/store/courier.js:236 retains current own-detail preflight before new collection and explicit replay. The existing pending body remains the submitted body at :254. Key creation, server expectedVersion, method handling and write-before-POST at :241-250 are unchanged. No amount or caller-selected courier is added.

Check: the diff leaves recovery serialization/validation/bounds unchanged. Its exact six persisted fields remain shopId, courierId, deliveryId, idempotencyKey, method and expectedVersion. Freshness metadata contains IDs/sequences in memory; the fix adds no storage writer or change to general persistence. Retained tests 6, 14, 18-20, 24 and 29 corroborate recovery and persistence behavior.

## Named Checks And Retained Evidence

**NC1 - Package identity and scope.** Read task-14-brief.md, the exact original I1 in task-14-review.md, the complete appended Round1 report, and the requested re-review rubric. Package BASE is 7c4e12efc12865e283a15fd142b058a329133d07; HEAD is 6cd46a4163aa04ba7ce875b19501e51c9203bde9. Its only source paths are store/courier.js and test/courier-mobile.test.js, 225 additions/13 deletions. task-14-fix1-commit.txt agrees on the commit and delta and records nativeExit=0. No git command was used to regenerate or independently audit the package. B0150e247fd3ff874eabeb85857aaa7482d2b430e was not freshly reviewed.

**NC2 - Exact I1 behavioral coverage.** Read both complete final logs, task-14-fix1-final-node22.txt and task-14-fix1-final-node18.txt. Each records 36 tests, 36 pass, 0 fail/cancelled/skipped/todo, nativeExit=0. The supplied diff adds the following named cases; each is present and successful in both logs:

| Test | Named scenario and assertion checked against the diff |
| --- | --- |
| 28 | round1 I1 detail404 blocks an old list started during collection preflight (new collection): original ordering, no POST, no resurrection, independent version8 row and local order, loading cleanup, later authoritative version9 publication. |
| 29 | Same scenario (unresolved replay): exact retained storage/body/key/method, no replay POST on denial. |
| 30 | round1 I1 newer terminal detail defeats older list and detail without blocking a fresh authoritative reopen: terminal version7, absent address/contact/items, independent row retained, later version8 read allowed. |
| 31 | round1 I1 newer list closure defeats an older detail: terminal row remains redacted. |
| 32 | round1 I1 newer list removal defeats an older detail: mission remains absent. |
| 33 | round1 I1 older command success cannot restore private data over a newer terminal detail: version5 terminal preserved, one POST, confirmed pending cleared, loading released. |
| 34 | round1 I1 command newer closure fences a concurrent older active detail and list: confirmed server version3 closure wins over active version2 and old list. |
| 35 | round1 I1 command 404 fences a concurrent older active detail and list: removal asserted while the follow-up detail is still held, then again after the old list finishes. |
| 36 | round1 I1 empty authoritative list fences an in-flight detail not previously in missions: delayed detail cannot introduce the absent ID. |

**NC3 - Retained counterexamples.** Inspected failure/count/exit excerpts from task-14-fix1-red-node22.txt: six named failures, including both original resurrection cases, nativeExit=1. task-14-fix1-command-red-node22.txt records 2/3 passing and the lost-closure failure, nativeExit=1. task-14-fix1-command-denial-red-node22.txt records both lost closure and failure to clear command404 before reread, 0/2, nativeExit=1. These correspond to the final added assertions and the command changes, rather than unrelated harness failures.

**NC4 - Retained affected compatibility checks.** Inspected completion summaries of all fourteen task-14-fix1-regression-node18/22-NAME.txt logs. Each records nativeExit=0. Per runtime, delivery-checkout is 29/29, customer-account 27/27 and delivery-operator 37/37, each with zero failures/cancellations/skips/todos; auth-middleware, session-auth, counter-checkout-store and persisted-state report their legacy assertion success. This corroborates the author report; it is not a fresh whole-branch review.

**NC5 - Retained lint.** Read task-14-fix1-lint.txt in full. It records nativeExit=0 and no ESLint code diagnostics for the two changed files. Browserslist stderr remains present; the evidence is not described as noise-free.

**NC6 - Focused new-breakage reproduction.** Static reading of the changed command publication rule raised N-I1, which no retained run answers. Ran only the controlled in-memory scenario described above. Auth/expiry helpers were fixture adapters accepting a fixed identity; the transport was an in-memory response adapter, while the exported store actions/mutations and Vue/Vuex were executed. An initial fixture attempt did not reach POST and exited1; it did not establish the ordering. The corrected scenario seeded an unresolved pickup body/key, exercised the supported explicit-recovery path, reached the held POST, published the pre-commit detail, and asserted the discarded confirmation. It exited0 with the diagnostic above. No production branch was bypassed or source file edited.

Check: these were two runtime-only loads of the store into an isolated VM, with ESM export/import adaptation and fixture dependency injection; no implementation source was separately displayed or statically reread. No suite, lint, build, server or SQL was rerun. All suite/lint results above are attributed to retained logs, not fresh executions. The focused diagnostic is new reviewer evidence only for N-I1.

## Out-Of-Scope Observations

- **Deferred M1:** the original stale read-error banner remains a final-triage item. It was not reopened or promoted into a blocking finding.
- **Deferred M2:** retained final compiler/lint logs still contain outdated Browserslist diagnostics; session-auth regression summaries contain inherited fixture logging. These are the already-deferred diagnostics, not new fix breakage.
- **Additional observations:** none. Untouched code/backend behavior was not expanded into a new review.

## Limits And Boundaries

Check: workspace_fs was attempted as the primary project reader and rejected this worktree as outside its allowed directories. PowerShell was used solely for the authorized worktree/scratch reads. No permission/configuration change or original checkout access was used.

Check: read the complete supplied diff once; no git diff regeneration, separate static changed-source reread, nested agent, source/index/branch edit, environment/provider access, real payment/refund/print/call, remote database, browser/detector, server action, push, deploy or merge occurred. The only additional implementation use was runtime loading for NC6's focused diagnostic. The only written artifact is this scratch report.

Limit: conclusions apply only to original I1 and breakage introduced by this two-file fix package. Retained logs and package metadata are evidence, not a new execution or independent HEAD/status attestation. Backend unchanged status is supplied context, not a new backend audit.

Limit: actual phone portrait/landscape, long-address, network-error and mixed-payment visual acceptance remains PENDING Task17 ONEbatch. No visual PASS is inferred. Full application suites/build and configured Node20 commissioning remain outside this intermediate gate.

## Verdict

**Fix round: Findings remain open - N-I1 (Important).** Original I1 is ADDRESSED, but the fix introduces lost nonterminal command confirmation under a concurrent active detail. Open in-scope findings: 1. New C/I/M: 0/1/0. Previously deferred M1/M2 remain 2 nonblocking final-triage items. Task17 visual acceptance remains pending.

