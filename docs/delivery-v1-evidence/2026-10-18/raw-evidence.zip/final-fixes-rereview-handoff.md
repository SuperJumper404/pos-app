# Final Fixes: ONE Scoped Independent Re-Review

Use the installed subagent-driven-development/re-review-prompt.md template.
This is the one final scoped re-review after the one broad fix dispatch,
not another full branch/task review. Read final-review.md in FULL, the amended
final-fixes-brief.md, complete final-fixes-report.md, current acceptance/decisions
and the exact paired scoped contextual packages supplied at dispatch.

F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
B = sibling express-pos. Fix bases F9fc355799e1124cc257a9e647f0933aadf04389c,
B8dbc562efb69a291a09b515b3d1ce17eb1253279; final HEADs follow at dispatch.
Review source/index/HEAD read-only; only write final-fixes-rereview.md and a
strictly necessary named focused scratch repro. No nested agents, modeloverride,
package-wide rerun, repeated/high-count loops, new detector/browser polish,
real sends/money/providers/print/calls/maps/clipboard/remoteenv/DB/deploy.

Read packages once. Changed source reread only if necessary context is cut off;
name it. Unchanged source only for a concrete integration risk with one focused
check. Author rationales/approvals are not evidence of correct behavior.
Read exact raw logs rather than rerun full gates to recreate known evidence.

## Findings To Close

I1: actual manual register settlement must produce immutable source proof
on the same transaction for initial pay-before and later collect/archive.
Register refund cannot require/forge courier collection. Full accepted fee,
current actor/shop before replay, unique/exact source and key/body, rollback,
post-lock UTC posting, old closure preservation, cash versus declared noncash
semantics and no courier debt/sale/VAT/stock duplication. Inspect additive
FK/trigger origin exclusivity and actual producer/controller handoffs; old
courier payment/refund data/FKs must remain valid. Cheque/mealvoucher are existing
offered register methods, not new courier methods or partial/mixed payments.
Unverifiable legacy paid flags must NOT be backfilled into invented proof.

I2: accepted unassigned operator reportIssue/resolution must close without an
available/fictitious courier, implicit refund/restock/debt or transfer. Legal
actions/dialog choices must align. Returned-unassigned/suspended and unpaid/
prepaid, exact replay/current role/version, explicit available retry, tracking/
operational closure and admin terminal correction with null courier must work.
No invented issue history or extended earliest immutable privacy ceiling.

## Scope And Qualifications

The controller accepted the additive two-table register payment/refund model
and exact two c_orders current req.id handoffs; the latter was retrospective
scope approval, not prior authorization. Both rationale/costs are in latest
Rulings; do not treat them as correctness proof. No unrelated controller change.

M1 inherited diagnostics/audit47/lint/build noise and M2 runtime final-probe
timeouts remain explicitly deferred. Do not reopen maintenance as if a new
financial regression, but report any actual Important/Critical new breakage
introduced by this fix. Do not audit untouched feature areas again.

Earlier complete Task17 gates/screenshot matrix are BEFORE this fix. Current
final-fix full commands, runtime, source/test binding qualifications are in the
new author report. F screenshots are not newly taken for these tiny dialogs;
actual compiled Vue/Vuex tests exercise the new source/actions. Both actual
email/WhatsApp receipts NOT EXECUTED, commissioning and deployment remain
outside approval. Raw archive/hash finalization follows this review while all
original evidence remains present; no false completed-retention claim.

## Output

Write final-fixes-rereview.md: I1/I2 ADDRESSED/PARTIAL/NOTADDRESSED with concrete
file:line evidence, scoped new Critical/Important/Minor findings, necessary
context/repro checks and exact retained evidence reviewed. Clear technical
verdict; no merge/deploy/live readiness authorization. Avoid repeat whole-branch
review or recommending an open-ended new QA/review loop. Controller adjudicates
every residual after this one re-review.
