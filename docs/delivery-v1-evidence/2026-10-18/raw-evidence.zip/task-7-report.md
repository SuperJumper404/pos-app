# Task 7: Courier cash handovers and immutable cash periods

## Status and identity

Implementation and author self-review in the approved worktree. Unit integration has an additional exact fixture ownership gap described below; do not interpret the SQL evidence as an all-green npm test claim. Final verification and commit evidence are appended below. Independent review belongs to the controller; no reviewer or subagent was dispatched.

- B: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
- F: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
- Branch: feat/delivery-v1
- BASE: 39f116934f9873eef70fd56836799493b6100467
- Original checkouts, real env files, providers, remote databases, push/deploy/merge and shared ledger were not modified or used.
- workspace_fs was attempted first and denied the paired worktree. Shell reads followed worker-context's explicit fallback. Manual source/report edits use apply_patch.
- Read task-7-brief FIRST, then worker-context, task-7-integration-notes, common plan contracts/index, specification 7/10, Task6 actual producer/interfaces/clock/locks, Task4 resolver/commercial-first protocol, Task5 current actor/permission and lock findings, and relevant controller rulings. No whole sibling task plan was reloaded.
- Skills: executing-plans, test-driven-development, verification-before-completion and systematic-debugging. User's specific ownership/no-subagents/no-ledger instructions govern the workflow.

## Files and boundaries

1. New B/src/modules/m_courierCash.js: injectable transaction/repository/clock service, immutable journal projection, remittances, FIFO allocations, source-linked admin corrections, exact string journal identities, closure cash summary.
2. New B/test/courier-cash.integration.test.js: actual disposable MySQL, production-style mysql2 BIGINT defaults, actual collection producer, actual archive/refund controllers/modules, real HTTP/auth/permissions, lock waits, rollback and precision coverage.
3. New B/db/migrations/20261016121000_delivery_cash_closures.sql: nullable cash_closures.courier_cash JSON; financial collection/remittance/allocation/adjustment created_at widened to DATETIME(6) with CURRENT_TIMESTAMP(6) defaults. Historical migrations and immutable-journal triggers are untouched.
4. B/src/controllers/c_delivery.js and B/src/routers/r_delivery.js: operator balance, handover and admin correction adapters. Mutation body allowlists; actor/shop from authentication, holder from validated route.
5. B/src/controllers/c_courier.js and B/src/routers/r_courier.js: GET /courier/cash-balance, same service, courier/shop from current authenticated identity. Posted/query identities do not select another holder.
6. B/src/helpers/cashClosure.js: optional additional immutable summary, first-period opening event when a physical-only period precedes any archive. Existing pure-helper callers retain their original shape.
7. B/src/modules/m_cashClosures.js: injectable closure clock/runner, shop-barrier preview/close, stored JSON read/list/detail roundtrip, physical-only closure eligibility, full-precision cutoff, exact delivery link string projection. Existing exports retained.
8. B/src/routers/r_orders.js: ONLY the four existing /reports/z routes gain the existing authorizeCashRegister after authentication. All unrelated bindings preserved.
9. B/test/delivery-dispatch.integration.test.js: ONLY obsolete reserved own-balance GET404 assertion replaced with actual 200/own shop/user/zero financial totals/version/empty collection assertions. Existing Task6 empty-body400/code and all other behavior retained.
10. B/package.json: append new SQL integration file to registered test:delivery:db. Existing unit command/dependencies/lockfile unchanged.

B/src/controllers/c_orders.js required no new behavior: Task4/5 commercial settlement/archive guards remain the actual owners and are reused through their real producers. No production dependency shim, global transaction retry, nested transaction or unrelated refactor was added.

## Stable service and HTTP interfaces

buildCourierCash({repository?, runInTransaction?, clock?}) returns:

- balance({actor,courierId}) -> {shopId,courierId,version,collectedCents,receivedCents,remainingDueCents,discrepancyCents,surplusCents,adjustedDueCents,collections,remittances,adjustments}.
- remit({actor,courierId,receivedCents,expectedBalanceVersion,idempotencyKey}) -> {remittanceId,expectedCents,receivedCents,discrepancyCents,remainingDueCents}.
- adjust({actor,courierId,collectionId|null,remittanceId|null,deltaDueCents,reason,idempotencyKey}) -> {adjustmentId,balance}.

New journal/source IDs are decimal strings, including above 2^53; courier/shop/payment IDs preserve legacy integer types. Money is safe integer cents. version is 1 + immutable cash collections + remittances + corrections for this holder/shop. External-card collections do not create a cash balance/version. No mutable courier debt column exists.

Routes under the normal existing API prefix:

| Method | Relative route | Authority |
| --- | --- | --- |
| GET | /courier/cash-balance | Current active role6, server-derived own identity |
| GET | /delivery/couriers/:id/cash-balance | Current admin or cashier with delivery permission, same-shop holder |
| POST | /delivery/couriers/:id/remittances | Same operator authority; cannot confirm own physical funds |
| POST | /delivery/couriers/:id/adjustments | Current active admin, justified immutable source-linked correction |

All delivery cash responses reuse DomainError/response envelope and Cache-Control:no-store. No mission address/contact/instructions/items/tracking token are included. Balance includes only financial identities/amounts/dates and correction audit metadata. No self-remit/adjust route was added to the courier namespace or central guard (the exact own GET was already allowed).

Handover body is exactly {receivedCents,expectedBalanceVersion,idempotencyKey}; expected cash is calculated under lock, never posted. Correction body is exactly {collectionId,remittanceId,deltaDueCents,reason,idempotencyKey}. Claimed refund IDs/actors, arbitrary actor/shop fields, invalid amounts/IDs and missing sources/reasons are rejected. IDs cannot be already-rounded JS Numbers for new journals. Same key/payload returns the saved response plus exact SQL ID without another write; changed actor/payload/source or changed cash operation conflicts409. Current DB permissions are checked before replay. Cash-local key checking does not add global journal gap locks.

Custody follows immutable collection.courier_id. Reassignment and inactive/former-role holder metadata do not transfer, hide or erase money. Operator balance/history/remittance remains usable for those holders. Only the own courier endpoint requires current active role6. A role-changed cashier still cannot remit to themself, because exclusion compares holder and actor IDs. New service independently reloads actor status, non-null current role and module_permissions, rather than trusting actor.access/JWT claims.

Partial receipt allocates only the amount physically received and leaves shortage due. Surplus is distinct, cannot overallocate a collection or create negative debt/additional revenue. Allocations reuse foundation trigger caps and append-only constraints. A correction appends source applications and audit identity/reason, never changes a sale, collection, previous remittance or closure. Negative correction is bounded by source debt; positive correction can restore a prior source write-off up to its remaining original unallocated custody. Surplus remains separately visible, not silently erased. Corrections also refuse confirming one's own former cash.

## Clock, serialization and closure JSON

Lock order is shop FOR UPDATE FIRST, then actor/holder accounts in deterministic numeric order; immutable source/replay reads start only after that barrier. Allocations acquire their existing immutable source caps through the foundation triggers. Collection/archive/close retain Task4/6's existing shop-first protocol; no commercial or dossier lock is acquired by the cash service. No shared helper/global retry was changed.

Production posting is SELECT DATE_FORMAT(UTC_TIMESTAMP(6),'%Y-%m-%d %H:%i:%s.%f') on the SAME transaction connection AFTER barrier acquisition. Clock injection is test-only and may return an exact SQL6 UTC string or Date/ISO value padded to microseconds. Closure comparisons preserve SQL6 strings throughout; public JS projection never supplies a cutoff. The new migration stores all six digits. Closure's DB query checks session CURRENT_TIMESTAMP(6) equals UTC_TIMESTAMP(6): a non-UTC session fails explicitly instead of silently interpreting historic session-time cutoffs as UTC. No global/server/session timezone change was added to production.

buildCashClosures({runInTransaction?,clock?}) preserves mGetCurrentCashClosure, mCloseCurrentCashClosure, mGetCashClosures and mGetCashClosureById; the original default exports remain. Snapshot JSON stored once in cash_closures.courier_cash is:

```json
{
  "collected_cents": 3000,
  "received_cents": 2800,
  "outstanding_cents": 200,
  "discrepancy_cents": -200,
  "adjusted_due_cents": 0,
  "surplus_cents": 0,
  "courier_cash_sales_cents": 3000,
  "register_cash_sales_cents": 0,
  "remittances_count": 1,
  "adjustments_count": 0,
  "first_event_at": "2026-10-24 21:50:00.123456"
}
```

The four required fields are always present for new snapshots. Collected/received/discrepancy/adjusted/surplus/counts use (lastClosedAt,closedAt]. outstanding is the running custody balance as of closedAt, including older debt. Courier/register cash SALES use this period's archived orders and immutable collection -> actual payment -> original order/delivery linkage, regardless collection date. first_event_at is the earliest financial event in the period (null if none). Receipt totals are physical drawer input, never sales or VAT. These axes give Task15 enough persisted source breakdown; do not compute register cash sales by subtracting period collections from period sales.

Historic courier_cash remains null and is never recomputed from live debt. Read/list/detail only parse the stored JSON. The existing sale/payment/VAT summaries still count each archive once; no fake order or revenue enables physical-only periods. Empty sale/receipt/correction periods still reject400. A receipt-only or correction-only period legitimately closes with zero sales and empty payment summary.

## Refund ownership gap and concrete proposal

UNIT FIXTURE OWNERSHIP GAP: npm.cmd test now stops in unchanged B/test/delivery-authorization.test.js:62, actual503 versus expected200 for GET /courier/cash-balance. Its fixture injects dispatch only, mocks pool.query without getConnection, and previously reached the fallback sentinel for that reserved GET. The new real route correctly reaches the cash service. This file is NOT in the authorized Task7 ownership list, and the brief's narrow direct-router middleware-export allowance does not authorize an unrelated cash-service injection. No fallback, placeholder, production shim, assertion removal or unowned edit was used to hide the failure.

Exact bounded proposal: authorize ONLY adding cash: { balance: operation } to that fixture's existing buildCourierController options at line39. operation already asserts actor.id===11; retain every assertion and all other behavior. The actual financial response is independently covered by Task7 SQL/HTTP and the authorized linked Task5 assertion. A concrete unapplied diff is at scratch/task-7-authorization-fixture-proposal.patch. The full unit command was run once and its failure is retained; separately executing its remaining62 commands produced zero failures. This continuation is NOT an all-green npm.cmd test.

SOURCE-CONFIRMED GAP: actual Task4/6 manual collection writes payments.status=succeeded with a local manual_delivery:* reference, while the commercial order's Stripe provider/intent remain null. m_payments.getPaidOrderForRefund matches real Stripe intent or Terminal linkage; c_stripe.buildRefundPaidOrderController/refundPaidOrder and Terminal refund service implement provider refunds, not a manual cash return carrying physical-holder evidence. The test invokes the actual production refund controller on an actual courier cash collection: it returns404 before any provider call, leaves payment paid, and custody remains3000. A separate pre-marked refunded header only characterizes independence; it is explicitly NOT reported as an authorized refund path.

Bounded controller ownership proposal, NOT implemented: authorize B/src/modules/m_payments.js plus B/src/controllers/c_orders.js/B/src/routers/r_orders.js for one explicit manual delivery cash-return operation; approve one new additive immutable cash-return journal migration and corresponding actual SQL/HTTP tests. Proposed service recordManualDeliveryCashRefund({actor,shopId,orderId,collectionId,returnedByUserId,idempotencyKey},connection) must acquire shop -> original commercial/archive -> dossier/current charge -> identities/source, reload admin/cashier authority and original payment/amount, and record a confirmed full refund including the accepted fee. Store immutable refund ID, original payment/collection, server-derived confirmed amount, authorizing actor, actual physical-return holder, server UTC6 time, key/hash. No claimed refund/status/reason alone is evidence. A trusted cash integration adapter applyConfirmedCourierCashReturn({refundId,connection}) must load that confirmed record on the same caller transaction, verify shop/payment/source/current immutable collection holder, deduplicate by refund ID and lower debt ONLY when returnedByUserId equals collection.courier_id. A cashier physical return leaves courier custody unchanged and belongs to drawer physical-outflow reporting. Partial refunds/partial fee scope need explicit product approval; do not invent them. Tests must execute the real operation before/after archive, compare cashier/courier physical return, refuse forged/foreign/duplicate/over-return evidence, roll back both ledgers together and prove no old closure changes. Existing adjust is an admin write-off/restoration mechanism, never this missing confirmed-refund adapter.

Additional bounded shared-auth concern found during self-review: existing helpers/middleware/auth.js normalizes nullable users.access with Number(user.access), so null becomes0; existing authorizeCashRegister then treats it as admin. Task7's new cash service explicitly rejects a null DB role, with actual SQL RED/GREEN evidence. The required existing middleware is bound to all four Z routes, but that pre-existing shared null-role normalization was not edited outside Task7 ownership. Exact proposal: authorize a guard rejecting user.access == null before Number(...) inside buildAuthentication, and an actual HTTP regression in test/delivery-authorization.test.js covering the Z routes/new cash routes. This would close the shared malformed-account issue without altering legitimate roles or per-module behavior. This is a source-confirmed boundary concern, not a claim that Task7 repaired the whole legacy auth system.

Other practical limits: production DB UTC/session assumptions were verified only on the disposable server, never against a real environment. Non-UTC historical cutoffs require an explicit migration/operations decision before enabling the new closure flow. Native Node22 and compatible Node18 fixture SQL evidence do not claim that unbridged production Node18 ESM Nano ID boot was modernized. Controller retains independent review/acceptance.

## Verification Evidence

All SQL commands below used only the authorized explicit URL and the random-database harness; no application DB fallback. Native Node v22.13.1; compatible Node v18.20.8 at C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe. The only bridge is the existing fixture-only import of the ACTUAL installed Nano ID dependency into require.cache on Node18. No production shim.

Common PowerShell setup for EVERY SQL invocation:

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task7-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task7-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
```

These are disposable fixture credentials only. Each execution redirects *> the named scratch log, records $task7Exit=$LASTEXITCODE, prints the log and exits with that code. Full log outputs, exact commands, outcomes and final git evidence follow.

### task-7-red.txt

Initial RED before production implementation. Missing module/factory/migration and actual own GET404 versus200. All failures retained; these are not represented as passing assertions. Exit1.

```powershell
Remove-Item Env:TASK7_FILTER -ErrorAction SilentlyContinue
node test/courier-cash.integration.test.js
```

Full captured output:

```text
node : FAIL SQL 3000 collected, 2800 then 200 physically received, immutable allocations and replay: Error: Cannot 
find module '../src/modules/m_courierCash'
Au caractère Ligne:6 : 1
+ node test/courier-cash.integration.test.js *> '../pos-app/.superpower ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (FAIL SQL 3000 c.../m_courierCash':String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:47:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL surplus remains distinct, external card never creates cash custody: Error: Cannot find module 
'../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:73:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL same balance version admits only one cashier; current version survives barrier wait: Error: Cannot find 
module '../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:86:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL admin justified correction is new source-linked evidence; cashier and courier forbidden: Error: Cannot find 
module '../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:97:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL custody follows collection holder through reassignment, suspension and role change; no self-remit: Error: 
Cannot find module '../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:116:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL cashier refund state or client refund claims do not prove a courier physical return: Error: Cannot find 
module '../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:129:19
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL R5 sale closes once; next physical-only period persists and reads immutable running debt: TypeError: 
buildCashClosures is not a function
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:143:24
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:286:11)
FAIL SQL collection before closure and archive next period retain courier sales source: Error: Cannot find module 
'../src/modules/m_courierCash'
Require stack:
- 
C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.test.js
    at Function._resolveFilename (node:internal/modules/cjs/loader:1244:15)
    at Function._load (node:internal/modules/cjs/loader:1070:27)
    at TracingChannel.traceSync (node:diagnostics_channel:322:14)
    at wrapModuleLoad (node:internal/modules/cjs/loader:217:24)
    at Module.require (node:internal/modules/cjs/loader:1335:12)
    at require (node:internal/modules/helpers:136:16)
    at cash (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:38:29)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:168:15
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
FAIL SQL actual queued close/remittance takes posting clock after shop barrier at submillisecond cutoff: TypeError: 
require(...).buildCashClosures is not a function
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:188:58
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:286:11)
FAIL SQL additive migration up/down/up preserves historic null snapshots and journal constraints: Error: ENOENT: no 
such file or directory, open 'C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\db\migra
tions\20261016121000_delivery_cash_closures.sql'
    at Object.readFileSync (node:fs:442:20)
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:222:21
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:41:11
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:286:11)
Loaded env file: NUL
FAIL SQL actual HTTP trusted own balance, operator handovers, strict payloads and four Z boundaries: AssertionError 
[ERR_ASSERTION]: 404 == 200
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:250:12
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:286:11)
```

### task-7-partial-green.txt

First focused GREEN. Exit0.

```powershell
$env:TASK7_FILTER='3000 collected'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL 3000 collected, 2800 then 200 physically received, immutable allocations and replay
```

### task-7-focus-0.txt

First two closure SQL cases GREEN. Exit0.

```powershell
$env:TASK7_FILTER='period'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL R5 sale closes once; next physical-only period persists and reads immutable running debt
PASS SQL collection before closure and archive next period retain courier sales source
```

### task-7-focus-1.txt

Fixture clock error: future collection combined with a current-time remittance made an as-of summary see allocation before source. Corrected HTTP fixture to use the current Date; no production workaround. Exit1.

```powershell
$env:TASK7_FILTER='actual HTTP'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
Loaded env file: NUL
node : FAIL SQL actual HTTP trusted own balance, operator handovers, strict payloads and four Z boundaries: 
AssertionError [ERR_ASSERTION]: {"status":500,"data":{"code":500,"success":false,"message":"Impossible de recuperer 
l'apercu Ticket Z.","pagination":"Missing cash allocation source","data":null},"cache":null}
Au caractère Ligne:7 : 1
+ node test/courier-cash.integration.test.js *> '../pos-app/.superpower ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (FAIL SQL actual...},"cache":null}:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
    at C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integration.t
est.js:287:14
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:41:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:296:11)
```

### task-7-green-attempt.txt

All14 groups present at this stage passed. Subsequent null-role/cross-operation and production DB clock cases are separately evidenced below and in the final registered chain. Exit0.

```powershell
Remove-Item Env:TASK7_FILTER -ErrorAction SilentlyContinue
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL 3000 collected, 2800 then 200 physically received, immutable allocations and replay
PASS SQL surplus remains distinct without negative debt or additional sales
PASS SQL external card never creates cash custody
PASS SQL same balance version admits only one cashier; current version survives barrier wait
PASS SQL admin justified correction is new source-linked evidence; cashier and courier forbidden
PASS SQL custody follows collection holder through reassignment, suspension and role change; no self-remit
Loaded env file: NUL
PASS SQL cashier refund state or client refund claims do not prove a courier physical return
PASS SQL real allocation failure rolls back receipt and totals; correction failure rolls back its journal
PASS SQL exact BIGINT cash identities survive production driver defaults and source-linked correction
PASS SQL R5 sale closes once; next physical-only period persists and reads immutable running debt
PASS SQL collection before closure and archive next period retain courier sales source
PASS SQL actual queued close/remittance takes posting clock after shop barrier at submillisecond cutoff
PASS SQL additive migration up/down/up preserves historic null snapshots and journal constraints
Loaded env file: NUL
PASS SQL actual HTTP trusted own balance, operator handovers, strict payloads and four Z boundaries
```

### task-7-dbclock.txt

Production DB UTC6 query exercised under deterministic disposable SET timestamp. Actual performance_schema shop wait and .500123/.500124 persistence, not JS clock arithmetic. Exit0.

```powershell
$env:TASK7_FILTER='production DB UTC'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL production DB UTC clocks retain queued submillisecond receipt after closure and refuse timezone reinterpretation
```

### task-7-null-role-red.txt

RED at null DB-role rejection, before explicit null guard. Exit1.

```powershell
$env:TASK7_FILTER='current null role'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
node : FAIL SQL current null role cannot become admin and one cash key cannot change operation: AssertionError 
[ERR_ASSERTION]: Missing expected rejection.
Au caractère Ligne:7 : 1
+ node test/courier-cash.integration.test.js *> '../pos-app/.superpower ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (FAIL SQL curren...cted rejection.:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:161:3
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:46:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:421:11)
```

### task-7-cross-key-red.txt

After null guard, RED moves to changed cash operation using one key. Fixed by checking the other cash journal under the same shop barrier; no gap lock/retry. Exit1.

```powershell
$env:TASK7_FILTER='current null role'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
node : FAIL SQL current null role cannot become admin and one cash key cannot change operation: AssertionError 
[ERR_ASSERTION]: Missing expected rejection.
Au caractère Ligne:7 : 1
+ node test/courier-cash.integration.test.js *> '../pos-app/.superpower ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (FAIL SQL curren...cted rejection.:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:164:3
    at async C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.integra
tion.test.js:46:5
    at async withDeliveryDatabase (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\tes
t\helpers\deliveryDatabase.js:123:12)
    at async main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\courier-cash.i
ntegration.test.js:421:11)
```

### task-7-null-key-green.txt

Both discovered cases GREEN. Exit0.

```powershell
$env:TASK7_FILTER='current null role'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL current null role cannot become admin and one cash key cannot change operation
```

### task-7-node18-queued.txt

Node18 actual SQL, both injected and production DB clock boundary variants. Exit0.

```powershell
$env:TASK7_FILTER='queued'
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL actual queued close/remittance takes posting clock after shop barrier at submillisecond cutoff
PASS SQL production DB UTC clocks retain queued submillisecond receipt after closure and refuse timezone reinterpretation
```

### task-7-r5-final.txt

Final R5 includes third correction-only period and second-period immutable read. Exit0.

```powershell
$env:TASK7_FILTER='R5'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL R5 sale closes once; next physical-only period persists and reads immutable running debt
```

### task-7-http-final.txt

Final native HTTP focused round before the subsequent disabled-cashier/admin-correction additions. Exit0.

```powershell
$env:TASK7_FILTER='actual HTTP'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
Loaded env file: NUL
PASS SQL actual HTTP trusted own balance, operator handovers, strict payloads and four Z boundaries
```

### task-7-race-final.txt

Two different cashiers/version race plus concurrent same-key replay. Exit0.

```powershell
$env:TASK7_FILTER='same balance version'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL same balance version admits only one cashier; current version survives barrier wait
```

### task-7-node18-http.txt

Final HTTP coverage, including disabled CASHIER on four Z routes and current DB-admin correction despite a cashier JWT access claim. Exit0.

```powershell
$env:TASK7_FILTER='actual HTTP'
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/courier-cash.integration.test.js
```

Full captured output:

```text
Loaded env file: NUL
PASS SQL actual HTTP trusted own balance, operator handovers, strict payloads and four Z boundaries
```

### task-7-adjust-final.txt

Final correction round includes positive restoration then actual final receipt; allocation total stays3000. Exit0.

```powershell
$env:TASK7_FILTER='admin justified'
node test/courier-cash.integration.test.js
```

Full captured output:

```text
PASS SQL admin justified correction is new source-linked evidence; cashier and courier forbidden
```

### task-7-npm-test.txt

Full registered unit command ONCE. Stops at the unowned authorization fixture cash GET503 versus200. No whole-unit success claim. Exit1.

```powershell
Remove-Item Env:TASK4_TEST_FILTER,Env:TASK5_REVIEW_FILTER,Env:TASK7_FILTER -ErrorAction SilentlyContinue
npm.cmd test
```

Full captured output:

```text

> express-pos@1.0.0 test
> node test/delivery-authorization.test.js && node test/delivery-pricing.test.js && node test/delivery-quotes.test.js && node test/stripe-terminal-routes.test.js && node test/stripe-terminal-kiosk-routes.test.js && node test/stripe-terminal-migration.test.js && node test/stripe-terminal-module.test.js && node test/stripe-terminal-locking.test.js && node test/stripe-terminal-domain.test.js && node test/stripe-terminal-readers.test.js && node test/stripe-terminal-kiosk-assignment.test.js && node test/stripe-terminal-payments.test.js && node test/stripe-terminal-kiosk-payments.test.js && node test/stripe-terminal-webhooks.test.js && node test/stripe-terminal-refunds.test.js && node test/json-body-errors.test.js && node test/shop-theme.test.js && node test/shop-theme-contract.test.js && node test/table-access-token.test.js && node test/table-access-controller.test.js && node test/service-point-access-token.test.js && node test/service-point-session-auth.test.js && node test/shop-service-points-init.test.js && node test/transaction-helper.test.js && node test/database-readiness.test.js && node test/vat.test.js && node test/vat-migration.test.js && node test/discount.test.js && node test/receipt-shop-settings.test.js && node test/service-points-migration.test.js && node test/service-points-controller.test.js && node test/service-point-order-display.test.js && node test/service-point-cash-register-detail.test.js && node test/stripe-payment.test.js && node test/order-detail-stock.test.js && node test/cash-register-payment.test.js && node test/cash-closure.test.js && node test/payment-method-standardization.test.js && node test/order-metrics-revenue-series.test.js && node test/payment-method-migration.test.js && node test/customization-rules.test.js && node test/customization-choice-propagation.test.js && node test/stock-requirements.test.js && node test/stock-inventory-domain.test.js && node test/stock-inventory-migration.test.js && node test/stock-inventory-controller.test.js && node test/stock-inventory-module.test.js && node test/stock-authorization.test.js && node test/product-stock-mutation.test.js && node test/product-stock-tracking.test.js && node test/click-and-collect-products.test.js && node test/customization-migration.test.js && node test/reservation-lifecycle.test.js && node test/counter-checkout-payment-mode.test.js && node test/checkout-contract.test.js && node test/order-delete-hidden-archive.test.js && node test/order-attribution.test.js && node test/order-attribution-transition.test.js && node test/staff-credentials.test.js && node test/staff-module-permissions.test.js && node test/staff-login-contract.test.js && node test/admin-email-login.test.js && node test/admin-legacy-password-login.test.js

Loaded env file: NUL
npm.cmd : AssertionError [ERR_ASSERTION]: 503 == 200
Au caractère Ligne:7 : 1
+ npm.cmd test *> '../pos-app/.superpowers/sdd/2026-10-16-delivery-mana ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (AssertionError ...ON]: 503 == 200:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
    at main (C:\Users\kalag\Desktop\projects\clone-pos\pos\.worktrees\delivery-v1\express-pos\test\delivery-authorizati
on.test.js:62:187)
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5) {
  generatedMessage: true,
  code: 'ERR_ASSERTION',
  actual: 503,
  expected: 200,
  operator: '=='
}
```

### task-7-npm-continuation.txt

Harness invocation error ONLY: Windows native-argument quoting stripped JS quotes before Node parsed it. No unit test executed in this invocation. Corrected by piping the literal here-string below. Exit1.

```powershell
node -e <unit continuation JS passed as a PowerShell single-quoted native argument>
```

Full captured output:

```text
node : [eval]:1
Au caractère Ligne:6 : 1
+ node -e 'const {spawnSync}=require("child_process");const commands=re ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: ([eval]:1:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
const {spawnSync}=require(child_process);const commands=require(./package.json).scripts.test.split(
                                                                ^

SyntaxError: Unexpected token '.'
    at makeContextifyScript (node:internal/vm:185:14)
    at node:internal/process/execution:107:22
    at [eval]-wrapper:6:24
    at runScript (node:internal/process/execution:101:62)
    at evalScript (node:internal/process/execution:136:3)
    at node:internal/main/eval_string:55:3

Node.js v22.13.1
```

### task-7-npm-continuation-fixed.txt

All62 remaining actual registered unit commands execute. This is supplemental continuation, not a passing npm test. Exit0.

```powershell
@'
const {spawnSync} = require('child_process');
const commands = require('./package.json').scripts.test.split(' && ');
let failed = 0;
for (const command of commands.slice(1)) {
  const match = /^node (test\/[A-Za-z0-9.-]+\.js)$/.exec(command);
  if (!match) throw new Error('Unexpected unit command');
  const result = spawnSync(process.execPath, [match[1]], {stdio: 'inherit'});
  if (result.status !== 0) {
    failed++;
    console.error('UNIT CONTINUATION FAILED ' + match[1] + ' exit=' + result.status);
  }
}
console.log('UNIT CONTINUATION commands=' + (commands.length - 1) + ' failures=' + failed);
process.exitCode = failed ? 1 : 0;
'@ | node
```

Full captured output:

```text
delivery pricing tests passed (distance, bands, money, fiscal snapshot, signed address expiry/scope)
Loaded env file: NUL
PASS I1 integer discount thresholds
PASS I2 loaded settings safety
PASS I3 selected postal precision
delivery quotes tests passed (server prices/discounts, IGN privacy/cache/errors, HTTP scope/roles, expiry, timeout)
Loaded env file: NUL
stripe terminal route contracts passed
Loaded env file: NUL
stripe terminal kiosk route contracts passed
stripe terminal migration tests passed
Loaded env file: NUL
stripe terminal module tests passed
Loaded env file: NUL
PASS overlapping start/finalization waits on rows without a lock cycle and revalidates paid orders
PASS payment creation lock success
PASS payment creation lock work-failure
PASS payment creation lock busy
PASS payment creation lock acquire-null
PASS payment creation lock acquire-failure
PASS payment creation lock release-failure
PASS payment creation lock release-null
PASS payment creation lock rollback-failure
PASS payment reader lock success
PASS payment reader lock work-failure
PASS payment reader lock busy
PASS payment reader lock acquire-null
PASS payment reader lock acquire-failure
PASS payment reader lock release-failure
PASS payment reader lock release-null
PASS payment reader lock rollback-failure
PASS payment refund lock success
PASS payment refund lock work-failure
PASS payment refund lock busy
PASS payment refund lock acquire-null
PASS payment refund lock acquire-failure
PASS payment refund lock release-failure
PASS payment refund lock release-null
PASS payment refund lock rollback-failure
PASS reader handoffs serialize across repository instances and nested locks reuse the connection
PASS nested reader release-failure destroys the connection
PASS nested reader release-null destroys the connection
PASS nested reader rollback-failure destroys the connection
stripe terminal domain tests passed
Loaded env file: NUL
PASS first registration creates a France location and forwards the code once on the platform account
PASS later registration reuses the location without requiring an address
PASS changed address synchronizes the platform location before registration
PASS unchanged address avoids a location update
PASS registration rejects missing code before any Stripe call
PASS registration rejects blank code before any Stripe call
PASS registration rejects object code before any Stripe call
PASS registration rejects oversized code before any Stripe call
PASS registration rejects blank label before any Stripe call
PASS registration rejects object label before any Stripe call
PASS registration rejects oversized label before any Stripe call
PASS registration rejects missing assignment before any Stripe call
PASS registration rejects boolean assignment before any Stripe call
PASS registration rejects array assignment before any Stripe call
PASS registration rejects fractional assignment before any Stripe call
PASS registration rejects unsafe assignment before any Stripe call
PASS registration rejects invalid shop before any Stripe call
PASS registration rejects missing first address before any Stripe call
PASS registration rejects foreign country before any Stripe call
PASS registration rejects missing country before any Stripe call
PASS registration rejects invalid postal code before any Stripe call
PASS registration rejects blank city before any Stripe call
PASS registration rejects long address before any Stripe call
PASS registration rejects future kiosk input before any Stripe call
PASS duplicate active cashier assignment fails before updating location or registering
PASS registration rejects cross-shop assignees before Stripe
PASS registration rejects inactive assignees before Stripe
PASS registration rejects customer assignees before Stripe
PASS registration rejects web customer assignees before Stripe
PASS inactive historical assignment does not reserve the cashier
PASS assignment changes the cashier and preserves the nullable service-point field
PASS assigning the same cashier is idempotent
PASS assignment rejects another active reader for the cashier
PASS assignment rejects inactive readers
PASS assignment can move a service-point reader back to a cashier
PASS assignReader rejects a cross-shop reader
PASS assignReader rejects malformed reader IDs
PASS setReaderActive rejects a cross-shop reader
PASS setReaderActive rejects malformed reader IDs
PASS deactivation is local, preserves registration and assignment, and hides current reader
PASS reactivation restores current reader after validating the active assignee
PASS reactivation rejects duplicate assignment
PASS reactivation rejects an inactive cashier
PASS active flag must be a boolean
PASS list returns only sanitized readers in the authenticated shop
PASS refresh retrieves only local shop readers and preserves assignment fields
PASS current reader is resolved from staff identity and returns null without assignment
PASS listReaders requires an active same-shop database administrator
PASS listReaders controller rejects non-admin and service-point sessions
PASS registerReader requires an active same-shop database administrator
PASS registerReader controller rejects non-admin and service-point sessions
PASS assignReader requires an active same-shop database administrator
PASS assignReader controller rejects non-admin and service-point sessions
PASS setReaderActive requires an active same-shop database administrator
PASS setReaderActive controller rejects non-admin and service-point sessions
PASS refreshReaders requires an active same-shop database administrator
PASS refreshReaders controller rejects non-admin and service-point sessions
PASS controller uses authenticated scope and returns registration DTO
PASS controller exposes assignment, activation, list, and refresh results
PASS current-reader controller accepts staff and rejects customer or kiosk sessions
PASS Stripe errors are sanitized by service and controller without logging or persisting raw details
PASS database uniqueness races become a stable conflict without exposing raw errors
PASS unexpected infrastructure errors never expose raw data
PASS compensation deletes the returned Stripe Reader after throw
PASS compensation deletes the returned Stripe Reader after empty insert
PASS compensation deletes the returned Stripe Location after throw
PASS compensation deletes the returned Stripe Location after empty insert
PASS compensation restores the old Stripe address after a location update persistence failure
PASS compensation failure for Reader is sanitized and the lock is released
PASS compensation failure for Location is sanitized and the lock is released
PASS compensation treats an already deleted reader as cleaned up
PASS compensation requires Stripe to confirm deletion
PASS a DTO read failure after a successful insert does not delete a tracked reader
PASS registration rechecks the administrator and assignee while holding the database lock
PASS registration lock timeout is sanitized and performs no Stripe mutation
PASS concurrent registrations across service instances create one tracked reader and one location
PASS router binds all six reader endpoints with auth and preserves web/connect bindings
stripe terminal reader tests passed (77 tests)
Loaded env file: NUL
PASS registration accepts an active kiosk service point assignment
PASS assignment can move a reader from cashier to kiosk and clears the cashier
PASS assignment payloads must target either a cashier or a kiosk but not both
PASS assignment rejects table service points before mutation
PASS assignment rejects inactive kiosk service points before mutation
PASS assignment rejects cross-shop kiosk service points before mutation
PASS assignment rejects missing kiosk service points before mutation
PASS a second active reader cannot use the same kiosk assignment
PASS repository finds active readers assigned to a service point in the shop
stripe terminal kiosk assignment tests passed (9 tests)
Loaded env file: NUL
PASS aggregates persisted order amounts, allocates discount and creates a platform destination charge
PASS cash-register success exposes only authoritative settled allocations for a discounted receipt
PASS idempotent retry returns the active session without additional Stripe calls
PASS start reconciles a canceled active reader payment before reserving a new cash-register payment
PASS start cancels a stale cancelable active reader payment before reserving a new cash-register payment
PASS polling expires a cash-register terminal payment after thirty seconds
PASS round2 ambiguous creation replays byte-equivalent params after the shop account changes (enabled=1)
PASS round2 ambiguous creation replays byte-equivalent params after the shop account changes (enabled=0)
PASS round2 rejects 1 cents before reservation and allows a corrected 50-cent retry
PASS round2 rejects 49 cents before reservation and allows a corrected 50-cent retry
PASS round2 delayed cancel at reader-read cannot cancel B after A succeeds and B attempts handoff
PASS round2 delayed cancel at cancel-action cannot cancel B after A succeeds and B attempts handoff
PASS round2 cancel rereads the local session after waiting for the reader lock
PASS round2 process rereads local session and reader action after acquiring the reader lock
PASS round2 reader lock timeout makes no cancellation calls and retains the active session
PASS two service instances starting simultaneously reserve one session and call Stripe once
PASS rejects no reader before Stripe mutation
PASS rejects inactive reader before Stripe mutation
PASS rejects other cashier reader before Stripe mutation
PASS rejects foreign orders before Stripe mutation
PASS rejects paid orders before Stripe mutation
PASS rejects web payment pending before Stripe mutation
PASS rejects inactive orders before Stripe mutation
PASS rejects already attached orders before Stripe mutation
PASS rejects other reader order lock before Stripe mutation
PASS rejects missing connect account before Stripe mutation
PASS rejects disabled charges before Stripe mutation
PASS rejects invalid input {"orderIds":[]}
PASS rejects invalid input {"orderIds":[12,12]}
PASS rejects invalid input {"orderIds":[true]}
PASS rejects invalid input {"orderIds":[1.2]}
PASS rejects invalid input {"shopId":true}
PASS rejects invalid input {"cashierUserId":null}
PASS rejects invalid input {"discountType":"amount","discountValue":1.5}
PASS rejects invalid input {"discountType":"percent","discountValue":100}
PASS rejects offline reader and retains the retryable reservation
PASS rejects busy reader and retains the retryable reservation
PASS definitive creation failure retains the durable key without raw failure details
PASS ambiguous creation timeout retains reservation and retry does not create a second intent
PASS round1 recovers a 401 creation rejection with the durable key
PASS round1 recovers a 403 creation rejection with the durable key
PASS round1 recovers a 429 creation rejection with the durable key
PASS round1 concurrent recovery loser returns the session without another Stripe call
PASS round1 delayed original starter cannot release an ambiguously created intent
PASS round1 refuses to replay creation after the safe idempotency window
PASS round1 retries ER_LOCK_DEADLOCK in database-only reservation
PASS round1 retries ER_LOCK_DEADLOCK in database-only finalization
PASS round1 retries ER_LOCK_WAIT_TIMEOUT in database-only reservation
PASS round1 retries ER_LOCK_WAIT_TIMEOUT in database-only finalization
PASS round1 stops database retries after three attempts and keeps errors sanitized
PASS round1 retries cancellation persistence without repeating Stripe cancellation
PASS process failure cancels its intent before freeing the session
PASS failed cleanup keeps the intent and reservation recoverable
PASS allocation failure rolls back before Stripe
PASS polling success finalizes paid orders atomically without archiving them
PASS failed success finalization preserves active session for paid-but-not-archived recovery
PASS getPaymentStatus rejects another shop or cashier before Stripe
PASS cancelPayment rejects another shop or cashier before Stripe
PASS cancel stops the matching reader action before canceling the intent and is idempotent
PASS cancel never cancels a processing intent
PASS cancel never cancels a succeeded intent
PASS cancel does not interrupt a different reader action
PASS cancel action failure preserves reservation and never cancels the intent
PASS controller takes identity from auth and whitelists body fields
PASS controller rejects service-point sessions and sanitizes unexpected errors
PASS cashregister authorization rejects staff without permission and allows permitted staff
PASS every cashier Terminal route binds authentication and cashregister authorization
PASS cashregister authorization sanitizes database errors
PASS polling a failed reader action cancels its intent and returns a safe failure
PASS polling does not mistake a waiting customer for a failed payment
PASS cancel requires Stripe to confirm action cancellation before canceling the intent
PASS cancel reconciles a success racing with intent cancellation
PASS creating sessions cannot be canceled while the start request owns the Stripe handoff
PASS success reconciliation rejects a mismatched amount without marking orders paid
PASS shop lookup does not require a second pool connection while a reservation transaction is open
PASS a process timeout after handoff stops the reader before releasing the reservation
PASS failure to save the intent never hands an untracked payment to the reader
PASS a paid intent discovered during process cleanup is finalized without cancellation
PASS default controller wires reservation SQL to one transaction connection and commits before Stripe
stripe terminal payment tests passed (79 tests)
PASS gets the active reader assigned to this kiosk service point
PASS starts one kiosk order and one Terminal PaymentIntent on the assigned reader
PASS replays the same client order token without creating a second PaymentIntent
PASS rejects a kiosk start when the assigned reader has another active payment
PASS reconciles a canceled active reader payment before starting a kiosk payment
PASS cleans a stale cancelable kiosk reader payment before starting a new one
PASS cleans a stale kiosk preparation without a Stripe intent before starting a new one
PASS polling expires a kiosk terminal payment after thirty seconds
PASS reader lock timeout cancels the kiosk intent and falls back to counter payment
PASS success reconciliation marks the kiosk order paid and exposes only safe card-ticket fields
PASS failed reader action leaves the kiosk order payable at the counter
PASS explicit kiosk cancel cancels the Terminal payment and removes the prepared order
stripe terminal kiosk payment tests passed (12 tests)
Loaded env file: NUL
PASS browser-independent success finalizes linked orders once under duplicate delivery
PASS reader and stale failure events before or after success never finalize or regress payment
PASS unrelated events fall through and malformed Terminal metadata cannot reach web handlers
PASS success validates tenant, persisted intent, amount, currency and succeeded status
PASS DB contention retries only transactions and failed commits stay retryable
PASS controller dispatches Terminal metadata first and keeps raw-body signature verification
stripe terminal webhook tests: 6/6 passed
Loaded env file: NUL
PASS shop order listing exposes only paid successful linked allocations without payment-owner access
PASS archive listing exposes safe Terminal card ticket fields for history receipts
PASS archive fields preserve Terminal identity and never recollect or change its method
PASS archive failure leaves payment paid; retry preserves allocation and cannot charge again
ON archive : 12
ON archive : 12
PASS Terminal archive controller bypasses web synchronization and rejects unpaid links
PASS refund uses successful shop/order/payment allocation and a stable key, never group total
PASS refund survives local persistence failure and timeout without creating another refund
PASS pending and failed refunds do not report refunded or expose provider errors
PASS refund rejects foreign shops, unsuccessful sessions, missing allocation and archive races
PASS existing refund endpoint branches only for a linked Terminal order
PASS asynchronous Terminal refund webhooks reconcile without browser or legacy refund handlers
PASS zero-cent allocations complete locally without a Stripe refund
PASS archive without line details still preserves the successful allocated amount
PASS refund state SQL remains scoped and monotonic and retries DB contention only
PASS refund pagination recovers its own allocation without refunding another grouped order
PASS malformed or mismatched Stripe refund snapshots never trigger another refund or mark refunded
PASS default refund lookup preserves eligible web orders without an extra Terminal lookup
PASS round1 authoritative failure of the same refund corrects local success to paid
PASS round1 failed or canceled refund advances generation and creates a new exact allocation refund
PASS round1 delayed pending creation response cannot overwrite webhook failure or block archive
PASS round1 old generations and mismatched refund IDs cannot undo the current refund
PASS round2 creating/pending observer stays pinned when failure arrives before reservation
PASS round2 two failed observers advance once and issue exactly one Stripe creation for g2
PASS round2 a caller observing g2 creating cannot duplicate its in-flight Stripe creation
PASS round2 stale failed observer cannot take over a newer ambiguous generation after its owner exits
PASS round2 reservation compares the exact observed terminal status as well as generation
PASS round3 a cross-instance loser waits before g2 exists and returns the committed g2
PASS round3 genuine lock timeout is retryable busy, never a stale failed refund or provider error
PASS round3 Terminal refund endpoint exposes only sanitized retryable busy fields
PASS round1 delayed pending retrieval cannot undo a confirmed failure
PASS round1 ambiguous outcomes retain their generation and persisted refund identity
PASS round1 destination ownership is verified against the persisted connected account
PASS round1 missing or mismatched retrieval identity never creates another refund
stripe terminal refund/archive tests: 33/33 passed
Loaded env file: NUL
PASS production: malformed JSON is sanitized; valid QR JSON and raw webhook are preserved
PASS development: malformed JSON is sanitized; valid QR JSON and raw webhook are preserved
JSON body error tests passed (production and development)
shop theme tests passed
shop theme backend contract tests passed
Loaded env file: NUL
table access token tests passed
Loaded env file: NUL
table access controller tests passed
Loaded env file: NUL
service point access token tests passed
Loaded env file: NUL
service point session auth tests passed
shop service point initialization contract passed
Loaded env file: NUL
transaction helper tests passed
database readiness tests passed
vat tests passed
vat migration contract passed
discount tests passed
receipt shop settings tests passed
service points migration contract passed
Loaded env file: NUL
service points controller tests passed
service point order display contract passed
service point cash register detail contract passed
Loaded env file: NUL
ON archive : 42
stripePayment tests passed
order detail stock tests passed
cashRegisterPayment tests passed
cash closure helper tests passed
payment method standardization tests passed
order metrics revenue series tests passed
payment method migration tests passed
customization rule tests passed
Loaded env file: NUL
customization choice propagation tests passed
stock requirements tests passed
stock inventory domain tests passed
stock inventory migration tests passed
Loaded env file: NUL
stock inventory controller tests passed
stock inventory module tests passed
Loaded env file: NUL
stock authorization tests passed
Loaded env file: NUL
product stock mutation tests passed
Loaded env file: NUL
product stock tracking tests passed
Loaded env file: NUL
click and collect products tests passed
customization migration contract passed
customization verifier contract passed
reservation lifecycle tests passed
Loaded env file: NUL
counter checkout payment mode tests passed
Loaded env file: NUL
customization and checkout contracts passed
Loaded env file: NUL
DELETE orders 42
DELETE orders 43
order delete hidden archive contracts passed
Loaded env file: NUL
order attribution archive tests passed
Loaded env file: NUL
order attribution transition tests passed
staff credential tests passed
staff module permission tests passed
staff login contract tests passed
admin email login tests passed
admin legacy password login tests passed
UNIT CONTINUATION commands=62 failures=0
```

## Original Scope Final Checkpoint

- Original registered SQL command, all filters cleared: `npm.cmd run test:delivery:db`, exit0, all7 registered commands completed, including16 courier-cash groups. Raw output: `task-7-delivery-db.txt`.
- Final narrowed actual default clock observation (connection-query forwarding proxy, no postingTime substitution): `TASK7_FILTER='production DB UTC'; node test/courier-cash.integration.test.js`, exit0,1 group. Raw: `task-7-actual-default-clock-final.txt`. This fixture-only refinement happened while the prior registered command was in flight; production code was unchanged and its actual default method is covered by this final narrowed run.
- Syntax: `node --check` on all10 changed/new JS files, exit0. `git diff --check` and staged check exit0; only existing LF/CRLF notices.
- Scoped original commit: `5ffaf4a0e5fd64e1f03726a240c25e2b4a14bfd1`, `feat: reconcile courier cash with cashier handovers`;12 files,786 insertions/20 deletions. `git -c core.hooksPath=.git-hooks-disabled-task7 commit ...`, exit0. B status empty immediately afterward; persistent `core.hooksPath` remained `.githooks`.
- Original whole `npm.cmd test` failure and supplemental62-command pass remain exactly as reported above; this checkpoint does not claim a single passing whole unit command.

## Controller-Approved Bounded Completion

The amended Task7 brief now authorizes the exact fixture injection, shared nullable-role guard, focused manual-refund producer/migration/test, and existing cash/closure/delivery adapter integration. This completion supersedes the earlier proposed ownership gaps when verified; the original source-confirmed findings and raw evidence above are intentionally retained. No fresh agent/reviewer, shared-ledger edit, provider operation or unapproved file expansion.

Additional files: `src/modules/m_deliveryRefunds.js`, `db/migrations/20261016122000_delivery_manual_refunds.sql`, `test/delivery-refunds.integration.test.js`; exact approved fixture maintenance and malformed-role regressions in `test/delivery-authorization.test.js`; one null/undefined DB-access rejection in `src/helpers/middleware/auth.js`. Already-owned cash, closure, delivery controller/router and package are extended. `m_payments.js`, provider refunds and other routes are unchanged.

### Completion Contract

`buildDeliveryRefunds({repository?,runInTransaction?,clock?}).refund({actor,deliveryId,returnSource,reason,idempotencyKey})` and POST `/deliveries/:id/refund` with EXACT body `{returnSource,reason,idempotencyKey}`. Current active same-shop admin or delivery-enabled cashier only. No client amount/payment/order/actor/physical-user/partial-fee fields. Returned financial DTO:

```text
{refundId,deliveryId,collectionId,paymentId,amountCents,method,
 returnSource,physicalHolderId,authorizedById,reason,createdAt,
 confirmation:'restaurant_declaration',providerVerified:false}
```

All new IDs are decimal strings, including >2^53; legacy IDs remain integers. Amount is the FULL immutable collection/payment/accepted grand total including fee. `cash` permits `courier|register`; `external_card` permits only `external_card`. Courier physical holder is the ORIGINAL immutable collection holder, independent of assignment/current role/status. Register holder is the current authorizer; external-card holder is null. A promoted holder cannot authorize their own courier-funds return. External-card confirmation explicitly declares the independent TPE refund was performed; it is never Stripe/provider verification. Nothing sends money or contacts a provider.

Source is reloaded from the actual immutable collection, original active/archive commercial representation/current charge and actual manual succeeded payment; provider/pending/unsupported/mismatched/already-refunded sources refuse. The immutable refund record authorizes the financial change. A claimed refunded header, reason or client holder is not proof. Same key/payload replays after current actor authorization; changed source/actor/reason conflicts. A new key cannot refund an already-refunded original payment.

`delivery_manual_refunds` has unique original payment and shop/key, full source composite FK (shop/delivery/payment/collection/original courier/method/full amount), authorizer/physical-holder FKs, source/money/reason checks, UTC6 and append-only triggers. `courier_cash_refund_impacts` uniquely references each confirmed refund with an exact matching immutable source FK and source-dependent due-reduction constraint. The only added parent index supports this FK; historical migrations/data/triggers remain untouched.

Lock order: shop barrier FIRST -> original commercial/archive -> dossier/current charge -> immutable source identity read -> sorted current actor/original-holder account locks -> source payment current lock. Replay/source reads do not take missing-journal gap locks. Same transaction inserts confirmed refund, marks actual commercial payment_status/refunded and payment status/refund_status using existing financial semantics, then invokes cash integration on the SAME connection. Legacy Stripe refund ID stays null; no fake provider refund identity. Preparation/logistics/version/stock/address/charge/sale totals remain unchanged. Any late failure rolls back refund, commercial/payment and cash journals together; no global retry.

Internal `buildCourierCash().applyConfirmedRefund({shopId,refundId,connection})` requires a caller connection, takes/reuses the shop barrier, LOADS immutable confirmed refund + actual collection/payment/holder, verifies full source and refunded manual-payment state, and deduplicates by exact refund ID. It accepts no claimed amount/holder as proof. Full courier return reduces only that source's still-due cash; insufficiency after remittance or write-off yields409 `DELIVERY_REFUND_CUSTODY_INSUFFICIENT`, with every preceding financial write rolled back. Register return remains available and leaves courier due untouched. External-card return has zero cash impact. Positive admin restoration capacity excludes already confirmed courier-return reductions, so it cannot recreate that refunded debt.

### Consumer Fields

Balance/version now includes confirmed refund events. New totals: `refundedCents`, `courierRefundedCents`, `registerRefundedCents`, `externalCardRefundedCents`; source collections include `refundedCents` (custody reduction, courier source only); financial `refunds[]` includes `{refundId,collectionId,method,amountCents,returnSource,dueReductionCents,createdAt}`. Expected balance version changes on each confirmed event, including zero-cash register/external declarations.

New stored closure `courier_cash` adds `manual_refunded_cents`, `cash_refunded_by_courier_cents`, `cash_refunded_by_register_cents`, `external_card_refunded_cents`, `refunds_count`. All are (lastClosedAt,closedAt] POSTING flows. Only register-return cash is drawer OUTflow. Courier-return cash reduces original-holder debt without a drawer movement. External-card declaration has zero cash flow. Running outstanding includes earlier debt and confirmed courier returns as of cutoff. Refund-only financial periods may close with orders_count/revenue0 and no fake sale/VAT. Prior stored JSON is not augmented/recomputed: absent refund fields on old snapshots mean unavailable historic breakdown, not a live recalculation.

Task13 should display explicit full-return choices/reason/manual confirmation, handle source insufficiency and refresh authoritative delivery/payment + cash balance after success. Task15 should preserve original sale/fee/VAT documents, expose payment_status/refunded, and read posting-period stored refund flows without inferring custody/outflow from a current header. Existing provider refund UI/API paths remain distinct.

### Completion Evidence

Every SQL invocation uses the same explicit disposable URL, ENV_FILE=NUL, JWTKEY and PUBLICIMAGEPATH setup recorded above. Focused refund selection is `TASK7_REFUND_FILTER`; final whole commands clear it AND TASK4_TEST_FILTER/TASK5_REVIEW_FILTER/TASK7_FILTER. Raw logs remain in this scratch directory; only relevant lines/exits/counts are appended below.

- Auth RED: `node test/delivery-authorization.test.js`, exit1, actual200 vs403 at malformed DB role GET /reports/z/current after exact fixture injection. Raw `task-7-completion-auth-red.txt`.
- Auth GREEN after one `user.access == null` guard: same command, exit0; all existing assertions retained, null/undefined current-role HTTP checks cover four Z and new delivery cash/refund surfaces. Raw `task-7-completion-auth-green.txt`.
- Refund RED: `TASK7_REFUND_FILTER='HTTP real full'; node test/delivery-refunds.integration.test.js`, exit1, actual POST404 vs200. Raw `task-7-refunds-red.txt`.
- Initial focused GREEN: same file with filters `HTTP real full`, `register refund after archive`, `late failures`, each exit0/1 group. Raw `task-7-refunds-focus-0.txt`, `task-7-refunds-focus-1.txt`, `task-7-refunds-focus-2.txt`. Actual collection/refund/archive/rollback paths, not a pre-marked source fixture.

Focused completion runs use `node test/delivery-refunds.integration.test.js`; set selection with `$env:TASK7_REFUND_FILTER='<Filter>'`. Node18 uses the exact executable command:

```powershell
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-refunds.integration.test.js
```

| Filter / Runtime | Exit | PASS / FAIL Groups | Retained Raw Log |
| --- | --- | --- | --- |
| Unfiltered focused file / Node22, intermediate14-group version | 1 | 12 / 2 | task-7-refunds-green-attempt.txt |
| HTTP real full / Node18, first attempt | 1 | 0 / 1 | task-7-refunds-node18-http.txt |
| HTTP real full / Node18, isolated final | 0 | 1 / 0 | task-7-refunds-node18-http-final.txt |
| fully remitted / Node22 | 0 | 1 / 0 | task-7-refunds-fully-remitted.txt |
| refund migration / Node22, corrected fixture | 0 | 1 / 0 | task-7-refunds-migration-final.txt |
| register refund after archive / Node22, including later actual handover | 0 | 1 / 0 | task-7-refunds-register-final.txt |
| concurrent / Node18, same/different-key races and exact BIGINT | 0 | 2 / 0 | task-7-refunds-node18-concurrent.txt |

Intermediate failures are retained, not counted as GREEN: the native register-refund case and first Node18 HTTP run raised `Can't add new command when connection is in closed state` in the shared disposable helper's `admin.end()` cleanup. Origin was not established; container remained up and explicit local server inspection showed wait_timeout28800. No production/shared-helper retry, timeout or server restart change was made. The affected cases subsequently passed in isolation. The other intermediate failure was the new migration fixture calling JSON.parse on mysql2's already-parsed object (`[object Object] is not valid JSON`); fixture now handles the driver's object/string forms and serializes a deliberately foreign cloned JSON row before testing FK refusal. That correction passed actual up/down/up plus append-only/FK assertions.

Final whole-command environment and filter clearing (performed independently for each command):

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task7-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task7-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
Remove-Item Env:TASK4_TEST_FILTER,Env:TASK5_REVIEW_FILTER,Env:TASK7_FILTER,Env:TASK7_REFUND_FILTER -ErrorAction SilentlyContinue
npm.cmd test
```

Final `npm.cmd test`: exit0, ALL63 registered unit commands in ONE invocation, including the repaired original authorization fixture and retained provider/refund/stock/payment contracts. Raw `task-7-completion-npm-test.txt`; final line `admin legacy password login tests passed`. This is the new whole-command PASS, distinct from the earlier failed invocation and62-command continuation.

Final source syntax: `node --check` on all14 changed/new JavaScript files, exit0; `git diff --check`, exit0 (existing LF/CRLF notices only). No implementation changes after these final whole commands began.

Author self-review covered current-DB authorization, source/physical-holder identities, full fee-inclusive amount, FK types and exact BIGINTs, barrier/clock ordering, replay and immutable proof on the caller connection, no negative/duplicated custody, active/archive linkage, rollback phases, zero-cash external-card declaration, later handover after register refund, old JSON preservation, and separate posting/sale axes. No independent review was dispatched; controller owns the full-range review.

## Completion Final Result

COMPLETE for author implementation/self-review; ready for controller full-range independent review. The original fixture, confirmed manual-refund producer and nullable-role ownership gaps are now implemented and verified in the approved follow-up. The old Stripe-only refund controller remains unchanged and intentionally is not the manual-refund route. No open Task7 ownership proposal remains.

- Final whole SQL command with the complete environment/filter clearing above: `npm.cmd run test:delivery:db`, exit0. ALL8 registered commands completed in ONE invocation, including all16 courier-cash and all16 manual-refund groups, both additive migration regressions, existing provider/payment/archive/dispatch and real concurrency/rollback suites. Raw `task-7-completion-delivery-db.txt`; final line `PASS SQL queued confirmed courier return posts after closure cutoff and freezes prior debt snapshot`. No suffix aggregation or filtered SQL command substitutes for this final PASS.
- Final whole unit command: `npm.cmd test`, exit0,63 registered commands; raw `task-7-completion-npm-test.txt`. Final native Node22 code was unchanged between these whole commands and commit.
- Compatible Node18 completion SQL:3 groups (actual refund HTTP + same/different-key concurrent refunds with exact BIGINT), exit0; raw `task-7-refunds-node18-http-final.txt`, `task-7-refunds-node18-concurrent.txt`. Original-scope Node18 cash evidence above adds3 more groups. Real installed Nano ID fixture bridge retained; no production/runtime/dependency shim or unbridged Node18 boot claim.
- Follow-up commit: `a0a135fd501cb734f409eb71fb55bf5ff988cb64`, `feat: confirm manual delivery refunds and cash custody`;10 files,671 insertions/13 deletions. Command `git -c core.hooksPath=.git-hooks-disabled-task7 commit -m 'feat: confirm manual delivery refunds and cash custody'`, exit0, after explicit10-file staging and staged whitespace check0.
- Original commit retained: `5ffaf4a0e5fd64e1f03726a240c25e2b4a14bfd1`. Review range: `39f116934f9873eef70fd56836799493b6100467..a0a135fd501cb734f409eb71fb55bf5ff988cb64`.
- Post-commit `git status --short` in B and `git -C ../pos-app status --short`: both empty, exit0. Persistent `git config --get core.hooksPath` is still `.githooks`. Scratch reports/raw logs remain ignored F artifacts; no frontend source commit.

Remaining practical concerns are explicit, not unfinished ownership: closure sessions must be UTC (non-UTC fails rather than reinterpreting historic boundaries); production config/history was not inspected. Independent-TPE refunds are restaurant declarations, never provider-verified or actual provider operations. The earlier disposable cleanup connection failures remain in raw evidence with unconfirmed origin; their affected paths and final single whole SQL invocation passed without retry/helper/server changes. Existing unbridged Node18/production Node20 commissioning remains Task17 scope. No remote DB, real env/decryption, provider sends, printing, push/deploy/merge, original-checkout edits or independent reviewer occurred.

## Fix Round1: Review I1 Only

Replacement fixer on B `feat/delivery-v1`, starting at exact `a0a135fd501cb734f409eb71fb55bf5ff988cb64`, preserving `5ffaf4a` and `a0a135f`. Read brief top I1 ruling first, worker context, review I1 verbatim and applicable contracts, then original/superseding report contracts without reloading raw original logs. workspace_fs denies these worktrees; used the documented shell fallback. No subagent/reviewer or original-checkout edit.

Files: B `src/modules/m_cashClosures.js`, authorized optional `src/modules/m_deliverySettings.js`, and owned `test/courier-cash.integration.test.js` only. The unconditional UTC refusal caused ordinary Z HTTP500. Under the existing shop barrier, the default closure clock now preserves session CURRENT_TIMESTAMP(6). On a non-UTC connection it refuses explicitly with `Delivery financial summaries require a UTC database session` only when that shop is enabled OR has ANY persisted collection (cash or external_card), remittance, adjustment or confirmed manual refund. Existence checks have no date/debt/status cutoff; allocations/refund impacts require these source parents. Disabled/missing settings do not hide accepted history, settled debt or future-dated UTC journal rows. Actual history is never replaced with a synthetic zero summary. UTC session/UTC6 posting, injected test clocks, fullprecision comparisons and physical-only periods retain their contracts.

Every settings save requesting enabled=true now checks CURRENT_TIMESTAMP(6)=UTC_TIMESTAMP(6) on the SAME locked write connection before INSERT/UPDATE/DELETE, returning DomainError503 `DELIVERY_UTC_SESSION_REQUIRED` on refusal. No settings/revision/band write occurs, including first activation without a settings row. Disabled saves remain available on non-UTC; supported UTC saves keep normal revisions. Normalize SQL flags numerically: the actual BIGINT-string fixture returns `utc_ready:'0'`, which is truthy in JavaScript.

New actual SQL/HTTP regressions cover missing and disabled settings, current active cashier/cashregister authorization despite an admin JWT claim, session +02:00 across midnight, lower-exclusive/upper-inclusive six-digit bounds with distinct excluded-sale amounts, default CURRENT archive time, stored closure bounds and unchanged old closure/archive rows. The former blanket-refusal test now specifically asserts actual financial-history refusal (also after settings deletion) while retaining the production UTC queued .500123/.500124 proof. Additional coverage includes enabled/no-history refusal, disabled/no-history success, external-card history refusal and no-write activation readiness.

This supersedes ONLY the prior report's blanket UTC closure prerequisite: ordinary disabled/missing-settings shops without delivery financial history retain their historical session basis. No production SET time_zone, history rewrite, schema migration or transition engine. A current UTC readiness check DOES NOT prove old naive DATETIME history was UTC; commissioning must audit/reconcile any actual historical basis change before enabling delivery. No real environment/history inspection was performed. Immutable financial source proof, privacy, historical snapshots and M1 diagnostics are unchanged; M1 remains deferred.

Commands below run from B. Common SQL/HTTP fixture environment (explicit disposable URL; no application DB fallback):

```powershell
$env:ENV_FILE='NUL'
$env:JWTKEY='task7-disposable-signing-fixture-only'
$env:PUBLICIMAGEPATH='http://127.0.0.1/task7-fixture/'
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
```

Each invocation uses the existing capture form `*> ../pos-app/.superpowers/sdd/2026-10-16-delivery-management/<log>`, then `$task7Exit=$LASTEXITCODE; Get-Content <log>; exit $task7Exit`. All raw names below are in that SAME scratch directory. Native node=v22.13.1; Node18 executable is `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe` (v18.20.8). Existing fixture-only actual Nano ID import-cache bridge is retained; no runtime/dependency fix claimed.

| Command/selection | Exit and relevant evidence | Raw log |
| --- | --- | --- |
| `$env:TASK7_FILTER='non-UTC'; node test/courier-cash.integration.test.js` initial | 1, ECONNREFUSED before assertions. Docker Desktop was stopped; started it hidden, verified named disposable mysql:8.0.33 container/loopback33319 mounts and started only that container. | `task-7-fix-round1-red.txt` |
| Same selection, actual SQL RED | 1, ordinary missing/disabled HTTP500 vs200; activation wrongly accepted; old refusal message generic. Extra enabled fixture initially violated activation CHECK. | `task-7-fix-round1-red-sql.txt` |
| `$env:TASK7_FILTER='requirement covers'; node test/courier-cash.integration.test.js` after valid activation fixture correction | 1, disabled/no-history preview still wrongly refused. | `task-7-fix-round1-red-fixture-corrected.txt` |
| `$env:TASK7_FILTER='non-UTC'; node test/courier-cash.integration.test.js` first fix attempt | 1, four groups PASS (including both ordinary HTTP cases and UTC queue), activation still accepted because SQL string zero was truthy. Corrected flag normalization. | `task-7-fix-round1-green-sql.txt` |
| Read-only explicit disposable mysql2 clock diagnostics, default parser then supportBigNumbers/bigNumberStrings | Both 0; same +02 SQL equality returns numeric0 vs string'0'. Diagnostic scripts/outputs retained in tool evidence; no app config loaded. | `task-7-fix-round1-readiness-diagnostic.txt`, `task-7-fix-round1-readiness-bigint-diagnostic.txt` |
| `node test/cash-closure.test.js` (ENV_FILE=NUL) | 0, original helper precision/closure contracts; repeated after final code change, also 0. | `task-7-fix-round1-cash-unit.txt`, `task-7-fix-round1-cash-unit-final.txt` |
| `node test/delivery-quotes.test.js` (fixture environment above) | 0, settings/quote unit, HTTP roles/privacy/lazy boot; final rerun 0. | `task-7-fix-round1-quotes-unit.txt`, `task-7-fix-round1-quotes-unit-final.txt` |
| `node test/delivery-quotes.test.js --database` | 0, actual atomic settings/revision/rollback and existing quote-related SQL; final rerun after flag correction 0. | `task-7-fix-round1-quotes-sql.txt`, `task-7-fix-round1-quotes-sql-final.txt` |
| `$env:TASK7_REFUND_FILTER='queued confirmed'; & 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-refunds.integration.test.js` | 0, queued confirmed UTC courier return posts after cutoff and freezes old debt snapshot; final rerun after flag correction also 0. | `task-7-fix-round1-queued-refund-node18.txt`, `task-7-fix-round1-queued-refund-node18-final.txt` |
| `node --check` individually on all three modified JS files; `git diff --check` | All 0; only existing LF/CRLF notices. `git diff --cached --check` also 0 after explicit three-file staging. | `task-7-fix-round1-syntax.txt` (syntax/unstaged check); staged check in tool evidence |

No whole npm test63-command or registered SQL8-suite rerun; original successful evidence remains above. Final modified-file SQL result, scoped commit and final worktree checks follow below. Author self-review checked shop-scoped/unbounded source existence, barrier placement, numeric flag parsing, same-connection prewrite readiness, ordinary bounds, unchanged source journals/privacy/snapshot reads and exact three-file ownership. Independent I1 fix-diff review remains the controller's responsibility.

Fix Round1 final result: implementation/self-review COMPLETE, ready for controller SCOPED I1 rereview of `a0a135f..8cd5567` only.

- Final modified cash SQL command, with common fixture environment above: `Remove-Item Env:TASK7_FILTER -ErrorAction SilentlyContinue`, then `& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/courier-cash.integration.test.js`, exit0, ALL20 groups in ONE invocation. Raw `task-7-fix-round1-cash-sql-node18.txt`. Includes all16 original cash groups, both UTC microsecond queue variants, all4 new I1 regressions, immutable old snapshots/source proof, migration up/down/up, HTTP privacy/current roles and four Z boundaries. All final runs used the final source; no code edits after they began.
- Scoped commit `8cd556726e9029b1e38e3b94070ff390f3022a12`, `fix: preserve ordinary Z closures on non-UTC sessions`; three files,152 insertions/11 deletions. Exact command `git -c core.hooksPath=.git-hooks-disabled-task7-fix-round1 commit -m 'fix: preserve ordinary Z closures on non-UTC sessions'`, exit0. Previous `a0a135f` and `5ffaf4a` remain immediate ancestors. Persistent `git config --get core.hooksPath` still `.githooks`.
- Post-commit B `git status --short --branch` shows only `## feat/delivery-v1`; F `git status --short` empty; both exit0. `git diff --name-only a0a135fd501cb734f409eb71fb55bf5ff988cb64 HEAD` confirms exactly the three files above. Scratch report/logs remain ignored frontend artifacts.
- Concerns: historical time-basis commissioning audit/reconciliation remains mandatory before delivery activation; UTC readiness alone cannot establish old DATETIME provenance. M1 remains deferred. No indispensable scope gap, real env/decryption, real data inspection, provider send/payment, remote action, push/deploy/merge, global/session timezone change in production or independent reviewer.
