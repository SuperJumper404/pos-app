const path = require('path')
const { pathToFileURL } = require('url')
const { createRequire } = require('module')
const fromBackend = createRequire(path.join(process.cwd(), 'package.json'))
;(async () => {
  const installed = fromBackend.resolve('nanoid')
  require.cache[installed] = { exports: await import(pathToFileURL(installed).href) }
  require(path.resolve(process.cwd(), process.argv[2]))
})().catch(error => { console.error(error); process.exitCode = 1 })
