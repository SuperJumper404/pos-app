# Delivery V1 Worker Context

## Paths and authority

- F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
- B = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
- Scratch = F/.superpowers/sdd/2026-10-16-delivery-management
- Read your task-N-brief.md first; exact numbers/signatures/test scenarios live there. Read common contracts in F/docs/superpowers/plans/2026-10-16-delivery-management.md and applicable sections of F/docs/superpowers/specs/2026-10-16-delivery-management-design.md. Do not load other task plans wholesale.
- User approved implementation with fresh workers and controller-dispatched independent task reviews. Never spawn subagents/reviewers. Never push, deploy, merge shared branches, migrate remote DBs, contact real recipients, or decrypt real environment secrets.
- User expressly confirmed preparation WITHOUT actual email/WhatsApp sends for now. Stub provider HTTP boundaries; actual code receipt/verification is commissioning work, not a success to claim locally.
- Shared filesystem: edit only task-owned files in named worktrees. Do not edit original checkouts, ledger, or other tasks. Manual edits use apply_patch. workspace_fs primarily for original repo exploration; it denies external paired worktrees, use shell reads there.
- Every task TDD RED/GREEN, covering regression tests, self-review and scoped commit. Report full evidence to scratch/task-N-report.md; short final status/commits/tests/concerns/report path only. Controller owns reviews.

## Compatibility and security

- Nuxt2/Vue2/Vuetify/Vuex/Axios and Express routers/controllers/modules, Node18-compatible code (local Node22). Keep changes targeted.
- New IDs BIGINT UNSIGNED strings, legacy FK types copied, safe integer cents internally and legacy euro API compatibility. New text UTF8MB4. New config lazy so disabled feature never breaks historical POS boot.
- No provider secrets in Nuxt, commits, logs, examples. Never expose OTP, tracking token, or entry instructions in logs.
- Delivery payment and preparation separate; no second payment state in delivery. Active/archive durable linkage, fee not fake product. One sale, one stock movement, immutable financial/address snapshots.
- Idempotent/replay-safe mutations, optimistic version and transactional locks; same key/different payload conflict. No automatic refund/restock on logistical issue.
- Staff/customer/service point distinct. Role6 courier denied legacy staff APIs centrally; customer context never overwrites staff context. New permission delivery. Historical categories/product steps/stock remain hidden from main menu.
- Guest checkout always possible. Email/WhatsApp login OTP only, no SMS and no delivery progress notifications. Independent external courier TPE is manual declaration, never Stripe-verified.

## Local validation

- Disposable Docker container smarteat-delivery-v1-tests, MySQL8.0.33, loopback33319, no project data volumes.
- PowerShell each SQL command explicitly sets DELIVERY_TEST_DATABASE_URL to mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql. This password is a local test fixture only. Harness must create/drop only random smarteat_delivery_test_* databases, never supplied catalog.
- npm.cmd on Windows. Dependencies installed isolated; B bcrypt rebuilt. Baseline B npm test PASS; F npm test PASS; F lint 0 errors/151 old warnings and stale Browserslist. Preserve F pretest image-library.
- SQL suite test:delivery:db explicit; no silent skips or app DB fallback. Unit tests npm test no SQL/provider requirement. Real OTP supplier validation remains external prerequisite unless approved test destinations/config available.
- Original frontend dev process exists: do not kill it. Choose free port for isolated UI server.
- Original backend compose uses node:20-alpine, MySQL8.0.33. Native local22 works. PlainNode18 legacy m_orders require(nanoid) fails ESM; Task3 uses real-dependency import-cache bridge only for Node18 actual-handler tests (see task3 report). Do not claim productionNode18 boot fixed or broaden dependency modernization. Task17 validates configured Node20 directly without bridge.

## Frontend design when applicable

- Existing PRODUCT.md/DESIGN.md established world, restrained Operate mode: Poppins/MDI, existing semantic tokens and Vuetify controls, dense scan-friendly layouts, 44px important touch targets. Four operator views already approved. No new visual identity exercise, marketing page, global redesign, or context artifact cleanup.
- Impeccable context already run once successfully by controller. Read skill reference/craft-floor.md immediately before UI edits; new-work/operate apply as extensions of established world. Controller runs final detector once and captures desktop/mobile review evidence. Do not spawn nested design reviewers.
- Existing context drift (obsolete Product Register/schema/stale sidecar) is out of scope; do not repair.
