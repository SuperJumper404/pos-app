# Task 8 implementation report

Status: implementation and author self-review complete; independent review belongs to the controller.
Backend branch: `feat/delivery-v1`; verified starting HEAD/BASE: `8cd556726e9029b1e38e3b94070ff390f3022a12`.
Commit: `b8e62b5c2194c7859473b6c6678e676b7923e670` (`feat: add verified customer identities and address book`). Backend worktree clean after commit.

## Scope and files

All backend changes are in `../express-pos` relative to the named delivery-v1 frontend worktree. No original checkout or real environment file was read/edited, and no ledger or other task implementation was edited. Existing delivery sources were read for their contracts and patterns. No subagent/reviewer, provider account operation/send, remote DB operation, push, deployment or merge ran. `workspace_fs` refused these paired worktrees; shell reads followed the worker-context fallback.

| File in B | Result |
| --- | --- |
| `db/migrations/20261016130000_delivery_customers.sql` | Five customer tables, tenant-compatible FKs on the three Task1 customer links, reversible schema. |
| `src/helpers/customerIdentity.js` | Email domain lowercase/IDN only, mailbox case/dots/aliases preserved; strict international WhatsApp E164 normalization. |
| `src/modules/m_customers.js` | SQL repository, staff profile creation/search, transactional owned address book and stored-address proof renewal. |
| `src/controllers/c_customers.js` | Staff adapters, fresh-account authorization, field allowlists, sanitized DomainError responses and no-store results. |
| `src/routers/r_customers.js`, `index.js` | Staff-only routes under existing API prefix. |
| `test/customer-identity.test.js` | Three pure test groups with literal valid/invalid destinations. |
| `test/customer-addresses.integration.test.js` | Nine actual SQL/HTTP functional groups and a populated migration rollback test. |
| `test/helpers/deliveryDatabase.js` | Only customers 51/52 for shops 7/8 in nonlegacy seed and returned string fixture IDs; legacy seed and dynamic migration discovery retained. |
| `package.json`, `package-lock.json` | One backend dependency and pure/SQL test registration, preserving every old command verbatim. |

`libphonenumber-js@1.13.15` (range `^1.13.15`) supplies `/max`, `extract:false`, `isValid()` and extension rejection. No reliable parser existed. Installation used `npm.cmd install libphonenumber-js --save --registry=https://registry.npmjs.org --ignore-scripts --no-audit --no-fund`, exit 0; only one package added. No global npm configuration changed. Primary reference checked: https://github.com/catamphetamine/libphonenumber-js ; controller phone evidence: `customer-provider-evidence.md`. One old Singapore example is now valid in current metadata; negative fixtures use numbers observed possible in `/min` but invalid in `/max` (`+33700000000`, `+5511555555555`).

## Interfaces and consumers

`normalizeCustomerDestination({channel,value,countryCode}) -> string` throws `CUSTOMER_DESTINATION_INVALID` (422). Email supports unquoted ASCII mailboxes with IDN domains; it does not collapse local case, dots or aliases. WhatsApp requires a valid entire number; national input requires a supported countryCode. SMS, prose extraction, extensions, malformed values and control characters are rejected.

`buildCustomers({repository,runInTransaction,clock?,tokenCodec?})` and `buildSqlCustomersRepository({pool?})` are exported. Shop IDs retain legacy integers; customer/address IDs are canonical unsigned BIGINT decimal strings. All SQL ID projections use CAST; each insert reads `CAST(LAST_INSERT_ID() AS CHAR)` on the same transaction connection, including when mysql2 uses production numeric defaults.

- `createProfile({shopId,name?,contactPhone?,contactEmail?}) -> {id,shopId,name,contactPhone,contactEmail}` requires at least one nonblank field. These are unverified delivery contacts, with no identity insertion, order claim or historical phone-group ownership.
- `searchProfiles({shopId,query?})` returns at most 50 profiles, newest first; a literal substring of profile name/contact fields only, scoped to the shop. LIKE wildcards are escaped. No historical order lookup.
- `listAddresses({shopId,customerId}) -> [{id,customerId,label,isDefault,addressSnapshot}]`, ordered by monotone label number.
- `saveAddress({shopId,customerId,addressId|null,addressResolutionToken?,complement?,instructions?,makeDefault?})` returns that address DTO. A new or changed postal destination needs a fresh valid Task2 proof. Existing rows permit private complement/instructions/default edits without geocoding. The entire signed postal/provider/precision/coordinates snapshot is persisted. Customer locks serialize label allocation/default changes. Initial address becomes default; `makeDefault:true` selects it; false never unsets an existing default.
- `deleteAddress({shopId,customerId,addressId}) -> {id}` moves a deleted default to the oldest surviving label or null, without resetting counters or renumbering.
- `resolveStoredAddress({shopId,customerId,addressId}) -> {addressSnapshot,addressResolutionToken,expiresAt}` reloads the owned row and calls the EXISTING `deliveryAddress.signAddressResolution`. It issues a new 15-minute Task2-shaped proof, without using original proof expiry, client coordinates, any geocoder or duplicated signing implementation. It includes current private fields. Task10 can adapt the same service using only verified session customer/shop and requested addressId; Task11/12 can use the staff adapter below.

Staff adapters: `buildCustomersController({customers?})`, `buildCustomersRouter({controller?,authentication?})`. Routes relative to the existing prefix:

| Method | Route | Adapter |
| --- | --- | --- |
| GET / POST | `/delivery/customers` (GET uses `?q=`) | searchProfiles / createProfile |
| GET / POST | `/delivery/customers/:customerId/addresses` | listAddresses / saveAddress |
| PATCH / DELETE | `/delivery/customers/:customerId/addresses/:addressId` | saveAddress / deleteAddress |
| POST | `/delivery/customers/:customerId/addresses/:addressId/resolve` (empty body) | resolveStoredAddress |

Existing authentication reloads the active account. Controller checks currentUser status/shop/id, then current role 0 or role 1 with `delivery` permission. JWT role assertions and body shop/customer/coordinate overrides confer no access. Roles 2/4/5/6, null role, disabled admin, service points and customer subjects are refused. No `/customer/addresses`, `/customer-auth/*`, public contact search, or cookie API is mounted. Errors: CUSTOMER_REQUEST_INVALID 400, CUSTOMER_NOT_FOUND / CUSTOMER_ADDRESS_NOT_FOUND 404, existing DELIVERY_FORBIDDEN 403, DELIVERY_ADDRESS_INVALID 422; unexpected failures return sanitized CUSTOMER_UNAVAILABLE 503.

## Schema contract for Task10

All new keys are BIGINT UNSIGNED; shop FKs copy legacy int(11). New text is VARCHAR/utf8mb4; fixed hash fields use ASCII binary. Identity/challenge channel and destination are `utf8mb4_bin`, matching normalization's case-sensitive mailbox semantics; identity UNIQUE is `(shopid,channel,destination)`. Verified identities require verified_at and tenant-owned customer_id.

`customers` owns `next_address_number` and a single nullable `default_address_id`; a composite FK `(shopid,id,default_address_id)` targets address ownership. Addresses have unique `(shopid,customer_id,label_number)` and full `address_snapshot` JSON. Customer deletion is restricted by references; no order snapshot is cascaded away.

`customer_otp_challenges` prepares `customer_id` (nullable login target, mandatory link target), `purpose` login/link, channel/destination, `code_hash`, `browser_binding_hash`, attempts 0..5, send_status pending/sent/failed, sent_at, expires_at, invalidated_at, verified_at, consumed_at and verified_customer_id. A verified row must have a consumed timestamp, verified owner and sent state. Task10 must implement HMAC binding, resend invalidation, quotas, timing, purpose isolation and transactions; this task provides schema only.

`customer_sessions` prepares shop/customer, token_hash, csrf_secret_hash, expires_at, revoked_at, created_at and UNIQUE verified_challenge_id. Its composite FK points to `(shopid,verified_customer_id,id)` on the challenge, so a session cannot reference an unverified/wrong-owner challenge. Task10 implements opaque tokens, CSRF derivation/checks, session expiry/cookie/origin rules and single consumption of the challenge in its transaction. No authentication/send/session logic exists here.

Existing `service_rate_limits` UNIQUE `(shopid,scope,subject_hash,window_start)` already supports contact/IP/verification/resend quotas. Tested scopes: `customer_otp_contact`, `customer_otp_ip`, `customer_otp_verify`, `customer_otp_resend`; Task10 hashes subjects and enforces rolling/resend limits rather than seeding real contacts now.

Orders, archives and deliveries now enforce `(shopid,customer_account_id) -> customers(shopid,id)`. No historical phone grouping/backfill occurs. On DOWN only, those nullable links are cleared before removing customer tables, preserving operational/financial/address history and allowing populated down/up. Existing Task1/Task7 migrations were not edited.

## Validation evidence

Commands ran from B except the explicitly named frontend regression. Every SQL run explicitly set `DELIVERY_TEST_DATABASE_URL=mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql`; the unchanged harness creates/drops only random `smarteat_delivery_test_*` databases on the authorized local disposable MySQL. No application DB fallback. Raw log names below resolve beside this report.

| Command | Exit / evidence | Raw log |
| --- | --- | --- |
| `node test/customer-identity.test.js` before implementation | 1, absent customerIdentity helper | `task-8-identity-red.txt` |
| `node test/customer-addresses.integration.test.js` before implementation | 1, 0/2: absent m_customers and migration | `task-8-addresses-red.txt` |
| `node test/customer-addresses.integration.test.js` first implementation | 0, 11/11; empty-customer migration cycle | `task-8-addresses-green-attempt.txt` |
| `node --test --test-name-pattern='migration alone' test/customer-addresses.integration.test.js` after populated rollback regression | 1, 0/1: orphan customer links prevent adding FK on subsequent UP | `task-8-rollback-populated-red.txt` |
| `node test/customer-identity.test.js` final | 0, 3/3 | `task-8-identity-green.txt` |
| `node test/customer-addresses.integration.test.js` final | 0, 11/11 including populated rollback | `task-8-addresses-green-node22.txt` |
| Node18 executable + `test/customer-identity.test.js` | 0, 3/3 | `task-8-identity-green-node18.txt` |
| Node18 executable + `test/customer-addresses.integration.test.js` | 0, 11/11 including actual HTTP/SQL | `task-8-addresses-green-node18.txt` |
| `node test/delivery-schema.integration.test.js` | 0, 2/2 existing schema/journal groups, including whole delivery chain down/up | `task-8-foundation-regression.txt` |
| F: `node test/clients.test.js` | 0, existing history/phone grouping/CSV assertions | `task-8-legacy-clients.txt` |
| Structured package JSON comparison against BASE | 0, both test scripts prepend new test and retain all old commands; every other script identical | `task-8-scripts.txt` |
| Unset URL; `node --test --test-name-pattern='migration alone' test/customer-addresses.integration.test.js` | 1 EXPECTED, explicit URL required; no silent SQL skip | `task-8-missing-url.txt` |
| Dependency install, command above | 0, one package | `task-8-install.txt` |

Native runtime: Node22.13.1. Compatible runtime: Node18.20.8 at `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`. Task8 handler tests do not import legacy Nano ID consumers and need no bridge. This does not claim an unbridged Node18 application boot. No redundant whole previous suites ran, as instructed.

The 11 TAP tests comprise 9 functional subtests, their parent, and one standalone migration test. They cover concurrent label/default allocation, deletion fallback/null/default/counter persistence; cross-tenant/owner/address rejection and FKs; exact IDs above MAX_SAFE_INTEGER under production driver defaults; SQL mailbox case/dot/alias/IDN uniqueness and lookups; purpose/browser/send/verified-session columns and unique one-use session FK; expired original proof, zero HTTP/HTTPS calls with provider outage tripwires, fresh 15-minute proof and expiry boundary, private edits, new postal proof requirement, and unchanged delivery snapshot; actual staff HTTP current roles/permissions, forged fields/claims, unauthorized subjects, no personal endpoints or cookies; unclaimed historical contacts and populated rollback without Task7/history damage.

Author self-review read the complete staged production diff and checked task ownership, SQL constraints/rollback, transaction and ID handling, actor checks, address proof provenance, public exposure, and test registration. `git diff --cached --check` and syntax checks on all 8 changed JS files passed (exit 0); only repository LF-to-CRLF informational warnings occurred during staging. No indispensable gap found. Independent review remains controller-dispatched.

Scoped commit command: `git -c core.hooksPath=NUL commit -m 'feat: add verified customer identities and address book'`, exit 0; raw `task-8-commit.txt`. Hook override was invocation-local only, with no git configuration write or environment hook execution. Commit contains exactly the 11 backend files listed above. Final `git diff 8cd556726e9029b1e38e3b94070ff390f3022a12 HEAD --check` exited 0, and `git status --short --branch` showed only `## feat/delivery-v1`.

## Concerns and handoff

No Task8 blocker remains. Real Mailjet/WhatsApp sends/reception and full V1 acceptance remain commissioning work; Task9/10 authentication/transports/session implementation is intentionally pending. Task10 must use normalized identity fields with binary SQL comparisons and exact string IDs, derive link/customer context from a verified session, and expose customer stored-address resolution only through that context. Staff contacts never grant verified identity or historical order access. Down migrations intentionally remove customer records and clear only their prepared links; snapshots and sale history remain.

## Fix Round 1: I1 (2026-10-18)

Read the full `task-8-review.md`, including Important I1 verbatim. Fix BASE/starting clean HEAD: `b8e62b5c2194c7859473b6c6678e676b7923e670`. Only B `src/helpers/customerIdentity.js` and `test/customer-identity.test.js` changed. The helper rejects raw domain `/`, `\`, `?`, `#`, `:`, `%` BEFORE calling URL-based `domainToASCII`, preventing truncation/escape decoding into another mailbox. No dependency or parser/Unicode redesign. Valid IDN/punycode/lowercase domains and local case/dots/aliases remain; a new positive literal also protects `%` in the local part. Phone tests/code remain intact.

Four reported literals plus percent/escaped variants have 14 separate literal rejection tests. The actual pre-fix converter/helper probe confirmed eight silent rewrites: the four reported cases, `%65xample.com`, `ex%61mple.com`, `example%2ecom`, and a path with percent encoding. Port and encoded delimiter/percent variants were already rejected and remain covered. The three existing normalization groups still pass. Raw logs below are beside this report; all commands ran from B. Test capture used `*> '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/<log>'`, recorded `$LASTEXITCODE`, read the tail and exited with the same code.

| Exact test command | Phase / exit / counts | Raw log |
| --- | --- | --- |
| `node test/customer-identity.test.js` | RED, exit 1, 9 pass / 8 fail, all failures are missing expected rejection for I1 | `task-8-fix-round1-red-node22.txt` |
| `& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-identity.test.js` | RED, exit 1, 9 pass / 8 fail, same I1 failures | `task-8-fix-round1-red-node18.txt` |
| `node test/customer-identity.test.js` | GREEN, exit 0, 17 pass / 0 fail | `task-8-fix-round1-green-node22.txt` |
| `& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-identity.test.js` | GREEN, exit 0, 17 pass / 0 fail | `task-8-fix-round1-green-node18.txt` |

Runtime checks: `node --version` -> v22.13.1; `& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' --version` -> v18.20.8, both exit 0. Pre-fix probe command (exit 0, raw `task-8-fix-round1-converter.txt`):

```powershell
node -e "const {domainToASCII}=require('url'); const normalize=require('./src/helpers/customerIdentity').normalizeCustomerDestination; for(const raw of ['example.com/path','example.com?x=1','example.com#x','example.com'+String.fromCharCode(92)+'evil','example.com:443','%65xample.com','ex%61mple.com','example%2ecom','example.com%2fpath','example.com%3fx=1','example.com%23x','example.com%5cevil','example.com/%65vil','example.com%25evil']) {let result; try {result=normalize({channel:'email',value:'a@'+raw})} catch(error){result=error.code} console.log(JSON.stringify({raw,converted:domainToASCII(raw),result}));}"
```

Self-review: read the complete two-file diff; the raw-domain guard precedes conversion and affects only malformed domain syntax, with literal positive regressions for permitted outputs. `git diff --check` exited 0 (only existing LF-to-CRLF informational notices). No SQL rerun was needed: valid normalized outputs and SQL collation/uniqueness/schema/repository code did not change; malformed inputs now fail before SQL. No whole SQL/npm baseline, agents/reviewers, real environment reads, provider or remote operations ran. M1 TAP bootstrap noise remains DEFERRED as instructed. Future timeout/send-status/global-quota conditions remain controller-owned Task9/10 contracts, with no auth/schema changes here.

Fix commit: `34f9323e488540123654dc80dc9ee1843c020cfe`, command `git -c core.hooksPath=NUL commit -m 'fix: reject URL syntax in customer email domains'`, exit 0; raw `task-8-fix-round1-commit.txt`. Invocation-local hook override only. Exactly two backend files, 14 insertions. `git diff --cached --check` before commit and `git diff b8e62b5c2194c7859473b6c6678e676b7923e670 HEAD --check` afterward exited 0. `git status --short --branch` showed only `## feat/delivery-v1` (clean).

Fix status: I1 addressed, focused RED/GREEN and author self-review complete; no remaining I1 concern. M1 remains deferred. Fresh scoped I1 diff review belongs to the controller.
