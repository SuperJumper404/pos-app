# Task 12 Independent Spec and Quality Gate

## Spec Compliance

**Issues found. Coupled Task12 gate: Needs fixes. Critical: 0; Important: 3; Minor: 0.**

The implementation substantially follows the amended checkout, pricing, identity and authorization contracts, but normal Stripe preparation and two required recovery cases fail at the frontend boundary. Backend changes reviewed here have no independently identified blocking defect. The paired task is not approved while I1-I3 remain.

Reviewed pair and packages:

- F = `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app`; BASE `955f3981b0e0339c388aa87e6dbb18ce0720f74e`, HEAD `13e2a2ca5759c0a41b3909bca74bd797ecae7479`.
- B = sibling `express-pos`; BASE `1a0d7c32a26d20bac0a1da3b707b13364611eee7`, HEAD `6dfdc2cdc48ea47fd50940887f8d2580dddad5c8`.
- Supplied `task-12-frontend-review.diff`: 10 files, 110641 bytes; `task-12-backend-review.diff`: 9 files, 53749 bytes. One sequential review pass over each supplied package, including its commit/stat context. No regenerated git diff or git command.
- Read the entire amended `task-12-brief.md` first, then worker context, Task12 integration notes, common plan contracts and applicable design sections 3-4, 6-8, 10-13; then the complete implementer report, including its superseding final reader grant, paired commits and evidence bounds.
- Applied `superpowers/subagent-driven-development/task-reviewer-prompt.md` as the task-scoped spec/quality gate. No subagents or additional reviewers. Preserve this independent review seat for the fix loop; no next task.

## Strengths

- Server pricing remains authoritative. Delivery quotes contain product intent, signed address proof and authorized discount intent; the browser does not calculate delivery fees. Explicit confirmation gates checkout, and the actual SQL R3 witness verifies 2500 - 1 + 400 = 2899 before a provider start. See F `store/delivery.js:104`, `components/delivery/DeliveryCheckout.vue:145`, `pages/cart.vue:1163`; B `test/delivery-customer-checkout.integration.test.js` R3 subtest.
- Verified ownership is derived from `req.customerSession`, independently of the posted account ID, validated as a BIGINT string, checked against the caller shop and attached transactionally to both commercial order and delivery. See B `src/modules/m_checkout.js:140`, `:300`, `:877`, `:1016`, `:1144`; the actual SQL tests use account ID `9007199254740993`.
- The isolated transport uses explicit Fetch `credentials: 'omit'` for guest/staff delivery requests, and includes customer credentials plus CSRF only for the selected same-shop personal checkout. It avoids shared Axios defaults/interceptors and legacy public/staff bootstrap. See F `store/delivery.js:17`, `:26`, `:118`; `pages/cart.vue:592`, `:1545`.
- Exact original wire payload, quote/address proof strings and private confirmation secret are retained in the existing narrow cart attempt rather than refreshed during an unresolved replay. Generic delivery 409 responses do not automatically release recovery. See F `store/cart.js:260`, `:303`, `:340`.
- Current paid/refunded resolution is obtained from the original delivery's current commercial linkage, rather than the immutable accepted replay. It returns a bounded resolution descriptor without a new receipt, tracking URL or implicit token rotation. See B `src/controllers/c_stripe.js:224`, `:231`; unchanged resolver linkage checks at B `src/modules/m_deliveryOrders.js:103`.

## Issues

### Critical

None identified.

### Important

**I1. Locking the first attempt destroys the address input and clears the accepted display proofs.**

- Location: F `components/delivery/DeliveryCheckout.vue:6`, `:144`, `:146`; F `pages/cart.vue:601`, `:1634`. Necessary unchanged lifecycle definition: F `components/delivery/DeliveryAddressInput.vue:57`, `:59`, `:67`.
- Trigger: submit a confirmed delivery. `cart/checkoutOrder` sets status to `pending`, so `deliveryAttemptLocked` becomes true. The `v-if="!locked"` block destroys `DeliveryAddressInput`. Its existing `beforeDestroy -> invalidate -> resolved(null)` callback still reaches `onResolved` in the new consumer. That handler clears the parent address, then `refreshQuote()` invalidates and emits `quote(null)` before checking `locked`.
- Result: the page loses both `deliveryResolution` and `deliveryQuote` during the in-flight request. Their tokens participate in `currentStripeCheckoutSignature`. When Stripe preparation returns, its existing signature comparison detects a change and calls `cancelReturnedPayment()`. Thus the normal first online delivery attempt can be canceled by the new locking transition itself; keeping the persisted wire payload exact does not preserve the live payment UI.
- Focused lifecycle witness: using the actual Vue component methods and unchanged input `$destroy()` hook, with the input's real `resolved` event wired to the consumer and `locked=true`, produced `parentQuote:null`, `parentResolution:null`, `confirmed:false`.
- Fix in the owned consumer: preserve the frozen resolution/quote when locking, either by retaining the input instance with editing disabled or by ignoring destruction/invalidation callbacks while locked. Do not alter the shared Task11 input contract. Add a mounted parent/child regression covering confirmed quote -> pending -> Stripe response, proving the same tokens/signature survive and no cancellation is requested. The existing headless component tests and template compilation do not exercise this conditional child destruction.

**I2. A persisted `pending` attempt cannot be recovered after a reload or interrupted tab.**

- Location: F `store/cart.js:276`, `:340`, `:342`; F `pages/cart.vue:601`, `:1039`.
- Trigger: reload or close the page after the request has been sent, while its outcome is still unknown. The existing persisted cart includes the new exact attempt body and status `pending`. The server may already have accepted the order or created its payment. On mount, `restoreCheckoutFromStore()` restores that payload but does not distinguish a restored pending status from an active in-memory request.
- Result: the locked UI exposes `Resoudre la tentative`, but `retryCheckout` always rejects `pending` before dispatching any HTTP replay. There is no surviving promise after reload that can move it to `uncertain` or `stripe_prepared`, so recovery remains stuck despite retaining the correct key/proofs/secret.
- Focused action witness: a restored delivery payload with its original token and status `pending` returned `CHECKOUT_ATTEMPT_UNRESOLVED`, with zero dispatches.
- Fix: distinguish the transient live request from persisted uncertainty. On restoration, permit exact replay of the original pending attempt, or normalize only a restored pending status to recoverable uncertainty while retaining the body, endpoint/payment choice, key and identity. Keep concurrent clicks during a live request guarded. Add a reload/interrupted-response regression; do not issue a new order token.

**I3. A coexisting personal session blocks recovery of a POS guest attempt.**

- Location: F `store/cart.js:343`, `:345`; intended initial POS behavior: F `pages/cart.vue:592`, `:1545`.
- Trigger: a staff cashier uses the new POS delivery flow with a same-shop personal account already present in customer memory, including when choosing a restaurant-created unverified profile/address. Initial POS checkout correctly omits `customerSession`, so the stored attempt has no `customerContextId`. Its reply is lost.
- Result: `retryCheckout` independently selects the personal session solely by shop, even though the original attempt was guest/POS. The comparison of null original context with the personal customer ID rejects the replay without sending a request. This can also happen when a personal session appears after a guest site attempt. The POS locked UI offers no account-resolution link for an attempt without `customerContextId`, and requiring personal logout would violate the independent-principal workflow.
- Focused action witness: an uncertain guest delivery with a same-shop personal customer session returned `CHECKOUT_ATTEMPT_UNRESOLVED`, with zero dispatches.
- Fix: derive retry credentials from the original attempt's intended identity. An original guest attempt must replay with cookies omitted, regardless of unrelated personal state. An original personal attempt must require that same verified customer in the same shop and send its current CSRF token. Do not attach the selected staff contact as a personal owner, or bootstrap/swap staff/public tokens. Cover the combined POS profile/address + personal cookie + lost-reply workflow, not only the resolver adapter.

### Minor

None recorded. Baseline lint warnings, stale Browserslist output and the existing Node18 `buffer.File` warning are nonblocking and require no cleanup in this task.

## Named Checks and Scope

| Check / concrete risk | Evidence and assessment |
| --- | --- |
| Safe availability must not expose admin settings or accept a posted shop | B `src/controllers/c_delivery.js:78`, `src/routers/r_delivery.js:10`; actual SQL/HTTP availability subtest covers staff, web, foreign shop, unauthenticated and courier, with only `{enabled}` exposed. Full settings remains admin-only. |
| Verified identity versus posted owner, tenant FK and atomic attachment | B `src/modules/m_checkout.js:140`, `:300`, `:877`, `:1144`; actual email/WhatsApp attachment and foreign-shop/forged-owner tests. The original delivery helper temporarily initializes owner null, then the new code attaches both rows in the same supplied transaction. No Number cast of new account/delivery IDs. |
| Shop/customer lock order and unchanged replay contract | Necessary B `src/modules/m_checkout.js` cutoff continuations `:849-868`, `:891-934`, `:1160-1176`; `src/modules/m_deliveryOrders.js:95`, `:163-180`. Exact durable replay occurs before new writes; shop/customer locks are taken for new verified attachment; producer files supply existing transaction/stock/lock evidence. No new stress/race run. |
| Private detail override surface | B `src/modules/m_checkout.js:146`, `:226`, `:343`, `:1143`: only complement/instructions, string limits 200/500 JS code units, control rejection, fingerprint inclusion and accepted JSON snapshot merge. Unicode text is retained; no separate UTF8 byte quota is specified in the binding brief. Postal fields, coordinates, financials and owner cannot be supplied through this object. Private instructions are excluded from F `store/delivery.js:12` postal requests. |
| Same server price, one fee/VAT/stock movement | F `store/delivery.js:104`, `pages/cart.vue:860`, `:1545`; B R3, concurrent HTTP, private-paid snapshot and minimum/radius SQL tests. Full Task3/4 producer logs also retain fee/VAT, stock-once, paid immutability and archive behavior. |
| Suspension/radius/minimum retain cart without forced takeaway | F `components/delivery/DeliveryCheckout.vue:5`, `:72`, `:96`, `store/delivery.js:43`; B final SQL witnesses and F focused suspension test. A rejected quote blocks confirmation rather than changing fulfillment silently. |
| POS counter-paid versus reception/site modes | F `pages/cart.vue:251`, `:596`, `:1559`; B actor/payment guard cutoff `src/modules/m_checkout.js:891`. POS uses existing `counter_pay_before:<method>`; site offers online when configured or reception, excludes dine-in, and cannot declare a paid counter mode. |
| Staff selected contact must not divert into personal addressbook | F `components/delivery/DeliveryCheckout.vue:67`, `:143`, `store/delivery.js:88`; same-shop coexisting personal resolver regression passes. Initial page payload excludes personal identity in POS. Retry violates that intended distinction as I3. |
| Actual orders boundary must stay bearer -> optional customer -> CSRF | Necessary unchanged B `src/routers/r_orders.js:14` checked directly: exact route-local chain remains. No modification to this file. |
| Actual Stripe boundary / exact CORS scope | B `src/routers/r_stripe.js:38`, `src/helpers/customerCors.js:19`: optional customer/CSRF follow bearer only on actual start route; shared parsed-path classifier adds exactly that path. Existing prefix/double-slash/absolute-form handling is reused. New SQL preflight checks both prefix spellings and disallowed origin. Reader assertion changes only the authorized import and exact route chain. No raw webhook/Terminal/cancel/refund route change. |
| Current settled result must match original commercial delivery | B `src/controllers/c_stripe.js:224`, `:231`; necessary unchanged `src/modules/m_deliveryOrders.js:103-131` verifies shop, origin and order/delivery linkage for active/archive. Descriptor is derived from current paid/refunded status; no new tracking rotation or receipt path. |
| New private data in general persistence | Necessary unchanged F `helpers/persistedState.js:3`, `plugins/persistedState.client.js:8`: delivery/customer/courier roots excluded on read/write and their mutations filtered. The existing cart attempt intentionally holds exact wire details/secret and a postal-only display snapshot until resolution, then `clearCheckoutAttempt` clears it. New tracking URL is page-local, not placed in cart or a persisted root. I2 concerns reachability of that resolution, not a second persistence store. |
| New private data reaching existing logs | Focused inspection of F `plugins/axios.js`, cart console call sites; B checkout/Stripe logging, `src/helpers/response.js` and actual index middleware. New delivery checkout uses the independent transport rather than global staff error handling; old cart console calls belong to legacy split-write actions. B checkout and Stripe sanitize delivery failures instead of logging request/error bodies. No new tracking/private-secret/instruction log flow identified. This was not a platform logging/finance audit. |
| API/interface cutoffs necessary for payment behavior | Only cut-off changed-file continuations were read: F `pages/cart.vue:695-748`, `:1035-1102`, `:1586-1718` and B checkout continuations listed above. These establish signature matching, recovery mount and cancellation call sites. No separate whole changed-source review. |

The missing brief-listed edits to `DeliveryAddressInput.vue` and `r_orders.js` are intentional amendment-compliant reuse, not missing implementation. Availability, exact Stripe CORS and the one reader test adjustment are expressly authorized scope extensions. No dependency, package-lock, auth bootstrap, global persistence refactor, invoice/history/operator/tracking Task13+ feature or navigation change is required by this gate.

## Verification Evidence and Limits

Inspected retained raw terminal summaries, not just the report. These are prior implementer runs, not suites rerun by this reviewer:

| Retained evidence | Observed result / limit |
| --- | --- |
| `task-12-final-focused-node22.txt`, `task-12-final-focused-node18.txt` | 23 tests / 23 pass / 0 fail, skip, cancel or todo in each. These tests do not cover I1-I3's combined lifecycle/recovery transitions. |
| `task-12-sql-final-node22.txt`, `task-12-sql-final-node18.txt` | 13 TAP tests pass in each: 12 scenarios plus parent. Not 13 independent scenarios. |
| `task-12-cors-final-node22.txt`, `task-12-cors-final-node18.txt` | Existing complete CORS file, 76/76 in each. |
| `task-12-reader-final-node22.txt`, `task-12-reader-final-node18.txt` | Corrected complete reader file, 77/77 in each, including route binding and provider-boundary cases. Final report supersedes the earlier pending-grant section; no remaining reader ownership request. |
| `task-12-producers-node22.txt`, `task-12-producers-node18.txt` | Both complete Task3 delivery-checkout and Task4 delivery-archive/payments SQL producer files end in success on both runtimes. This is not a full registered SQL-suite run. |
| `task-12-required-frontend-initial.txt`, `task-12-required-frontend-continuation.txt` | Initial loader error retained; corrected continuation succeeds, including Task11 account 27/27. Required counter/Stripe/order-edit/QR/auth/persistence regressions retained. |
| `task-12-required-backend-node22*.txt`, `task-12-required-backend-node18-corrected.txt` | Initial exact DTO assertion failure retained; bounded corrected legacy counter/Stripe/order-edit/QR/checkout runs succeed on both runtimes. Existing Node18 compatibility bridge is test-only, not a production-boot claim. |
| `task-12-npm-frontend.txt` | The single whole frontend invocation succeeded at its then-current revision, preserving image-library pretest. Later staff-adapter, mode-CSRF and consumed-draft fixes have final focused/lint evidence; this is not whole npm execution on the final revision. |
| `task-12-npm-backend.txt`, `task-12-npm-backend-continuation.txt` and final reader logs | Original whole invocation failed on the obsolete reader assertion after its 12-file passing prefix. Only its previously unrun 53-command suffix was continued successfully; then corrected complete reader file passed on both runtimes. Composite coverage of all 66 unit commands, not a whole npm exit0. |
| `task-12-lint-current.txt`, `task-12-final-draft-lint.txt` | Zero affected lint errors; broader affected run has three pre-existing cart no-console warnings, final bounded run has the existing Browserslist notice. No baseline cleanup requested. |

Only new execution: one bounded local, provider-free Node/Vue probe of the three unanswered doubts. The complete added retry action and new consumer component were extracted from the supplied package; only the unchanged shared address component was loaded for its necessary lifecycle contract. The retry probe replaced the unresolved-result formatter with an equivalent error-code stub and counted dispatch calls; it did not mock a successful request or run an SQL/provider path.

```text
PENDING_AFTER_REMOUNT {"ok":false,"error":{"code":"CHECKOUT_ATTEMPT_UNRESOLVED"}} dispatches=0
POS_GUEST_WITH_PERSONAL_SESSION {"ok":false,"error":{"code":"CHECKOUT_ATTEMPT_UNRESOLVED"}} dispatches=0
ADDRESS_CHILD_DESTROY_ON_LOCK {"parentQuote":null,"parentResolution":null,"confirmed":false}
```

The corrected bounded probe exited0. Its initial assembly attempt failed in Babel before product execution because discontinuous diff hunks cannot be concatenated as a complete action; that harness error is not product RED evidence. The corrected probe extracted the complete added retry method. The lifecycle witness invokes the real child destruction hook and event handlers; it is not browser rendering or a Nuxt compilation claim. The normal Stripe cancellation consequence follows from the inspected unchanged signature/cancellation continuation and needs the mounted regression requested in I1.

No suite rerun, heavy/repeated race, browser/controller server access, real provider/Stripe/Terminal/printing/phone/push/deployment, environment/secret read, agent dispatch or source/index/HEAD mutation. The only written artifact is this report. `workspace_fs` was unavailable; used the paired-worktree shell fallback documented in worker context. All probe/tool sessions completed.

Actual browser behavior, full Nuxt compilation, desktop/mobile overflow/assets/touch acceptance and commissioning remain separate controller-owned checks. The single batched Task17 visual/runtime acceptance is pending; this pending batch is neither a code-gate defect nor a passed claim. No Task13+ deliverable is imposed here.

## Assessment

**Spec compliance: Needs fixes. Task quality: Needs fixes. Counts: C0 / I3 / M0.**

The backend boundaries and retained pricing/SQL evidence are strong. The frontend tests leave live child teardown, restored pending state and intended-identity replay disconnected; those transitions break required checkout/recovery workflows and must be fixed within Task12 before approval. Retain the original reviewer for the bounded fix loop; do not advance to another task.
