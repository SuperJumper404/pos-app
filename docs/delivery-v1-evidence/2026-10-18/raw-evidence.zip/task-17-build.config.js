import config from '../../../nuxt.config.js'

export default {
  ...config,
  buildDir: '.superpowers/sdd/2026-10-16-delivery-management/task-17-nuxt-build',
}
