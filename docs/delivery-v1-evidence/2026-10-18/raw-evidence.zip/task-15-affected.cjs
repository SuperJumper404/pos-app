const { spawnSync } = require('child_process')
const frontend = process.argv[2] === 'frontend'
const names = frontend ? [
  'delivery-receipts', 'receipt-printing', 'receipt-bundle', 'history-ticket', 'vat-breakdown',
  'cash-closures-store', 'reports-ticket-z', 'history-archive-ordering', 'order-detail-checkout',
  'cash-register', 'refund-status', 'printing-fire-and-forget', 'order-edit', 'stripe-terminal-payout',
] : [
  'order-metrics-revenue-series', 'cash-closure', 'vat', 'cash-register-payment',
  'service-point-order-display', 'service-point-cash-register-detail', 'order-delete-hidden-archive',
  'stripe-terminal-payments', 'stripe-terminal-refunds',
]
console.log(`Runtime ${process.version}; ${frontend ? 'frontend' : 'backend'}; ${names.length} files`)
let failed = 0
for (const name of names) {
  const result = spawnSync(process.execPath, [`test/${name}.test.js`], { encoding: 'utf8', env: process.env })
  console.log(`FILE ${name}\n${result.stdout || ''}${result.stderr || ''}NATIVE_EXIT ${result.status}`)
  if (result.status !== 0) failed++
}
console.log(`RESULT ${names.length - failed}/${names.length} files; failed=${failed}`)
process.exitCode = failed ? 1 : 0
