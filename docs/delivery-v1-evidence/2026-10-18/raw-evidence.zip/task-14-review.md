# Task 14 Review

## Spec Compliance

**Verdict: Issues found.** I1 violates the required reassignment/stale-async privacy behavior: an older list response can republish private mission data after a newer authority read has removed it. The remaining reviewed requirements conform to the amended brief.

**Scope:** Task 14 only. F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app; B = sibling express-pos.

**Reviewed packages:** task-14-frontend-review.diff, a04f9da3b6cb444b7be4317922ba6acdce27252c..7c4e12efc12865e283a15fd142b058a329133d07; task-14-backend-review.diff, b16d97cae4cb2eabb27512ac4c9c543b57c1570d..0150e247fd3ff874eabeb85857aaa7482d2b430e.

**Cannot verify here:** Actual phone portrait/landscape, long-address, network-error and different-payment-mission visual acceptance is explicitly PENDING Task17's ONE visual-qa-matrix batch. No browser, detector, screenshot or visual PASS was attempted or inferred from the SFC tests. Full build, whole application suites and configured Node20 commissioning remain controller/Task17 gates, not failures of this intermediate review.

## Strengths

- F/store/courier.js:191 and F/store/courier.js:207: collection uses a fresh own-detail authority read before new collection or explicit replay, per-mission busy locks, a server version and an exact saved body/key. The only collection fields are method/expectedVersion/idempotencyKey; no caller monetary amount or selected courier is sent.
- F/store/courier.js:32, F/store/courier.js:34 and F/store/courier.js:49: dedicated recovery records have exactly six fields, strict validation, 32-entry/16000-input-character bounds, and write-before-POST behavior. Malformed/full/unwritable storage blocks new collection without evicting unresolved keys. Addresses, access instructions, contacts, full missions, balances and issue reasons are absent from this storage.
- F/store/courier.js:18, F/store/courier.js:88 and F/store/courier.js:203: terminal projections remove contact/address/items; identity epochs reject replies for previous couriers, shops and tokens. Unknown financial metadata remains available across loss of authority; definitive new collection does not silently replace an unresolved key.
- F/middleware/courier.js:4, F/helpers/staffRoles.js:166 and F/layouts/default.vue:225: courier initialization precedes namespace refusal; role6 enters /livreur with a limited shell. The public tracking exception has a path boundary and does not open /livraison or similarly prefixed operator paths.
- F/store/courier.js:110 and F/pages/livreur/index.vue:35: own balance comes from /courier/cash-balance, with server cents displayed directly. There is no local debt inferred from missions, self-remittance, refund or adjustment workflow.
- F/pages/livreur/index.vue:92, F/store/courier.js:149 and B/src/routers/r_courier.js:15: mount/refresh reads availability through GET; only an explicit toggle PATCH writes it. Unknown availability is visibly unknown. B/src/controllers/c_courier.js:27 and B/src/modules/m_deliveryDispatch.js:292 derive identity from the authenticated actor and reuse the current-account transaction/reload guard.
- B/src/helpers/deliveryAuthorization.js:14: the central amendment adds ONLY exact GET /courier/availability to the existing surface. This is authorized by the amended brief/controller ruling, not an extra-scope finding. Other verbs, routes and role6 restrictions are unchanged in the package.
- F/components/delivery/CourierMission.vue:60: phone links validate and normalize the number, then use fixed tel: with encoding; maps uses a fixed HTTPS Google destination URL and encoded postal address. Access instructions are not included in directions.
- F/test/courier-mobile.test.js:1 and B/test/courier-availability.integration.test.js:29: tests exercise real Vue/Vuex and compiled controls across a loopback HTTP boundary, and the backend GET uses actual disposable SQL/Express/JWT. The no-write SQL trigger is stronger than merely comparing unchanged values.

## Issues

### Critical (Must Fix)

None. Count: 0.

### Important (Should Fix)

**I1 - An authoritative detail denial does not invalidate an older concurrent list, allowing private data to return.**

**References:** F/store/courier.js:115, F/store/courier.js:118, F/store/courier.js:136, F/store/courier.js:204 and F/store/courier.js:207.

The read token is checked only for its resource key. Collection invalidates existing reads at command entry, then awaits detail. A refresh may start a NEW list read while that preflight is pending. If detail then returns 404 after reassignment, its catch removes the mission, but it does not invalidate the in-flight list. That list's token remains current and its older snapshot subsequently replaces missions, restoring address/access instructions for the old assignee. Identity and epoch remain the same throughout, so neither protects this case.

Focused in-memory reproduction with the actual exported store and real Vuex confirmed: preload an assigned in-transit mission; start collection and hold its detail response; start/hold a list refresh containing the old snapshot; reject detail with 404; observe missions empty and no POST; release the older list; observe the private instructions restored. Output: "REPRODUCED: authoritative detail404 cleared mission, then older concurrent list restored private instructions; POST count=0". The diagnostic exited 0 because it asserted the faulty behavior. No server or database was opened.

Make freshness coordinated across overlapping list/detail reads, including denial/removal and newer terminal detail responses, rather than checking only each resource's latest token. A per-mission generation or equivalent invalidation rule must prevent an older list/detail from resurrecting a mission after newer authoritative removal/closure. Add this exact interleaving as a regression. Existing delayed-list coverage proves invalidation around a successful mutation, not this preflight-denial ordering.

### Minor (Nice to Have)

**M1 - Successful refresh leaves an old read-failure banner displayed.**

**References:** F/store/courier.js:118, F/store/courier.js:130, F/store/courier.js:140 and F/pages/livreur/index.vue:7.

A failed read stores "Lecture impossible. Actualisez avant de continuer." Subsequent successful reads replace their data but never clear that error. The page continues to tell the courier that reading failed after the requested refresh succeeded; only a later mutation entry or identity reset clears it. Clear recovered resource errors with appropriate request freshness, preserving failures of other resources. This is visible state feedback, not a financial-authority failure.

**M2 - Retained passing validation output is noisy (inherited).**

**References:** scratch/task-14-final-frontend-node22.txt:1, scratch/task-14-final-frontend-node18.txt:1, scratch/task-14-final-lint.txt:1 and scratch/task-14-regression-node22-session-auth.txt:1.

The successful frontend/lint logs emit the outdated caniuse-lite/Browserslist diagnostic; the session regression also prints legacy fixture authentication projections ("REspondse DAta"). These are inherited diagnostics, explicitly not test failures, new secret exposure, or a request to broaden Task14 into a dependency/logger cleanup. The rubric requires recording test-output noise. Address through the established tooling/logging maintenance scope; do not treat these logs as pristine.

## Named Checks And Evidence

**NC1 - Cross-resource privacy freshness.** The single focused reproduction described in I1 executed the actual Task14 store with real Vuex, an in-memory transport, disposable fixture state/storage and controlled promises. It made no network request, environment-file read, DB access or disk write. The initial diagnostic setup used an invalid fixture token and did not reach the scenario; after correcting it to a future-expiry fixture token, the guarded initial-load assertion and complete ordering reproduced I1. No suite was rerun. This runtime load is the only additional use of changed implementation source beyond static package review.

**NC2 - Retained frontend gates.** Inspected both full task-14-final-frontend-node22.txt and task-14-final-frontend-node18.txt: 27 tests, 27 pass, 0 fail/cancel/skip/todo, nativeExit=0 each. Tests cover two missions, double taps, loss/reload/exact replay, current-authority denial, identity change, terminal redaction, controls, URLs, availability, bounded storage and unchanged persistence/operator state. Their green result does not cover I1's ordering.

**NC3 - Retained backend GET/current-role gates.** Inspected task-14-availability-green-node22.txt and task-14-availability-green-node18.txt: three PASS groups each, current false/true value, exact DTO/no-store/no writes, caller IDs ignored, inactive/role/tenant/subject refusal and unchanged PATCH. These older logs do not include an embedded nativeExit marker; the report supplies exit0, and the retained raw files show completion of all three assertion groups without failure. Inspected both task-14-task5-http-node*.txt: 27 PASS groups each; Node18 includes nativeExit=0, while Node22 is the older unmarked capture. No SQL rerun was used to reconstruct exit evidence.

**NC4 - Compatibility evidence.** Scanned every retained task-14-regression-node18/22-*.txt (17 named files per runtime) and task-14-backend-node18/22-*.txt (four per runtime). Raw files report passing auth/session/storage/QR/kiosk/staff/navigation/persistence/checkout/customer/operator checks and backend authorization/session/login/permissions checks. TAP regressions report 29 delivery-checkout, 27 customer-account and 37 delivery-operator passes per runtime; legacy scripts use success messages. Node18 frontend and both backend captures include nativeExit=0; earlier Node22 frontend captures lack that appended exit line. Legacy auth diagnostics and Browserslist noise are M2.

**NC5 - Lint evidence.** Inspected task-14-final-lint.txt: nativeExit=0, no ESLint code diagnostics, inherited Browserslist stderr. No lint or package-wide test rerun was made.

**NC6 - Scope/contracts.** All eleven specified F files and all six amended B paths have corresponding hunks. Dependencies, lockfiles, general staff projections, PATCH implementation and broad route authorization were not changed in these packages. Existing customer transport, auth/session persistence and kiosk implementation paths were not replaced; compatibility confidence additionally comes from NC4, not from a new whole-branch audit. Read the brief first, then worker context, author report/integration notes, common plan contracts and applicable mobile/state/payment/privacy/authority design sections. Task7's superseding financial consumer fields were checked in task-7-report.md:1063; no mission-derived financial projection is introduced.

**NC7 - Review boundaries.** workspace_fs denied the paired worktree path; used the worker-context-authorized shell fallback. Read each complete review package once, with nonoverlapping frontend chunks; no hunk was cut off and no changed source was separately displayed for static inspection. No git command or diff regeneration, nested agent, branch/index/source edit, provider action, original-checkout access, real environment read, remote DB/payment/print/call, browser/detector, server action, push or deploy occurred. No outside implementation source was inspected for an additional contract hypothesis. The only file written is this report.

**Limit - Visual acceptance:** PENDING Task17 ONEbatch: real Vuetify/browser layout, portrait/landscape, long names/addresses, network-error visibility, different payment missions, touch targets, icon rendering and overflow. Behavioral SFC tests use Vuetify primitive stubs and cannot settle those checks.

## Assessment

**Task quality: Needs fixes.**

**Counts:** Critical 0; Important 1 (I1); Minor 2 (M1, M2).

The implementation is appropriately scoped and the author evidence supports most required behavior. I1 leaves a reproducible privacy regression under overlapping reads, so both spec compliance and quality require a fix before this task gate can pass; visual acceptance remains separately pending Task17.

