# Task 4: durable delivery settlement and archive

## Status and Commit

**DONE_WITH_CONCERNS, ready for controller independent review.** No remaining Task4 ownership blocker or implementation step. Author self-review only; no subagents or reviewers were spawned.

- B: `C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos`
- Branch: `feat/delivery-v1`
- BASE: `739f9dd24100ce387f6651e412df088c60867c03`
- Commit: **`c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8`**
- Message: `fix: preserve delivery through settlement and archive`
- Compatible F contract HEAD: `6f694519d0db9ee631fe9d85550af71165dac293`; the amended Task4 brief, integration notes and direct controller rulings were binding.
- Post-commit B status: exactly `## feat/delivery-v1`, clean. Persistent `core.hooksPath` remains `.githooks`.

Read the Task4 brief first, then worker context, integration notes, common contracts, specification sections 3/5/6/7/10 and Task3's integration/follow-up report. No other task plans or ledger were loaded. `workspace_fs` was unavailable; shell reads in the paired worktrees follow the worker-context exception. Source edits are confined to the eleven owned B files. This report and command-output artifacts are in authorized F scratch only.

## Files and Behavior

1. `src/modules/m_deliveryOrders.js`: commercial-first locked resolution; current locked charge-snapshot reads after a wait; new `archiveDeliveryOrder`; safe-cent financial projection; original-order commercial resolution across active/archive representations. Creation, accepted replay journal, tracking URL/token and revision producers retain their existing semantics.
2. `src/modules/m_orders.js`: changes the actual exported transactional archive builder, not its dead legacy definition. Copies delivery/customer/fulfillment links, accepted product/discount fields, product VAT and customization snapshots; saves preparation before active deletion in the same transaction. Requires preparation status 3 and compatible payment resolution. An unpaid delivery requires an explicit cashier payment method; pending Stripe/Terminal, hidden deletion and a new inline discount are refused. Validates accepted products plus fee against total and Terminal allocation. Delivery archive bypasses legacy product-discount redistribution. Adds guarded transactional manual collection and financial/original-payment-reference projection to active detail and archive detail/history reads.
3. `src/modules/m_payments.js`: commercial locks and refund reconciliation resolve the original order reference under its shop, including after archive. Refund updates target the actual archive PK internally while payment metadata/records retain the original ID. Keeps the historical active-order refund JOIN first, including intent/status coherence. Delivery settlement/refund/fallback preserves preparation status/timing; non-delivery branches keep their former behavior. Checks delivery payment cents against the accepted commercial total.
4. `src/modules/m_orderTransitions.js`: rejects generic legacy delivery cancellation in favor of its explicit commercial workflow; normal preparation transitions remain available.
5. `src/controllers/c_orders.js`: routes linked delivery manual collection through the transactional guard instead of unconditional `mUpdateOrders`. Delivery archive does not silently cancel/substitute a pending Stripe payment. New delivery errors use domain codes or generic unexpected-error responses.
6. `src/controllers/c_stripe.js`: payment start resolves current delivery/commercial state before calling Stripe, rather than trusting frozen checkout replay. Reuses an attached pending intent; refuses paid/archive/terminal state. Production replacement start resolves even Task3's bare producer object and checks current eligibility plus unchanged attempt token, attached intent and accepted amount. Delivery creation failures retain the durable pending attempt for reconciliation/retry rather than implicitly canceling/restocking it. Delivery provider errors are logged without payloads. Refunds include the entire accepted amount, explicitly including the fee; Terminal refund lookup falls back from the existing active path to durable commercial resolution.
7. `src/helpers/cashRegisterPayment.js`: shared accepted-discount and collection-eligibility guards; preserves paid/refunded delivery commercial identity and method. An omitted/zero settlement discount preserves the accepted discount, as does an exact unchanged resubmission; a new discount requires requote/reconfirmation.
8. `src/services/stripeTerminalPayments.js`: a selection containing delivery refuses any nonzero payment-time group discount before allocation/provider mutation. Uses the existing allocation helper with accepted grand totals, including fees.
9. `src/modules/m_stripeTerminal.js`: retains sorted active-order locks before payment-session locks; resolves missing settled delivery allocations through archive for refund/replay. Checks delivery allocation against its accepted total, updates archived refund state through its archive PK and preserves preparation timing. Named-lock scalar checks accept numeric or string 0/1 from the actual mysql2 driver.
10. `test/delivery-archive-payments.integration.test.js`: thirteen final focused disposable-SQL scenarios using production repositories, modules, exported controllers/webhook handlers and actual transactions. Only provider boundaries are substituted; the targeted mutation/rollback barriers forward real SQL. New-ID accuracy also runs through a separate production-style pool with `supportBigNumbers:false`.
11. `package.json`: appends this test to `test:delivery:db`; preserves the entire existing `npm test` script.

`src/helpers/stripeTerminal.js` did not need modification. Its allocation algorithm is reused, not duplicated. No dependency, migration, router, frontend source, real environment or configuration file was edited.

## Interfaces for Later Tasks

- `archiveDeliveryOrder({shopId, deliveryId, archiveId, preparationStatus, connection})`: requires the caller's transaction. Validates same-shop archive/dossier linkage, preparation 3 and paid/refunded archive state, then persists the preparation snapshot. Does not set payment/logistics state, bump logistics version, create a second sale or open a nested transaction.
- `resolveDeliveryOrder({shopId, deliveryId, connection?, forUpdate?})`: existing return shape `{delivery, order, orderKind}` remains. New IDs are strings. For an archived result `order.id` remains the archive's historical PK as before; payment callers must use the stable original reference, not that PK.
- `resolveCommercialOrder({shopId, orderId, connection?, forUpdate?})`: `orderId` is the original historical order ID. Returns the active row, or a linked delivery archive with `id` normalized to that original ID and an additional internal `archive_id`. New link IDs are SQL-cast strings. Archive fallback requires shop context; no lookup by a guessed archive PK.
- `m_orders.findCommercialOrderById(orderId, shopId)`: array-returning adapter for existing controller conventions.
- `m_orders.collectDeliveryOrderPayment({orderId, shopId, paymentMethod, discount})`: transactionally locks/rechecks eligibility, the accepted snapshot and pending Terminal allocations, then performs one manual collection. Duplicate/already-paid/pending-provider attempts are conflicts; archived targets are unavailable. No provider call occurs in this transaction.
- Production `regenerateOrderPaymentIntent` wires `resolveOrder: findCommercialOrderById` into the existing injectable builder. It resolves the real representation even when its input lacks `delivery_id`, as Task3's immediate amendment producer does. For delivery, an old attempt token/attached intent/amount returns `ORDER_EDIT_CONFLICT` before a provider call; paid/archive state returns `DELIVERY_PAYMENT_NOT_SETTLED`. Custom production builders handling bare inputs should supply the same array-returning resolver. The existing isolated legacy builder tests remain injectable without an implicit database dependency.
- `financials`: `{items_total, items_discount, delivery_fee, grand_total, delivery_charge}` in the common euro-plus-cent/fiscal-snapshot contract. Detail/history delivery rows also expose these euro fields at top level, with `subtotal` retaining the grand total. History/detail add `originalorderID` and `payment_order_id` for refund/payment consumers; archive `id` remains its own PK. Header history is decorated once per distinct dossier per response.
- `DELIVERY_REQUOTE_REQUIRED`: no new inline collect/archive discount, and no nonzero Terminal group discount when any selected order is delivery. Legacy non-delivery discount behavior remains. Task15 should submit zero/omitted settlement discounts for delivery and use Task3 explicit unpaid/pre-pickup revision/requote for price changes.
- `DELIVERY_PREPARATION_NOT_FINISHED`, `DELIVERY_PAYMENT_NOT_SETTLED`, `DELIVERY_TOTAL_MISMATCH`, `DELIVERY_ARCHIVE_NOT_ALLOWED`, `DELIVERY_TRANSITION_NOT_ALLOWED`: explicit boundary errors rather than implicit settlement/preparation/logistics changes.

`findCheckoutReplay` remains the exact accepted event snapshot without a renewed tracking URL. Its initial `unpaid`/`requires_payment` status is deliberately frozen. It is not payment-start authority. The regression invokes the actual durable replay producer and Stripe controller against a paid active order and its real archive, asserts no provider creation, and compares the replay unchanged. Terminal start locks/rechecks current orders; manual collection rechecks current commercial state under lock.

## Lock Protocol and Actual SQL Evidence

Use **commercial row before delivery row**, followed by effective charge-snapshot current read when locking. The resolver first reads only the immutable dossier/original-order identity without a row lock, then locks the active commercial PK or its archive, then locks/revalidates the dossier. This composes with Task3 amendment's existing commercial-first protocol. Reading the effective charge with `FOR UPDATE` is essential: the immutable identity pre-read establishes a repeatable-read snapshot that may predate the revision committed by a transaction on which the commercial lock waited.

Archive retains **shop -> active order -> delivery -> details/copy/delete**. Any caller needing the archive shop lock must acquire it before commercial/dossier locks. No new caller locks a dossier then waits for its commercial order.

Terminal retains **sorted active orders -> payment session**. Missing settled delivery representations are resolved to archive before the payment-session lock; it never acquires a delivery lock. The immutable allocation read identifies original IDs and whether a settled representation can have archived. No payment-first finalization, fabricated lock-count assertions or duplicated allocator was introduced.

The SQL tests query `performance_schema.data_lock_waits` by the actual waiting connection ID before releasing barriers. They prove:

- The original resolver/commercial mutation cycle produces `ER_LOCK_DEADLOCK` RED; commercial-first resolution waits and completes GREEN.
- A committed concurrent charge revision is visible after the wait; the intermediate plain snapshot read produced `DELIVERY_CHARGE_MISSING` RED.
- Actual Task3 amendment (its explicit refusal path after real locks) and the production archive builder overlap with standalone dossier resolution, with no cycle and correct active/archive result.
- Actual grouped Terminal finalization overlaps a competing start and archive; finalization commits, start revalidates paid orders and refuses, archive succeeds. Archive keeps its existing shop serialization.
- Two manual collectors produce one 200 and one 409. Manual collection racing Stripe success refuses substitution, while Stripe remains authoritative.
- A persisted pending Terminal allocation blocks both manual collection and explicit cashier archive, even though the order itself is still `unpaid` and has no finalized Terminal ID.

## RED/GREEN Commands and Outputs

All SQL runs execute in B with this explicit authorized local fixture URL, and never use an application catalog:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:ENV_FILE='NUL'
node test/delivery-archive-payments.integration.test.js
```

The helper creates/drops only random `smarteat_delivery_test_*` databases. `ENV_FILE=NUL` prevents reading a real environment file. Output was retained with `2>&1 | Tee-Object -FilePath <absolute-scratch-log>` and `exit $LASTEXITCODE`.

Genuine pre-implementation RED, exit 1, `task-4-red.txt`:

```text
FAIL SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery: ERR_ASSERTION
FAIL SQL kitchen archive cannot collect and cashier preserves accepted discount: ERR_ASSERTION
FAIL SQL manual delivery collection refuses duplicate pending Stripe and inline discounts: ERR_ASSERTION
FAIL SQL standalone resolver and commercial-first mutation have no SQL lock cycle: ER_LOCK_DEADLOCK
FAIL SQL mixed Terminal selection rejects new discount before provider and allocation: ERR_ASSERTION
FAIL SQL Terminal settles full accepted fee and archive preserves product VAT: TERMINAL_INTERNAL_ERROR
ERR_ASSERTION Delivery settlement/archive regressions must pass
```

The last initial failure was a real driver/named-lock boundary failure, not evidence that the negative-fee archive branch had executed. Diagnostics in `task-4-terminal-diagnostic.txt` and `task-4-terminal-diagnostic-2.txt` localized it to acquisition. A separate actual SQL characterization returned `GET_LOCK scalar: string 1` and `RELEASE_LOCK scalar: string 1` with `supportBigNumbers:true, bigNumberStrings:true`; accepting both driver scalar representations resolved it. `task-4-terminal-driver-green.txt` exited 0. The temporary test diagnostics were removed. The packet-order warnings in the earlier failed runs did not recur in passing runs.

Additional focused RED runs all exited 1 before their corresponding fixes:

| Log | `TASK4_TEST_FILTER` | Failure |
| --- | --- | --- |
| `task-4-replay-red.txt` | `frozen checkout replay` | Provider creation reached despite actual paid order. |
| `task-4-pending-terminal-red.txt` | `pending Terminal allocation` | Explicit cashier archive could bypass pending allocation. |
| `task-4-current-snapshot-red.txt` | `standalone resolver` | `DELIVERY_CHARGE_MISSING` after a concurrent revision committed. |
| `task-4-preparation-time-red.txt` | `kitchen archive\|Terminal settles` | Counter fallback reset preparation; Terminal settlement rewrote its timestamp. |

Full native Node22 registered SQL command, **exit 0**, `task-4-delivery-db.txt`:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:ENV_FILE='NUL'
npm.cmd run test:delivery:db
```

This passed existing schema (including up/down/up), financial journal, quote/settings/quota, Task3 checkout/guards/edit/replay tests, followed by all twelve Task4 scenarios:

```text
PASS SQL frozen checkout replay cannot start another Stripe payment after paid or archive
PASS SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery
PASS SQL delivery archive rollback restores active rows and durable preparation snapshot
PASS SQL legacy driver preserves exact BIGINT dossier through production archive
PASS SQL kitchen archive cannot collect and cashier preserves accepted discount
PASS SQL manual delivery collection refuses duplicate pending Stripe and inline discounts
PASS SQL standalone resolver and commercial-first mutation have no SQL lock cycle
PASS SQL actual amendment and archive serialize with standalone dossier resolution
PASS SQL mixed Terminal selection rejects new discount before provider and allocation
PASS SQL pending Terminal allocation blocks cashier archive and manual collection
PASS SQL actual grouped Terminal finalization start and archive have no SQL lock cycle
PASS SQL Terminal settles full accepted fee and archive preserves product VAT
delivery archive/payment SQL tests passed
```

`task-4-green.txt` is the earlier standalone GREEN before the final extra race/BIGINT assertions. `task-4-green-attempt.txt` is a historical failed attempt at the driver boundary, not passing evidence.

After the full registered run, self-review added the preparation-timing assertions and actual webhook-handler replay calls. The timing RED above was fixed with delivery-only SQL CASE expressions. Final focused native Node22 command used `TASK4_TEST_FILTER='kitchen archive|Terminal settles|paidDoes'`; **exit 0**, `task-4-preparation-webhooks-green.txt`:

```text
PASS SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery
PASS SQL kitchen archive cannot collect and cashier preserves accepted discount
PASS SQL Terminal settles full accepted fee and archive preserves product VAT
delivery archive/payment SQL tests passed
```

These final tests invoke the actual web success handler after archive, and the actual Terminal webhook handler after archive/refund, retaining idempotence and refunded state. Both web and Terminal full refunds assert **2400 cents**, including the fee. Product VAT, customization snapshots, courier 11, delivery status `assigned`, preparation 3, zero remaining due and stock/payment uniqueness survive archive/refund. Injected failure after active deletion rolls back the archive, details/customizations and durable preparation update.

## Legacy Suite and Runtime Evidence

Ran **`npm.cmd test` exactly once**, with `ENV_FILE=NUL`; full output is `task-4-npm-test.txt`. It exited 1 at `default refund lookup preserves eligible web orders without an extra Terminal lookup` (500 instead of 200). Restored the existing active lookup before durable fallback; its final affected file passes **33/33**.

Per the instruction not to repeat broad suites, continued from each failed/unrun boundary rather than restarting `npm test`. Each continuation reads `package.json.scripts.test`, splits its existing `node test/<file>.test.js && ...` list, and invokes only the suffix with `spawnSync(process.execPath, [file], {stdio:'inherit', env:process.env})`. All **62** backend test files have passing results across the original prefix and these targeted continuations:

| Log | Boundary / result |
| --- | --- |
| `task-4-npm-continuation.txt` | From `stripe-terminal-refunds.test.js`; that file passes 33/33, later stops at `service-points-controller.test.js` because `ENV_FILE=NUL` supplies no JWT key. |
| `task-4-npm-remaining.txt` | From `service-points-controller.test.js` with disposable `JWTKEY='task4-local-signing-fixture-only'`; passes it, then exposes `stripe-payment.test.js`'s historical active-refund JOIN contract. Restored the real active JOIN, not a fake source comment or a weakened test. |
| `task-4-npm-final-remaining.txt` | From `stripe-payment.test.js`; Stripe/payment/refund/archive/stock files pass; stops at `product-stock-tracking.test.js` because the old test expects `PUBLICIMAGEPATH`. |
| `task-4-npm-final-tail.txt` | From `product-stock-tracking.test.js` with the same disposable JWT key and `PUBLICIMAGEPATH` set to the absent `task-4-absent-image-fixture` directory in F scratch; **exit 0**, reaches the last admin-password test and `PASS fixture configuration and all final npm test commands`. No image directory or file was created/deleted. |

The missing JWT/image-path failures are fixture configuration omissions from intentionally disabling real env loading, not fixes to unowned production code. Do not describe the original `npm test` invocation as exit 0. Its failed cases are all recorded above and subsequently passed.

Additional native Node22 `node test/order-editing.test.js` passed. After the final preparation SQL correction, reran only four affected legacy files (`stripe-payment`, `stripe-terminal-module`, `stripe-terminal-locking`, `stripe-terminal-refunds`), all **exit 0**, in `task-4-preparation-legacy-green.txt`. Earlier focused Terminal module/locking/payment runs also passed; no additional full-suite repetition occurred.

Node18 executable: `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`.

- `task-4-node18-sql.txt`: full twelve-scenario Task4 SQL run **exit 0** before the final preparation/webhook strengthening.
- `task-4-node18-final-preparation-webhooks.txt`: the same final three-case filter as Node22, **exit 0**, with identical PASS output.
- `task-4-node18-legacy-final.txt`: checkout contract, order editing and Stripe payment tests all **exit 0** using the actual dependency bridge in isolated test processes:

```js
require.cache[require.resolve("nanoid")] = { exports: await import("nanoid") };
require(testFile);
```

The first compatibility attempt (`task-4-node18-legacy.txt`) lacked the disposable image-path setting and failed `ERR_INVALID_ARG_TYPE`; final run supplies it, plus `ENV_FILE=NUL` and the disposable JWT key. Node18 emitted its existing `buffer.File` experimental warning. No global runtime/dependency patch or token/handler stub was installed. Node22 Task4 SQL runs load Nano ID natively (the test bridge is conditional on Node major <22).

## Self-Review and Limits

Reviewed the complete staged diff against the amended ruling and actual services. Confirmed the live archive export, rollback boundary, original/archive-ID distinction, same-shop payment references, exact BIGINT strings through the production-style pool, accepted discount/fee separation, unmodified product VAT, pending allocation guard, actual lock waits, immutable replay, actual success/refund handlers and no second mutable paid state in `deliveries`.

Corrected findings during self-review were reproduced RED: named-lock driver scalar handling, repeatable-read charge visibility, pending Terminal archive substitution, frozen replay payment start, preparation timestamp/status overwrite and stale replacement-attempt adoption (including the actual bare producer shape). Legacy test failures also restored the historical lookup/JOIN behavior. Final whitespace/staged checks exited 0 with only Git's existing LF-to-CRLF notices.

Remaining concerns are bounded:

- Plain Node18 legacy CommonJS `require(nanoid)` production boot remains a pre-existing incompatibility. Only compatibility tests use the real ESM import/cache bridge. This task does not claim it repaired native Node18 boot. The controller's previously passing unbridged configured Docker Node20.20.2 Nano ID probe is not a full-app boot result, and was not rerun here.
- No real Stripe, geocoding, email, WhatsApp, OTP or recipient call was made. Provider boundaries were local stubs. No real environment was read/decrypted, remote DB migrated, dependency/runtime patched, image data removed, server started, push/deploy/merge performed, original checkout edited or shared branch changed.
- Dispatch/courier collection/cash ledger, payout UI, receipt/report adaptation and commissioning remain their later approved task owners. Later mutations must follow the commercial-before-dossier protocol; Task4 does not add those services or mutable paid/balance state to the dossier.
- Independent review is intentionally left to the controller. There is no indispensable extra-file proposal and no unfinished owned-file implementation.

## Commit Evidence

Staged exactly the eleven files above, then ran `git diff --cached --check`, `git diff --cached --stat`, and the original scoped commit. Final interface review added the bounded stale-attempt regression/fix described below; amended only this unpublished local commit, with the same invocation-local hook override:

```powershell
git -c core.hooksPath=.git-hooks-disabled-task4 commit -m "fix: preserve delivery through settlement and archive"
git add -- src/controllers/c_stripe.js test/delivery-archive-payments.integration.test.js
git diff --cached --check
git -c core.hooksPath=.git-hooks-disabled-task4 commit --amend --no-edit
git rev-parse HEAD
git status --short --branch
git config --get core.hooksPath
```

All exited 0. Commit output:

```text
[feat/delivery-v1 c9c41c2] fix: preserve delivery through settlement and archive
 11 files changed, 826 insertions(+), 92 deletions(-)
 create mode 100644 test/delivery-archive-payments.integration.test.js
c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8
## feat/delivery-v1
.githooks
```

The hook override was invocation-local, as authorized; no environment encryption/staging occurred. The report and local output logs are not part of the backend commit. No push.

## Final Stale-Attempt Follow-Up

The intermediate unpublished commit `478a96d8e552f3a735960e58bfe535db38858ea8` was superseded by the final amended SHA above. Final source changes still touch only the same eleven Task4-owned files.

Final review found that refreshing a delivery replacement's order object could adopt a newer attempt token while retaining the older content-revision idempotency key. Also, Task3's immediate post-amendment controller passes a bare commercial object without `delivery_id`. Both observations were covered before finalizing; `c_orderEditing.js` was read but not edited.

- `task-4-replacement-red.txt`, exit 1: old attempt could adopt current state when a delivery marker was present.
- `task-4-replacement-bare-red.txt`, exit 1: actual bare producer shape bypassed marker-only detection.
- `task-4-replacement-green-node22.txt` / `task-4-replacement-green-node18.txt`: intermediate marker-present targeted checks passed before strengthening the producer-shape test; these are not the final factory-wiring evidence.
- `task-4-replacement-bare-green-node22.txt`, exit 0: actual exported production regeneration service with real SQL/shop lookup and only the Stripe boundary substituted. Old bare attempt is refused before any create; the current bare attempt creates/attaches exactly once; further calls after actual success and real archive are refused without a second creation. Frozen accepted checkout replay also passes unchanged.
- `task-4-replacement-bare-legacy-green.txt`, exit 0: affected Stripe payment and order-editing legacy files pass after the final production resolver wiring. `task-4-replacement-legacy-green.txt` records the earlier focused Stripe PASS.

Final native Node22 filtered command, with the same explicit disposable URL and `ENV_FILE=NUL`:

```powershell
$env:TASK4_TEST_FILTER='stale delivery replacement|frozen checkout replay'
node test/delivery-archive-payments.integration.test.js
```

Output:

```text
PASS SQL frozen checkout replay cannot start another Stripe payment after paid or archive
PASS SQL stale delivery replacement cannot adopt a newer accepted payment attempt
delivery archive/payment SQL tests passed
```

Finally executed the entire final Task4 SQL file with native Node18 and its fixture-local real Nano ID bridge, without a filter. **Exit 0**, `task-4-final-node18-sql.txt`: all thirteen scenarios pass, including all earlier archive/lock/driver/preparation/refund cases under the final provider fixture and factory wiring. This does not claim unbridged Node18 boot. No full npm or registered cross-task SQL suite was repeated for this bounded follow-up.

```text
PASS SQL frozen checkout replay cannot start another Stripe payment after paid or archive
PASS SQL stale delivery replacement cannot adopt a newer accepted payment attempt
PASS SQL paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery
PASS SQL delivery archive rollback restores active rows and durable preparation snapshot
PASS SQL legacy driver preserves exact BIGINT dossier through production archive
PASS SQL kitchen archive cannot collect and cashier preserves accepted discount
PASS SQL manual delivery collection refuses duplicate pending Stripe and inline discounts
PASS SQL standalone resolver and commercial-first mutation have no SQL lock cycle
PASS SQL actual amendment and archive serialize with standalone dossier resolution
PASS SQL mixed Terminal selection rejects new discount before provider and allocation
PASS SQL pending Terminal allocation blocks cashier archive and manual collection
PASS SQL actual grouped Terminal finalization start and archive have no SQL lock cycle
PASS SQL Terminal settles full accepted fee and archive preserves product VAT
delivery archive/payment SQL tests passed
```
