### Task 4: Preserver livraison et totaux lors des paiements et archives

**Controller settlement ruling:** Delivery discounts/price changes must use task3 explicit unpaid/pre-pickup revision/requote/reconfirmation. Legacy collect/archive/Terminal settlement reject a new inline discount for delivery and use its accepted product/fee snapshots only; mixed selections containing delivery cannot silently apply a group discount to fees. Non-delivery behavior unchanged. Task15 adapts payout UI accordingly. Guard delivery manual collection transactionally against already-paid/pending-Stripe races, not the existing unconditional legacy update. Read task-4-integration-notes.md for actual archive path and Terminal allocation risks. If existing `B/src/helpers/stripeTerminal.js` needs a narrow shared allocation change, use the real owner rather than duplicating its algorithm. See progress.md ruling/cost.

**Files:** Create `B/test/delivery-archive-payments.integration.test.js`; modify `B/src/modules/m_deliveryOrders.js`, `B/src/modules/m_orders.js`, `B/src/modules/m_payments.js`, `B/src/modules/m_orderTransitions.js`, `B/src/controllers/c_orders.js`, `B/src/controllers/c_stripe.js`, `B/src/helpers/cashRegisterPayment.js`, `B/src/services/stripeTerminalPayments.js`, `B/src/modules/m_stripeTerminal.js`, `B/package.json`.

**Interfaces:** Produit `archiveDeliveryOrder` et la projection financiere commune `financials` du plan principal. Le paiement demeure dans la commande active/archivee et les paiements existants ; aucun second etat paye mutable dans `deliveries`. La resolution d'une reference de paiement recherche la representation active ou archivee par lien stable, sous le commerce verifie.

- [ ] **Step 1: Ecrire `paidDoesNotFinishKitchenAndArchiveDoesNotFinishDelivery`**, puis cas paiement/refund sur archive. Avec preparation en cours et paiement paye, archiver => refus livraison specifique, commande toujours active. Apres fin de preparation, archiver => commande active absente, dossier encore attribue et montant du nul. Rejouer un webhook reussi apres archivage => aucun doublon ; remboursement complet de 2400 centimes => frais compris et etat rembourse visible dans le dossier.
  ```js
  assert.equal(viewAfterArchive.deliveryStatus, 'assigned')
  assert.equal(viewAfterArchive.remainingDueCents, 0)
  assert.equal(refundAmountCents, 2400)
  assert.equal(viewAfterRefund.paymentStatus, 'refunded')
  ```
- [ ] **Step 2: Executer** `node test/delivery-archive-payments.integration.test.js` ; attendu rouge sur disparition/total ou controle cuisine.
- [ ] **Step 3: Ajouter les branches livraison ciblees** aux transactions d'archivage/edition/paiement, sans changer les parcours historiques. Etendre les gardes de fin de preparation, copier les liens et snapshots avant suppression active, puis relire via `resolveDeliveryOrder`. Les encaissements Terminal en caisse doivent utiliser le total autoritatif incluant les frais ; une remise aux articles ne peut pas redistribuer silencieusement les frais dans les details produits. Adapter ces allocations et leurs validations, pas seulement le montant du PaymentIntent. Remboursement/logistique restent des actions distinctes.
- [ ] **Step 4: Executer test vert** puis `npm.cmd test` backend. Ajouter ce test au script SQL et verifier les tests checkout, Stripe, Terminal, annulation, refund et archive sur base jetable.
- [ ] **Step 5: Commit `fix: preserve delivery through settlement and archive`** dans `B`.

