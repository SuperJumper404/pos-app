const fs = require('fs');
const path = require('path');
const qa = require('./ui-qa.cjs');
const { chromium, openContext, capture, go, report, reportPath, output, origin, clone, balance, missions, charge, shop } = qa;
report.mode = 'finance';
const item = { id: 1001, shopid: 7, orderid: 1001, productid: 21, name: 'Menu de recette', product_name: 'Menu de recette', customer: 'Client de recette', qty: 1, price: 20, total: 20, total_ht: 18.18, total_vat: 1.82, vat_rate: 10, subtotal: 24, subtotal_before_discount: 20, discount_type: 'none', discount_value: 0, discount_amount: 0, payment: 'Especes', payment_status: 'paid', status: 3, created: '2026-10-18T10:00:00Z', archived_at: '2026-10-18T10:30:00Z', is_takeaway: 1, source: 'web', fulfillment_type: 'delivery', delivery_id: '501', delivery_status: 'assigned', financials: { items_total: 20, grand_total: 24, delivery_charge: charge } };
Object.assign(item, { ordernumber: 'LIV-2026-000001', order_source: 'web' });
const currentClosure = { id: '301', closure_number: 'Z-0003', opened_at: '2026-10-18T10:00:00Z', closed_at: '2026-10-18T11:00:00Z', orders_count: 0, total_revenue: 0, payments_summary: [], vat_summary: [], courier_cash: { register_cash_sales_cents: 0, courier_cash_sales_cents: 0, collected_cents: 0, received_cents: 1650, outstanding_cents: 750, manual_refunded_cents: 0, cash_refunded_by_register_cents: 0, cash_refunded_by_courier_cents: 0, external_card_refunded_cents: 0, remittances_count: 1, adjustments_count: 0, refunds_count: 0 } };
const dialog = page => page.locator('.v-dialog--active');
const select = async (page, label, option) => {
  await page.locator('.v-select').filter({ has: page.getByLabel(label, { exact: true }) }).locator('.v-input__slot').click();
  await page.getByRole('option', { name: option, exact: true }).click();
};
async function one(browser, size, viewport) {
  if (process.argv[2] !== 'documents') {
  if (process.argv[2] !== 'courier-confirm') {
  const operator = await openContext(browser, 'admin', viewport);
  let financial = clone(balance);
  let conflict = true;
  let refunded = false;
  operator.state.handleApi = ({ path: p, method, body }) => {
    if (/cash-balance$/.test(p)) return { data: financial };
    if (/\/remittances$/.test(p) && method === 'POST') {
      if (conflict) { conflict = false; financial = { ...financial, remainingDueCents: 950, version: 5 }; return { data: {}, status: 409, error: 'COURIER_CASH_VERSION_CONFLICT' }; }
      const response = { remittanceId: '802', expectedCents: 950, receivedCents: body.receivedCents, discrepancyCents: body.receivedCents - 950, remainingDueCents: Math.max(0, 950 - body.receivedCents) };
      financial = { ...financial, remainingDueCents: response.remainingDueCents, version: 6 };
      return { data: response };
    }
    if (/refund-eligibility$/.test(p)) return { data: { eligible: !refunded, collectionId: '701', method: 'cash', amountCents: 2400, originalCourierId: 11, returnSources: ['register', 'courier'] } };
    if (/\/refund$/.test(p)) { refunded = true; return { data: { refundId: '901', amountCents: 2400, method: 'cash', returnSource: body.returnSource } }; }
    if (/\/deliveries\/503$/.test(p)) return { data: { ...missions[2], paymentStatus: refunded ? 'refunded' : 'paid' } };
    if (p === '/delivery/settings' && method === 'PUT') return { status: 503, error: 'DELIVERY_UTC_SESSION_REQUIRED', data: {} };
  };
  await go(operator.page, '/livraison');
  await operator.page.getByRole('tab', { name: "Remises d'especes", exact: true }).click();
  await select(operator.page, 'Detenteur des fonds', 'Livreur de recette');
  await operator.page.getByLabel('Especes reellement recues (EUR)', { exact: true }).fill('5.00');
  await operator.page.getByRole('button', { name: 'Confirmer la remise', exact: true }).click();
  await capture(operator.page, `remittance-conflict-${size}`, ['9,50', 'nouvelle confirmation']);
  await operator.page.getByRole('button', { name: 'Confirmer le nouvel attendu', exact: true }).click();
  await capture(operator.page, `remittance-confirmed-${size}`, ['4,50', 'Remise #802']);
  const previousTab = operator.page.locator('.v-tabs .v-slide-group__prev:not(.v-slide-group__prev--disabled)');
  if (viewport.width < 600 && await previousTab.isVisible()) { await previousTab.click(); await operator.page.waitForTimeout(350); }
  await operator.page.getByRole('tab', { name: 'Commandes', exact: true }).click();
  await operator.page.getByRole('button', { name: 'Actions livraison', exact: true }).nth(2).click();
  await operator.page.getByText('Remboursement manuel complet', { exact: true }).click();
  await capture(operator.page, `refund-dialog-${size}`, ['24,00', 'Detenteur initial']);
  await select(operator.page, 'Restitution effectuee par', 'Caisse du restaurant');
  await operator.page.getByLabel('Motif du remboursement', { exact: true }).fill('Restitution de recette, aucun mouvement reel.');
  await dialog(operator.page).locator('input[type="checkbox"]').check({ force: true });
  await dialog(operator.page).getByRole('button', { name: 'Confirmer la restitution', exact: true }).click();
  await capture(operator.page, `refund-confirmed-${size}`, ['Restitution enregistree', '4,50']);
  await dialog(operator.page).getByRole('button', { name: 'Fermer', exact: true }).click();
  await operator.page.getByRole('tab', { name: 'Reglages', exact: true }).click();
  await operator.page.getByRole('button', { name: 'Enregistrer les reglages', exact: true }).click();
  await capture(operator.page, `settings-utc-refusal-${size}`, ['UTC', 'anciennes archives']);
  await operator.context.close();
  }

  const courier = await openContext(browser, 'courier', viewport);
  await go(courier.page, '/livreur');
  const mission = courier.page.locator('.courier-mission').filter({ hasText: 'LIV-2026-000002' });
  await mission.locator('.v-select .v-input__slot').click();
  await courier.page.getByRole('option', { name: 'Carte externe (declaration manuelle)', exact: true }).click();
  await capture(courier.page, `courier-manual-card-${size}`, ['declaration manuelle', 'TPE independant']);
  await mission.getByRole('button', { name: 'Signaler un probleme', exact: true }).click();
  await mission.getByLabel('Motif du probleme', { exact: true }).fill('Adresse inaccessible en recette.');
  await capture(courier.page, `courier-issue-form-${size}`, ['Confirmer le signalement']);
  courier.state.fail = '/courier/deliveries';
  await courier.page.getByRole('button', { name: 'Actualiser les missions et le solde', exact: true }).click();
  await capture(courier.page, `courier-network-error-${size}`, ['Lecture impossible']);
  courier.state.fail = null;
  await courier.page.getByRole('button', { name: 'Actualiser les missions et le solde', exact: true }).click();
  await capture(courier.page, `courier-network-recovered-${size}`, ['LIV-2026-000001']);
  report.interactions.push({ name: `courier-recovery-banner-${size}`, staleBanner: await courier.page.getByText('Lecture impossible. Actualisez avant de continuer.', { exact: true }).isVisible() });
  if (process.argv[2] === 'courier-confirm' && await courier.page.getByText('Lecture impossible. Actualisez avant de continuer.', { exact: true }).isVisible()) report.failures.push({ name: `courier-recovery-${size}`, staleReadError: true });
  await courier.context.close();
  }
  if (['dialogs', 'courier-confirm'].includes(process.argv[2])) return;

  const checkout = await openContext(browser, 'admin', viewport);
  checkout.state.handleApi = ({ path: p }) => {
    if (p === '/orders/archives') return { data: [item] };
    if (p === '/detailorder/1001' || p === '/detailorder/archive/1001') return { data: [item] };
    if (p === '/reports/z/current') return { data: currentClosure };
    if (p === '/reports/z') return { data: [{ ...currentClosure, id: '300', orders_count: 1, total_revenue: 24 }] };
    if (p === '/reports/z/300') return { data: { ...currentClosure, id: '300', orders_count: 1, total_revenue: 24 } };
  };
  await go(checkout.page, '/compte?shopId=7');
  await checkout.page.evaluate(async () => {
    const store = window.$nuxt.$store;
    await store.dispatch('users/restoreAuthenticatedUser');
    await store.dispatch('cart/setTocart', [{ id: 21, name: 'Menu de recette', qty: 1, price: 20, subtotal: 20, selectedChoiceIds: [] }]);
    await store.dispatch('cart/setTotal', 20);
    await window.$nuxt.$router.push('/cart');
  });
  await checkout.page.locator('.delivery-checkout').waitFor();
  await select(checkout.page, 'Mode de remise', 'Livraison');
  await capture(checkout.page, `pos-delivery-checkout-${size}`, ['Mode de remise', 'Adresse de livraison']);
  const inputs = checkout.page.locator('.delivery-checkout');
  await inputs.getByLabel('Numero et voie', { exact: true }).fill('7 avenue des Ateliers');
  await inputs.getByLabel('Code postal', { exact: true }).fill('75011');
  await inputs.getByLabel('Ville', { exact: true }).fill('Paris');
  await checkout.page.getByRole('button', { name: 'Confirmer ce total', exact: true }).waitFor();
  await capture(checkout.page, `pos-delivery-quote-${size}`, ['24,00', '4,00']);
  await checkout.page.getByRole('button', { name: 'Confirmer ce total', exact: true }).click();
  await capture(checkout.page, `pos-delivery-confirmed-${size}`, ['Total confirme']);
  await checkout.page.evaluate(async () => {
    await window.$nuxt.$store.dispatch('users/set/user.order_source', 'web');
    window.$nuxt.$store.commit('customer/RESET', 7);
  });
  await capture(checkout.page, `site-delivery-guest-${size}`, ['Se connecter', 'Paiement']);
  await checkout.page.evaluate(session => window.$nuxt.$store.commit('customer/AUTHENTICATED', session), qa.session);
  await checkout.page.waitForTimeout(350);
  await select(checkout.page, 'Adresse de livraison', 'Adresse 1');
  await capture(checkout.page, `site-delivery-saved-address-${size}`, ['Compte connecte', 'Adresse 1']);
  await checkout.page.evaluate(async () => {
    await window.$nuxt.$store.dispatch('cart/setTocart', null);
    await window.$nuxt.$router.push('/orders/detail/1001');
  });
  await checkout.page.waitForTimeout(600);
  await capture(checkout.page, `order-delivery-vat-${size}`, ['Livraison', '24']);
  await checkout.page.evaluate(() => window.$nuxt.$router.push('/history/ticket/1001'));
  await checkout.page.waitForTimeout(1000);
  await capture(checkout.page, `history-delivery-receipt-${size}`, ['Livraison', '24']);
  await checkout.page.evaluate(() => window.$nuxt.$router.push('/reports'));
  await checkout.page.waitForTimeout(500);
  await capture(checkout.page, `reports-remittance-only-${size}`, ['Remises physiques', '16,50']);
  await checkout.context.close();
}
async function main() {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    for (const [size, viewport] of Object.entries({ desktop: { width: 1440, height: 1000 }, mobile: { width: 390, height: 844 } })) {
      if (process.argv[2] === 'dialogs' && size !== 'mobile') continue;
      try { await one(browser, size, viewport); }
      catch (error) {
        const contexts = browser.contexts();
        const pages = contexts.length ? contexts[contexts.length - 1].pages() : [];
        if (pages.length) await capture(pages[pages.length - 1], `finance-failure-${size}`);
        report.failures.push({ name: `finance-${size}`, harnessOrProductUndetermined: error.message }); process.stderr.write(`${size}: ${error.stack}\n`);
      }
    }
  } finally {
    await browser.close();
    report.finishedAt = new Date().toISOString();
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    fs.writeFileSync(path.join(output, 'ui-report.json'), JSON.stringify(report, null, 2));
    process.stdout.write(`Finance captures=${report.captures.length}, failures=${report.failures.length}, pageErrors=${report.errors.length}\n`);
  }
}
main().catch(error => { process.stderr.write(`${error.stack}\n`); process.exitCode = 1; });
