# Task 3 durable checkout implementation

## Status and scope constraint

Implementation in the eight Task3-owned backend files is ready for controller review. Overall status is **BLOCKED on the mandatory legacy split-write guard**, which cannot be wired within the explicit file ownership list. This report does not claim all Task3 acceptance criteria are complete.

Concrete finding: `src/controllers/c_orders.js` implements `addOrder` and `addDetailOrder`; `src/routers/r_orders.js` wires POST `/orders` and `/detailorder` directly to them. Neither path calls the Task3-owned checkout or amendment modules. `addOrder` ignores the new fulfillment/proof fields, and `addDetailOrder` can append to an already accepted delivery and mutate stock outside the new quote transaction. An exported helper in an owned module alone would not protect these endpoints.

Bounded proposal for the controller: extend ownership to **only the two legacy handler bodies in `src/controllers/c_orders.js`**, rejecting explicit delivery/proof fields on header creation, and rejecting details whose same-shop target order has `delivery_id`/delivery fulfillment. Reuse `mFindOrderById` and the response conventions already imported there; add endpoint regressions in the Task3 integration test. No router, archive, payment or broad module refactor is necessary. I did not change that unowned file, monkey-patch its exports, or claim this protection is present.

BASE B: `f673929f0b92c5bf88141739eeabad39f60f3cd1`. F contract checkout at verification: `6f694519d0db9ee631fe9d85550af71165dac293`. Commit details are appended after the scoped commit.

Only B source/test/package files were changed; this requested report and tool-generated validation logs live in F scratch. No other plans or the ledger were loaded or changed. No subagents/reviewers, dependency additions, remote migrations, provider calls, pushes, deployments, environment decryption or persistent hook changes occurred. `workspace_fs` was unavailable; worker-context explicitly permits shell reads in these paired worktrees.

## Files and behavior

- `src/helpers/deliveryTrackingToken.js`: 32 random bytes encoded as base64url; SHA-256 hash helper.
- `src/modules/m_deliveryOrders.js`: transactional dossier creation, append-only charge/event insertion, stable accepted-response replay, active/archive resolution, explicit DTO projection, and append-only explicit revision support. Inserts retrieve `CAST(LAST_INSERT_ID() AS CHAR)` rather than trusting mysql2's rounded BIGINT `insertId`. SELECTs cast all returned new IDs to CHAR.
- `src/modules/m_checkout.js`: normalize the four new public fields; bind the fingerprint to fulfillment, proof/quote hashes, private confirmation hash and actor context; authorize the current DB staff actor or existing web click-and-collect service point; reject table QR/kiosk delivery and public counter-paid declarations; authoritatively recalculate inside the checkout transaction; include fees in subtotal; keep product-only stock and takeaway VAT. Durable token lookup also rejects non-delivery reuse after archival. Original non-delivery discount calculation is retained.
- `src/modules/m_orderQuote.js`: shared `quoteDeliveryOrder` comparator and integer allocation of delivery product discounts/VAT. Calls the actual Task2 `calculateDeliveryDiscount`; fixed amounts are not normalized through legacy `parseMoney` before that helper. No checkout import/cycle was introduced in the quote service.
- `src/modules/m_orderEditing.js`: delivery edits require explicit fresh signed quote/address proof, optimistic delivery version, amendment key, current content revision and authorized staff actor. Refuses paid, picked-up, terminal/uncertain payment and implicit delivery cancellation paths. Stripe edits require the existing trusted replacement callback. Recalculates products/fees/discount, adjusts product stock, writes effective charge/settings revision and preserves the previous address/financial/revision in an immutable event, all in the existing transaction.
- `src/controllers/c_orderEditing.js`: whitelist/map explicit delivery amendment fields; unexpected exceptions are logged without raw SQL/private payloads; a succeeded Stripe payment encountered by the existing replacement callback maps to `DELIVERY_EDIT_NOT_ALLOWED` for delivery.
- `test/delivery-checkout.integration.test.js`: actual disposable MySQL transactions, persisted row/count/stock assertions, duplicate checkout race, rollback injection after dossier insertion, stale/suspended replay, previous tracking validity, quote drift, discount authorization/rounding, guest identity separation, explicit audited edits/replay/refusals, BIGINT production-driver regression, safe HTTP mapping/logging, and fixture-only archive/replay linkage.
- `package.json`: append the integration test to `test:delivery:db`; retain all existing unit commands.

## Integration interfaces

`deliveryTrackingToken` exports `createTrackingToken()` and `hashTrackingToken(raw)`.

`m_deliveryOrders` exports the default methods and `buildDeliveryOrders({clock,randomToken}?)` for deterministic injection:

- `createDeliveryForOrder({checkout,quote,connection}) -> {delivery: DeliveryView,tracking_url}`. Requires the caller's transaction. Checkout includes the validated checkout intent, historical `orderId`/`orderReference`, canonical `requestHash`, verified `actor` and base accepted `result`. The raw tracking token appears only in this returned initial URL. Only its hash and the confirmation-secret hash are stored. New `customer_account_id` is always null until Task12 wires a verified optional context; historical `customerID` is retained.
- `resolveDeliveryOrder({shopId,deliveryId,connection?,forUpdate?}) -> {delivery,order,orderKind:'active'|'archive'}|null`. `forUpdate` requires an existing transaction. `delivery.charge` is the effective immutable charge snapshot; IDs are strings. This is read support for Task4, not an archive implementation.
- `toDeliveryView({delivery,order,actor})` derives commercial payment/remaining due from the resolved order; no mutable payment status/balance is added to deliveries. It exposes the common camelCase DTO and financial euro fields plus `delivery_charge` cents/fiscal snapshot. `acceptanceStatus` is an additional derived field: `payment_pending` for `requires_payment`/`processing`, otherwise `accepted`. Pending payment has no assignment action. Future dispatch must enforce its own authorization and payment eligibility; allowedActions alone is not authorization.
- `findCheckoutReplay({shopId,token,requestHash,connection?})`: stable accepted response from `checkout_created` event, including original order/delivery IDs and financial projection; flips only `idempotent_replay`, does not return a tracking URL, reprice, validate expired proofs, rotate or invalidate the previous link.
- `findEditReplay({shopId,idempotencyKey,requestHash,connection})`, `assertEditable({delivery,order})`, `reviseDeliveryForOrder({checkout,previous,quote,result,connection})` support the existing amendment transaction. Event types/keys are `checkout_created:<clientOrderToken>` and `checkout_revised:<deliveryIdempotencyKey>`. Journals contain no raw tracking/confirmation/quote/address-proof tokens.

`m_orderQuote.quoteDeliveryOrder({checkout,connection,deliveryQuotes,quoteItems?})` returns the existing item quote shape with discounted resolved items, a delivery-inclusive total, `deliveryQuote` and normalized `discount`. It validates signed purpose/shop/time and compares current server settings, address, distance, items/discount and financials with the signed quote and expected total. Task2 `createQuote` and item reads use the supplied connection; no nested transaction or real geocoder is used at checkout.

Checkout HTTP input adds `fulfillment_type:'delivery'`, `delivery_quote_token`, `address_resolution_token`, `delivery_confirmation_secret`. Other identity/actor/source fields remain derived from the established trusted request context. `customer_account_id` from the body is ignored. Creation returns the legacy fields plus `delivery` and initial `tracking_url`; replay returns the legacy fields and accepted `delivery`, without a URL.

Explicit amendment HTTP input adds `delivery_quote_token`, `address_resolution_token`, `delivery_expected_version`, `delivery_idempotency_key` and optional `discount_type`/`discount_value`, alongside existing `content_revision`, `expected_total`, `items` and optional `is_takeaway`. Delivery forces takeaway VAT. A missing reconfirmation yields `DELIVERY_QUOTE_CHANGED`; stale version yields `DELIVERY_VERSION_CONFLICT`; key/payload mismatch yields `DELIVERY_IDEMPOTENCY_CONFLICT`; paid/picked-up/unsafe payment edits yield `DELIVERY_EDIT_NOT_ALLOWED`.

## RED/GREEN evidence

All commands ran in B under PowerShell. Every SQL invocation explicitly set the authorized disposable URL; the harness creates/drops only random `smarteat_delivery_test_*` databases, never the URL's catalog. Native runtime is Node 22.13.1; cached compatibility runtime is Node 18.20.8.

### 1. Initial SQL RED

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-checkout.integration.test.js
```

Exit 1. Full diagnostic (absolute worktree prefix abbreviated to B in stack frames):

```text
Loaded env file: .env.local
DomainError: The order price changed
    at transactionWork (B/src/modules/m_checkout.js:838:15)
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async B/src/helpers/withTransaction.js:7:20
    at async Object.createCheckout (B/src/modules/m_checkout.js:1040:14)
    at async B/test/delivery-checkout.integration.test.js:51:19
    at async withDeliveryDatabase (B/test/helpers/deliveryDatabase.js:123:12)
    at async main (B/test/delivery-checkout.integration.test.js:5:3) {
  status: 409,
  code: 'ORDER_REPRICE_REQUIRED',
  server_quote: {
    total: 20,
    items: [ [Object] ],
    subtotal_before_discount: 20,
    discount_type: 'none',
    discount_value: 0,
    discount_amount: 0
  }
}
```

After creation/replay persistence was implemented, the same command exited 0 and printed the first three PASS lines in the final GREEN output below, then `delivery checkout SQL tests passed`.

### 2. Amendment RED and fixture diagnostic

After adding explicit edit/BIGINT/rounding scenarios before amendment implementation, the same SQL command exited 1:

```text
Loaded env file: .env.local
PASS SQL delivery totals, single stock movement, expired/suspended exact replay, address conflict, tracking privacy
PASS SQL rollback includes order, delivery, charge, events, detail, reservation and stock
PASS SQL POS/web-only origins, verified discount caller and guest account isolation
PASS SQL concurrent replay, settings reprice, 105c/10% half-up threshold and provisional payment
AssertionError [ERR_ASSERTION]: Missing expected rejection.
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async B/test/delivery-checkout.integration.test.js:158:5
    at async withDeliveryDatabase (B/test/helpers/deliveryDatabase.js:123:12)
    at async main (B/test/delivery-checkout.integration.test.js:5:3) {
  generatedMessage: false,
  code: 'ERR_ASSERTION',
  actual: undefined,
  expected: [Object],
  operator: 'rejects'
}
```

After implementation, one run exited 1 at the fixture assertion: `SyntaxError: "[object Object]" is not valid JSON`, test line 171, because mysql2 already decodes JSON. Normalized the assertion to accept decoded JSON or text. The next run exited 0 through the BIGINT scenario.

### 3. Historical checkout contract regression and fix

`node test/checkout-contract.test.js` initially exited 1 at `runCheckoutApiSurfaceContracts`, line 2550: deepStrictEqual actual added `addressResolutionToken:undefined`, `deliveryConfirmationSecret:undefined`, `deliveryQuoteToken:undefined`, `fulfillmentType:undefined` to the historical request. Conditional spreads restored the exact legacy shape. Same command exited 0:

```text
Loaded env file: .env.local
customization and checkout contracts passed
```

`node test/order-editing.test.js` exited 0 both before and after the amendments:

```text
Loaded env file: .env.local
order editing tests passed
```

### 4. Fixed-amount half-cent RED

Added a literal expectation: 2000c products, 1.005 EUR fixed discount -> 101c discount, 400c fee, total 2299c. With historical input normalization still present, the SQL command exited 1 at test line 146 with `DomainError: Delivery quote must be reconfirmed`, code `DELIVERY_QUOTE_CHANGED`. The returned fixture server quote showed `itemsDiscountCents:100`, `itemsNetCents:1900`, `grandTotalCents:2300`, discount intent value 1. The fixture signed quote token/address fields from the expanded diagnostic are deliberately not reproduced here. The full relevant stack was `quoteDeliveryOrder (m_orderQuote.js:189) -> transactionWork (m_checkout.js:848) -> withTransaction.js:7 -> createCheckout (m_checkout.js:1101) -> test line146 -> withDeliveryDatabase:123 -> main:5`.

Keeping delivery discount intent unrounded until the actual Task2 integer helper made the same command exit 0, including the existing 105c at 10% -> 11c discount/free-threshold regression. Historical discount helper was not changed.

### 5. Self-review regression RED

Added four independent SQL cases before fixing their production paths. Same explicit SQL command exited 1:

```text
Loaded env file: .env.local
PASS SQL delivery totals, single stock movement, expired/suspended exact replay, address conflict, tracking privacy
PASS SQL rollback includes order, delivery, charge, events, detail, reservation and stock
PASS SQL POS/web-only origins, verified discount caller and guest account isolation
PASS SQL concurrent replay, settings reprice, 105c/10% half-up threshold and provisional payment
PASS SQL explicit unpaid edit, immutable previous revision, edit replay/conflict, paid/picked-up refusal
PASS SQL production-style driver preserves BIGINT delivery IDs as strings
PASS HTTP delivery request/explicit amendment mapping, account isolation and unexpected-error privacy
FAIL SQL public caller cannot declare counter-paid delivery: Missing expected rejection.
FAIL SQL delivery cannot enter kiosk terminal payment: Missing expected rejection.
FAIL SQL delivery repricing must settle an engaged payment first: Missing expected rejection.
FAIL SQL durable replay and key conflict survive commercial archive: Missing expected rejection.
AssertionError [ERR_ASSERTION]: Self-review regressions must pass
+ actual - expected
+ [
+   'SQL public caller cannot declare counter-paid delivery',
+   'SQL delivery cannot enter kiosk terminal payment',
+   'SQL delivery repricing must settle an engaged payment first',
+   'SQL durable replay and key conflict survive commercial archive'
+ ]
- []
    at B/test/delivery-checkout.integration.test.js:280:12
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async withDeliveryDatabase (B/test/helpers/deliveryDatabase.js:123:12)
    at async main (B/test/delivery-checkout.integration.test.js:5:3) {
  generatedMessage: false,
  code: 'ERR_ASSERTION',
  actual: [Array],
  expected: [],
  operator: 'deepStrictEqual'
}
```

Added the source/payment authorization guards, trusted replacement-callback requirement, and durable occupied-token fallback. All four pass in the final runs below.

### 6. Final focused GREEN, both runtimes

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-green-node22.txt'
exit $LASTEXITCODE
```

And in a separate command session:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-green-node18.txt'
exit $LASTEXITCODE
```

Both exit 0. Identical full stdout, also retained in the two named scratch log files:

```text
Loaded env file: .env.local
PASS SQL delivery totals, single stock movement, expired/suspended exact replay, address conflict, tracking privacy
PASS SQL rollback includes order, delivery, charge, events, detail, reservation and stock
PASS SQL POS/web-only origins, verified discount caller and guest account isolation
PASS SQL concurrent replay, settings reprice, 105c/10% half-up threshold and provisional payment
PASS SQL explicit unpaid edit, immutable previous revision, edit replay/conflict, paid/picked-up refusal
PASS SQL production-style driver preserves BIGINT delivery IDs as strings
PASS HTTP delivery request/explicit amendment mapping, account isolation and unexpected-error privacy
PASS SQL public caller cannot declare counter-paid delivery
PASS SQL delivery cannot enter kiosk terminal payment
PASS SQL delivery repricing must settle an engaged payment first
PASS SQL durable replay and key conflict survive commercial archive
delivery checkout SQL tests passed
```

Final standalone `node test/order-editing.test.js` exited 0, same full output as section 3.

### 7. Broad backend suite once

```powershell
npm.cmd test 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-npm-test.txt'
exit $LASTEXITCODE
```

Exit 0, run once after the final production corrections. Full unabridged command expansion/stdout is in `task-3-npm-test.txt`; it includes the checkout contracts, counter payment modes, stock, historical discounts/VAT, Stripe/Terminal/kiosk/refund/archive contracts and all previous unit commands. The last output is `admin legacy password login tests passed`. These supplier tests use their existing fixture/injected transports, not real provider data. The separate existing order-editing test is not in npm test, so it was explicitly executed as recorded above.

### 8. Aggregated SQL command and whitespace

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
npm.cmd run test:delivery:db 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-delivery-db.txt'
exit $LASTEXITCODE
```

Exit 0. Full stdout is retained in `task-3-delivery-db.txt`. It starts with the package command expansion, then:

```text
PASS legacyRowsStayLegacyAndLinksSurviveArchive (including up/down/up)
PASS financialJournalIsTenantScopedImmutableAndCapped
Loaded env file: .env.local
delivery quotes SQL tests passed (atomic settings/revision, shared two-shop quota, narrow identifier projection)
```

This is followed by the identical complete checkout GREEN stdout in section 6. `git diff --check` exited 0 with no output.

## Self-review and follow-up boundaries

Author self-review only, as requested; no independent reviewer was spawned. Reviewed the eight-file diff against the brief/common contract, actual Task2 implementation and final fix report. The real SQL tests use normal production repositories; a separate pool with `supportBigNumbers:false` demonstrates exact string IDs at `9007199254740993`. SQL fixtures, not fake transaction counts, prove stock, atomic rollback, replay and append-only previous financial/address revisions. The archive case is fixture setup/read-contract coverage, not production archive code. The four self-review defects above were reproduced RED before fixes and pass GREEN on both runtimes.

The mandatory unowned legacy guard remains the scope blocker described first. Do not activate delivery until that protection and the later payment/archive/dispatch integrations are reviewed. This is a concrete ownership mismatch, not a request for a general refactor.

Task4 must add `archiveDeliveryOrder` and actual archive/payment integration; none was implemented here. Resolve already reads active/archive commercial rows and does not store a second mutable commercial state. Future transaction callers must coordinate lock ordering with amendments (the existing amendment locks the active order first, then resolves/locks delivery; standalone `resolveDeliveryOrder(forUpdate)` locks delivery then commercial row). Task4/6/7 own cross-service SQL races and the final consistent order. This task proves concurrent checkout replay, not those future races.

Tracking rotation/authorized recovery, seven-day-after-closure expiry shortening, tracking HTTP route and verified optional customer context belong to later owners. Creation sets the 30-day maximum expiry, never implicitly rotates a token, stores the private confirmation hash, and deliberately omits a lost initial URL on replay. Existing pending Stripe replacement interfaces are reused; no payment provider implementation was added.

Task2's deferred M1 signing preflight/provider rollout prerequisites remain outside this task. No other new unrelated issues were changed.

## Scoped commit and final state

Commit: `c02516b966b419585a6dc842701cbefed6c68d77` (`feat: attach durable delivery to checkout`). Review range: `f673929..c02516b`. Eight named files, 704 insertions and 39 deletions; no environment or unowned files in the commit.

```powershell
git add -- src/helpers/deliveryTrackingToken.js src/modules/m_deliveryOrders.js test/delivery-checkout.integration.test.js src/modules/m_checkout.js src/modules/m_orderQuote.js src/modules/m_orderEditing.js src/controllers/c_orderEditing.js package.json
git diff --cached --check
git diff --cached --stat
git -c core.hooksPath=.git-hooks-disabled-task3 commit -m "feat: attach durable delivery to checkout"
git status --short --branch
git config --get core.hooksPath
git rev-parse HEAD
```

Every command exited 0. Staging emitted only Git's expected LF-to-CRLF normalization notices for the three new files. The staged whitespace check emitted no output. Commit output:

```text
[feat/delivery-v1 c02516b] feat: attach durable delivery to checkout
 8 files changed, 704 insertions(+), 39 deletions(-)
 create mode 100644 src/helpers/deliveryTrackingToken.js
 create mode 100644 src/modules/m_deliveryOrders.js
 create mode 100644 test/delivery-checkout.integration.test.js
```

Post-commit status was exactly `## feat/delivery-v1` (clean B). `core.hooksPath` remained `.githooks`; the encryption-hook bypass was invocation-local only, as authorized. HEAD printed the full commit above. Scratch report/log files are intentionally outside the backend commit. No push.

Final task status: **BLOCKED**, despite green owned-file implementation, because the explicit ownership restriction prevents completing the mandatory legacy split-write guard. The bounded one-file proposal at the start is the remaining required action for the controller; no permission was inferred to modify its legacy handlers.

## Follow-up: ownership amendment and fragment URL correction

This section supersedes the historical BLOCKED status above. The controller amended `task-3-brief.md` to authorize only the `addOrder`/`addDetailOrder` handler bodies in `src/controllers/c_orders.js`. The required legacy guard is now implemented and verified. The user's additional fragment-link correction is also implemented, following specification section 4, line 137: `/livraison/suivi#<jeton-opaque>`. No tracking HTTP endpoint or rotation implementation was added.

Follow-up BASE: `c02516b966b419585a6dc842701cbefed6c68d77`. Only these three files differ from that commit:

- `src/controllers/c_orders.js`: `addOrder` rejects explicit delivery fulfillment, including trimmed/case-normalized delivery, or presence of `delivery_quote_token`, `address_resolution_token`, `delivery_confirmation_secret`, `delivery_id`. It returns the existing `custom` envelope with HTTP 409 and `data.code = DELIVERY_CHECKOUT_REQUIRED` before header insertion. `addDetailOrder` retains existing input validation, then reads the target through the existing same-shop `mFindOrderById(orderid, req.shopid)` before any detail/stock mutations. Linked delivery or delivery fulfillment returns the same 409 code; foreign/missing targets return the identical 404 envelope. Normal legacy detail insertion, stock reduction and stock journal calls remain the original chain. No handler signature, router, archive or payment code was changed.
- `src/modules/m_deliveryOrders.js`: initial `tracking_url` now places the token solely in the fragment, `/livraison/suivi#${rawToken}`. Hash-only storage and exact replay semantics are unchanged.
- `test/delivery-checkout.integration.test.js`: initial URL assertion requires exactly `/livraison/suivi#` plus 43 base64url characters; URL pathname/search are checked explicitly and token extraction uses `URL.hash`, never splitting the path. It retains token-length/hash/replay assertions. New tests invoke the actual exported legacy handlers, with both real SQL database adapters directed at the disposable pool. They cover eight explicit header intent/proof variants, linked delivery, fulfillment-only delivery, successful legacy header/detail and one stock movement, foreign legacy/delivery and missing-target indistinguishability, and the old invalid-detail 400 response. Rejection checks compare persisted order/product state and all existing row counters, not query-call counts.

The integration test also loads the **real** ESM `nanoid` exports into the fixture's CommonJS require cache. This is a loader bridge for the pre-existing `m_orders.js` CommonJS import on Node 18, not a stub of token generation, handlers, queries or business logic. See the runtime caveat below.

### Follow-up RED evidence

All SQL commands ran in B and explicitly set the authorized disposable URL. Full, unabridged stdout/stderr is retained in these existing scratch artifacts:

- `task-3-fragment-red-node22.txt`: safe boolean fragment assertion, exit 1.
- `task-3-legacy-guards-red-node22.txt`: actual-handler guard failures, exit 1, including the normal legacy positive control.

Exact commands, each executed in its own PowerShell session:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-fragment-red-node22.txt'
exit $LASTEXITCODE
```

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-legacy-guards-red-node22.txt'
exit $LASTEXITCODE
```

The first command failed before implementation with `AssertionError [ERR_ASSERTION]: Initial tracking link must use /livraison/suivi#<token>`, actual false, expected true. An initial assertion used `assert.match`, whose diagnostic displayed a disposable fixture token; it was immediately replaced by the safe boolean assertion and the same RED log was overwritten by this confirmed safe failure. No raw token is present in the retained fragment RED artifact.

After the one-line production URL correction, all original checkout tests passed and the actual-handler RED command produced these eleven failures before the handler guards were implemented:

```text
FAIL SQL actual legacy header rejects fulfillment_type=delivery: 201 == 409
FAIL SQL actual legacy header rejects fulfillment_type= DELIVERY : 201 == 409
FAIL SQL actual legacy header rejects delivery_quote_token=string: 201 == 409
FAIL SQL actual legacy header rejects address_resolution_token=string: 201 == 409
FAIL SQL actual legacy header rejects delivery_confirmation_secret=string: 201 == 409
FAIL SQL actual legacy header rejects delivery_id=string: 201 == 409
FAIL SQL actual legacy header rejects delivery_quote_token=object: 201 == 409
FAIL SQL actual legacy header rejects address_resolution_token=string: 201 == 409
FAIL SQL actual legacy detail rejects linked delivery before mutation: 200 == 409
PASS SQL actual normal legacy header and detail retain sale and stock behavior
FAIL SQL actual legacy detail rejects delivery fulfillment without linked ID: 200 == 409
FAIL SQL actual legacy detail hides foreign delivery/legacy and missing targets without mutations: 200 == 404
PASS SQL actual legacy invalid detail retains validation response without mutations
AssertionError [ERR_ASSERTION]: Self-review and actual-handler regressions must pass
```

The complete log includes the existing legacy detail SQL result diagnostics, the earlier delivery PASS lines and the final assertion stack/list of all eleven failures. No production handler/repository was mocked to obtain this RED.

### Follow-up final GREEN evidence

Final commands ran sequentially against independently created disposable databases. Both exited 0:

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-legacy-guards-final-node22.txt'
exit $LASTEXITCODE
```

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/delivery-checkout.integration.test.js 2>&1 | Tee-Object -FilePath '../pos-app/.superpowers/sdd/2026-10-16-delivery-management/task-3-legacy-guards-final-node18.txt'
exit $LASTEXITCODE
```

Full identical stdout is retained in those two files. It includes every original delivery PASS line from section 6, followed by:

```text
PASS SQL actual legacy header rejects fulfillment_type=delivery
PASS SQL actual legacy header rejects fulfillment_type= DELIVERY 
PASS SQL actual legacy header rejects delivery_quote_token=string
PASS SQL actual legacy header rejects address_resolution_token=string
PASS SQL actual legacy header rejects delivery_confirmation_secret=string
PASS SQL actual legacy header rejects delivery_id=string
PASS SQL actual legacy header rejects delivery_quote_token=object
PASS SQL actual legacy header rejects address_resolution_token=string
Liste des customization []
PASS SQL actual legacy detail rejects linked delivery before mutation
Liste des customization []
ADD DETAIL ORDER null ResultSetHeader {
  fieldCount: 0,
  affectedRows: 1,
  insertId: 11,
  info: '',
  serverStatus: 2,
  warningStatus: 0
}
FLAG []
PASS SQL actual normal legacy header and detail retain sale and stock behavior
Liste des customization []
PASS SQL actual legacy detail rejects delivery fulfillment without linked ID
Liste des customization []
Liste des customization []
Liste des customization []
PASS SQL actual legacy detail hides foreign delivery/legacy and missing targets without mutations
Liste des customization []
PASS SQL actual legacy invalid detail retains validation response without mutations
delivery checkout SQL tests passed
```

Native Node 22 legacy regression commands and their complete stdout, each exit 0:

```text
node test/checkout-contract.test.js
Loaded env file: .env.local
customization and checkout contracts passed

node test/order-editing.test.js
Loaded env file: .env.local
order editing tests passed

node test/order-detail-stock.test.js
order detail stock tests passed

node test/counter-checkout-payment-mode.test.js
Loaded env file: .env.local
counter checkout payment mode tests passed
```

Node 18 direct `order-detail-stock.test.js` and `counter-checkout-payment-mode.test.js` also exited 0 with exactly the stdout above. Direct Node 18 checkout/editing tests exposed the existing loader incompatibility: `Error [ERR_REQUIRE_ESM]: require() of ES Module .../node_modules/nanoid/index.js from .../src/modules/m_orders.js not supported`, at `m_orders.js:1:20`; both exited 1 before test execution. No dependency or unowned module was changed. Both tests then passed, exit 0, using the real-dependency bridge with these exact commands (substitute only the indicated test filename for the second invocation):

```powershell
@'
(async () => {
  require.cache[require.resolve("nanoid")] = { exports: await import("nanoid") };
  require("./test/checkout-contract.test.js");
})().catch(error => { console.error(error.stack); process.exitCode = 1; });
'@ | & 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe'
exit $LASTEXITCODE
```

Second invocation requires `./test/order-editing.test.js`. First stdout: `Loaded env file: .env.local`, the standard Node 18 `ExperimentalWarning: buffer.File is an experimental feature and might change at any time` with its trace-warnings hint, then `customization and checkout contracts passed`. Second stdout: `Loaded env file: .env.local` and `order editing tests passed`.

### Intermediate SQL connection failure and self-review

The first parallel Node 22/18 GREEN attempts both exited 1 before reaching the legacy handlers: `Error: Can't add new command when connection is in closed state`, thrown by `PromisePoolConnection.rollback` at `mysql2/promise.js:152`, `withTransaction.js:11`, while the existing fixed-discount checkout ran at integration test line 151. These failed outputs are retained under `task-3-legacy-guards-green-node22.txt` and `task-3-legacy-guards-green-node18.txt`; despite their preliminary filenames, they are not passing evidence.

Read-only inspection of the authorized disposable server showed running state, `OOMKilled:false`, restart count 0, `Aborted_clients:2`, `Aborted_connects:0`, `wait_timeout:28800`, `net_read_timeout:30`, packet limit 67108864 and no recent server restart in its log. The original error was masked by rollback, so a precise disconnect cause is not claimed. Sequential reruns passed; no connection/transaction production helper or SQL settings were changed to hide this failure. One diagnostic Node `-e` command encountered PowerShell quote stripping and did not execute SQL; the read-only diagnostics were then run successfully through the local container's MySQL client.

Author self-review confirmed all `c_orders.js` changes are confined to the two amended handler bodies; the other production change is the one-line fragment correction. Delivery rejection precedes the old write/stock chain; no absent shop context can trigger the helper's unscoped fallback. Foreign and missing target bodies are identical. Actual successful legacy writes remain exercised against SQL. Fragment assertion and extraction cannot accept a secret-bearing HTTP path. No subagents/reviewers, broad-suite rerun, provider sends (including Mailjet/WhatsApp OTP), provider data/configuration changes, deployment, push, remote migration or environment decryption occurred. The earlier complete backend suite result remains historical evidence from the main commit; this narrow follow-up uses the focused validations above, as instructed.

`git diff --check` exited 0; only Git's existing LF-to-CRLF notices appeared for the two previously created files. Final scoped commit details follow below. Current implementation status: required guards and fragment fix complete; the remaining concern is the pre-existing plain-Node-18 Nano ID loader mismatch, explicitly bridged only for tests. This is not a claim that native Node 18 production boot was repaired.

### Follow-up commit and completion

Follow-up commit: `739f9dd24100ce387f6651e412df088c60867c03` (`fix: guard legacy delivery writes and fragment tracking links`), directly after `c02516b`. Controller review range: **`f673929..739f9dd`**.

```powershell
git add -- src/controllers/c_orders.js src/modules/m_deliveryOrders.js test/delivery-checkout.integration.test.js
git diff --cached --check
git diff --cached --stat
git status --short
git -c core.hooksPath=.git-hooks-disabled-task3 commit -m "fix: guard legacy delivery writes and fragment tracking links"
git rev-parse HEAD
git status --short --branch
git config --get core.hooksPath
```

All commands exited 0. The staged whitespace check had no output. Staging contained exactly the three files above (139 insertions, 20 deletions); the only notices were LF-to-CRLF normalization for the two previously created files. Commit output:

```text
[feat/delivery-v1 739f9dd] fix: guard legacy delivery writes and fragment tracking links
 3 files changed, 139 insertions(+), 20 deletions(-)
```

`git rev-parse HEAD` printed the full follow-up SHA above. Post-commit status was exactly `## feat/delivery-v1` (clean B); `core.hooksPath` remained `.githooks`, with the authorized bypass limited to the commit invocation. No environment artifacts or unrelated files were staged, and no push was made.

Final status: **DONE_WITH_CONCERNS**. Both required follow-up fixes are complete with focused RED/GREEN and actual-handler SQL validation. There is no remaining ownership blocker. The concern is the existing Node 18 ESM/CommonJS Nano ID loader mismatch described above; Node 18 SQL/handler and legacy contract validation used the real dependency bridge, while Node 22 runs natively. Task4/16 and provider rollout boundaries from the original report remain later-task responsibilities, not unfinished guard work. No real Mailjet/WhatsApp/provider OTP sends occurred.
