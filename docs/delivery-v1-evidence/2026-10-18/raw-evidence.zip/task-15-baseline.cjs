const path = require('path')
const { execFileSync } = require('child_process')
const root = process.cwd()
const baseline = '0150e247fd3ff874eabeb85857aaa7482d2b430e'
const owned = new Set(['src/modules/m_orders.js', 'src/controllers/c_orders.js', 'src/helpers/orderMetrics.js'])
const original = require.extensions['.js']
require.extensions['.js'] = (module, filename) => {
  const relative = path.relative(root, filename).replace(/\\/g, '/')
  if (!owned.has(relative)) return original(module, filename)
  module._compile(execFileSync('git', ['-C', root, 'show', `${baseline}:${relative}`], { encoding: 'utf8' }), filename)
}
require(path.join(root, 'test/delivery-reports.integration.test.js'))
