const fs = require('fs')
const path = require('path')
const Module = require('module')
const { test } = require('node:test')
const root = path.resolve(__dirname, '../../..')
const filename = path.join(root, 'test/delivery-tracking.review.cjs')
const fixture = new Module(filename, module)
fixture.filename = filename
fixture.paths = Module._nodeModulePaths(path.dirname(filename))
const baseRequire = fixture.require.bind(fixture)
fixture.require = name => name === 'node:test'
  ? { test: (name, callback) => { if (name.startsWith('ROUND2 REVIEW')) return test(name, callback) } }
  : baseRequire(name)
const witness = `
test('ROUND2 REVIEW verified renewal expiry between store acceptance and page continuation', async () => {
  const f = trackingFixture(); authenticate(f)
  const page = await mountTrackingCart(f)
  const expires = Date.now() + 60000
  f.store.commit('customer/SESSION', { ...personalSession(), expiresAt: new Date(expires).toISOString() })
  const data = await f.checkout(31, { customerSession: f.store.state.customer.session })
  await page.finishDeliveryCheckout(data)
  page.deliveryTrackingUrl = null
  const dispatch = f.store.dispatch.bind(f.store)
  const realNow = Date.now
  let acceptedBeforeExpiry = false
  f.store.dispatch = (type, ...args) => {
    const result = dispatch(type, ...args)
    if (type !== 'cart/rotateDeliveryTracking') return result
    return result.then(value => {
      acceptedBeforeExpiry = !value.discarded && Boolean(value.trackingUrl)
      Date.now = () => expires + 1
      return value
    })
  }
  try {
    const renewal = page.renewDeliveryTracking()
    await drain()
    f.calls[f.calls.length - 1].resolve({ trackingUrl: '/livraison/suivi#' + token })
    await renewal
    const proofAvailable = await dispatch('cart/hasDeliveryTrackingConfirmation')
    console.log(JSON.stringify({ acceptedBeforeExpiry, sessionExpired: Date.now() > expires,
      publishedAfterExpiry: Boolean(page.deliveryTrackingUrl), proofAvailable }))
    assert.equal(acceptedBeforeExpiry, true)
    assert.equal(proofAvailable, false)
    assert.equal(Boolean(page.deliveryTrackingUrl), false, 'Renewal must recheck verified authority after its page await')
  } finally { Date.now = realNow; page.$destroy() }
})
`
fixture._compile(fs.readFileSync(path.join(root, 'test/delivery-tracking.test.js'), 'utf8') + '\n' + witness, filename)
