# Final Review: Single Bounded Integration Fix Dispatch

This is the ONE final fix dispatch after the broad review, not a restart of
tasks1-17. Read worker-context.md, final-review.md IN FULL, Task7/13/15/17 final
reports/briefs as needed and current master spec/contracts. Use systematic
debugging, TDD/writing-good-tests and verification-before-completion. No nested
agents/reviewers or model overrides. Main owns independent scoped re-review.

F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
B = sibling express-pos. Bases: F9fc355799e1124cc257a9e647f0933aadf04389c;
B8dbc562efb69a291a09b515b3d1ce17eb1253279. Only these isolated worktrees.
workspace_fs denies them: documented shell fallback; manual edits apply_patch.
Do not regenerate any old brief/ledger, touch original checkout/env, merge,
push, deploy, migrate remote, send real messages, transact real money, print,
call/maps-navigate or touch OS clipboard. Prepare WITHOUT realemail/WhatsApp.

## I1: Immutable Register-Origin Payment And Full Refund

Current manual refund only recognizes an actual courier collection. Real POS
counter_pay_before and later cashier manual settlement are offered but lack
that source. Extend the authoritative producer, not a dialog-only workaround.

- Record immutable server-derived register settlement proof on the SAME
  commercial payment transaction/connection for both real initial POS manual
  pay-before and later cashier manual collection. Use the accepted full amount,
  exact delivery/shop/original payment/method identity and current operator.
- Cash origin is the register, never a fabricated courier collection/debt or
  transfer. Independent manual card remains a declaration, never Stripe proof.
  Inventory actual offered counter methods and handle each still offered for
  delivery explicitly; do not silently relabel an unknown method as cash/card.
  Preserve actual provider/Terminal refund paths and legacy non-delivery flows.
- Prefer an additive immutable register-source/refund model that leaves
  existing courier proof/FKs intact. A new scoped module and additive migration
  are authorized. Do not rewrite old migrations, forge a courier, backfill
  unverifiable old paid rows, or infer immutable proof from present paid flags.
  Any schema alternative must enforce exclusive actual source/FKs/uniqueness
  and preserve existing populated courier refund/impact rows. Record the choice
  and reason/cost in report; tell main if it conflicts with this contract.
- Existing manual refund endpoint/eligibility and operator UI must support
  both origins truthfully. Current operator authority BEFORE replay; exact same
  key/body outcome; cross-origin/key/payload and duplicate full return refusal.
- Register cash full return becomes actual drawer outflow in the post-lock UTC
  posting period, including fee. It does not affect any courier debt, create a
  sale/VAT/stock movement or rewrite old closure JSON. Register manual card has
  no cash movement/providerVerified claim. No implicit financial resolution on
  cancellation, issue or stock amendment. No partial refund feature.
- Real-producer SQL/HTTP RED/GREEN: initial counter_pay_before cash and later
  manual counter settlement; active/archive; independent card/other offered
  manual methods; full fee-inclusive return; uncertain exact replay; different
  key duplicate; current role/cross-shop denial; rollback and concurrent source
  uniqueness; no courier debt; later refund-only Z and frozen old sale/VAT.

## I2: Restaurant Cancellation Before Assignment

Accepted unassigned missions need restaurant reasoned closure without an
available courier or fictitious assignment. Prefer the established reportIssue
-> restaurant resolveIssue workflow extended only where valid; an equivalently
small explicit operation is acceptable if all guards remain coherent.

- Permit current authorized operator, NEVER an unassigned courier, to report
  and resolve accepted unassigned logistics with reason/version/idempotency.
  No automatic refund/restock/debt or physical transfer. Financial outcome is
  separate even for prepaid orders and register refunds from I1.
- Preserve suspension behavior, current auth/tenant BEFORE replay, stale-version
  rejection, explicit retry semantics and no reopen of terminal states outside
  existing admin correction. Align allowed actions/operator dialog with legal
  transitions; do not offer in-transit-only resolutions for an unassigned issue.
- Check terminal correction/journal context/public tracking/private expiry
  consumers for the new unassigned terminal source, including null courier;
  preserve earliest immutable closure ceiling and refusal of missing history.
- Actual HTTP/SQL and focused UI/store RED/GREEN: accepted unpaid/prepaid and
  returned-to-unassigned, no available couriers; cancel/fail and exact replay,
  stale version/current role/cross-shop; no fabricated assignment/debt/refund/
  stock. Correct operational-list closure/public tracking and valid explicit
  admin correction without extending private tracking lifetime.

## Scope / Ownership

**Narrow c_orders handoff:** B/src/controllers/c_orders.js additionally owned
ONLY to pass current req.id as operatorId into existing delivery collect, and
as the fifth argument to existing archiveOrder (ordinary legacy callers retain
their behavior). Main inspected these exact two hunks and accepted the scope
retrospectively after the worker proposal/implementation checkpoint. No other
legacy controller edits. Carry actual-router/current-role producer coverage.

Owned narrowly as required by these TWO findings:
- B new additive migration and optional m_deliveryRegisterPayments.js (or one
  clearly named equivalent register payment-source module).
- B m_checkout.js, m_orders.js, m_deliveryOrders.js, m_deliveryRefunds.js,
  m_deliveryDispatch.js, m_courierCash.js, m_cashClosures.js; relevant existing
  cashClosure/deliveryMoney helpers ONLY if needed for actual new origin flow.
- B delivery routers/controllers ONLY for actual minimal HTTP contract changes;
  prefer existing endpoints. Existing schema/test helper only for additive
  migration fixtures, package.json for registering focused/new acceptance file.
- B existing affected delivery checkout/refund/dispatch/cash/report/tracking/
  journey tests plus one new final-fixes SQL file if clearer; no broad test
  rewrite or weakened assertions. Original positive scenarios remain covered.
- F components/delivery/DeliveryDispatch.vue, store/delivery.js ONLY if new
  source/action DTO requires it, test/delivery-operator.test.js and existing
  affected financial/tracking tests. No unrelated layout/menu/style changes.
- F docs/delivery-v1-acceptance.md and decisions.md for exact new results and
  contract/operational limitations. NEVER stage/edit docs/delivery-v1-evidence/**.
- Task17 MinorM1/M2 remain explicitly deferred; don't expand to dependency,
  diagnostics or runtime-tool cleanup. Any other unowned need: concrete small
  proposal BEFORE edit; do not stall on a non-destructive contract choice.

## Verification / Resources / Handoff

Current Nuxt127.0.0.1:8097 PID6024/.nuxt is main-owned: leave live server and
buildDir alone. If F source changes, use the approved scratch build wrapper
task-17-build.config.js through existing npm build-local --config-file/--dotenv
false (override buildDir ONLY). No new browser/detector/polish rounds. For tiny
changed dialog, actual compiled Vue/Vuex and bounded geometry checks are enough;
main can coordinate a strictly functional geometry check if necessary.

Only disposable SQL: ENV_FILE=NUL and explicit
DELIVERY_TEST_DATABASE_URL=mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql;
fake JWTKEY/PUBLICIMAGEPATH. Existing Docker fixture smarteat-delivery-v1-tests.
Random helper schemas only, no env-file or production reads. Clear every known
SQL selector (Task4/5/7/7refund/15report), never skip with absent configuration.
Current Node22.13.1; cached18.20.8 path in worker-context, actual NanoID bridge
limits retained. Configured Node20 runtime test already exists (no bridge).

Run focused actual failing-before/passing-after cases and affected regressions;
because this touches shared financial producers/schema/closures, finish whole
B npm and registered SQL chain, whole F npm/lint/build on final source, configured
Docker actual-app smoke if new schema/runtime producer changes affect it.
Do not rerun completed source gates just to recover old evidence. Capture every
native result/failed iteration/current source identity. No blanket exit0 or
silent retry. Preserve earlier final gates as BEFORE-fix evidence, not latest.

Commit explicit scoped allowlists in each repo, per-command hooksPath=NUL only.
Write final-fixes-report.md concise technical results plus raw log paths, exact
BASE/HEADs and tests/source bindings, unresolved/minor/deployment prerequisites.
Refresh ALL latest Rulings verbatim and add justified contract decisions through
main ledger before final docs snapshot. Do not self-approve final review or mark
live readiness. Stop author work after report with no required session running;
main dispatches the ONE scoped re-review and adjudicates every residual.
