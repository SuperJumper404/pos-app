### Task 2: Valider les adresses et publier un devis fiable

**Controller policy ruling after independent review:** A mandatory house number / score 0.7 is not an approved coverage restriction. Support adequately resolved unnumbered street/locality postal locations only through explicit provider-candidate selection, retaining the selected provider postal snapshot and precision. Reject municipality-only results, unrelated postal locations, and silent downgrade of a requested house number. No arbitrary centroid, raw browser coordinate or zero-distance fallback. Representative fixtures must demonstrate accepted explicit unnumbered selection and rejected inadequate alternatives. See progress.md ruling and cost.

**Files:** Create `B/src/helpers/deliveryPricing.js`, `B/src/helpers/deliveryAddress.js`, `B/src/helpers/deliveryMoney.js`, `B/src/services/deliveryGeocoding.js`, `B/src/modules/m_deliverySettings.js`, `B/src/modules/m_deliveryQuotes.js`, `B/src/controllers/c_delivery.js`, `B/src/routers/r_delivery.js`, `B/test/delivery-pricing.test.js`, `B/test/delivery-quotes.test.js`; modify `B/index.js`, `B/src/helpers/env.js`, `B/package.json`.

**Interfaces:** Consomme `DeliverySettings`, `quoteOrderItems` existant et schema tache 1 ; produit le builder de devis du plan principal, `distanceMeters(origin, destination)`, `priceDelivery({settings, distanceMeters, itemsNetCents}) -> {deliveryFeeCents, grandTotalCents}` et `validateAddressResolution(token, now) -> addressSnapshot`. Routes : `POST /delivery/address-resolutions`, `POST /delivery/quotes`, `GET/PUT /delivery/settings`. Le devis derive le commerce de la session staff/service-point ; le corps ne choisit pas un autre commerce.

- [ ] **Step 1: Ecrire les tests purs et HTTP** avec origin identique => 0 metre, 1 degre de longitude a l'equateur => environ 111195 metres (tolerance 2 metres), preuves expirees/falsifiees et config sans taux refusee. Fixture reglages validee : rayon 6000 m, paliers 3000/200 centimes et 6000/400 centimes, minimum 1500, gratuite a 2500 :
  ```js
  assert.deepEqual(priceDelivery({settings, distanceMeters: 3000, itemsNetCents: 2000}), {deliveryFeeCents: 200, grandTotalCents: 2200})
  assert.equal(priceDelivery({settings, distanceMeters: 3001, itemsNetCents: 2499}).deliveryFeeCents, 400)
  assert.equal(priceDelivery({settings, distanceMeters: 6000, itemsNetCents: 2500}).deliveryFeeCents, 0)
  assert.throws(() => priceDelivery({settings, distanceMeters: 6001, itemsNetCents: 2500}), {code: 'DELIVERY_OUT_OF_RANGE'})
  ```
  R1 : `12 rue de l'Eglise` avec accents et complement `interphone 42` ; le transport IGN capture uniquement la partie postale, le snapshot conserve le complement. R3 : base 2500 moins 1 centime => 2499 et frais 400. Rejeter NaN/Infinity/negatifs et les trous de paliers.
- [ ] **Step 2: Executer** `node test/delivery-pricing.test.js` puis `node test/delivery-quotes.test.js` ; attendu rouge sur exports/comportements manquants.
- [ ] **Step 3: Implementer les signatures**, les snapshots fiscaux au taux configure, les preuves signees 15 minutes et devis 5 minutes. Normaliser les erreurs `DELIVERY_DISABLED`, `DELIVERY_ADDRESS_INVALID`, `DELIVERY_OUT_OF_RANGE`, `DELIVERY_MINIMUM_NOT_MET`, `DELIVERY_QUOTE_CHANGED`. Aucun fallback geographique a 0. Cache d'adresse cote backend ; debounce de saisie sera frontend, limite globale fournisseur 40 requetes/seconde/IP au maximum, partagee entre instances, et delai HTTP 5 secondes. Ne pas cacher un refus fournisseur comme une adresse inexistante. Monter le router et configurer uniquement des noms d'environnement sans secrets.
- [ ] **Step 4: Relancer les deux tests verts** et le test SQL de tache 1. Ajouter les tests purs a `npm test` ; une configuration initiale vide laisse la livraison desactivee.
- [ ] **Step 5: Commit `feat: quote validated delivery addresses and fees`** dans `B`.

