### Task 14: Donner au livreur un espace mobile limite

**Own availability read amendment:** The existing courier API has only PATCH /courier/availability; its mission list is an array and current auth projection omits courier_available. Displaying current manual availability must not invent a default or mutate it on page load. Also own B/src/modules/m_deliveryDispatch.js, B/src/controllers/c_courier.js, B/src/routers/r_courier.js, B/test/courier-availability.integration.test.js and B/package.json narrowly to add GET /courier/availability. It returns only current `{courierId,available}` after current active same-shop staff role6 reload, server-derived identity, no caller-selected ID. Reject inactive/role-changed/foreign or non-courier contexts; existing PATCH behavior unchanged. Reuse existing account/reload guard and transaction pattern, no new table/general staff projection. Register actual disposable-SQL/HTTP test; cover current DB value, identity changes, denied noncourier/inactive, caller IDs cannot select another account and GET never writes. Paired scoped commit if this minimal backend addition is needed. See task-14-integration-notes.md for current contract.

**Visual gate scheduling:** Phone portrait/landscape, long-address, network-error and mixed-payment acceptance is in the controller's single Task17 visual-qa-matrix batch. This intermediate gate uses actual Vue/store/HTTP-boundary tests and lint/source review, with visual acceptance explicitly pending. Do not start a browser/detector loop here.

**Central route guard integration:** B/src/helpers/deliveryAuthorization.js is additionally owned ONLY to add exact GET /courier/availability to the existing courier surface allowlist. Existing central guard otherwise rejects the authorized new read before its role/current-account router. All other methods/routes and general role6 restrictions remain unchanged. The author reported this necessity before edit; controller confirmed the exact one-line diff and accepted this bounded scope interpretation for review, not a broader authorization expansion.

**Own-balance API:** Task7 supplies `GET /courier/cash-balance`, server-derived current courier/shop; use it, not operator-only `/delivery` routes or caller-selected courier IDs. Courier reads own balance but never confirms own remittance/adjustment. Read Task7 final report for financial response details and keep recap memory-only except permitted minimal unresolved mutation metadata.

**Controller integration note:** Task11 excludes entire courier/customer/delivery modules from general 24h Vuex persistence. Keep full mission/address data memory-only. If pending mutation keys must survive reload, use minimal shop/courier/delivery/key/method/version recovery metadata in a dedicated bounded mechanism, not persisted whole missions or access instructions.

**Files:** Create `F/pages/livreur/index.vue`, `F/layouts/courier.vue`, `F/components/delivery/CourierMission.vue`, `F/components/delivery/CourierPayment.vue`, `F/store/courier.js`, `F/middleware/courier.js`, `F/test/courier-mobile.test.js`; modify `F/middleware/auth.js`, `F/helpers/staffRoles.js`, `F/layouts/default.vue`, `F/package.json`.

**Interfaces:** Actions store `loadMissions`, `pickup`, `collectPayment`, `deliver`, `reportIssue`, `loadCashBalance`; signatures du backend, pas de montant libre en paiement. Reprise par la meme idempotencyKey tant que resultat incertain. L'ordre manuel de passage reste une preference locale des missions attribuees, pas une tournee optimisee ni une nouvelle transaction commerciale.

- [ ] **Step 1: Ecrire tests comportementaux** : role 6 redirige sur `/livreur`, pas sur caisse ; deux missions peuvent etre recuperees et terminees separement. Une commande deja payee n'offre pas encaisser ; carte externe est libellee comme declaration manuelle. Etat `issue` bloque la conclusion normale, livreur ne peut annuler/rembourser. R2 : coupure apres encaissement garde la cle et relit le resultat avant toute nouvelle collecte. R1 : une mission terminee garde le recap/solde mais ne renvoie plus interphone/consignes privees. Les URLs d'appel/itineraire sont construites avec des schemes fixes et valeurs encodees.
  ```js
  assert.equal(paymentRequestsForDoubleTap, 1)
  assert.equal(cashDebtAfterExternalCardCents, 0)
  assert.equal(closedMission.addressSnapshot.instructions, undefined)
  ```
- [ ] **Step 2: Executer** `node test/courier-mobile.test.js` ; attendu rouge sur page/store inexistants.
- [ ] **Step 3: Implementer cartes de mission tactiles et commandes explicites** : recuperer, appeler, itineraire, paiement, livree, probleme. Reponse serveur remplace l'etat local ; boutons bloques pendant mutation et aucune validation hors ligne. Recuperation exige preparation prete. Ne pas stocker les donnees d'acces client dans la persistance generale longue duree. Montrer la disponibilite manuelle du livreur, son solde et ses remises, sans droit de les confirmer lui-meme.
- [ ] **Step 4: Tests verts**, auth/session/staff existants et tests HTTP de role 6 de la tache 5. Inspection sur telephone de portrait et paysage avec nom/adresse longs, erreur reseau et deux missions de paiements differents.
- [ ] **Step 5: Commit `feat: add courier mobile delivery workflow`** dans `F`.

