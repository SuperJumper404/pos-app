# Task17 Independent Review Handoff

Use the installed subagent-driven-development task-reviewer-prompt.md template
for BOTH spec compliance and quality. One paired task gate, not a broad branch
review. Read-only source/index/HEAD; write only the named scratch review report.
No nested agents, package-wide reruns or a second opinion. No model overrides.

Paths: this folder is scratch. Frontend F is three levels up; backend B is
its sibling ../express-pos. Read worker-context.md for paths/test safety and
task-17-brief.md for all amended scope, then task-17-report.md in full. The
controller will supply exact paired review packages/HEADs at dispatch.

Task bases: F9d8efd9b5662ff8eb6f60035bf20df14f4fe83d5;
Bb63e38ea385ede2f85be2dd6774c552abe36b732.

Read each review package once; it includes commit list/stat/full contextual
diff. Do not rerun git or reread changed source unless the hunk ends before
a necessary function completes; name each such exception. Inspect unchanged
code only for a concrete named integration risk, one focused check per risk.
The actual transport/router/SQL evidence is not replaced by UI doubles.

Binding constraints:
- Prepare WITHOUT actual e-mail/WhatsApp sends. Both real receipts remain
  NOT EXECUTED. No real provider payment/refund, print, call/maps navigation,
  clipboard, remote DB/env-secret access, push, merge or deployment.
- Delivery disabled by default, no invented production prices or tax defaults.
- Keep existing Nuxt2/Vue2/Vuetify/Vuex/Axios and Express architecture.
- New SQL IDs strings, safe integer cents, immutable fiscal/address snapshots.
- Staff/customer/courier authorities stay isolated and current before replay.
- One commercial stock/payment/archive chain. Remittance is not another sale.
- Exact unknown-attempt replay, current authority, posting clock after barrier,
  original cash custody and explicit manual-refund source remain mandatory.
- Categories/product steps/stock stay absent from main menu/home.

Task17 additions include controller F98bfb39: resource-scoped read recovery
feedback preserving unrelated errors/freshness; actual history chip prop;
fee-inclusive detail total without a discount. Actual RED/GREEN tests and one
browser confirmation are recorded in evidence README; include these changes
in your task review, not merely the worker-authored backend and docs changes.

Known declared limits are not automatically findings: real receipt/TLS/origin/
UTC historical audit/upstream shared limiter commissioning is external. Still
check the code and documentation truthfully distinguish local completion from
live readiness. Current Docker audit inherited47 findings, old lint/log noise,
earlier composite/Node18 NanoID bridge limits must not be silently rewritten.
Native browser PDF iframe is blank in headless Chrome; actual Task15 PDF/PNG
was independently rendered/viewed/hashbound. Complex UI race/suspension cases
are not all browser-clicked; component/HTTP/SQL evidence is distinguished.

Output task-17-review.md with Spec Compliance, Strengths, Issues grouped
Critical/Important/Minor, file:line evidence for findings/checks and Task quality
Approved/Needs fixes. Read exact log paths to resolve truncated evidence rather
than rerunning suites. Only a specific unanswered doubt permits one focused
repro, no high-count loops or expensive validation. Do not grade an author's
rationale as proof or downgrade an actual issue because it was intentional.
