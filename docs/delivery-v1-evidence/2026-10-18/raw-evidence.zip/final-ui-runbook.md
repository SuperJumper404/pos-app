# Final UI Verification Runbook

Preparation only; no app browser navigation, screenshot or detector scan has run yet.

## Existing Decisions

- Run one batched account/checkout/operator/courier/tracking/documents/reports matrix after Task16 source gate. See visual-qa-matrix.md for exact viewport/state coverage.
- Impeccable context already succeeded once; do not invoke it again or repair existing PRODUCT/DESIGN drift. Incumbent Operate/Vuetify/Poppins/MDI world remains binding.
- Read current craft-floor immediately before UI corrections. One bounded complete fix batch, at most one affected-view confirmation batch; no polishing loop.
- Main controller owns browser QA/detector; Task17 worker owns actual end-to-end HTTP/SQL journeys, complete tests/build/runtime and acceptance documentation. Clarify disjoint write ownership before dispatch; no simultaneous production edits. Main supplies visual evidence/fix outcomes for the worker's final record.
- No real OTP, provider payment/refund, print, phone/maps navigation or OS clipboard operations. Use fictional local fixtures; deny unexpected outbound browser requests. A local HTTP boundary double must not be described as a real provider receipt.

## Runtime Readiness

- Existing Nuxt URL is http://127.0.0.1:8097; confirm current process/port/log readiness first, never stop original servers. API config points to localhost5005; no controller backend server has been started. Do not call the preview a complete running backend.
- Ignored qa-runtime has playwright-core1.64.1 and installed Chrome headless readiness was checked with an ephemeral profile only. Never use the user's real Chrome profile/cookies/tabs. Read current computer-use guidance before control and use the supported local test tooling.
- Fixture must exercise actual rendered app and actual UI transitions; inspect response shapes from final producer reports. If using browser route doubles for UI states, label them and retain separate actual-router/SQL journey evidence.
- Capture screenshots plus DOM/network/console/overflow/touch/focus/asset evidence. Emulated portrait/landscape is not a physical handset.

## Single Detector

Launcher path: C:/Users/kalag/.codex/plugins/cache/openai-curated-remote/impeccable/4.3.1/skills/impeccable/scripts/impeccable.cmd

Only detect --help was run during preparation (exit0), not a scan. The supported command is detect --json followed by all relevant feature UI files in ONE invocation. Use actual task changes against the recorded feature base to choose targets; preserve configured DESIGN/context, do not suppress findings or modify ignore config. Save structured stdout separately from stderr and record LASTEXITCODE. Exit0 no primary findings, exit2 primary findings, exit1 operational target failure. Triage actual context/legacy false positives explicitly; clean detector is not proof of visual quality. Do not run another detector merely to obtain green output after the one fix batch.

## Artifact Retention

- Task15 author and independent reviewer already viewed/bound actual paid/refunded PDF PNGs; see its report for hashes. Preserve final accepted artifacts outside scratch before cleanup. Minimal renderer needs the artifact-local Courier font configuration already prepared; no new renderer/dependency install.
- Keep actual screenshot/artifact paths and checks in the tracked final acceptance record. Preserve ALL ledger Rulings/reasons/costs, composite-run limits, actual native exits and external commissioning prerequisites before removing ignored plan scratch. Do not link the user to files then delete them.
