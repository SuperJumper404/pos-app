# Final Broad Paired-Branch Review

Read the installed requesting-code-review/code-reviewer.md template and use
its Strengths/Issues/Recommendations/Assessment output. This is the ONE broad
whole-feature review after all seventeen task gates, not another Task17 review.
You are an independent senior reviewer; no nested agents or second opinions.
Source/index/HEAD are read-only. Write only scratch/final-review.md and any
explicitly named bounded scratch repro. No real sends, provider transactions,
printing/calls/clipboard/maps navigation, remote DB/env-secret access or deploy.

## Scope And Packages

F = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
B = its sibling express-pos. Both feat/delivery-v1 isolated worktrees.
Full branch bases: F6f694519d0db9ee631fe9d85550af71165dac293;
B9bd0a1ed9ea8dcb30bc77f1d9c997790d902b8a9.
Exact reviewed HEADs and contextual full review packages follow at dispatch.
Use those packages, read each once. For broad integration judgment, inspect
necessary unchanged callers with a named risk and focused scope. Do not crawl
unrelated features or redo every past reviewer run. No package-wide reruns,
repeated stress loops or extra detector/browser-polish rounds. Specific doubt
unanswered by retained evidence may justify one narrow repro only.

## Requirements

Read docs/superpowers/specs/2026-10-16-delivery-management-design.md and the
master plan docs/superpowers/plans/2026-10-16-delivery-management.md/common
contracts. Read tracked docs/delivery-v1-decisions.md for every adjudicated
Ruling/reason/cost and latest final-triage.md. A rationale is NOT proof of
correctness; independently judge behavior. Read current local acceptance and
stable evidence README; source task reports are retained in this scratch.

The spec is a vision, not a closed enumeration of every input. Reasonable
user expectations count even where silent. Before your verdict, list EVERY
considered behavior you declined to judge as out of scope and its reason;
executor must adjudicate each, so none silently disappears. Empty list means
nothing set aside. Grade actual effects, not whether a failure was named.

Required feature: existing POS/site checkout extended, internal couriers,
optional verified email/WhatsApp customer account/address book, manual dispatch,
independent kitchen/payment/logistics/cash-custody states, transparent accepted
distance bands/fees/VAT, private tracking, explicit financial/cash resolution.
No delivery-confirmation OTP, SMS/progress notifications, GPS/ETA/route optimizer,
external marketplace or remote terminal-control feature. No broad architecture
refactor or reappearing Categories/Product Steps/Stock in main menu/home.

## Cross-Task Risk Anchors

- One commercial stock/payment/archive chain; durable delivery survives archive.
  New BIGINT IDs stay strings, safe cents, immutable address/fiscal snapshots.
- Quote/address proof lifetimes and server recomputation. Geocoder sees postal
  fields only; private access details retained on same-address repricing, unsafe
  destination changes explicitly refused. No guessed tax/production fee default.
- Current role/account/shop/ownership BEFORE replay. Courier6 restricted from
  legacy general APIs; operator/customer/courier transports and persistence
  isolated. Independent account never claims staff identity or phone history.
- Original guest versus verified checkout context, exact unresolved intent/key/
  credentials, no inferred paid browser return. Late shop/customer/session/clock
  responses cannot republish private tracking URLs or stale mission privacy.
- Shop-first transaction/barrier and post-lock clock. Collection exactly once;
  original courier cash custody survives reassign/disable/role change. External
  card is a manual declaration, no Stripe claim/cash debt. Source-linked FIFO
  remittances and explicit full refunds cannot become second sales or pretend
  physical money moved. No self-remittance/refund/correction.
- Closure sale versus later physical period and immutable old snapshots; UTC
  precision for delivery history while legacy no-delivery ordinary session-time
  Z continues. No silent conversion of historic naive DATETIME data.
- Hash-only bounded OTP/session/tracking proofs; strict purpose, origin/CSRF,
  verified subject/current authority, explicit link renewal after lost result.
  Earliest immutable closure anchor limits privacy even after terminal correction.
- UI privileges match API. Resource errors clear correctly without hiding other
  failures; closed/reassigned stale data cannot resurrect private instructions.

## Evidence And Explicit Limits

Task17 final complete commands: F image pretest3+main88, B npm66, SQL17,
configured Node20.20.2/MySQL8.0.33 actual index.js/listener/API runtime all native0;
F lint0errors143warnings and isolated build0. Exact source bindings in acceptance
and task17 report. Do not rerun those suites merely to reproduce evidence.

One actual desktop/mobile/narrow/landscape UI matrix with fictional browser API
doubles, one UI source wave and affected confirmation; actual router/SQL evidence
is separate. Later full-suite label/shared-class compatibility hunks have actual
DOM geometry1440/390/320 and corrected complete commands, not fresh screenshots.
Some complex race/replay/suspension states are automated, not browser-clicked.
One detector: zero primary,79 advisory; not zero-warning/a11y certification.
Actual paid/refunded PDF/PNG independently rendered/viewed/hashbound. Native
embedded PDF iframe blank in headless Chrome is explicitly NOT visually passed.

Old Node18 NanoID bridge/composite commands/native-marker qualifications remain
historical evidence, not unbridged production support or failed current commands.
Inherited runtime audit47 (3low/7moderate/31high/6critical), lint/Browserslist and
webpack-size warnings are explicit maintenance risks, not silently fixed.

Real email AND WhatsApp receipt/verification NOT EXECUTED by user's latest explicit
instruction to prepare without sends; no provider credentials/recipients requested.
All real financial/print actions and remote migration/push/merge/deploy NOT EXECUTED.
Commissioning requires actual TLS/origin/proxy/cookies/provider approval/UTC and
historic time-basis audit, aggregate egress quota and shared upstream tracking
limiter. OTP quota coordinates shared SQL+secret; tracking limiter is process-local.
Judge software behavior and truthful limitations, not invented live-readiness.

Raw-evidence.zip/sha256 retention finalization occurs after final review while
all original scratch evidence still exists; no evidence is yet deleted. Preserve
this sequencing qualification. Reviewers may read raw original logs/reports now.

## Final Report

Write final-review.md with severity-ranked concrete file:line findings,
strengths, checked integration risks/evidence, recommendations, Declined To Judge
list, and a clear software ready/with fixes/not ready assessment. Do not confuse
that technical assessment with authorization to merge or deploy. Final process
allows ONE bounded fix dispatch and ONE scoped re-review, so gather related
findings into this report rather than serial speculative audits.
