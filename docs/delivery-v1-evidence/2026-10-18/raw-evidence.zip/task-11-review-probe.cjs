const assert = require('assert')
const fs = require('fs')
const path = require('path')
const vm = require('vm')
const { createRequire } = require('module')
const root = path.resolve(__dirname, '../../..')
const req = createRequire(path.join(root, 'package.json'))
req('axios/lib/adapters/xhr')

// In-memory DOM boundary only; the installed Vue patcher owns component lifecycles.
class MemoryNode {
  constructor(tag, type = 1, text = '') {
    this.tagName = tag && tag.toUpperCase()
    this.nodeType = type
    this.data = text
    this.childNodes = []
    this.parentNode = null
    this.attrs = {}
    this.style = { setProperty() {} }
  }
  appendChild(node) { return this.insertBefore(node, null) }
  insertBefore(node, before) {
    if (node.parentNode) node.parentNode.removeChild(node)
    const index = before ? this.childNodes.indexOf(before) : -1
    if (index < 0) this.childNodes.push(node)
    else this.childNodes.splice(index, 0, node)
    node.parentNode = this
    return node
  }
  removeChild(node) { this.childNodes.splice(this.childNodes.indexOf(node), 1); node.parentNode = null; return node }
  setAttribute(key, value) { this.attrs[key] = value }
  removeAttribute(key) { delete this.attrs[key] }
  hasAttribute(key) { return Object.hasOwn(this.attrs, key) }
  getAttribute(key) { return this.attrs[key] || null }
  addEventListener() {}
  removeEventListener() {}
  get nextSibling() { return this.parentNode && this.parentNode.childNodes[this.parentNode.childNodes.indexOf(this) + 1] }
  get textContent() { return this.nodeType === 1 ? this.childNodes.map(node => node.textContent).join('') : this.data }
  set textContent(value) { this.childNodes = []; this.data = value }
}
global.window = { navigator: { userAgent: 'node-review' }, addEventListener() {}, removeEventListener() {} }
global.document = {
  createElement: tag => new MemoryNode(tag),
  createElementNS: (ns, tag) => new MemoryNode(tag),
  createTextNode: text => new MemoryNode(null, 3, text),
  createComment: text => new MemoryNode(null, 8, text),
  createEvent: () => ({ timeStamp: Date.now() }),
}
const Vue = req('vue')
Vue.config.productionTip = false
Vue.config.devtools = false
const Vuex = req('vuex')
Vue.use(Vuex)
const compiler = req('vue-template-compiler')
const babel = req('@babel/core')
const settle = req('axios/lib/core/settle')
const lineRefs = {}
function load(relative) {
  const filename = path.join(root, relative)
  let source = fs.readFileSync(filename, 'utf8')
  lineRefs[relative] = source.split(/\r?\n/).flatMap((line, index) => /AUTHENTICATED|this\.\$emit|addressInput\.resolve|chooseCandidate|async save\(|this\.loadingBook|const result = await scoped|if \(result\) await|finally|contextKey\(\)|return this\.resolve|function load\(/.test(line) ? [`${index + 1}: ${line.trim()}`] : [])
  if (relative.endsWith('.vue')) source = compiler.parseComponent(source).script.content
  const code = babel.transformSync(source, { babelrc: false, configFile: false, plugins: ['@babel/plugin-transform-modules-commonjs'] }).code
  const module = { exports: {} }
  vm.compileFunction(code, ['module', 'exports', 'require', 'crypto'])(module, module.exports, name => name.startsWith('@/') ? load(name.slice(2)) : req(name), req('crypto').webcrypto)
  return module.exports
}
const session = { subject: 'customer', shopId: 7, customerId: '9007199254740993', expiresAt: '2099-01-01T00:00:00Z', csrfToken: 'a'.repeat(64) }
const postal = { street: '12 rue de la Paix', postalCode: '75002', city: 'Paris', country: 'FR' }
const address = { id: '9007199254740995', label: 'Adresse 3', isDefault: true, addressSnapshot: postal }
const proof = { addressSnapshot: postal, addressResolutionToken: 'server-proof', expiresAt: '2099-01-01T00:00:00Z' }
const calls = []
const api = load('plugins/customerApi.client.js').buildCustomerApi({ baseURL: 'http://localhost:5005', adapter: async config => {
  const body = config.data ? JSON.parse(config.data) : null
  calls.push({ path: config.url, method: config.method, body })
  let status = 200
  let data = null
  let error
  if (config.url.endsWith('/channels')) data = { email: true, whatsapp: true }
  else if (config.url.endsWith('/challenges')) data = { challengeId: '999', status: 'sent', expiresAt: '2099-01-01T00:00:00Z', resendAfter: '2020-01-01T00:00:00Z' }
  else if (config.url.endsWith('/verify')) data = session
  else if (config.url.endsWith('/addresses')) data = config.method === 'get' ? [address] : address
  else if (config.url.endsWith('/address-resolutions')) {
    if (!body.candidateId && !body.addressId) { status = 422; error = 'DELIVERY_ADDRESS_INVALID'; data = { candidates: [{ providerId: 'candidate-2', providerLabel: '12 rue de la Paix 75002 Paris' }] } }
    else data = proof
  }
  return new Promise((resolve, reject) => settle(resolve, reject, { config, status, statusText: '', headers: {}, data: JSON.stringify({ success: !error, data, error }) }))
} })
const store = new Vuex.Store({ modules: { customer: load('store/customer.js') } })
store.$customerApi = api
const dispatch = (name, payload) => store.dispatch('customer/' + name, payload)

async function main() {
  await dispatch('resetForShop', 7)
  store.commit('customer/CHANNELS', { email: true, whatsapp: true })
  const loginOptions = load('components/customer/CustomerCodeLogin.vue').default
  const pageOptions = load('pages/compte/index.vue').default
  // Compile the actual account template. Stub leaf Vuetify/book widgets only.
  const pageSfc = compiler.parseComponent(fs.readFileSync(path.join(root, 'pages/compte/index.vue'), 'utf8'))
  const compiled = compiler.compile(pageSfc.template.content)
  assert.deepStrictEqual(compiled.errors, [])
  const leaf = { functional: true, render: (h, context) => h('div', context.children) }
  const page = new Vue({ ...pageOptions, store, mounted: [], components: {
    CustomerCodeLogin: { ...loginOptions, render(h) { return h('div') } },
    CustomerAddressBook: leaf,
    'v-btn': leaf, 'v-icon': leaf, 'v-skeleton-loader': leaf, 'v-alert': leaf,
  }, render: new Function(compiled.render), staticRenderFns: compiled.staticRenderFns.map(code => new Function(code)) })
  page.opening = false
  page.$mount(document.createElement('div'))
  const login = page.$children[0]
  assert.equal(typeof login.verify, 'function')
  login.destination = 'me@example.test'
  await login.sendCode()
  login.code = '123456'
  let authenticated = 0
  login.$on('authenticated', () => { authenticated++ })
  await login.verify()
  await Vue.nextTick()
  console.log('mounted-login', JSON.stringify({ sessionPresent: !!store.state.customer.session, loginDestroyed: login._isDestroyed, authenticatedEmits: authenticated, addressGetCalls: calls.filter(call => call.path.endsWith('/addresses') && call.method === 'get').length, addressCount: store.state.customer.addresses.length }))
  assert.ok(store.state.customer.session)
  assert.equal(login._isDestroyed, true)
  assert.equal(authenticated, 0)
  assert.equal(store.state.customer.addresses.length, 0)
  page.$destroy()

  await dispatch('resetForShop', 7)
  store.commit('customer/SESSION', session)
  const book = new Vue({ ...load('components/customer/CustomerAddressBook.vue').default, store })
  book.editAddress(null)
  const input = new Vue({ ...load('components/delivery/DeliveryAddressInput.vue').default, store, propsData: { resolver: book.resolveAddress } })
  book.$refs.addressInput = input
  input.draft = { ...postal, complement: '', instructions: '' }
  await Vue.nextTick()
  await input.resolve()
  assert.equal(input.candidates.length, 1)
  await input.chooseCandidate(input.candidates[0])
  assert.equal(input.resolution.addressResolutionToken, 'server-proof')
  const before = calls.length
  await book.save()
  console.log('candidate-save', JSON.stringify({ newCalls: calls.slice(before), editing: book.editing, error: book.validationError, candidates: input.candidates.length, resolution: input.resolution }))
  assert.equal(book.editing, true)
  assert.ok(book.validationError)
  assert.equal(calls.slice(before).filter(call => call.path.endsWith('/addresses') && call.method === 'post').length, 0)
  input.$destroy()
  book.$destroy()
  console.log('line-refs', JSON.stringify(lineRefs, null, 2))
}
main().catch(error => { console.error(error); process.exitCode = 1 })
