const fs = require('fs')
const path = require('path')
const vm = require('vm')
const { createRequire } = require('module')
const req = createRequire(path.join(process.cwd(), 'package.json'))
const babel = req('@babel/core')
const Vue = req('vue')
const Vuex = req('vuex')
Vue.use(Vuex)
global.crypto = require('crypto').webcrypto
global.localStorage = { getItem: key => ({ shopid: '7', access: '1', token: 'fixture-bearer' }[key] || null), setItem() {} }
global.window = { navigator: { userAgent: 'scope-probe' }, addEventListener() {}, removeEventListener() {} }
process.env.privateURL = 'http://fixture.invalid'
function load(relative) {
  let filename = path.resolve(process.cwd(), relative)
  if (!path.extname(filename)) filename += '.js'
  const module = { exports: {} }
  const code = babel.transformSync(fs.readFileSync(filename, 'utf8'), { babelrc: false, configFile: false,
    plugins: ['@babel/plugin-transform-modules-commonjs'] }).code
  vm.compileFunction(code, ['module', 'exports', 'require'])(module, module.exports,
    name => name.startsWith('@/') ? load(name.slice(2)) : name.startsWith('.') ? load(path.resolve(path.dirname(filename), name)) : req(name))
  return module.exports
}
const session = customerId => ({ subject: 'customer', shopId: 7, customerId, csrfToken: 'c'.repeat(64), expiresAt: '2099-01-01T00:00:00.000Z' })
const drain = async () => { for (let i = 0; i < 20; i++) { await Promise.resolve(); await Vue.nextTick() } }
function fixture() {
  const cart = load('store/cart.js')
  const delivery = load('store/delivery.js')
  const calls = []
  const fetch = (url, options) => new Promise(resolve => calls.push({ resolve: data => resolve({ ok: true, status: 200, headers: new Map(),
    json: () => Promise.resolve({ data }), text: () => Promise.resolve(JSON.stringify({ data })) }) }))
  window.fetch = fetch
  const store = new Vuex.Store({ modules: {
    cart: { ...cart, namespaced: true, state: cart.state() },
    delivery: { ...delivery, state: delivery.state() },
    users: { namespaced: true, state: { user: { shopid: 7, id: null, session_subject: 'service_point', order_source: 'web' } } },
    customer: { namespaced: true, state: { shopId: 7, session: session(101) } },
    notifications: { namespaced: true, actions: { success() {} } },
  }, plugins: [req('vuex-easy-access').default()] })
  store.$deliveryApi = delivery.buildDeliveryApi({ baseURL: 'http://fixture.invalid', fetch })
  const start = () => store.dispatch('cart/checkoutOrder', { fulfillmentType: 'delivery', servicePointId: 70, total: 12.5,
    dataCart: [{ id: 21, qty: 1, price: 12.5, subtotal: 12.5 }], deliveryQuoteToken: 'quote', addressResolutionToken: 'address',
    customer: 'Fixture', payment: 'Paiement a la livraison', customerSession: store.state.customer.session })
  return { store, calls, start }
}
async function main() {
  const a = fixture()
  const checkout = a.start()
  await drain()
  a.store.state.customer.session = session(202)
  a.calls[0].resolve({ orderId: 31, delivery: { id: '41' }, tracking_url: '/livraison/suivi#' + 'a'.repeat(43) })
  const result = await checkout
  const accepted = await a.store.dispatch('cart/deliveryTrackingContext', result.data)
  console.log(JSON.stringify({ check: 'verified-customer-replacement-during-checkout', financialSuccess: result.ok,
    staleUrlReturned: Boolean(result.data.tracking_url), staleContextAccepted: Boolean(accepted),
    staleProofAvailable: await a.store.dispatch('cart/hasDeliveryTrackingConfirmation') }))
  const b = fixture()
  const initial = b.start()
  await drain()
  b.calls[0].resolve({ orderId: 32, delivery: { id: '42' } })
  const confirmed = await initial
  const context = await b.store.dispatch('cart/deliveryTrackingContext', confirmed.data)
  const rotation = b.store.dispatch('cart/rotateDeliveryTracking', context.confirmationId)
  await drain()
  b.store.state.customer.session = null
  b.calls[1].resolve({ trackingUrl: '/livraison/suivi#' + 'b'.repeat(43) })
  const rotated = await rotation
  console.log(JSON.stringify({ check: 'verified-customer-logout-during-rotation', staleUrlReturned: Boolean(rotated.trackingUrl),
    discarded: rotated.discarded === true, staleProofAvailable: await b.store.dispatch('cart/hasDeliveryTrackingConfirmation') }))
}
main().catch(error => { console.error(error.stack); process.exitCode = 1 })
