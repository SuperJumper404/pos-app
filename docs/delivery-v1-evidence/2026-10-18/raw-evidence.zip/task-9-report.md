# Task 9 implementation report

Status: implemented, self-reviewed and committed; awaiting controller-dispatched independent review. Task8 approval was confirmed in progress.md and its scoped review before implementation.

B = C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos. F = sibling pos-app. Branch: feat/delivery-v1. BASE: 34f9323e488540123654dc80dc9ee1843c020cfe. Commit: 42f929258e505811a39368d3cbda892fa2efeda9, `feat: authenticate customers with email and WhatsApp codes`.

## Owned files

Exactly eight backend files: new src/services/customerCodeTransports.js, src/modules/m_customerAuth.js, test/customer-code-transports.test.js, test/customer-auth.integration.test.js; modified src/controllers/c_customers.js, src/routers/r_customers.js, src/helpers/env.js and package.json. 837 insertions / 3 deletions. No migration, shared transaction helper, dependency/lockfile, legacy mailer, staff source, frontend source or original-checkout edits. Scratch report/logs only in F.

## Interfaces and Task10 handoff

- `buildCustomerCodeTransports({getConfig?})` produces synchronous `channels() -> {email:boolean,whatsapp:boolean}` and `sendCode({channel,destination,code,expiresInMinutes,locale?}) -> {providerMessageId,accepted:true}`. Only email/WhatsApp; no fallback or notification content. Errors are sanitized DomainErrors, without supplier payloads or credentials.
- `getCustomerAuthConfig()` in env.js lazily reads CUSTOMER_AUTH_SECRET, existing EMAIL/MAILAPIKEY/MAILSECRETKEY, JWTKEY for secret separation, and the five CUSTOMER_WHATSAPP_* variables from the common contract. Construction requires no new secrets. Both channels require a nonblank auth secret of at least 32 bytes, different from JWTKEY. Each channel additionally requires its own valid configuration. Discovery measures configuration readiness, not supplier availability/approval.
- `buildSqlCustomerAuthRepository({pool?})` owns the local `transaction(work)` adapter and SQL reserve/getChallenge/recordSend/wrongCode/consume methods. `work` receives the same acquired mysql2 promise connection. No nested/shared-helper transaction is introduced.
- `buildCustomerAuth({repository?,transports?,clock?,randomCode?,secret?})` produces `requestChallenge({shopId,channel,destination,countryCode?,ip,browserBinding,purpose='login',customerId=null,locale?}) -> {challengeId,expiresAt,resendAfter,status}`. Both dates are UTC ISO strings; status is pending/sent/failed. No OTP, provider ID, identity-existence flag, token or cookie is returned.
- `verifyChallenge({shopId,challengeId,code,browserBinding}) -> {shopId,customerId,verifiedChallengeId}` accepts login challenges only. It yields this context once, for the session service only. It does not create a customer HTTP session or staff subject.
- `linkIdentity({customerSession,challengeId,code,browserBinding?})` derives shop/customer from the trusted session context, checks the stored link target and verifies the code/binding. Task10 should pass the attempt's browserBinding explicitly as the fourth field. The three-field form can read browserBinding from a transient decorated customerSession context; this is not a session-table/cookie field requirement. Public callers cannot declare that context. A verified conflict raises CUSTOMER_IDENTITY_CONFLICT, invalidates the challenge and never merges accounts.
- `buildCustomerAuthController({customerAuth?,transports?})` plus the existing router's optional `customerAuthController` register GET /customer-auth/channels and POST /customer-auth/challenges, relative to the API prefix. Responses use the existing response envelope, no-store, and only the documented DTO in data. POST allows exactly shopId/channel/destination/countryCode/browserBinding/locale; purpose is forced to login and customerId to null. IP is req.ip; body IP, customerId, purpose and arbitrary provider URL fields are rejected.
- Task10 still owns HTTP verify/link/session/logout adapters, cookie/CSRF/origin/trusted-proxy wiring and integration with the existing global authenticationIfPresent middleware, including stale staff-header coexistence. No /customer-auth/verify route or invented session is mounted here. Existing customer-route/global CORS behavior was preserved. The verified challenge remains protected by Task8's composite session FK and UNIQUE verified_challenge_id.

New errors: CUSTOMER_REQUEST_INVALID 400, CUSTOMER_CODE_INVALID 401, CUSTOMER_RATE_LIMITED 429, CUSTOMER_AUTH_UNAVAILABLE / CUSTOMER_CHANNEL_UNAVAILABLE / CUSTOMER_CODE_UNAVAILABLE / CUSTOMER_CODE_TIMEOUT 503; existing identity normalization errors remain 422, and CUSTOMER_IDENTITY_CONFLICT is 409. Unknown/mismatched/expired/used codes share the same generic verification error.

## State, crypto and account ownership

Native crypto.randomInt generates six decimal digits; clock and randomCode are injectable for fixtures. HMAC-SHA256 covers challenge ID, shop, purpose, link owner, channel, normalized destination, browser-binding hash and code, with domain-separated browser/contact/IP hashes. Comparisons use timingSafeEqual. No plaintext code column/log is introduced. All new IDs are decimal strings, including LAST_INSERT_ID() read with CAST on the same connection; tested above 2^53 with production numeric driver defaults.

Code lifetime is 600 seconds; 599 succeeds, 600 fails. Five incorrect valid-format guesses persist and invalidate the challenge; returning an error result from the transaction before throwing preserves failed-attempt writes. Wrong shop/browser/purpose cannot consume it. Resend before 60 seconds fails; a successful reservation at 60 seconds invalidates open predecessors for that destination within the same shop. Time comparisons/storage use whole-second UTC precision, matching the existing DATETIME schema. Explicit UTC SQL strings/DATE_FORMAT avoid dependence on a driver's local timezone.

Reservation creates pending. A valid supplier acknowledgement promotes an open row to sent and records the acknowledgement time; this never claims end-user receipt. An explicit rejection becomes failed. Timeout/network uncertainty remains pending with no invented sent_at/provider ID. A valid pending code can atomically set sent + verified_at + consumed_at + verified_customer_id under Task8's existing CHECK, while sent_at remains null. Late results update only still-open, unconsumed, unverified pending rows: they cannot downgrade a verified challenge or resurrect an invalidated predecessor. Replaying a consumed code fails; lost verification responses require a new challenge, not another session.

Only a verified customer_identities row supplies login account ownership. A new verified contact creates an empty separate customer account; staff-created profile contacts and historical phone/order groups never grant account ownership or get claimed/backfilled. Same contact in different shops yields separate customers. A second contact can be linked only through the trusted-session service path after its own OTP proof.

## Shared quotas and locking

No schema/ownership expansion was needed. The adapter uses a database-derived MySQL named lock (customer_auth_ + 48 hex characters) on the acquired connection, waits at most five seconds, then begins the transaction. It keeps coordination through COMMIT/ROLLBACK and RELEASE_LOCK, and only then returns the connection to the pool. SQL failures or uncertain release destroy the connection; a real RELEASE_ALL_LOCKS fault test proves a subsequently queried acquired connection is closed and the pool remains usable.

Foundation rows retain real shop FKs and per-shop uniqueness, but enforcement aggregates ALL shops' unexpired customer_otp_contact/IP rows under that single database-wide lock. Contact hashes omit shop and include channel + normalized destination; IP hashes omit shop and canonicalize IPv6/IPv4-mapped equivalents. All instances use the same auth secret and SQL database. Buckets start at each sending second and expire after 3600 seconds: this is a rolling hour, not a calendar-hour reset. Cross-shop cooldown is also checked from contact buckets. Limits are five/contact/hour and twenty/IP/hour. Counters, predecessor invalidation and new HMAC challenge commit together; any refused/failed reservation rolls all of them back and makes no provider call. Supplier rejection/timeout retains its reserved budget.

The provider request starts strictly AFTER COMMIT AND advisory release. Its result is stored in a separate short transaction. There is no automatic application send retry. This intentionally serializes short auth SQL operations across instances; provider latency never holds the coordination lock. Verification attempts are shared challenge-row state, not process memory. Tests exercise both shops, concurrent module instances (including independent pools at the contact ceiling), the IP ceiling, rolling-hour boundary, HTTP counts after refusal, real SQL rollback and lock-release failure.

## Provider contract evidence

Mailjet uses the installed node-mailjet 3.x SDK, existing central credentials, Send v3.1 Messages, one recipient, central EMAIL/Smart Eat From, dedicated sign-in text and per-message success/recipient UUID validation. The historical activation mailer is unchanged. SDK response/deadline timeout is five seconds. A discovered legacy proxy dependency patches https.request's URL overload; the owned Meta transport uses the supported options-object overload instead, without dependency or global patches.

Meta uses fixed graph.facebook.com, explicitly configured Graph version, business phone ID, approved authentication-template name/language and bearer token. The SAME code appears in body/text and button/sub_type=url/index="0"/text components, matching the superseding official Meta evidence in customer-provider-evidence.md (copy-code authentication page updated 2026-10-06). The configured template language is authoritative. WhatsApp uses an absolute five-second HTTP deadline, with no application retry, template creation or SMS fallback.

Every provider request in tests is redirected at https.request to a loopback HTTP fixture. Installed Mailjet serialization/parsing, native Meta HTTP logic, crypto, bcrypt, JWT and SQL/storage remain real. No actual provider send, recipient/credential request, template/account operation, remote migration, payment or deployment occurred. No prod.env read/decrypt or application-DB fallback occurred.

## Verification and raw logs

All paths below are relative to this scratch directory. Commands ran from B. Each SQL invocation explicitly set `DELIVERY_TEST_DATABASE_URL=mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql` using the disposable fixture specified by worker-context. The harness created/dropped random smarteat_delivery_test_* databases only. Node22 was native v22.13.1; Node18 v18.20.8 used `C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe`.

| Command / stage | Exit and evidence |
| --- | --- |
| node test/customer-code-transports.test.js, initial RED | 1, missing service; task-9-transports-red.txt |
| node test/customer-auth.integration.test.js, initial RED | 1, missing service; task-9-auth-red.txt |
| Initial GREEN attempts, same two commands | 1 each; task-9-transports-green-attempt.txt and task-9-auth-green-attempt.txt. Exposed SDK URL-overload incompatibility, four-versus-five SQL assignment ordering, and two fixture expectations (BIGINT count string; required cooldown before another contact send). |
| Initial focused GREEN, same commands | 0 each, 6 transports / 12 SQL TAP tests; task-9-transports-green-node22.txt and task-9-auth-green-node22.txt |
| Extended SQL coverage | 0, 19 TAP tests; task-9-auth-extended-node22.txt |
| Transport input RED then GREEN | 1 (numeric code caused a send before validation), task-9-transports-input-red.txt; fixed by strict string validation; final Node22 and Node18 command each exit 0, 7/7, task-9-transports-final-node22.txt and task-9-transports-final-node18.txt |
| SQL safety expansion / fixture correction | 1, task-9-auth-final-node22.txt: only fixture SELECT 1 result type assertion failed; corrected numeric assertion. Fault tests exercised actual SQL, not mocks. |
| Non-UTC driver RED | 1, literal two-hour storage mismatch; task-9-auth-timezone-red.txt |
| FINAL node test/customer-auth.integration.test.js | 0, 22/22, task-9-auth-utc-green-node22.txt |
| FINAL explicit Node18 executable + test/customer-auth.integration.test.js | 0, 22/22, task-9-auth-final-node18.txt |
| Node stdin structured baseline/package comparisons; node --check for all seven JS files | 0, task-9-static-checks.txt; every prior script and dependency preserved, only new test command prefixes added |
| git diff --cached --check | 0 before commit |
| git -c core.hooksPath=NUL commit -m 'feat: authenticate customers with email and WhatsApp codes' | 0, task-9-commit.txt; invocation-local hook override, no persistent git config change |
| git diff 34f9323e488540123654dc80dc9ee1843c020cfe HEAD --check; git status --short --branch | 0 each after commit; clean B on feat/delivery-v1. F status was also clean; scratch artifacts are ignored. |

The SQL coverage includes HMAC transplant/context tampering, exact expiry/cooldown/attempt boundaries, concurrent verification once, shared quotas/two instances, tenant identity isolation, linking/conflict, timeout with received-code verification, late failure versus verification, late success versus resend, atomic rollback, connection disposal, native random generation, large IDs, timezone independence, real staff login/storage regression and actual public HTTP/no-send discovery/field filtering/server-IP behavior. Node18 uses a test-only import-cache bridge to the actual Nano ID dependency when loading legacy staff handlers; no production dependency patch or unbridged Node18 boot claim. Whole previous suites were not redundantly rerun, as requested. No npm test/full SQL baseline or live-provider success is claimed.

## Self-review and concerns

Self-review covered all eight files, DTO secrecy, public ownership/purpose derivation, HMAC scope, failed-attempt commit, same-connection exact IDs, SQL rollback/lock disposal, provider boundary ordering, global aggregation, late-result guards and script preservation. Only owned sources were staged; both worktrees were clean apart from these changes before commit, and F source remains untouched. No subagent, reviewer, merge, push or deployment was invoked. Controller owns the independent review.

Remaining external acceptance: real receipt/verification on both configured suppliers is commissioning work and was expressly not authorized. Task10 must implement its HTTP/session/CSRF/CORS/proxy and stale-staff-header integration before customer browser authentication is complete. Fault-injection SQL cases emit old mysql2 packet-order diagnostics while disposing connections; all assertions and subsequent real SQL operations pass. The inherited unprefixed Loaded env file fixture-path diagnostic remains visible (Task8's already deferred TAP-noise observation). Neither diagnostic was hidden or fixed by unrelated driver/bootstrap changes.

## Fix Round 1: I1

Read task-9-review.md completely. Important I1 addressed, 1/1; no other finding changed. M1 remains deferred for final triage. BASE 42f929258e505811a39368d3cbda892fa2efeda9; commit d2f4d623b2f777dc57ce32aab579b96217ccefe0 (`fix: lock shop before customer OTP reservation`). Exactly two backend files, 87 insertions / 1 deletion: src/modules/m_customerAuth.js and test/customer-auth.integration.test.js. Report and raw logs are scratch artifacts only.

The initial Shop existence query in reserve is now a current locking SELECT FOR SHARE, before any existing-customer FOR UPDATE. This preserves Shop -> customer/FK ordering with the actual Shop-first archive producer. It holds the shared parent lock through reservation commit/rollback. No changes to quota aggregation, named-lock acquisition/release, connection disposal, commit-before-release-before-HTTP, provider-result persistence, interfaces, schema, environment/configuration or other production files. No send retry was added.

One controlled actual-SQL regression runs the production buildOrderArchiveModule.mArchiveOrder and customer requestChallenge against the disposable database. The archive's real Shop X query is paused after execution. The link's real customer-lock query is paused after execution if reached. Query wrappers forward SQL/results without faking them. On those two actor connections, performance_schema.data_locks observes either the unsafe granted customer X or the required Shop wait; metadata reads use the paused archive connection, with a bounded three-second observation deadline. Each producer executes once, with no stress/race-repeat loop or retry.

RED observed customer X before Shop, so the explicit required-order assertion failed (`customers` rather than `shop`). GREEN observes the link waiting on Shop while archive holds X, then releases the gates: both producers commit without SQL failures, the archive retains customer_account_id "51", the active order is removed, exactly one mock-boundary provider request occurs after the reservation can proceed, and the resulting link challenge verifies for customer "51". Existing affected-file tests also recheck quotas, timeouts, late-result races and staff login. This regression asserts the lock-order prerequisite directly rather than depending on InnoDB deadlock victim/index selection; no pre-fix deadlock result is claimed.

Each SQL command explicitly set the disposable URL below, never an app/remote database. Native Node22 and the already cached Node18 executable were used; the only Node18 Nano ID bridge remains in tests against the actual installed dependency.

```powershell
$env:DELIVERY_TEST_DATABASE_URL='mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
node test/customer-auth.integration.test.js
& 'C:/Users/kalag/AppData/Local/npm-cache/_npx/00073ba5d7c1f8bc/node_modules/node/bin/node.exe' test/customer-auth.integration.test.js
```

| Evidence | Exit / result / scratch log |
| --- | --- |
| Node22 RED before production fix, affected file command above | 1; 23 TAP tests, 21 pass / 2 fail (new subtest plus parent), zero skips; task-9-fix-round1-red-node22.txt. Diagnostic: link held customer first; SQL failures none. |
| Final Node22 GREEN, same affected file | 0; 23/23, zero failures/skips; task-9-fix-round1-final-green-node22.txt. Diagnostic: link waited for Shop; SQL failures none. |
| Final Node18 GREEN, executable/affected file above | 0; 23/23, zero failures/skips; task-9-fix-round1-final-green-node18.txt. Same Shop-wait diagnostic. |
| Existing narrow archive regression, Node22 | 0; task-9-fix-round1-archive-node22.txt; one selected named group exercises both amendment/archive schedules. |
| node --check src/modules/m_customerAuth.js; node --check test/customer-auth.integration.test.js | 0 each. |
| git diff --check; git diff --cached --check | 0 each before commit. |
| git -c core.hooksPath=NUL commit -m 'fix: lock shop before customer OTP reservation' | 0; task-9-fix-round1-commit.txt. Invocation-local override only. |
| git diff 42f929258e505811a39368d3cbda892fa2efeda9 HEAD --check; git status --short --branch in B and F | 0 each; both clean on feat/delivery-v1 after commit. |

Exact additional environment/command for the existing narrow regression (same explicit disposable URL):

```powershell
$env:ENV_FILE=Join-Path (Get-Location) 'test/task9-nonexistent.env'
$env:JWTKEY='task9-jwt-fixture'
$env:TASK4_TEST_FILTER='actual amendment and archive serialize with standalone dossier resolution'
node test/delivery-archive-payments.integration.test.js
```

Exploratory evidence retained: task-9-fix-round1-red-schedule-diagnostic.txt and task-9-fix-round1-lock-diagnostic.txt (exit 1 each) show that a preliminary wait-for-archive-FK assertion did not trigger with the fixture's PRIMARY-only customer lock; the final regression instead directly asserts the required actual ordering. Initial post-fix runs task-9-fix-round1-green-node22.txt and task-9-fix-round1-green-node18.txt exited 1 only on the new test's archive-row assertion using API alias originalorderID as a SQL column. That assertion was corrected to the fixture's actual shop/order number; the production fix was unchanged before the final GREEN runs above.

Self-review: the sole production change is the initial Shop lock, acquired under the existing auth advisory/transaction lifecycle; no customer lock precedes it in reserve. The new regression uses real archive/customer FK storage and actual lock metadata, checks one provider call, drains both operations in finally, and leaves the existing full-file coverage intact. No unrelated minor cleanup, schema/config changes, real providers, agents, original-checkout edits, full-suite reruns, merge/push/deploy or persistent hook configuration. Controller handoff: review only I1 and the two-file BASE..d2f4d623b2f777dc57ce32aab579b96217ccefe0 diff; M1 and the previously documented Task10/commissioning prerequisites remain unchanged.
