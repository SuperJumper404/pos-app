param([string]$Repository, [string]$Name, [string[]]$Command)
$ErrorActionPreference = 'Continue'
$scratch = $PSScriptRoot
$env:ENV_FILE = 'NUL'
$env:ENV = 'local'
$env:DELIVERY_TEST_DATABASE_URL = 'mysql://root:local_delivery_test_only@127.0.0.1:33319/mysql'
$env:JWTKEY = 'delivery-final-fixes-disposable-jwt'
$env:PUBLICIMAGEPATH = Join-Path $env:TEMP 'delivery-final-fixes-images'
'TASK4_TEST_FILTER','TASK5_REVIEW_FILTER','TASK7_FILTER','TASK7_REFUND_FILTER','TASK15_REPORT_FILTER' | ForEach-Object {
  Remove-Item -LiteralPath "Env:$_" -ErrorAction SilentlyContinue
}
Push-Location -LiteralPath $Repository
try {
  $files = @(@(& git diff HEAD --name-only) + @(& git ls-files --others --exclude-standard) | Sort-Object -Unique)
  $blobs = @($files | ForEach-Object { @{ path = $_; blob = (& git hash-object -- $_); sha256 = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash } })
  @{ head = (& git rev-parse HEAD); indexTree = (& git write-tree); command = $Command; startUtc = [DateTime]::UtcNow.ToString('o'); files = $blobs } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $scratch "$Name-source.json")
  $exe = $Command[0]
  $arguments = @($Command | Select-Object -Skip 1)
  & $exe @arguments *> (Join-Path $scratch "$Name.log")
  $taskExit = $LASTEXITCODE
  Add-Content -LiteralPath (Join-Path $scratch "$Name.log") -Value "nativeExit=$taskExit"
} finally { Pop-Location }
exit $taskExit
