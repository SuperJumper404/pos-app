# Delivery V1 Final Triage

Current final-gate disposition, not deployment approval. Authoritative history and every Ruling/cost remain in progress.md and tracked decisions. Do not repeat completed source tasks.

## Deferred Findings For The Final Review

| Source | Finding | Required final decision |
| --- | --- | --- |
| Task2 M1 | resolveAddress can call the geocoder before discovering the missing address/quote signer configuration. | Task17 worker implemented operation-boundary signer preflight and actual zero-provider-call RED/GREEN/lazy-boot tests; final task review pending. |
| Task6/7 M1 | Inherited customization/payment/archive SQL diagnostics in retained test output. | Decide whether bounded fixture capture/assertion is warranted. Preserve unexpected diagnostics; no general production logging refactor. |
| Task8 M1 | Inherited Loaded-env diagnostic is outside TAP in the new SQL files. | Assess narrowly in test bootstrap; do not suppress all output or change secret loading. |
| Task9 M1 | Expected fault/disposal packet-order diagnostics plus the same env bootstrap noise. | Distinguish intentional fault evidence from ordinary SQL failure. Consider targeted expected-diagnostic assertions only; current assertions pass. |
| Task11 M1 | Existing no-console lint baseline and stale Browserslist notice. | Nonblocking baseline unless new evidence changes that assessment. Do not update dependencies or clean unrelated warnings. |
| Task10 test-stability limit | Initial parallel legacy upload runs failed ECONNRESET/ENOTEMPTY; identical sequential whole-file runs passed without harness/source changes. | Preserve the actual evidence and unknown cause. Do not claim the harness was repaired or silently retry the final complete suite. |
| Task12 shell evidence | A controller PowerShell redirect returned shell1 on the old Browserslist stderr warning despite TAP29/29; explicit native-code propagation then returned0 on both runtimes. | Preserve both artifacts and inspect actual native/TAP status. Do not mislabel a warning wrapper as an assertion failure or hide failures behind a blanket exit0. |
| Task13 evidence qualification | Author says round1 raw files contain nativeExit markers, but scoped reviewer found those markers absent. TAP37/29/27 and no ESLint violations are directly visible; native0 is an author/tool-session claim, not embedded artifact evidence. | Preserve qualification without rerunning merely to regenerate evidence. Final Task17 commands must record native exits explicitly. Task13 M1 is the same old Browserslist baseline, not a new blocker. |
| Task14 M1 | Successful read refresh does not clear the earlier read-failure banner; courier error is shared across resources. | Fixed F98bfb39 in one UI wave: resource-scoped read errors, freshness and command-error preservation. Actual RED/GREEN47courier tests both runtimes and browser recovery desktop/mobile; final task review pending. |
| Task14 M2 / evidence | Old Browserslist and legacy session fixture projections remain in passing logs. Some earlier Node22/SQL logs lack embedded nativeExit markers although completion/PASS groups are visible; author tool sessions claim exit0. | Preserve diagnostic/evidence limits, no broad dependency/logging refactor. Final commands record actual native exit explicitly; fixture projections are not a new secret exposure. |
| Task15 M1 / evidence | Old Browserslist plus five inherited lint warnings; affected F22 batch13/14 then narrow bundle correction, plain B18 batch7/9 then two real-nanoid-bridge successes. | Nonblocking inherited noise; preserve composite coverage and exact test-revision strengthening limits in report/manifest. Do not claim those initial whole commands passed or modernize dependencies. Independent reviewer viewed/bound both final PDF PNGs to hashes. |
| Task16 M1 | Inherited Browserslist/cart console warnings and Node18 experimental buffer.File notice remain in native0 runs. Four legacy direct Node18 loader failures were retained and separately bridged successfully. | Nonblocking maintenance noise; preserve exact native exits/current-test-revision and bridge limits, no dependency/console sweep in tracking fix. |

Append any new deferred findings from Tasks13-17 before the single final broad review. Existing Critical/Important task findings must be fixed at their own gate, not parked here.

## Local Acceptance Still Required

Task17 independent Galileo gate approved,0Critical/0Important/2Minor, report
task-17-review.md. M1 carries known diagnostic debt. M2: the final two runtime
fetch probes lack explicit AbortSignal deadlines (readiness itself is bounded);
future hung endpoint may delay cleanup. Nonblocking current passing smoke,
explicitly retained for final broad review rather than silently discarded.

- Final complete frontend3pretests+88main/backend66 npm and original17-file registered SQL chain all native0 on recorded tested content; initial failures/composite continuations retained. Author handoff read in full; Task17 independent review pending.
- Final frontend lint0errors143warnings/build-local0 (isolated scratchbuildDir, unchanged actual config); configured Node20.20.2/MySQL8.0.33 actual whole-app boot native0 WITHOUT Node18 bridge. Runtime audit47 inherited findings and webpack size warnings explicitly retained, not live rollout approval.
- Actual initial visual matrix, one UI wave F98bfb39 and one affected confirmation complete; see stable docs/delivery-v1-evidence/2026-10-18/README.md. All completed captures have no page overflow/JSerrors/unknownAPI; interrupted fixture/selector failures retained. Complex stale/replay/suspension/ambiguous states not all clicked, automated boundary coverage distinguished. No physical-handset claim.
- ONE final detector native0/zero primary/79 advisory, contextual debt retained by explicit ruling; no suppressed/zero-warning/a11y-certification claim.
- Task15 paid/refunded actual generated PDF/PNG artifacts independently viewed/hashchecked and approved; retained under docs evidence/pdf. Native browser PDF iframe blank in headless Chrome, visual inline preview NOT validated. No physical print.
- One final broad paired-branch review and bounded fix/re-review wave. Preserve source-task gates and exact compatible hashes.

## External Commissioning Prerequisites, Not Local Success Claims

- The user explicitly chose preparation WITHOUT actual email/WhatsApp sends. Both real channel receipt/verification checks remain NOT EXECUTED; do not request recipients/keys or operate provider accounts/templates.
- Provider configuration readiness is not supplier approval, availability or end-user receipt. Delivery notifications/SMS and real financial/printing actions are not part of this local acceptance.
- OTP instances require the same SQL quota store AND auth secret. IGN quota is shared only within its actual coordination store; independent databases sharing egress need aggregate-budget planning before activation.
- Task16 public tracking limiter is30/IP/60s, process-local with10000 live buckets/fail-closed saturation, not an aggregate restart/multi-worker budget. Configure/verify an upstream shared limiter before claiming deployment-wide throttling. Lost rotation response requires a separate explicit renewal; replay returns no raw URL and never rotates again automatically.
- Verify supported UTC session readiness and audit/reconcile the basis of historic naive financial DATETIME values BEFORE feature activation; current UTC alone does not prove historical correctness. No automatic timezone conversion.
- Audit historically issued legacy staff activation links as recorded in Task5 before release; do not inspect real tokens or production databases here.
- Verify actual deployment origins/proxy topology and TLS/SameSite cookie behavior. Do not claim arbitrary third-party storefront domains work by default.
- No merge, shared push, production migration or staging/production deployment is authorized for this feature yet. Keep the isolated branches until explicit integration instructions.

## Tooling Already Prepared

- Frontend local server: see latest progress.md runtime entry; original server processes must not be stopped. Current preview is port8097 with API configuration pointing to localhost5005, not a claim that a new backend is running.
- Ignored qa-runtime uses playwright-core1.64.1/Chrome155 ephemeral contexts; actual local Nuxt browser batch executed with fictional API doubles, never the user's profile. See stable evidence README for allowed font-only external requests and blocked providers.
- Local-only image smarteat-delivery-pdf-qa:20261018/pdftoppm25.12.0 produced Task15 independently approved raster evidence. Minimal-image Courier font issue was fixed only in artifact-local font configuration; no new app renderer/dependency.

Before deleting any plan scratch artifacts, retain the final decisions, ALL Rulings with costs and actual acceptance evidence in the tracked final record. Do not link the user to files that the cleanup will remove.
