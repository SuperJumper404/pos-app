const fs = require('fs');
const path = require('path');
const qa = require('./ui-qa.cjs');
async function main() {
  const browser = await qa.chromium.launch({ channel: 'chrome', headless: true });
  try {
    const o = await qa.openContext(browser, 'admin', { width: 320, height: 640 });
    await qa.go(o.page, '/livraison');
    const next = o.page.locator('.v-tabs .v-slide-group__next');
    await next.click();
    await o.page.waitForTimeout(400);
    await o.page.getByRole('tab', { name: 'Reglages', exact: true }).click();
    await o.page.waitForTimeout(400);
    qa.report.interactions.push({ name: 'narrow-tabs-legitimate-arrow', boxes: await o.page.getByRole('tab').evaluateAll(tabs => tabs.map(t => ({ text: t.textContent, rect: t.getBoundingClientRect().toJSON() }))) });
    await qa.capture(o.page, 'settings-narrow-arrow-navigation');
    await o.context.close();
    const d = await qa.openContext(browser, 'admin', { width: 390, height: 844 });
    const row = { id: 1001, ordernumber: 'LIV-2026-000001', shopid: 7, productid: 21, name: 'Menu de recette', customer: 'Client de recette', qty: 1, price: 20, total: 20, total_ht: 18.18, total_vat: 1.82, vat_rate: 10, subtotal: 24, subtotal_before_discount: 20, discount_amount: 0, payment: 'Especes', payment_status: 'paid', status: 3, fulfillment_type: 'delivery', delivery_id: '501', delivery_status: 'assigned', financials: { grand_total: 24, delivery_charge: qa.charge } };
    d.state.handleApi = ({ path: p }) => p === '/detailorder/1001' ? { data: [row] } : undefined;
    await qa.go(d.page, '/orders/detail/1001');
    await d.page.locator('.order-detail-attribution').scrollIntoViewIfNeeded();
    qa.report.interactions.push({ name: 'detail-bottom-reachable', scroll: await d.page.locator('.order-detail-panel').evaluate(el => ({ top: el.scrollTop, height: el.clientHeight, content: el.scrollHeight })), feeVisible: await d.page.getByText('Livraison : 4,00', { exact: false }).isVisible() });
    await qa.capture(d.page, 'order-delivery-vat-mobile-scrolled', ['4,00', '0,67']);
    await d.context.close();
  } finally {
    await browser.close();
    fs.writeFileSync(qa.reportPath, JSON.stringify(qa.report, null, 2));
    process.stdout.write(`captures=${qa.report.captures.length}, failures=${qa.report.failures.length}, pageErrors=${qa.report.errors.length}\n`);
  }
}
main().catch(error => { process.stderr.write(error.stack + '\n'); process.exitCode = 1; });
