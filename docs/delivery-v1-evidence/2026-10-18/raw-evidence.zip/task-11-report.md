# Task 11 report

Status: frontend implementation and author source review done. Focused behavioral gate PASS (21/21). Full lint PASS (0 errors, exactly 151 baseline warnings). The single full npm invocation exited1 at an existing source-based design assertion; the owned-component correction, failing test and entire remaining suffix then passed, as detailed below. Every registered command has therefore been exercised successfully across that run and its bounded continuation; no second whole npm invocation was made. Strict unchanged-storage TTL requires the outside-ownership controller ruling below. Controller review and grouped Task17 desktop/mobile browser acceptance remain PENDING. This is not shipment or complete delivery V1 acceptance.

F: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/pos-app
B: C:/Users/kalag/Desktop/projects/clone-pos/pos/.worktrees/delivery-v1/express-pos
Scratch: F/.superpowers/sdd/2026-10-16-delivery-management
Frontend BASE: 6f694519d0db9ee631fe9d85550af71165dac293
Compatible backend HEAD: 1a0d7c32a26d20bac0a1da3b707b13364611eee7 (unchanged, approved Task10).
Frontend final commit: 73e87da94f92b33193c02169e2642722e0c59913, `feat: add customer code login and address book`.

## Authority and scope

Read the amended task-11-brief.md FIRST, then worker-context, task-11-integration-notes, common contracts, relevant specification/account/address sections, final Task10 actual HTTP report (including its routing/contract follow-up), Task8 DTO/renewal report and the existing PRODUCT/DESIGN/incumbent code. Read the controller's new visual scheduling amendment when notified. Did not regenerate any brief or ledger. workspace_fs was unavailable in this session; shell reads used the worker-context paired-worktree fallback. No original checkout changes.

Applied the TDD, execution, verification and Impeccable instructions within the explicit worker scope. Existing visual world inherited: Nuxt2/Vue2/Vuetify, MDI icons/tooltips, Poppins, restrained task layout and 44px principal actions. Read new-work/operate and craft-floor immediately before UI edit batches. Did not rerun the context launcher, run a detector, create a browser loop, start a server or spawn any agent/reviewer. No real .env or secret was read or changed. This deliberately supersedes the general API-work .env inspection rule, per the user's prohibition.

Exactly twelve owned source/test/config files:

| File | Change |
| --- | --- |
| plugins/customerApi.client.js | New independent Axios transport, cookie credentials, JSON envelope handling, explicit CSRF and sanitized local errors. |
| store/customer.js | New namespaced customer state, tenant/session epochs, safe public branding, channel discovery and personal account/book actions. |
| components/customer/CustomerCodeLogin.vue | New login/link SFC with server-derived resend timing, validation, status/errors, safe focus and submission guards. |
| components/customer/CustomerAddressBook.vue | New owned address book, inline add/edit/default/delete confirmation and resolved selection event. |
| components/delivery/DeliveryAddressInput.vue | New shared callback-driven address SFC, moved into Task11 by controller ruling. |
| pages/compte/index.vue | New /compte account entry, shop query changes, login/book/link/logout and explicit guest exit. |
| layouts/customer.vue | New lightweight restaurant name/logo layout, independent of staff shell/auth/theme bootstrap. |
| helpers/persistedState.js | Exclude customer/delivery/courier on both serialization and hydration via existing common sanitizer. |
| test/customer-account.test.js | New behavioral SFC/Vuex/Axios/persistence coverage, registered in npm test. |
| test/persisted-state.test.js | Extend existing roundtrip, legacy/wrapped hydration and production-plugin tests to the three excluded modules. |
| nuxt.config.js | Register customerApi client plugin; existing plugins/settings unchanged. |
| package.json | Prefix the new test to the existing test chain; exact pretest and every old command/dependency retained. |

No package-lock/dependency change. No backend edit or backend contract proposal was necessary. No other task, global design, staff auth transport, navigation, checkout, payment, printing or recovery code changed. This ignored report/logs are additional scratch artifacts, outside the commit.

## Consumer interfaces

`buildCustomerApi({baseURL,adapter?})` exports an independently constructed `new axios.Axios(...)`, using the installed Axios 0.21.1 XHR adapter in the browser. `$customerApi` is the injected API facade: `request({method='get',path,body?,shopId?,csrfToken?}) -> Promise<dataDTO>` and `browserBinding() -> 64-character random hex`. The optional adapter is the HTTP test boundary; there is no app dependency addition.

The constructor has explicit headers, adapter, timeout (15000ms), JSON transforms, status validation and withCredentials:true. It does not use Nuxt `$axios.create`, singleton Axios defaults, bearer/auth defaults, inherited params, XSRF-cookie names or staff interceptors. CSRF is the JSON session DTO's csrfToken, sent as X-CSRF-Token. HttpOnly cookies remain browser-owned; no cookie/OTP/nonce is written to local/session storage. browserBinding uses 32 cryptographically random bytes per challenge attempt, remains only with that in-memory challenge and is explicitly sent again on login/link verify. Errors never dispatch notifications or staff logout and never show raw provider/backend response messages.

Customer store required actions: `loadSession({shopId})`, `requestCode({channel,destination,purpose,countryCode?})`, `verifyCode({challengeId,code})`, `linkIdentity({challengeId,code})`, `logout()`, `loadAddresses()`, `saveAddress({id?,addressResolutionToken?,complement?,instructions?,makeDefault?})`, `deleteAddress(id)`, `resetForShop(shopId)`.

Additional narrow actions: `loadChannels()`, `clearChallenge()`, `resolveAddress({addressId}|{address,candidateId?})`. Resolver errors propagate to the active address consumer, so an obsolete postal error cannot poison a later draft's store error. Other expected request failures return null and populate customer.error. Stale responses return null without changing state/errors/busy.

State: required shopId/session/addresses/challenge/busy/error plus customer-owned shop, channels, channelsLoaded and epoch. Only shop_name/shop_profile_image from public shop DTO enter this state. No returned staff branding/payment settings or shop_theme are applied globally. Session requires subject:'customer', exact expected shop integer, string customer ID, future expiry and CSRF. Initial session 401 means logged out. Current personal-session 401 clears only customer session/challenge/book and advances epoch. CUSTOMER_CODE_INVALID is a distinct OTP rejection (also HTTP401): it preserves the existing challenge/session for another permitted code attempt.

Shop reset, successful login, logout and session invalidation advance the epoch. Every asynchronous reply, error and busy finalizer checks its captured shop/epoch. The page also sequences openShop calls, including invalid and repeated shop queries, and clears private in-memory account state on leaving. No default shop is inferred from staff state.

`CustomerCodeLogin` prop mode='login'|'link'; emits authenticated or identity-linked only on current successful result. Empty/incomplete/non-numeric codes and invalid contact syntax are rejected locally; the server remains authoritative. resend countdown comes from absolute server resendAfter, not a hardcoded local 60s. Empty/failed discovery cannot enable channels. Configured flags are availability flags, not a claimed live-provider success. A failed send remains an explicit failure; pending acknowledgement is described as uncertain and can accept a received code. No automatic second-channel send. Conflict leaves book/owner unchanged. Send/verify are guarded both in SFC and store.

`CustomerAddressBook` emits `select({addressId,addressSnapshot,addressResolutionToken,expiresAt})`, never a price. Display labels come directly from server DTO label; no array-index numbering. Default/delete reload the authoritative book. New proof is not inserted into permanent address DTO state. Deletion has an explicit inline confirmation.

`DeliveryAddressInput` props: `value` is saved `{id,addressSnapshot}` DTO or null; `resolver` is an async callback; `disabled` boolean; `contextKey` tenant/session identity. It emits `resolved(null)` immediately on invalidation, or `resolved({addressId,addressSnapshot,addressResolutionToken,expiresAt,complement,instructions})` after a current result. Exposed `resolve()` is used for explicit saves; chooseCandidate sends only server providerId as candidateId. Draft changes debounce for 300ms. New input/context/destroy invalidates timers/results/candidates/errors; sequence guards discard late success and failure. No dependency on a delivery store. Task12 should reuse this component and adapt its own resolver boundary.

Opening a saved editor does not geocode. An unchanged saved postal address, including private-only edits and selecting an address, resolves through `{addressId}` for a fresh server proof with no IGN/new-postal request. A new/changed postal address sends only street/postalCode/city/country, with optional candidateId returned by the server. Complement/instructions remain separate and never enter the geocoder request. Signed server snapshots/proofs determine postal coordinates; browser coordinates are never posted. Save obtains a current proof, then sends optional private/default fields separately. No quote or resolution is triggered by login alone.

## Exact routes and payloads

Browser route: `/compte?shopId=7` (or 8, etc.). shopId is required, canonical positive decimal legacy integer <=2147483647. Missing/array/noninteger/out-of-range query clears customer context and shows invalid-entry state. No staff auth middleware. There is no required shopName/returnTo/token query parameter. Guest exit is explicitly `/click-and-collect/<shopId>/<URL-encoded restaurant name>`; fallback name Restaurant preserves this exit if branding fails. Entering that legacy storefront is its pre-existing separate principal-switch workflow, not part of customer authentication.

API base: existing `process.env.privateURL`; path prefix is `/baseurl/api/v1`. Current config local base is http://localhost:5005. Every personal request includes query `shopId=<selected integer>`; posted owner/shop overrides are never used. Login challenge/verify instead carry body shopId as required. Browser supplies Origin; personal mutations carry cookie credentials and X-CSRF-Token.

| Method | Path after /baseurl/api/v1 | Query | Body |
| --- | --- | --- | --- |
| GET | /shopInfo/click-and-collect/7 | none | none; public endpoint only, never its /session variant or legacy Vuex bootstrap |
| GET | /customer-auth/channels | none | none; {email:boolean,whatsapp:boolean} |
| GET | /customer-auth/session | shopId=7 | none; safe customer session including csrfToken |
| POST | /customer-auth/challenges | none | {shopId:7,channel,destination,browserBinding,countryCode?} |
| POST | /customer-auth/verify | none | {shopId:7,challengeId,code,browserBinding} |
| POST | /customer-auth/link/challenges | shopId=7 | {channel,destination,browserBinding,countryCode?}; purpose/owner server-derived |
| POST | /customer-auth/link/verify | shopId=7 | {challengeId,code,browserBinding} |
| POST | /customer-auth/logout | shopId=7 | {} |
| GET | /customer/addresses | shopId=7 | none; [{id,customerId,label,isDefault,addressSnapshot}] |
| POST | /customer/addresses | shopId=7 | {addressResolutionToken,complement?,instructions?,makeDefault?} |
| PATCH | /customer/addresses/:stringAddressId | shopId=7 | optional proof/private/default allowlisted fields only |
| DELETE | /customer/addresses/:stringAddressId | shopId=7 | {} |
| POST | /customer/address-resolutions | shopId=7 | exactly {addressId} OR {address:{street,postalCode,city,country},candidateId?} |

All new customer/challenge/address IDs remain strings, including values above Number.MAX_SAFE_INTEGER. Legacy shopId alone is numeric. The API parses the existing success/data envelope and exposes filtered providerId/providerLabel candidates on domain error. No personal contact lookup, staff endpoint, service-point bootstrap, pricing call or alternate unguarded route is used.

## Verification

Runtime: native Node v22.13.1, installed Vue/Vuex/vue-template-compiler/Babel/Axios; no new harness or dependency. Behavioral tests compile each SFC template, load actual script through the established Babel/vm pattern, instantiate real Vue components and real Vuex, and execute actual Axios request/JSON transforms with only the HTTP adapter doubled. Production persistence plugin runs against disposable in-memory storage; UI refs/timers are controlled test boundaries. No real HTTP/provider request is made.

| Command / phase | Observed result | Scratch log |
| --- | --- | --- |
| node test/customer-account.test.js, initial RED | exit1, 0/11: owned components/store/transport absent | task-11-red.txt |
| node test/persisted-state.test.js, RED | exit1: excluded private roots still survived | task-11-persistence-red.txt |
| node test/customer-account.test.js, initial complete GREEN | exit0, 11/11 | task-11-green-attempt-2.txt |
| node test/customer-account.test.js, edge RED | exit1, 13/16: wrong-OTP reset, missing pending/failed presentation, invalid-query spinner | task-11-edge-red.txt |
| node test/customer-account.test.js, edge GREEN | exit0, 16/16 | task-11-edge-green.txt |
| node test/customer-account.test.js, added consumer coverage | exit0, 20/20 | task-11-coverage.txt |
| node test/customer-account.test.js, guest RED | exit1, 20/21: no guest exit on branding failure | task-11-guest-red.txt |
| node test/customer-account.test.js, FINAL focused | exit0, 21/21, no skipped/cancelled/todo | task-11-final-focused.txt |
| node test/persisted-state.test.js, GREEN | exit0, persistedState tests passed | observed together with first targeted lint invocation |
| node node_modules/eslint/bin/eslint.js [11 affected JS/Vue paths], FINAL | exit0, 0 errors/1 existing persisted-state no-console warning | task-11-lint-final.txt |
| npm.cmd run lint | exit0, 0 errors/151 baseline warnings; existing stale Browserslist notice | task-11-whole-lint.txt |
| npm.cmd test, exactly ONE invocation including unchanged pretest | exit1 at design-system.test.js:133 after pretest, 21 new tests and all preceding legacy commands passed | task-11-npm-test.txt |
| node test/design-system.test.js; node test/shop-hours.test.js; node test/click-and-collect-page.test.js; node test/staging-supabase-deploy.test.js (sequential loop, exits on any failure) | exit0; entire failing-and-remaining original suffix passed | task-11-npm-continuation.txt |
| structured package comparison against BASE | PASS: exact old pretest/test suffix/scripts/dependencies preserved; only new test prefix differs | observed terminal result |
| git diff --check | exit0 | observed terminal result |

Focused cases include poisoned singleton Axios auth/headers/params and actual registered staff logout interceptor; customer401 staff invariants; public DTO minimization; shop7->8 with delayed session/branding/channels/address success/errors; stale login not emitting; double send/verify; discovery disabled/retry; provider failed/pending and explicit alternative channel; server resend timestamp; code/contact validation/focus; identity-linked success/conflict; same account book after verified alternative-contact login at HTTP boundary; default/delete stable labels; private-edit save/selection proof renewal during simulated new-postal provider outage; candidate IDs without private fields/coordinates; stale postal errors and context changes; actual general persistence exclusion; invalid queries and guest fallback. HTTP doubles assert consumer behavior, not new backend SQL/provider acceptance.

The existing design-system test scans the entire source after `<v-text-field` for `Recherche` and compares a hardcoded search-surface list. The new structured postal form's progress/retry copy contained that word, which incorrectly classified it as a product/list search surface. Kept the global test unchanged; the owned address component now labels this step `Validation de l'adresse...` / `Reessayer la validation`, consistent with what it does. The initial npm log is the RED witness; the complete four-file suffix is GREEN after the two-line copy correction. Re-executed 21/21 behavioral tests and final affected-file lint after that change. No full npm retry, weakened assertion, new exclusion or unrelated file change.

## Concrete ownership concern for controller ruling

The unchanged `plugins/persistedState.client.js` has no mutation filter. Its actual vuex-persistedstate subscriber calls setState on EVERY customer mutation. The owned sanitizer successfully excludes all customer/delivery/courier data and preserves persisted staff auth/shop/products/cart/recovery content, but the plugin still rewrites the vuex string and refreshes expiresAt via serializePersistedState. Therefore strict byte-for-byte unchanged localStorage/TTL during customer-only activity is NOT achieved by the currently authorized helper-only edit. A behavioral characterization runs the real plugin and explicitly asserts this difference, alongside unchanged persisted content; the snapshot test does not pretend raw bytes are unchanged.

Smallest concrete proposal, NOT applied: grant `F/plugins/persistedState.client.js` ownership to add a createPersistedState mutation filter rejecting only `customer/`, `delivery/`, `courier/` module mutations, plus behavioral test extension in the already-owned persistence/customer tests. Preserve every staff mutation, existing 24h serializer/parser/hydration and narrowly scoped cart recovery. With that grant, assert raw vuex bytes and expiry unchanged for excluded-module mutations and still written for a staff/cart mutation. No session/auth-transport change or backend edit is needed. Controller must rule on this stricter R4 invariant; this worker did not edit outside ownership.

Existing staff session expiry plugin remains active globally as documented in integration notes; actual expired staff credentials can still redirect independently. This work never invokes that path on a customer response. No broad legacy auth change was made.

## Remaining acceptance and dev facts

Actual desktop/mobile browser acceptance (code entry/focus/errors, long labels, widths/overflow, icons/touch targets/assets and real theme coexistence) is PENDING in the single controller-owned Task17 batched visual matrix. No screenshot, detector or browser navigation result is claimed. No Nuxt build/dev boot was run in this worker; all five templates compile through the existing test compiler. Live OTP receipt, configured provider readiness, cross-origin cookie/CSRF and deployment acceptance remain external commissioning checks. No live provider, recipient, payment, phone, printer, push, merge or deploy operation occurred.

No task-created app server exists and no original server was stopped. Current Nuxt config defaults to frontend localhost:8083 and API localhost:5005 via ENV=local. Later controller should choose a free port; predev guard reads POS_DEV_PORT or PORT (default8083), POS_DEV_HOST (defaultlocalhost), while Nuxt accepts its explicit CLI port/host. Keep guard and selected Nuxt port consistent; avoid the original server port. Preserve existing NODE_OPTIONS=--openssl-legacy-provider. Browser route is `/compte?shopId=7` on that isolated origin; use disposable allowed-origin/backend fixtures and mocked code transports, never real sends. The controller's ignored scratch/qa-runtime Playwright installation is not an application dependency and was not touched.

## Self-review and final commit

Read the full owned store/transport/SFC/layout/page and tracked-file diffs after implementation. Checked ownership, epoch/finalizer guards, OTP versus session401, explicit tenant/CSRF/browserBinding contracts, public branding isolation, no login geocode/quote, server-only postal authority, proof renewal/private fields, stable labels, hydration exclusion, source compatibility and exact package preservation. Fixed the recorded in-scope RED/GREEN findings; the concrete persistence-plugin concern above remains outside ownership. Independent source review belongs to the controller.

Final npm result: the ONE full invocation exited1 at the source-based design assertion; the corrected failing file and all three remaining original commands exited0 in the bounded sequential continuation. The final focused suite is 21/21 and final affected-file lint is 0 errors/1 existing warning. No second full npm invocation was made, and no whole-invocation exit0 is claimed.

`git diff --cached --check` passed before commit; the staged list contained exactly the twelve files listed above. Scoped command `git -c core.hooksPath=NUL commit -m 'feat: add customer code login and address book'` exited0, invocation-local hook override only; raw log task-11-commit.txt. Commit 73e87da94f92b33193c02169e2642722e0c59913 contains 12 files, 1410 insertions/1 deletion. No persistent Git config change or environment hook execution. `git diff 6f694519d0db9ee631fe9d85550af71165dac293 HEAD --check` passed after commit.

Compatible pair for controller/sub-plan03: F=73e87da94f92b33193c02169e2642722e0c59913; B=1a0d7c32a26d20bac0a1da3b707b13364611eee7. Both worktrees are clean on feat/delivery-v1; scratch report/logs remain ignored. Every task-started test/lint process has finished; there is no task-created app server, browser or background job. Only the described persistence-filter ownership ruling and controller source/visual acceptance remain outstanding.

## Authorized persistence-filter follow-up

Status: strict unchanged-storage/TTL concern above is now RESOLVED by the controller-authorized follow-up. This section supersedes the earlier pending-ownership statements without removing their original evidence. Independent review and controller-owned Task17 visual acceptance remain pending. The original npm invocation/continuation history above is unchanged; no second whole npm or full lint was run.

User explicitly granted ownership of ONLY F/plugins/persistedState.client.js in addition to the already-owned two behavioral test files. Follow-up BASE was clean F HEAD 73e87da94f92b33193c02169e2642722e0c59913. No other production file, helper/serializer, config, backend, environment, dependency or UI changed in this follow-up.

Exact production interface: existing `createPersistedState({ ... })` now supplies the supported option `filter: ({ type }) => !/^(customer|delivery|courier)\//.test(type)`. Only mutation types beginning with the exact, case-sensitive namespaces `customer/`, `delivery/`, `courier/` are rejected. Their Vuex mutations still execute normally in memory; the persistence subscriber does not invoke setState for them. Staff/cart/other modules and root mutations continue through the original setState. Bare root mutation names customer/delivery/courier, names such as customerSupport/deliverySettings/courierCash, and nested/customer are not excluded. The existing sanitizer still protects serialization/hydration when another mutation causes a write. The 24h serializer/parser/getState/setState and minimal cart recovery remain unchanged.

`test/customer-account.test.js` now snapshots raw storage strings, including wrapper/expiry, in its existing staff-isolation assertions. The prior characterization expecting a rewrite now requires exact unchanged vuex bytes and expiresAt during real customer loadSession/loadAddresses activity. Existing login/link/logout/401/shop-switch/discovery cases also use those strict raw snapshots.

`test/persisted-state.test.js` additionally runs the production plugin with the REAL vuex-persistedstate subscriber and REAL Vuex store against disposable storage and a controlled clock (restored in finally). It commits each excluded namespace, proves the in-memory mutation occurred, proves zero vuex writes and identical bytes/expiry despite elapsed time, then commits eleven retained staff/cart/root/neighbor/nested mutation types. Each retained mutation writes once, preserves staff token and pending-recovery fixture, advances expiry to clock+24h, and continues to omit all three private modules. Existing sanitizer, wrapped/legacy hydration and expiry assertions still execute. No assertion or existing exclusion was weakened.

All commands below ran from F on native Node v22.13.1. Outputs are retained in ignored scratch:

| Command / stage | Result | Log |
| --- | --- | --- |
| node test/customer-account.test.js, RED before filter | exit1; tests21, pass16/fail5, strict raw-storage differences | task-11-persistence-filter-customer-red.txt |
| node test/persisted-state.test.js, RED before filter | exit1; first customer mutation changed raw bytes/expiry | task-11-persistence-filter-red.txt |
| node test/customer-account.test.js, first GREEN | exit0; 21/21 | task-11-persistence-filter-customer-green.txt |
| node test/persisted-state.test.js, first GREEN | exit0; persistedState tests passed | task-11-persistence-filter-green.txt |
| node node_modules/eslint/bin/eslint.js plugins/persistedState.client.js test/persisted-state.test.js test/customer-account.test.js, initial | exit1; one import/order error in new test imports, one existing no-console warning | task-11-persistence-filter-lint.txt |
| node test/customer-account.test.js, FINAL after import-order correction | exit0; tests21/pass21, fail/cancelled/skipped/todo0 | task-11-persistence-filter-customer-final.txt |
| node test/persisted-state.test.js, FINAL | exit0; persistedState tests passed | task-11-persistence-filter-final.txt |
| node node_modules/eslint/bin/eslint.js plugins/persistedState.client.js test/persisted-state.test.js test/customer-account.test.js, FINAL | exit0; 0 errors/1 pre-existing no-console warning, existing stale Browserslist notice | task-11-persistence-filter-lint-final.txt |

Self-review read the entire three-file diff: one production option, strict rather than normalized snapshots, real subscriber coverage, exact namespace boundaries, retained mutation writes, recovery/auth preservation, clock/window cleanup and unchanged helper/hydration. `git diff --check` and `git diff --cached --check` passed; the staged list contained exactly plugins/persistedState.client.js, test/customer-account.test.js and test/persisted-state.test.js.

Scoped commit command `git -c core.hooksPath=NUL commit -m 'fix: preserve staff persistence during customer mutations'` exited0; task-11-persistence-filter-commit.txt. Invocation-local hook override only, no persistent Git config or environment-hook execution. Follow-up commit: **25143d000a11e1fe493df23f9c5aee03cc63aec1**, 3 files, 88 insertions/3 deletions.

Final compatible pair: **F=25143d000a11e1fe493df23f9c5aee03cc63aec1**, **B=1a0d7c32a26d20bac0a1da3b707b13364611eee7** (unchanged). Full Task11 independent-review/fix-loop range: **6f694519d0db9ee631fe9d85550af71165dac293..25143d000a11e1fe493df23f9c5aee03cc63aec1**, including original implementation 73e87da94f92b33193c02169e2642722e0c59913 and this follow-up. Both worktrees are clean on feat/delivery-v1; full-range diff --check passed. All test/lint processes finished. Scratch/history remain retained for review and any authorized fix loop. No browser, dev server, detector, nested reviewer, backend/environment/provider/payment/deploy operation occurred.

## Fix round 1/5: I1 and I2

Status: both Important findings addressed and author-verified RED/GREEN. Source approval remains controller-owned; no visual acceptance or Nuxt compilation pass is claimed. M1 baseline warning/Browserslist noise remains deferred as instructed. Read task-11-review.md COMPLETE and retained task-11-review-probe.cjs COMPLETE before editing. The probe's real Vue patch/lifecycle reproduction was adapted into the owned behavioral suite; the original characterization probe/review were retained unchanged. Follow-up BASE: **25143d000a11e1fe493df23f9c5aee03cc63aec1**.

Exactly THREE files changed in this round:

| File | Bounded change |
| --- | --- |
| pages/compte/index.vue | I1: stable parent watches customer session transition and loads the book, independently of a destroyed login sender. |
| components/delivery/DeliveryAddressInput.vue | I2: retain server-validated candidate ID for the matching postal/context, and reuse it during fresh proof resolution at SAVE. |
| test/customer-account.test.js | Mounted compiled account lifecycle regressions plus new/changed postal candidate-to-SAVE and invalidation regressions; existing HTTP fixture now returns JSON strings through actual Axios response transforms. |

No store, login, book, persistence/plugin/helper, package, backend, dependency, environment or visual styling file changed in this round. No outside ownership was needed. Existing HTTP routes/query/CSRF/browserBinding and DTO interfaces are unchanged.

### I1 implementation and evidence

The parent account page now observes account.session; a valid session starts the existing book-loader method without depending on CustomerCodeLogin's completion event. Removed that event listener from the account template and removed openShop's duplicate direct book-loading call. A page-local bookEpoch prevents duplicate requests for the same session epoch. Epoch/session reset clears the prior loading flag/dedup state; completion/finally checks live page, shop and epoch before changing the current flag. Existing shop/openSequence and store stale-reply guards remain in place. The child still retains its original public authenticated event interface for consumers whose lifecycle permits it.

The new integration helper compiles the ACTUAL account template into render functions and MOUNTS it using installed Vue/Vuex and Vue's real DOM patcher against the retained probe's in-memory DOM boundary. It runs the page's real mounted/openShop hook, reactive route query watcher, real login methods and actual injected customer Axios/store. Only leaf UI/book rendering is stubbed; no page/session/store action or lifecycle is replaced. This is behavioral Node acceptance, NOT a browser or visual pass.

Mounted regressions prove: login commits the session and destroys its sender but still GETs the existing book exactly once; existing session restore also requests only once per shop; shop7->8 delayed old401 cannot clear the new session or dismiss its pending book indicator; a next shop without a session clears the old indicator and cannot receive the previous book. Login-only flow makes no resolution/quote call. Each page is destroyed and login intervals are cleaned up.

### I2 implementation and evidence

The shared input records only a successfully resolved server candidate ID plus its postalKey/contextKey in ephemeral component state. Private-only changes invalidate the old resolution but preserve that candidate when the postal key/context still match. resolve() still obtains a FRESH server proof on SAVE, now including the matching candidateId; it never promotes browser coordinates or an expired proof into permanent authority. Postal edits, value/context changes and destruction clear the candidate, and resolve() checks captured sequence/postal/context before accepting either success or error. It refuses a new request after destruction. A new ambiguity response clears any prior candidate selection for a new explicit choice.

Unchanged saved postal destinations still take the original `{addressId}` branch before any candidate behavior, including private-only edit and selection: no IGN/new-postal request. Complement/instructions remain separate from geocoder input and are submitted with the fresh proof to the existing address mutation.

The actual input/book SFC + real Vuex/Axios HTTP-boundary tests return ambiguity for text-only requests and proof ONLY for candidate-2. They choose that server candidate, change private instructions, invoke the actual book.save(), then require a fresh resolution with candidate-2 followed by POST for a NEW address or PATCH for a CHANGED saved postal address. Both preserve private fields, send exactly the four postal fields plus server candidate ID, and issue no quote/browser-coordinate request. Additional regression verifies candidate invalidation on postal/context change and no request after destroy. Existing saved-address/private-edit zero-new-postal renewal, stale replies, tenant isolation and strict raw persistence assertions still pass.

### Commands and results

Commands ran from F on native Node v22.13.1; raw logs retained in ignored scratch. No whole npm or full lint rerun was performed.

| Exact command / phase | Observed result | Scratch log |
| --- | --- | --- |
| node test/customer-account.test.js, initial RED | exit1; tests26/pass23/fail3: mounted login address GET count0, missing SAVE candidate for both new/changed postal | task-11-fix-round1-red.txt |
| node test/customer-account.test.js, expanded RED | exit1; tests27/pass23/fail4: same findings plus unwanted post-destroy resolver request | task-11-fix-round1-red-expanded.txt |
| node test/customer-account.test.js, first GREEN | exit0; tests27/pass27/fail0 | task-11-fix-round1-green.txt |
| node test/persisted-state.test.js | exit0; persistedState tests passed | task-11-fix-round1-persistence.txt |
| node node_modules/eslint/bin/eslint.js pages/compte/index.vue components/delivery/DeliveryAddressInput.vue test/customer-account.test.js, initial | exit1; four test-harness style errors/one component-option-order warning | task-11-fix-round1-lint.txt |
| node test/customer-account.test.js, FINAL after harness style correction | exit0; tests27/pass27, fail/cancelled/skipped/todo0; duration_ms6322.0676 | task-11-fix-round1-final-account.txt |
| node test/persisted-state.test.js, FINAL | exit0; persistedState tests passed | task-11-fix-round1-final-persistence.txt |
| node node_modules/eslint/bin/eslint.js pages/compte/index.vue components/delivery/DeliveryAddressInput.vue test/customer-account.test.js, FINAL | exit0; no lint errors/warnings in those three files; existing stale Browserslist notice retained | task-11-fix-round1-final-lint.txt |

The initial lint findings were confined to the new test boundary: required class-member spacing, Vue option ordering and Function constructor usage. Used vm.compileFunction for compiler-produced render bodies, consistent with the existing harness; no assertion was disabled or production fix altered. No dependency/baseline warning cleanup. Previous whole-npm failure plus bounded continuation history remains exactly as recorded above, not reclassified as a successful whole invocation.

### Self-review, commit and retained pair

Read the complete three-file diff after the fixes and checked parent session-watch ordering, one-load-per-epoch guard, null-session/loading reset, captured shop/epoch finalizers, candidate success-only retention, postal/context/value/destroy invalidation, private edits, stored-ID precedence and exact HTTP payloads. Verified tests exercise mounted lifecycle and candidate-to-mutation integration rather than only unmounted method assertions. `git diff --check` and staged diff --check passed. Staged list was exactly the three files above.

Scoped command `git -c core.hooksPath=NUL commit -m 'fix: load customer book and retain address candidates'` exited0; log task-11-fix-round1-commit.txt. Invocation-local hook override only; no persistent Git config or environment hook execution. Commit **955f3981b0e0339c388aa87e6dbb18ce0720f74e**, 3 files, 248 insertions/16 deletions.

Final compatible pair: **F=955f3981b0e0339c388aa87e6dbb18ce0720f74e**, **B=1a0d7c32a26d20bac0a1da3b707b13364611eee7** unchanged. Round review range: **25143d000a11e1fe493df23f9c5aee03cc63aec1..955f3981b0e0339c388aa87e6dbb18ce0720f74e**. Full Task11 range: **6f694519d0db9ee631fe9d85550af71165dac293..955f3981b0e0339c388aa87e6dbb18ce0720f74e**, retaining the original implementation and persistence follow-up. Both worktrees clean on feat/delivery-v1; both round/full diff --check passed. All worker-started test/lint processes exited.

Controller's existing hidden Nuxt server at 127.0.0.1:8097 (reported wrapper40396/listener37940) was not accessed, started, stopped or otherwise controlled. Compilation/log/runtime ownership stays with the controller. No new browser/visual QA, context launcher, detector, subagent/reviewer, provider, secret/env, backend, payment, printing, push or deploy action occurred. Full Task11 source approval and Task17 visual acceptance remain pending controller gates; retained reports/probe/logs stay available for the fix loop.
