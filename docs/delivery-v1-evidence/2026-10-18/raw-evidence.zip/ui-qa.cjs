const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright-core');
const root = path.resolve(__dirname, '../../..', '..');
const output = path.join(__dirname, 'screenshots');
fs.mkdirSync(output, { recursive: true });
const origin = 'http://127.0.0.1:8097';
const token = `eyJhbGciOiJIUzI1NiJ9.${Buffer.from(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + 3600, id: 1, shopid: 7, access: 0 })).toString('base64url')}.fixture`;
const session = { subject: 'customer', customerId: '101', shopId: 7, csrfToken: 'a'.repeat(64), expiresAt: '2036-01-01T00:00:00.000Z' };
const shop = { id: 7, shop_name: 'Restaurant de recette', shop_adress: '7 rue des Ateliers, 75011 Paris', shop_phone: '0100000000', shop_mail: 'restaurant@example.invalid', shop_profile_image: 'qa-logo.png', shop_description: 'Cuisine de saison', shop_hours: '', shop_social_media: '', shop_theme: 'default', shop_payment_methods: ['Especes', 'Carte bancaire'], shop_discount_percentages: [5, 10, 15], activate_tva: true, shop_status: 'Ouvert', kitchen_closed: false, qr_payment_mode: 'pay_at_counter', auto_print_order_tickets: false, stripe_connected: false, stripe_charges_enabled: false, stripe_onboarding_complete: false };
const address = { street: '7 avenue des Ateliers et de la Manufacture', postalCode: '75011', city: 'Paris', country: 'FR', latitude: 48.86, longitude: 2.37, complement: 'Batiment de recette, dernier etage', instructions: 'PRIVATE_QA_INSTRUCTIONS - entree de la cour, longue consigne fictive pour verifier le retour a la ligne.' };
const addresses = [1, 2, 3].map(n => ({ id: String(200 + n), label: `Adresse ${n}`, isDefault: n === 1, addressSnapshot: { ...address, street: `${n * 7} avenue des Ateliers et de la Manufacture` } }));
const charge = { feeCents: 400, totalExclTaxCents: 333, taxCents: 67, vatRate: 20 };
const missions = [
  { id: '501', orderId: 1001, orderReference: 'LIV-2026-000001', shopId: 7, version: 2, courierId: 11, deliveryStatus: 'assigned', preparationStatus: 3, paymentStatus: 'unpaid', remainingDueCents: 2400, acceptanceStatus: 'accepted', allowedActions: ['pickup', 'assign', 'reportIssue'], addressSnapshot: { ...address }, contactSnapshot: { name: 'Alexandre de la Manufacture et des Ateliers', phone: '+33000000000' }, items: [{ quantity: 1, name: 'Menu de recette avec accompagnement de saison', customizations: [{ step: 'Accompagnement', choice: 'Legumes' }] }], financials: { grand_total: 24, delivery_charge: charge } },
  { id: '502', orderId: 1002, orderReference: 'LIV-2026-000002-REFERENCE-LONGUE', shopId: 7, version: 3, courierId: 11, deliveryStatus: 'in_transit', preparationStatus: 3, paymentStatus: 'unpaid', remainingDueCents: 2400, acceptanceStatus: 'accepted', allowedActions: ['collectPayment', 'reportIssue'], addressSnapshot: { ...address, street: '28 rue des Longs Noms et des Ateliers de Recette' }, contactSnapshot: { name: 'Camille de la Recette', phone: '+33000000000' }, items: [{ quantity: 2, name: 'Produit de recette', customizations: [] }], financials: { grand_total: 24, delivery_charge: charge } },
  { id: '503', orderId: 1003, orderReference: 'LIV-2026-000003', shopId: 7, version: 4, courierId: 11, deliveryStatus: 'in_transit', preparationStatus: 3, paymentStatus: 'paid', remainingDueCents: 0, acceptanceStatus: 'accepted', allowedActions: ['deliver', 'reportIssue'], addressSnapshot: { ...address }, contactSnapshot: { name: 'Client fictif prepayant', phone: '+33000000000' }, items: [{ quantity: 1, name: 'Plat de recette', customizations: [] }], financials: { grand_total: 24, delivery_charge: charge } },
  { id: '504', orderId: 1004, orderReference: 'LIV-2026-000004', shopId: 7, version: 5, courierId: 12, deliveryStatus: 'issue', preparationStatus: 3, paymentStatus: 'paid', remainingDueCents: 0, acceptanceStatus: 'accepted', allowedActions: ['resolveIssue'], addressSnapshot: { ...address }, contactSnapshot: { name: 'Client fictif en attente', phone: '+33000000000' }, items: [], financials: { grand_total: 24, delivery_charge: charge } },
  { id: '505', orderId: 1005, orderReference: 'LIV-2026-000005', shopId: 7, version: 6, courierId: 11, deliveryStatus: 'delivered', preparationStatus: 3, paymentStatus: 'paid', remainingDueCents: 0, acceptanceStatus: 'accepted', allowedActions: [], items: [], financials: { grand_total: 24, delivery_charge: charge } },
];
const couriers = [{ id: 11, username: 'Livreur de recette', status: 1, available: 1, missionCount: 3 }, { id: 12, username: 'Livreur indisponible', status: 1, available: 0, missionCount: 1 }, { id: 13, username: 'Ancien livreur - fonds a rapprocher', status: 0, currentCourier: 0, available: 0, missionCount: 0 }];
const balance = { shopId: 7, courierId: 11, version: 4, collectedCents: 2400, receivedCents: 1650, remainingDueCents: 750, discrepancyCents: -750, surplusCents: 0, adjustedDueCents: 0, refundedCents: 0, collections: [{ collectionId: '701', collectedCents: 2400, allocatedCents: 1650, refundedCents: 0, remainingDueCents: 750 }], remittances: [{ remittanceId: '801', cashierId: 1, expectedCents: 2400, receivedCents: 1650, discrepancyCents: -750, createdAt: '2026-10-18T10:00:00Z' }], adjustments: [], refunds: [] };
const settings = { enabled: true, revision: 3, origin: { latitude: 48.86, longitude: 2.37 }, maxDistanceMeters: 5000, minimumItemsCents: 0, freeDeliveryEnabled: false, freeDeliveryThresholdCents: null, fiscalPolicy: { mode: 'configured_rate', vatRate: 20 }, bands: [{ upToMeters: 2000, feeCents: 200 }, { upToMeters: 5000, feeCents: 400 }] };
const publicView = { reference: 'LIV-2026-000001', stage: 'in_delivery', restaurant: { name: shop.shop_name, phone: shop.shop_phone, address: shop.shop_adress }, addressSnapshot: { street: address.street, postalCode: address.postalCode, city: address.city, country: 'FR' }, payment: { status: 'paid', totalCents: 2400, remainingDueCents: 0 } };
const report = { mode: process.argv[2] || 'batch', startedAt: new Date().toISOString(), boundaries: 'Actual rendered Nuxt/Vuetify with fictional browser API route doubles; not actual provider/SQL authority acceptance.', captures: [], errors: [], unmatchedApi: [], outboundBlocked: [], requests: [], interactions: [], failures: [] };
const reportPath = path.join(output, `ui-${report.mode}-${Date.now()}.json`);
if (fs.existsSync(path.join(output, 'ui-report.json'))) fs.copyFileSync(path.join(output, 'ui-report.json'), path.join(output, `ui-previous-${Date.now()}.json`));
const clone = value => JSON.parse(JSON.stringify(value));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function openContext(browser, role = 'anonymous', viewport = { width: 1440, height: 1000 }, scenario = {}) {
  const context = await browser.newContext({ viewport, deviceScaleFactor: 1, serviceWorkers: 'block' });
  const state = { personal: scenario.personal || false, channels: scenario.channels || { email: true, whatsapp: true }, fail: scenario.fail || null, ...scenario };
  await context.addInitScript(({ token, role }) => {
    if (role === 'anonymous') return;
    const access = role === 'courier' ? 6 : role === 'cashier' ? 1 : role === 'client' ? 2 : 0;
    const id = role === 'courier' ? 11 : role === 'client' ? 90 : role === 'cashier' ? 2 : 1;
    Object.entries({ token, access: String(access), idUser: String(id), shopid: '7', session_subject: 'staff', module_permissions: JSON.stringify(['delivery', 'orders', 'cashregister', 'history', 'reports']), is_primary_admin: access === 0 ? '1' : '0' }).forEach(([key, value]) => localStorage.setItem(key, value));
  }, { token, role });
  await context.route('**/*', async route => {
    const req = route.request();
    const url = new URL(req.url());
    if (/^\/api\/v1\/imgprofile\/qa-logo\.png$/.test(url.pathname) && ['localhost', '127.0.0.1'].includes(url.hostname)) return route.fulfill({ contentType: 'image/png', body: fs.readFileSync(path.join(root, 'static/logo.png')) });
    const apiAt = url.pathname.indexOf('/baseurl/api/v1');
    if (apiAt < 0) {
      if (url.origin === origin || ['data:', 'blob:'].includes(url.protocol)) return route.continue();
      if ((['fonts.googleapis.com', 'fonts.gstatic.com'].includes(url.hostname) && ['stylesheet', 'font'].includes(req.resourceType())) ||
        (url.hostname === 'cdn.jsdelivr.net' && url.pathname.startsWith('/npm/@mdi/font@latest/') && ['stylesheet', 'font'].includes(req.resourceType()))) {
        const headers = { ...req.headers() }; delete headers.referer;
        return route.continue({ headers });
      }
      report.outboundBlocked.push({ host: url.hostname, path: url.pathname, type: req.resourceType() });
      return route.abort('blockedbyclient');
    }
    const p = url.pathname.slice(apiAt + '/baseurl/api/v1'.length);
    const method = req.method();
    report.requests.push({ method, path: p, queryKeys: [...url.searchParams.keys()], hasAuthorization: Boolean(req.headers().authorization), hasCookie: Boolean(req.headers().cookie) });
    const headers = { 'Access-Control-Allow-Origin': req.headers().origin || origin, 'Access-Control-Allow-Credentials': 'true', 'Access-Control-Allow-Headers': 'Authorization,Content-Type,X-CSRF-Token', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' };
    const send = (data, status = 200, error = null) => route.fulfill({ status, headers, contentType: 'application/json', body: JSON.stringify({ code: status, success: status < 400, message: status < 400 ? 'OK' : 'Refus de recette', data, error }) });
    if (method === 'OPTIONS') return route.fulfill({ status: 204, headers });
    if (state.handleApi) {
      const extra = await state.handleApi({ path: p, method, url, body: req.postDataJSON(), state });
      if (extra !== undefined) return send(extra.data, extra.status || 200, extra.error || null);
    }
    if (state.fail && p.includes(state.fail)) return send({}, 503, 'DELIVERY_UNAVAILABLE');
    if (/customer-auth\/channels$/.test(p)) return send(state.channels);
    if (/customer-auth\/session$/.test(p)) return send(state.personal ? session : null, state.personal ? 200 : 401, state.personal ? null : 'CUSTOMER_SESSION_REQUIRED');
    if (/customer-auth\/(?:link\/)?challenges$/.test(p)) return send({ challengeId: '9001', expiresAt: new Date(Date.now() + 600000).toISOString(), resendAfter: new Date(Date.now() + 60000).toISOString(), status: state.challengeStatus || 'pending' });
    if (/customer-auth\/(?:link\/)?verify$/.test(p)) { state.personal = true; return send(session); }
    if (/customer-auth\/logout$/.test(p)) { state.personal = false; return send({ revoked: true }); }
    if (/customer\/addresses(?:\/\d+)?$/.test(p)) {
      if (method === 'DELETE') return send({ deleted: true });
      if (method !== 'GET') return send(addresses[0]);
      return send(addresses);
    }
    if (/address-resolutions$/.test(p)) return send({ addressResolutionToken: 'fixture-postal-proof', addressSnapshot: address, expiresAt: new Date(Date.now() + 900000).toISOString() });
    if (/shopInfo(?:\/click-and-collect\/\d+)?$/.test(p)) return send(p === '/shopInfo' ? [shop] : shop);
    if (p === '/delivery/availability') return send({ enabled: true });
    if (p === '/delivery/settings') return send(settings);
    if (p === '/delivery/quotes') return send({ shopId: 7, quoteToken: 'fixture-quote-proof', expiresAt: new Date(Date.now() + 300000).toISOString(), itemsTotalCents: 2000, itemsDiscountCents: 0, deliveryFeeCents: 400, grandTotalCents: 2400, addressSnapshot: address });
    if (p === '/delivery/customers') return send([{ id: '101', name: 'Client fictif', contactPhone: '+33000000000' }]);
    if (/delivery\/customers\/\d+\/addresses/.test(p)) return send(addresses);
    if (p === '/delivery/couriers') return send(url.searchParams.has('financialHolders') ? couriers : couriers.slice(0, 2));
    if (/cash-balance$/.test(p)) { const match = p.match(/couriers\/(\d+)/); return send({ ...balance, courierId: match ? Number(match[1]) : 11 }); }
    if (p === '/courier/availability') return send({ courierId: 11, available: true });
    if (p === '/deliveries') return send(missions);
    if (p === '/courier/deliveries') return send(missions.filter(row => row.courierId === 11));
    if (/\/deliveries\/\d+\/refund-eligibility$/.test(p)) return send({ eligible: true, collectionId: '701', method: 'cash', amountCents: 2400, originalCourierId: 11, returnSources: ['register', 'courier'] });
    if (/\/deliveries\/\d+$/.test(p)) return send(missions.find(row => row.id === p.split('/').pop()) || missions[0]);
    if (p === '/delivery/tracking/read') return state.trackingExpired ? send({}, 404, 'DELIVERY_NOT_FOUND') : send(publicView);
    if (/\/tracking-token$/.test(p)) return send({ trackingUrl: `/livraison/suivi#${'q'.repeat(43)}` });
    if (/\/orders$|\/ordersbyUserId|\/orders\/archives/.test(p)) return send([]);
    if (/service-points/.test(p)) return send([{ id: 70, name: 'Comptoir recette', type: 'counter', is_active: 1 }]);
    if (/\/user\/me$/.test(p)) return send({ id: role === 'courier' ? 11 : role === 'cashier' ? 2 : 1, shopid: 7, access: role === 'courier' ? 6 : role === 'cashier' ? 1 : 0, status: 1, session_subject: 'staff', token, module_permissions: ['delivery'] });
    report.unmatchedApi.push({ method, path: p });
    return send([]);
  });
  const page = await context.newPage();
  page.setDefaultTimeout(12000);
  page.setDefaultNavigationTimeout(60000);
  page.on('pageerror', error => report.errors.push({ role, message: error.message }));
  return { context, page, state };
}

async function capture(page, name, assertions = []) {
  await page.waitForTimeout(250);
  await page.evaluate(async () => { await document.fonts.ready; });
  await page.evaluate(() => { window.scrollTo(0, 0); });
  const info = await page.evaluate(() => {
    const visible = element => { const r = element.getBoundingClientRect(); const s = getComputedStyle(element); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
    const outside = [...document.querySelectorAll('h1,h2,h3,button,input,.v-alert,.v-card__title')].filter(visible).filter(element => { const r = element.getBoundingClientRect(); return r.left < -1 || r.right > innerWidth + 1; }).map(element => ({ tag: element.tagName, text: (element.textContent || element.getAttribute('aria-label') || '').trim().slice(0, 100) })).slice(0, 20);
    return { path: location.pathname, viewport: { width: innerWidth, height: innerHeight }, title: document.title, text: document.body.innerText.slice(0, 13000), overflow: document.documentElement.scrollWidth > innerWidth + 1, outside, images: [...document.images].map(img => ({ path: new URL(img.currentSrc || img.src, location.href).pathname, loaded: img.complete && img.naturalWidth > 0 })), mdi: [...document.querySelectorAll('.mdi')].filter(visible).slice(0, 6).map(el => ({ font: getComputedStyle(el, '::before').fontFamily, content: getComputedStyle(el, '::before').content })), font: getComputedStyle(document.body).fontFamily };
  });
  const screenshot = path.join(output, `${name}.png`);
  await page.screenshot({ path: screenshot, fullPage: true, animations: 'disabled' });
  for (const text of assertions) if (!info.text.toLocaleLowerCase().includes(text.toLocaleLowerCase())) report.failures.push({ name, missing: text });
  report.captures.push({ name, screenshot, ...info });
  fs.writeFileSync(path.join(output, 'ui-report.json'), JSON.stringify(report, null, 2));
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  process.stdout.write(`${name}: path=${info.path}, overflow=${info.overflow}, outliers=${info.outside.length}\n`);
}

async function go(page, pathname) {
  await page.goto(`${origin}${pathname}`, { waitUntil: 'domcontentloaded', timeout: 90000 });
  await page.waitForFunction(() => window.$nuxt && window.$nuxt.$store, { timeout: 90000 });
  await page.waitForTimeout(500);
}

async function main() {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    if (report.mode === 'operator') {
      const o = await openContext(browser, 'admin');
      await go(o.page, '/livraison');
      report.interactions.push({ name: 'operator-arrival', state: await o.page.evaluate(() => ({ path: location.pathname, authenticated: window.$nuxt.$store.state.authenticated, user: { id: window.$nuxt.$store.state.users.user.id, access: window.$nuxt.$store.state.users.user.access, shop: window.$nuxt.$store.state.users.user.shopid, subject: window.$nuxt.$store.state.users.user.session_subject }, text: document.body.innerText.slice(0, 5000) })) });
      await capture(o.page, 'operator-arrival-diagnostic');
      await o.context.close();
      return;
    }
    for (const [size, viewport] of Object.entries({ desktop: { width: 1440, height: 1000 }, mobile: { width: 390, height: 844 }, narrow: { width: 320, height: 640 } })) {
      if (!(report.mode === 'resume' && size === 'desktop')) {
      const a = await openContext(browser, 'anonymous', viewport);
      await go(a.page, '/compte?shopId=7');
      await capture(a.page, `account-login-${size}`, ['Mon compte', 'Recevoir un code']);
      if (size !== 'narrow') {
        await a.page.getByLabel('Adresse e-mail', { exact: true }).fill('recette@example.invalid');
        await a.page.getByRole('button', { name: 'Recevoir un code', exact: true }).click();
        await a.page.getByLabel('Code a 6 chiffres', { exact: true }).waitFor();
        await capture(a.page, `account-pending-${size}`, ['Envoi incertain', 'Renvoyer dans']);
        await a.page.getByLabel('Code a 6 chiffres', { exact: true }).fill('123456');
        await a.page.getByRole('button', { name: 'Me connecter', exact: true }).click();
        await a.page.getByRole('heading', { name: 'Mes adresses', exact: true }).waitFor();
        await capture(a.page, `addresses-${size}`, ['Adresse 1', 'Adresse 3']);
        await a.page.getByRole('button', { name: 'Modifier Adresse 1', exact: true }).click();
        await capture(a.page, `address-edit-${size}`, ['Adresse par defaut', 'Enregistrer']);
      }
      await a.context.close();

      const t = await openContext(browser, 'anonymous', viewport);
      await go(t.page, `/livraison/suivi#${'q'.repeat(43)}`);
      await capture(t.page, `tracking-active-${size}`, ['En livraison', '24,00']);
      const trackingState = await t.page.evaluate(() => ({ hashEmpty: !location.hash, noReferrerMeta: document.querySelector('meta[name="referrer"]')?.content === 'no-referrer', privateContentAbsent: !document.body.innerText.includes('PRIVATE_QA_INSTRUCTIONS') }));
      report.interactions.push({ name: `tracking-${size}`, ...trackingState });
      await t.context.close();
      }

      const o = await openContext(browser, 'admin', viewport);
      await go(o.page, '/livraison');
      await o.page.getByRole('tab', { name: 'Commandes', exact: true }).waitFor();
      if (!(report.mode === 'resume' && size === 'desktop')) {
      await capture(o.page, `dispatch-${size}`, ['Livraison', 'LIV-2026']);
      await o.page.getByRole('button', { name: 'Ouvrir le dossier', exact: true }).first().click();
      await capture(o.page, `dispatch-detail-${size}`, ['PRIVATE_QA_INSTRUCTIONS']);
      await o.page.getByRole('button', { name: 'Fermer', exact: true }).last().click();
      await o.page.getByRole('tab', { name: 'Livreurs', exact: true }).click();
      await capture(o.page, `couriers-${size}`, ['Livreur de recette']);
      }
      await o.page.getByRole('tab', { name: "Remises d'especes", exact: true }).click();
      await capture(o.page, `remittances-empty-${size}`, ['Detenteur des fonds']);
      await o.page.locator('.v-select').filter({ has: o.page.getByLabel('Detenteur des fonds', { exact: true }) }).locator('.v-input__slot').click();
      await o.page.getByRole('option', { name: 'Livreur de recette', exact: true }).click();
      await capture(o.page, `remittances-balance-${size}`, ['7,50', 'Solde attendu actuel']);
      await o.page.getByRole('tab', { name: 'Reglages', exact: true }).click();
      await capture(o.page, `settings-${size}`, ['TVA explicite des frais', 'Enregistrer les reglages']);
      await o.context.close();

      const c = await openContext(browser, 'courier', viewport);
      await go(c.page, '/livreur');
      await capture(c.page, `courier-${size}`, ['Mes missions', '7,50']);
      if (size === 'mobile') { await c.page.setViewportSize({ width: 844, height: 390 }); await capture(c.page, 'courier-landscape', ['Mes missions']); }
      report.interactions.push({ name: `courier-links-${size}`, hrefs: await c.page.locator('a[href^="tel:"],a[href^="https://www.google.com/maps/"]').evaluateAll(links => links.map(link => ({ scheme: new URL(link.href).protocol, hasPrivateInstructions: link.href.includes('PRIVATE_QA_INSTRUCTIONS') }))) });
      await c.context.close();
    }
    const expired = await openContext(browser, 'anonymous', { width: 390, height: 844 }, { trackingExpired: true });
    await go(expired.page, `/livraison/suivi#${'q'.repeat(43)}`);
    await capture(expired.page, 'tracking-expired-mobile', ['indisponible ou expire']);
    await expired.context.close();
  } finally {
    await browser.close();
    report.finishedAt = new Date().toISOString();
    fs.writeFileSync(path.join(output, 'ui-report.json'), JSON.stringify(report, null, 2));
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    process.stdout.write(`UI captures=${report.captures.length}, assertionFailures=${report.failures.length}, pageErrors=${report.errors.length}\n`);
  }
}
module.exports = { openContext, capture, go, report, reportPath, output, origin, shop, address, addresses, charge, missions, couriers, balance, settings, publicView, session, clone, chromium };
if (require.main === module) main().catch(error => { process.stderr.write(`${error.stack}\n`); process.exitCode = 1; });
