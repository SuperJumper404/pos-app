**N-I1 - Confirmed nonterminal command discarded after a concurrent pre-commit active detail: ADDRESSED.** F/store/courier.js:260, :261, :262 and :263 allow a strictly newer confirmed server version to supersede an existing active projection. Pickup version3/in_transit is therefore accepted after the concurrent version2/assigned detail; pending settlement at :265 no longer leaves that stale active projection behind. F/test/courier-mobile.test.js:703 covers both new pickup and explicit recovery, plus new collection and producer-shaped equal-version collection replay.

## Finding Verdicts

- **N-I1: ADDRESSED.** The version exception now applies to nonterminal confirmations, while still requiring an existing nonterminal current mission. When the current active DTO has equal/higher version, :262 prevents direct overwrite and :267-271 dispatch the existing guarded own-detail read, recheck the actor/epoch, and derive the returned delivery from accepted current state. This supplies the authority reconciliation missing from Round1.
- **Original I1 preservation within the fix: CHECKED.** The bypass requires `active` at :260-261; neither removal nor terminal authority qualifies. A suppressed result against those barriers also skips reconciliation at :267. The two new higher-version nonterminal reply controls and the retained nine Round1 tests record successful results on both runtimes. This is preservation checking of the fix, not a fresh verdict on untouched code.
- **Lower/equal-version and payment authority: CHECKED.** The strict comparison at :262 applies even when an intervening active list did not advance the per-mission privacy sequence. F/test/courier-mobile.test.js:753 covers version3 command confirmation against version5 detail/list, holds the reconciliation request, and checks version5 remains visible. The collection replay at :703 applies paid/version3 before losing the first reply, reloads paid/version3, and replays the original expectedVersion2 body/key; no version4 is invented. Its equal-version confirmation obtains one own-detail reconciliation and preserves idempotentReplay, with two explicit POSTs total.

## New Breakage In The Fix Diff

**None. New Critical: 0; Important: 0; Minor: 0.**

Check: inspected the entire supplied two-file package once. The implementation change is confined to confirmed-result publication and reconciliation. It changes no preflight, key generation, submitted body, amount, caller identity, recovery serialization, route, dependency, or persistent state schema.

Check: F/store/courier.js:264-265 still settles confirmed collection recovery and pending once the POST has succeeded. The equal-version case does not turn an already-confirmed payment into another collection attempt. :268 performs a read only; :271 preserves the response envelope/financial metadata and substitutes the accepted delivery projection. :273 retains own-balance refresh for collection/delivery. Existing catch/cleanup behavior is outside the changed lines and was not reopened as a new finding.

Check: :269 revalidates current actor/epoch after the new await. The reconciliation result is only returned when the read succeeds and the mission still exists in current state at :270. A concurrent removal cannot supply an old private DTO through that state lookup. Direct publication continues through the existing MISSION mutation and freshness barrier rather than a new state writer.

Check: the new tests assert independent mission/order preservation, pending cleanup, loading release, exact replay bodies, server payment status/due/actions, cleared dedicated collection metadata after confirmation, one reconciliation for equal-version replay, and no additional mutation. The newer-authority tests verify the visible version while the reconciliation request is held. Removal/terminal tests assert no extra GET and no private-address resurrection.

## Named Checks And Retained Evidence

**NC1 - Scope and identity.** Read task-14-brief.md, the complete task-14-fix-round1-review.md including exact N-I1, the appended Round2 section at the end of task-14-report.md, and the requested subagent-driven-development/re-review-prompt.md. Package BASE is 6cd46a4163aa04ba7ce875b19501e51c9203bde9; HEAD is 7ee09d3407760b3fc488e4eb051bea82b99e437c. Package names only F/store/courier.js and F/test/courier-mobile.test.js, 122 additions/5 deletions. task-14-fix2-commit.txt agrees with that commit/delta and records nativeExit=0. No git command or independent HEAD/status audit was performed. B0150e247fd3ff874eabeb85857aaa7482d2b430e is supplied unchanged context, not a fresh backend review.

**NC2 - Final covering runs.** Read both complete task-14-fix2-final-node18.txt and task-14-fix2-final-node22.txt. Each records 44 tests, 44 pass, 0 fail/cancelled/skipped/todo, nativeExit=0. Checked all eight added cases against the supplied diff and their successful log entries:

| Test | Coverage |
| --- | --- |
| 37 | New pickup version3 survives concurrent active version2 detail and returns a confirmed outcome. |
| 38 | Explicit pickup recovery survives the same ordering with identical replay body/key. |
| 39 | New collection publishes paid/version3, zero server due and deliver action after unpaid/version2 detail. |
| 40 | Applied-but-lost collection reloads paid/version3; same-key replay retains expectedVersion2 and version3, reconciles once, returns idempotentReplay, and sends no third POST. |
| 41 | Lower-version confirmation cannot replace newer active detail; current authority is reread. |
| 42 | Same protection and reconciliation after newer active list. |
| 43 | Higher-version nonterminal reply cannot restore an authoritatively removed mission or trigger a reopening read. |
| 44 | Higher-version nonterminal reply cannot replace terminal authority; private address remains absent and no reopening read is sent. |

Check: both full final logs also record unchanged tests28-36 passing, covering original same-actor detail404/list ordering, unresolved replay, terminal/list/detail barriers, command closure/404, and unseen-ID omission. Existing recovery/payment/persistence/identity cases also remain successful in those retained runs. Untouched test implementations were not separately reread.

**NC3 - Counterexamples and refinement.** Inspected named failures/counts/exits in both initial RED logs and both corrected producer BASE RED logs. Each executes eight new cases with two privacy controls passing and six failing, nativeExit=1. Read the corrected Node22 producer BASE log in full: pickup remains assigned, collection remains version2, equal-version replay returns null, and both newer-active-authority cases omit reconciliation. These failures match the changed assertions and the Round1 defect.

Check: initial focused GREEN logs record eight executed passes each; Node18 enumerates 36 name-filter skips. Their earlier version2/new collection label is superseded by the producer refinement, not treated as final replay evidence. task-14-fix2-producer-green-node22.txt records the refined eight cases passing. Both FINAL unfiltered logs contain the refined version3 replay case and no skips. The two initial producer BASE attempts record SyntaxError/nativeExit=1 before tests; those shell-quoting failures are excluded from product RED evidence. Corrected BASE characterization is retained author evidence; no BASE source was freshly loaded or executed by this reviewer.

**NC4 - Affected regressions.** Inspected named success/count/exit excerpts from all fourteen task-14-fix2-regression-node18/22-NAME.txt logs. Every log records nativeExit=0. Per runtime: delivery-checkout 29/29, customer-account 27/27, delivery-operator 37/37, each with zero failures/cancellations/skips/todos; auth-middleware, session-auth, counter-checkout-store and persisted-state report their legacy assertion success. These are retained results, not fresh executions.

**NC5 - Lint.** Read task-14-fix2-lint.txt in full: nativeExit=0, no ESLint code diagnostics, inherited outdated Browserslist stderr. The evidence is not described as noise-free.

**NC6 - Reviewer execution.** No test, lint, build, server, HTTP fixture or SQL was rerun. Reading the supplied fix and retained evidence left no unanswered named doubt requiring a focused reproduction. Review verification consisted of package/report/log inspection and checking the written report artifact.

## Out-Of-Scope Observations

- **Deferred M1:** stale read-error banner remains the previously deferred nonblocking final-review item. It was not reopened or promoted.
- **Deferred M2:** baseline Browserslist diagnostics and inherited fixture logging remain deferred. No tooling/logger cleanup is required by this fix review.
- **Additional observations:** none. No untouched-code issue was promoted into fix breakage.

## Evidence Limits And Boundaries

Check: workspace_fs was attempted as the primary project reader and denied the authorized worktree as outside its allowed roots. Local PowerShell supplied read-only scratch/package/log access; no permission or environment configuration was changed. The only written artifact is this report.

Check: the complete Round2 package was read once with no cutoff. No git regeneration or separate changed implementation/test source reread occurred. No agents, source/index/branch changes, original checkout reads, environment/provider access, remote DB, real financial/payment/refund/print/call action, server management, push/deploy/merge, browser or detector were used.

Limit: conclusions apply only to N-I1 and regressions introduced by this two-file Round2 fix. Retained logs corroborate the report and match the supplied diff; they are not fresh runtime results or independent working-tree/commit attestation. The actual fixture/backend producer implementations were not freshly audited, and no backend finding is asserted.

Limit: actual phone portrait/landscape, long-address, network-error and mixed-payment visual acceptance remains PENDING Task17 ONEbatch. No visual PASS, whole-application/build PASS, configured Node20 commissioning, or full Task14/V1 acceptance is inferred.

## Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** N-I1 ADDRESSED; open in-scope findings: 0; new C/I/M: 0/0/0. M1/M2 remain two nonblocking deferred final-review items. Task17 actual-phone visual acceptance remains pending.
