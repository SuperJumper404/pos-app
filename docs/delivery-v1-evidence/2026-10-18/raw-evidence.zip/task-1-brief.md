### Task 1: Persister reglages, dossiers et journal financier

**Files:** Create `B/db/migrations/20261016120000_delivery_foundation.sql`, `B/test/helpers/deliveryDatabase.js`, `B/test/delivery-schema.integration.test.js`; modify `B/package.json`.

**Interfaces:** Produit les tables livraison de la section 9, sauf tables `customer_*`/`customers` reservees a la tache 8 ; colonnes nullables `orders/archives.delivery_id`, `customer_account_id`, `fulfillment_type`, `users.courier_available`; helper SQL jetable defini dans le plan principal. Les identifiants references `shop.id`/`users.id` recopient exactement type et signedness existants. Chaque nouvelle table porte `shopid` et ses index de lecture/idempotence.

- [ ] **Step 1: Ecrire `legacyRowsStayLegacyAndLinksSurviveArchive` sur une base jetable**, en l'absence initiale de migration. Inserer les anciennes lignes dans `beforeDeliveryMigrations(db)` via `seedScenario({legacy:true})`, pas apres la migration que le test doit verifier. Assertions apres migration :
  ```js
  assert.equal(legacyOrder.delivery_id, null)
  assert.equal(legacyArchive.fulfillment_type, 'takeaway') // fixture is_takeaway = 1
  assert.equal(Boolean(settingsForShop7.enabled), false)
  await assert.rejects(insertDuplicateDeliveryForOrder31, { code: 'ER_DUP_ENTRY' })
  ```
  Verifier egalement FK cross-type, montants non negatifs et absence de cascade dossier lors d'une suppression active/archivee autorisee. La fixture ne supprime aucune base fournie par l'utilisateur.
- [ ] **Step 2: Executer** `node test/delivery-schema.integration.test.js` depuis `B` ; attendu rouge pour schema absent, pas pour une connexion mal configuree. Configurer d'abord une instance MySQL locale jetable via le compose local existant.
- [ ] **Step 3: Ajouter la migration reversible et le helper**. Creation atomique d'un seul defaut d'adresse reservee a la tache 8 ; ici garantir unicite des liens par representation, version optimiste, idempotency key/hash/result sur evenements et remises, allocation plafonnee par verrou transactionnel. Stocker les snapshots d'adresse/frais et la preuve du contexte prive de checkout. Ajouter `service_rate_limits` pour les quotas partages du geocodeur puis des codes, et `courier_cash_adjustments` pour les regularisations append-only (commerce, livreur, collection/remise source, impact signe, motif, acteur, date et idempotence). Creer un reglage desactive pour chaque commerce existant. Backfill `fulfillment_type` depuis `is_takeaway`, sans supposer un compte client historique ; pas de FK client avant tache 8.
- [ ] **Step 4: Executer le test vert**, puis migration up/down/up sur la base jetable. Creer `test:delivery:db` avec liste explicite et ajouter ce test ; aucune migration distante.
- [ ] **Step 5: Commit `feat: add delivery persistence`**, uniquement migration, helper, tests et script modifies dans `B`.

