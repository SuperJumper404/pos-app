const path = require('path')
const { spawnSync } = require('child_process')
const frontend = process.argv[2] === 'frontend'
const files = frontend ? ['delivery-receipts', 'order-edit', 'order-detail-checkout', 'receipt-printing',
  'receipt-bundle', 'history-ticket', 'vat-breakdown', 'stripe-terminal-payout']
  : ['order-editing', 'stripe-terminal-payments', 'stripe-terminal-refunds']
console.log(`Runtime ${process.version}; ${frontend ? 'frontend' : 'backend'}; ${files.length} files`)
let failed = 0
for (const name of files) {
  const file = `test/${name}.test.js`
  const bridged = !frontend && Number(process.versions.node.split('.')[0]) < 22 && ['order-editing', 'stripe-terminal-refunds'].includes(name)
  const args = bridged ? [path.join(__dirname, 'task-15-node18-real-nanoid.cjs'), file] : [file]
  const result = spawnSync(process.execPath, args, { encoding: 'utf8', env: process.env })
  console.log(`FILE ${name}; realNanoidBridge=${bridged}\n${result.stdout || ''}${result.stderr || ''}NATIVE_EXIT=${result.status}`)
  if (result.status !== 0) failed++
}
console.log(`RESULT ${files.length - failed}/${files.length}; failed=${failed}`)
process.exitCode = failed ? 1 : 0
