### Spec Compliance

- Spec compliant for Task4. The binding settlement ruling is implemented: delivery settlement preserves accepted discounts, rejects new inline/group discounts, includes the fee, and keeps preparation and logistics separate (`B/src/helpers/cashRegisterPayment.js:47`, `B/src/services/stripeTerminalPayments.js:289`, `B/src/modules/m_orders.js:424`). All eleven brief-listed files have corresponding changes.
- Reviewed package: BASE `739f9dd24100ce387f6651e412df088c60867c03`, HEAD `c9c41c22b09b52eb5e7c5e42c47ab4e0ada350b8`. Read the brief first, the complete author report including the final stale-attempt amendment, integration notes, worker context, common contracts, and specification sections 3/5/6/7/10.

### Strengths

- The live transactional archive path validates preparation and payment, preserves delivery/customer/fulfillment links and accepted financial fields, copies product VAT/customization snapshots, records durable preparation, and deletes active data within one transaction (`B/src/modules/m_orders.js:190`, `B/src/modules/m_orders.js:424`, `B/src/modules/m_orders.js:502`, `B/src/modules/m_orders.js:516`, `B/src/modules/m_orders.js:553`). Kitchen-only archive cannot silently collect an unpaid delivery.
- Payment resolution uses shop plus original order ID; only internal archive updates use the archive PK. Webhook success returns before stock settlement for an already-paid representation, and refund reconciliation retains the commercial/payment identity (`B/src/modules/m_deliveryOrders.js:26`, `B/src/modules/m_payments.js:579`, `B/src/modules/m_payments.js:1280`). The existing active refund JOIN is preserved before archive fallback (`B/src/modules/m_payments.js:147`).
- Commercial-before-dossier locking composes with Task3. The charge snapshot also receives a current locking read, preventing the identity pre-read's repeatable-read snapshot from hiding a revision committed during a lock wait (`B/src/modules/m_deliveryOrders.js:78`). Terminal retains sorted order locks before the payment session, adds archive fallback, and acquires no dossier lock (`B/src/modules/m_stripeTerminal.js:491`).
- Manual collection locks and rechecks the current commercial representation, accepted financial snapshot, provider state, and pending Terminal allocation before its conditional update (`B/src/modules/m_orders.js:1316`). Terminal allocation stays at the accepted grand total; archive bypasses product-discount redistribution for delivery (`B/src/modules/m_orders.js:464`, `B/src/modules/m_stripeTerminal.js:515`).
- Payment start consults current commercial state instead of frozen checkout replay. The actual exported replacement service wires the array-returning resolver and rejects changed attempt tokens, attached intents, amounts, paid state, or archive state before provider access (`B/src/controllers/c_stripe.js:215`, `B/src/controllers/c_stripe.js:366`, `B/src/controllers/c_stripe.js:481`).
- New SQL tests exercise production modules/controllers, real transactions and observed SQL waits; provider boundaries are substituted. They include rollback after active deletion, exact BIGINT strings through a production-style driver configuration, duplicate actual web/Terminal handlers after archive, and fee-inclusive 2400-cent refunds (`B/test/delivery-archive-payments.integration.test.js:1`). Registration is explicit in the existing disposable SQL script (`B/package.json:8`).

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- None.

#### Minor (Nice to Have)

- None.

### Focused Checks

- Read the supplied diff once, in consecutive segments. No Git command, subagent, suite rerun, provider call, environment/deployment change, or source/index/HEAD mutation was performed. The only write is this authorized scratch report. `workspace_fs` was unavailable; shell reads follow the worker-context exception for paired worktrees.
- Expanded changed-source hunks only where function bodies were cut: `m_orders` archive discount/copy/delete/export wiring; `c_stripe.buildRegenerateOrderPaymentIntent`; `m_payments` success/replacement/refund flows; `m_stripeTerminal.lockOrderRefund/saveOrderRefund`; `m_deliveryOrders.toDeliveryView`; and the cash-register payment helper's normalization boundary. These establish preserved snapshots, early replay returns, attachment guards, refund targets, remaining-due projection, and payment-method behavior.
- Named cross-file risk: Task3 amendment could reverse commercial/dossier locks. Checked `B/src/modules/m_orderEditing.js:492` and its locked resolver call at `:503`; they acquire the commercial row first, matching Task4. Archive retains shop -> commercial -> dossier, while Terminal never waits for a dossier (`B/src/modules/m_orders.js:414`, `B/src/modules/m_stripeTerminal.js:491`).
- Named cross-file risk: Task3's immediate post-amendment producer omits `delivery_id`. Checked its actual bare object and regeneration call (`B/src/controllers/c_orderEditing.js:226`); production resolver wiring detects delivery from current state before provider access (`B/src/controllers/c_stripe.js:366`, `B/src/controllers/c_stripe.js:481`). The author-added regression invokes that exported service rather than only an injectable marker-present builder.
- Named cross-file risk: the new archive resolver requires a promise connection when called from Terminal. Checked the Terminal controller construction sites (`B/src/controllers/c_stripeTerminal.js:11`, `:20`, `:42`, `:71`, `:82`) and webhook construction (`B/src/controllers/c_stripe.js:50`); production uses `dbPool`/transaction connections. No callback-only production callsite was found in this focused check.
- Named scalar compatibility check: GET_LOCK/RELEASE_LOCK comparisons accept the driver's numeric and string 0/1 values while null/unknown acquisition or release results still prevent unsafe connection reuse (`B/src/modules/m_stripeTerminal.js:41`, `B/src/modules/m_stripeTerminal.js:67`, `B/src/modules/m_stripeTerminal.js:109`). The change preserves the named-lock lifecycle; it is not a fabricated lock-count assertion.

### Validation Evidence And Limits

- Execution results are author evidence, not new reviewer runs: final complete thirteen-scenario SQL file on Node18 with the fixture-local real Nano ID bridge; native Node22 registered SQL run before the bounded final amendments plus affected final focused runs; and passing coverage of all 62 legacy files across the initial invocation and recorded continuations (`task-4-report.md`, including its final amendment).
- The original `npm.cmd test` exited 1. Subsequent affected-file runs and unrun suffixes passed; this review does not represent them as one full invocation exiting 0. Recorded early packet warnings disappeared from passing runs; the Node18 `buffer.File` warning is an existing runtime warning, not a newly introduced Task4 defect.
- Plain unbridged Node18 legacy `require(nanoid)` remains a known pre-existing limitation. The configured Docker Node20.20.2 narrow unbridged load probe is not a full application smoke test; that commissioning check remains Task17. No live provider or recipient validation is claimed. Task2 signer preflight and Tasks5/6/7/12/15/16 functionality are outside this Task4 gate.

### Assessment

**Task quality:** Approved.

**Reasoning:** No Critical, Important, or Minor issue found in the reviewed change and focused integration checks. The implementation satisfies the Task4 settlement/archive contract while preserving the existing non-delivery paths and keeping payment authority in commercial/payment records.
